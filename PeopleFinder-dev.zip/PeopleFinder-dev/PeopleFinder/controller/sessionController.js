const express = require('express');
const sessionService=require('../service/authService.js');
//const appMiddleware =  require('../middleware/appMiddleware');
//const elasticSearchMiddleware =  require('../middleware/elasticSearchMiddleware');
const sessionController = express.Router();

//sessionController.get('/session/renew',sessionService.sessionExtend);

module.exports = sessionController;