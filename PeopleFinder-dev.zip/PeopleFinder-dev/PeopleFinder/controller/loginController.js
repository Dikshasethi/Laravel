var express = require('express');
var loginApi=require('../service/loginapi.js');

var logincontroller = express.Router();
//logincontroller.post('/loginold',loginApi.authenticateold);
//logincontroller.post('/sso',loginApi.ssoAuthentication);
logincontroller.post('/login',loginApi.authenticate);

module.exports = logincontroller;
 
