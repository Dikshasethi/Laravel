var express = require('express');
var sendmailApi =require('../service/send-email.js');
//var appMiddleware = require('../middleware/appMiddleware');

var sendmailController = express.Router();
sendmailController.post('/sendemail', sendmailApi.sendEmail);

module.exports = sendmailController;
 
