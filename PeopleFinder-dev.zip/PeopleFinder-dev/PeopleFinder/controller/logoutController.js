var express = require('express');
const authService = require('../service/authService');

var logoutcontroller = express.Router();
logoutcontroller.get('/logout',authService.logout);

module.exports = logoutcontroller;
 
