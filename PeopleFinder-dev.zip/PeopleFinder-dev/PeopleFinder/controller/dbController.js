var express = require('express');
var set = require('../service/setfavapi.js');
var fav = require('../service/fetchfavapi.js');
var levals = require('../service/fetchlabelsapi.js');
var deletefav = require('../service/deletefavapi.js');
var deletelavel = require('../service/deletelabelapi.js');
var renamelavel = require('../service/renamelabelapi.js');
//const appMiddleware = require('../middleware/appMiddleware');
//const empServiceMiddleware = require('../middleware/empServiceMiddleware');

var mydbcontroller = express.Router();
mydbcontroller.post('/save', set.saveempfavreco);
mydbcontroller.post('/fetch/fav', fav.fetchempfavreco);
mydbcontroller.post('/fetch/labels', levals.fetchemplevalsreco);
mydbcontroller.post('/delete/fav', deletefav.deleteempfavreco);
mydbcontroller.post('/delete/label', deletelavel.deleteemplavelreco);
mydbcontroller.post('/rename/label', renamelavel.renameemplavel);

module.exports = mydbcontroller;


