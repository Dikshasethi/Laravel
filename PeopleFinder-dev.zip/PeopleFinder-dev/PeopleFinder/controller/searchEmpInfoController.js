var express = require('express');
var searchEmpInfoApi = require('../service/emp-search.js');
var empImgService = require('../service/emp-image.js');
var getEmpOrgChrt = require('../service/emp-orgchart');
const appMiddleware = require('../middleware/appMiddleware');
const elasticSearchMiddleware = require('../middleware/elasticSearchMiddleware');
const empServiceMiddleware = require('../middleware/empServiceMiddleware');
const hasMsalCookie = require('../middleware/hasMsalCookie')
const hasMsalAccessToken = require('../middleware/hasMsalAccessToken')
const sessionValidator = require('../middleware/sessionValidator')


var searchEmpInfoController = express.Router();
searchEmpInfoController.post('/searchempinfo', hasMsalCookie, hasMsalAccessToken,sessionValidator, searchEmpInfoApi.getEmpInfo);
//searchEmpInfoController.post('/searchempinfo', appMiddleware, elasticSearchMiddleware, searchEmpInfoApi.getEmpInfo);
//searchEmpInfoController.post('/getEmpImage', hasMsalCookie, hasMsalAccessToken,sessionValidator, empImgService.getEmpImage);
searchEmpInfoController.post('/getEmpOrgChart', hasMsalCookie, hasMsalAccessToken,sessionValidator, getEmpOrgChrt.getEmpOrgChart);
searchEmpInfoController.post('/updateEmpImage', empImgService.updateEmpImage);
searchEmpInfoController.post('/getEmpImageByEmpId', empImgService.getEmpImageByEmpId);
module.exports = searchEmpInfoController;