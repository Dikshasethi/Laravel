var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const postEmpServiceRequest = require('../utils/fetch/postEmpServiceRequest');
const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');


module.exports = {
    similarDashboard
}

async function similarDashboard (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	data = {
        "empid": reqBody.empid ? reqBody.empid : '' ,
        "page" : parseInt(reqBody.page),
		"items" : parseInt(reqBody.items),
		"keycode" :  reqBody.keycode ? reqBody.keycode : 0 ,
	},
	emp_data_ms_url = properties.get('mongo.employeedata_ms_url');
	
	if (emp_data_ms_url.lastIndexOf('/') == emp_data_ms_url.length - 1) {
		emp_data_ms_url = emp_data_ms_url + 'api/employeedata/similarDashboard';
	} else {
		emp_data_ms_url = emp_data_ms_url + '/api/employeedata/similarDashboard';
	}
	details = await postEmpServiceRequest(emp_data_ms_url, data, req);
	if (details.statusCode == 401) {
		res.status(401).send({ result: 'Not Authorized' })
	} else{
		return res.json(details);
    }
}

