

var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const postEmpServiceRequest = require('../utils/fetch/postEmpServiceRequest');
const moment = require('moment');
// var emphiredate=require('../service/empaniversery.js');
// const appMiddleware =  require('../middleware/appMiddleware');

// var hireDatecontroller = express.Router();
// hireDatecontroller.post('/getEmployees', appMiddleware, emphiredate.getEmpHireInfo);
// module.exports = hireDatecontroller;
module.exports = {
    GetWorkAniversaries
}

async function GetWorkAniversaries (req, res) {
	var employeedata_ms_url = properties.get('mongo.employeedata_ms_url');
	
	if (employeedata_ms_url.lastIndexOf('/') == employeedata_ms_url.length - 1) {
		employeedata_ms_url = employeedata_ms_url + 'api/employeedata/getWorkAniversaries';
	} else {
		employeedata_ms_url = employeedata_ms_url + '/api/employeedata/getWorkAniversaries';
	}
    let data ={
	dateTime:  moment(Date.now()).format('YYYY-MM-DD')
	}; //If we have to send the data  from Frontend.

	
	if(req.session.user && req.session.user.access_token)
	{
		req.headers.access_token=req.session.user.access_token;
	}
 
   const details = await postEmpServiceRequest(employeedata_ms_url, data, req);

	
	if (details.statusCode == 401) {
		res.status(401).send({ result: 'Not Authorized' })
	} else{
		return res.json(details);
    }
}
 
