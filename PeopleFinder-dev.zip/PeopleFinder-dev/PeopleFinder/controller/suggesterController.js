var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');

const postEmpServiceRequest = require('../utils/fetch/postEmpServiceRequest');

const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');

module.exports = {
	fetchSuggester ,
	countrySuggester
}

async function fetchSuggester (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	data = {
        "keycode": reqBody.keycode ? reqBody.keycode : 0 ,
        "value" : reqBody.value,
        "page" : reqBody.page ,
        "limit" : reqBody.limit
	};
	var fetchSuggesterUrl = properties.get('mongo.employeedata_ms_url');


	if (fetchSuggesterUrl.lastIndexOf('/') == fetchSuggesterUrl.length - 1) {
		fetchSuggesterUrl = fetchSuggesterUrl + 'api/employeedata/suggestion';
	} else {
		fetchSuggesterUrl = fetchSuggesterUrl + '/api/employeedata/suggestion';
	}
	details = await postEmpServiceRequest(fetchSuggesterUrl, data, req);
	if (details.statusCode == 401) {
		res.status(401).send({ result: 'Not Authorized' })
	} else
		return res.json(details);
}
/**
 * 
 * @param {value} req suggester comes against value
 * @param {*} res we send countries in response if value match
 */
async function countrySuggester( req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	data = {
        "value" : reqBody.value,
	};
	var fetchSuggesterUrl = properties.get('mongo.employeedata_ms_url');
	if (fetchSuggesterUrl.lastIndexOf('/') == fetchSuggesterUrl.length - 1) {
		fetchSuggesterUrl = fetchSuggesterUrl + 'api/employeedata/getcountries';
	} else {
		fetchSuggesterUrl = fetchSuggesterUrl + '/api/employeedata/getcountries';
	}
	details = await postEmpServiceRequest(fetchSuggesterUrl, data, req);
	if (details.statusCode == 401) {
		res.status(401).send({ result: 'Not Authorized' })
	} else
		return res.json(details);
}