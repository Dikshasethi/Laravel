var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');

const postEmpServiceRequest = require('../utils/fetch/postEmpServiceRequest');

const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');

module.exports = {
	getempimages ,
	uploadempimage,
	deleteempimage
}

async function getempimages (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	data = {
        "empIds": reqBody.empIds ? reqBody.empIds : 0 ,
	}; 
	var employeedata_ms_url = properties.get('mongo.employeedata_ms_url');


	if (employeedata_ms_url.lastIndexOf('/') == employeedata_ms_url.length - 1) {
		employeedata_ms_url = employeedata_ms_url + 'api/employeedata/getempimages';
	} else {
		employeedata_ms_url = employeedata_ms_url + '/api/employeedata/getempimages';
	}
	details = await postEmpServiceRequest(employeedata_ms_url, data, req);
	if (details.statusCode == 401) {
		res.status(401).send({ result: 'Not Authorized' })
	} else {
		return res.json(details);
	}
}
/**
 * 
 * @param {value} req suggester comes against value
 * @param {*} res we send countries in response if value match
 */
async function uploadempimage( req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	
	let data = {
		imageList : [{
			"category": "employee",
			"filetype": "image",
			"imageBase64": reqBody.base64Img ? reqBody.base64Img : '',
			"fileName": reqBody.firstname ? reqBody.firstname : '',
			"groupId": reqBody.empId ? reqBody.empId : '',
			"fileExtension": reqBody.imgType ? reqBody.imgType : '',
			"tags": [
				reqBody.firstname ? reqBody.firstname : reqBody.empName ,
				reqBody.lastname ? reqBody.lastname : '',
				reqBody.emailId ? reqBody.emailId : '',
				reqBody.empId ? reqBody.empId : ''
			]
		}],
		"appId": "PeopleFinder",
		"device": reqBody.device && reqBody.device === 'M' ? reqBody.device : 'website',
		"employeeid": reqBody.empId ? reqBody.empId : '',
		"uploader" : reqBody.empName ? reqBody.empName : ''
	}

	var employeedata_ms_url = properties.get('mongo.employeedata_ms_url');
	if (employeedata_ms_url.lastIndexOf('/') == employeedata_ms_url.length - 1) {
		employeedata_ms_url = employeedata_ms_url + 'api/employeedata/uploadempimage';
	} else {
		employeedata_ms_url = employeedata_ms_url + '/api/employeedata/uploadempimage';
	}
	details = await postEmpServiceRequest(employeedata_ms_url, data, req);
	if (details.statusCode == 401) {
		res.status(401).send({ result: 'Not Authorized' })
	} else
		return res.json(details);
}

async function deleteempimage(req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	data = {
		employeeid: reqBody.employeeid
	}; 
	var employeedata_ms_url = properties.get('mongo.employeedata_ms_url');


	if (employeedata_ms_url.lastIndexOf('/') == employeedata_ms_url.length - 1) {
		employeedata_ms_url = employeedata_ms_url + 'api/employeedata/deleteempimage';
	} else {
		employeedata_ms_url = employeedata_ms_url + '/api/employeedata/deleteempimage';
	}
	details = await postEmpServiceRequest(employeedata_ms_url, data, req);
	if (details.statusCode == 401) {
		res.status(401).send({ result: 'Not Authorized' })
	} else {
		return res.json(details);
	}
}