var express = require('express');
var saveApi=require('../service/update-record.js');
//const appMiddleware =  require('../middleware/appMiddleware');
//const elasticSearchMiddleware =  require('../middleware/elasticSearchMiddleware');
const hasMsalCookie = require('../middleware/hasMsalCookie')
const hasMsalAccessToken = require('../middleware/hasMsalAccessToken')
const sessionValidator = require('../middleware/sessionValidator')

var saveApiController = express.Router();
saveApiController.post('/updaterecord',hasMsalCookie, hasMsalAccessToken,sessionValidator,saveApi.updateRecords);
module.exports = saveApiController;
 
 