var http = require('http');
var https = require('https');
var fs = require('fs');
var constants = require('constants');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var session = require('express-session');
var login = require('./controller/loginController');
var logout = require('./controller/logoutController');
var search = require('./controller/searchEmpInfoController');
var save = require('./controller/saveApiController');
var sessionRenew = require('./controller/sessionController');
var path = require('path');
var cron = require('node-cron');
var cors = require('cors');
var PropertiesReader = require('properties-reader');
var prop = PropertiesReader('./config.properties');
var port = prop.get('nodeN.port');
 var mydbcontr = require('./controller/dbController');
 const cookieParser = require('cookie-parser')
// var emphireDate = require('./controller/hireDateController.js');
var sendEmail = require('./controller/sendmailController')
var httpflag = prop.get('nodeN.htts');
// ITTPPRD-1404  ITTPPRD-1538
var routes = require('./routes')
// ITTPPRD-1404 ITTPPRD-1538
let sessionOptions = {
  name: 'peoplefinder',
  secret: 'secret',
  cookie: { path: "/", secure: false, SameSite: true },
  saveUninitialized: false,
  resave: false
};

if (httpflag) {
  sessionOptions.cookie = { path: "/", secure: true, SameSite: true }
}

app.use(cors());
app.use(session(sessionOptions));

var jsonParser = bodyParser.json({ limit: '10mb', extended: true });
var urlencodedParser = bodyParser.urlencoded({ limit: '10mb', extended: true });
app.use(cookieParser())
app.use(urlencodedParser);
app.use(jsonParser);
app.use(express.static(path.join(__dirname, 'client/dist/peoplefinder')));
app.all('*', function (req, res, next) {
  if (req.headers.sso_user) {
    res.header('sso_user', req.headers.sso_user);
  }
  //res.header('sso_user', 'skashyap');
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'X-Requested-With');
  next();
});

app.use('/api/user', login);

app.use('/api/auth/session', logout);

app.use('/api/people', search);

app.use('/api/save', save);

app.use('/api/auth', sessionRenew);

app.use('/api/mydb', mydbcontr)

//app.use('/api/aniverseryDetail', emphireDate);

app.use('/api/email', sendEmail)
// ITTPPRD-1404 ITTPPRD-1538
app.use('/api', [ ...routes ] )
// ITTPPRD-1404 ITTPPRD-1538
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '/client/dist/peoplefinder/index.html'));
});


if (httpflag) {
  let options = {
    key: fs.readFileSync('../../certs/server.key'),
    cert: fs.readFileSync('../../certs/server.crt'),
    secureProtocol: 'TLSv1_2_method',
    secureOptions: constants.SSL_OP_NO_SSLv2 | constants.SSL_OP_NO_SSLv3 | constants.SSL_OP_NO_TLSv1 | constants.SSL_OP_NO_TLSv1_1,
    ciphers: [
      'TLS_AES_256_GCM_SHA384',
      'TLS_CHACHA20_POLY1305_SHA256',
      'TLS_AES_128_GCM_SHA256',
      'ECDHE-RSA-AES128-GCM-SHA256',
      'ECDHE-ECDSA-AES128-GCM-SHA256',
      'ECDHE-RSA-AES256-GCM-SHA384',
      'ECDHE-ECDSA-AES256-GCM-SHA384',
      'DHE-RSA-AES128-GCM-SHA256',
      'ECDHE-RSA-AES128-SHA256',
      'DHE-RSA-AES128-SHA256',
      'ECDHE-RSA-AES256-SHA384',
      'ECDHE-RSA-AES256-SHA384',
      'DHE-RSA-AES256-SHA256',
      'HIGH',
      '!aNULL',
      '!eNULL',
      '!EXPORT',
      '!DES',
      '!RC4',
      '!MD5',
      '!PSK',
      '!SRP',
      '!CAMELLIA',
    ].join(':'),
    honorCipherOrder: true
  }
  const httpsServer = https.createServer(options, app);
  httpsServer.listen(port, () => {
    console.log(`API running on https:localhost :${port}`)
   // logger.info("API running on localhost:" + port)
  })
} else {
  const usdprt = process.env.PORT || port;
  app.listen(usdprt, function () {
    console.log('CORS-enabled web server listening on port : ' + usdprt);
  })
}
