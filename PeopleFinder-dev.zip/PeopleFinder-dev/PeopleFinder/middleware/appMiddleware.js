// //@Author : nmehra
// let jwt = require('jsonwebtoken');
// var PropertiesReader = require('properties-reader');
// var properties = PropertiesReader('./config.properties');
// const appSecret = properties.get('Login.app-token-secret');
// const appExpiry = properties.get('Login.app-token-life');
// const moment = require('moment');

// module.exports = (req, res, next) => {
//     if (req.session && req.session.pplfinder) {
//         let token = req.session.pplfinder.jwtAppToken;

//         if (token) {
//             jwt.verify(token, appSecret, (err, decoded) => {
//                 req.session.pplfinder.state = "alive";
//                 if (err) {
//                     res.status(401).send("Unauthorized");
//                 } else {
//                     let now = moment(new Date());
//                     let expiration = moment.unix(req.session.pplfinder.jwtExpiryTime);
//                     let diff = expiration.diff(now);
//                     let diffDuration = moment.duration(diff);
//                     let min = diffDuration.asMinutes();
//                     if (min <= 1 && min > 0) {
//                         let userData = {
//                             userName: req.session.pplfinder.user
//                         }
//                         const token = jwt.sign(userData, appSecret, { expiresIn: appExpiry });
//                         req.session.pplfinder.jwtAppToken = token;
//                         req.session.pplfinder.jwtAppDuration = appExpiry;
//                         req.session.pplfinder.jwtExpiryTime = Math.floor(Date.now() / 1000) + req.session.pplfinder.jwtAppDuration;
//                         req.session.pplfinder.state = "extend";
//                     }
//                     next();
//                 }
//             });
//         } else {
//             res.status(401).send("Auth token is not supplied");
//         }
//     } 
//     else if(req.headers.authtoken!=undefined || req.headers.msalaccesstoken!=undefined)
//     {
//         next();
//     }
//     else {
//         res.status(401).send("Un-authorized");
//     }
// };

