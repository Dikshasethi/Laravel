
const validateAccessToken = require('../utils/msal/validateAccessToken');
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
let jwt = require('jsonwebtoken');
module.exports = async (req, res, next) => {
    try{
        const empjwtSecret = properties.get('Login.empjwtSecret');
        let msalaccesstoken = req.cookies['msalaccesstoken'];
        let authToken = req.cookies['authToken'];
        if(!msalaccesstoken || !authToken){
            return next();
        }
        let decoded = await jwt.verify(authToken, empjwtSecret);
        if(decoded){
            let response = await validateAccessToken(msalaccesstoken);
            if(response.error){
                res.status(401).send({ result: 'Not Authorized' })
            }
            else { 
                req.session.user = decoded;
                next();  
            }
        }else{
            res.status(401).send({ result: 'Not Authorized' })
        }
    }
    catch(e)
    {
        console.log("msalCookie validator catch block error", e);
        res.status(500).send({ result: 'Not Authorized' })
    }
}