// //@Author : nmehra
// const elasticSearchRegenrateToken = require('../utils/token/generateJWTToken');
// //let session = require('express-session');

// module.exports = async (req, res, next) => {
//   if (!req.session.pplfinder && !req.session.pplfinder.user) {
//     res.status(401).send("Unauthorized");
//   }
//   else {
//     if (Math.floor(Date.now() / 1000) > req.session.pplfinder.expiryTime) {
//       let tokenObject = await elasticSearchRegenrateToken(req.session);
//       if (tokenObject.error) {
//         return res.send(tokenObject);
//       } else {
//         return next();
//       }
//     } else {
//       next();
//     }
//   }
// }