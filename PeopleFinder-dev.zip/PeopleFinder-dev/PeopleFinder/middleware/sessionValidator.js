const validateAuthToken = require('../utils/token/validateAuthToken');
const isAuthorized = require('./isAuthorized');

module.exports = async (req, res, next) => {
    try {

        if(req.session.user){
            let authorized = await isAuthorized(req.session.user, req);
            if(authorized.pass){
                if(authorized.setSession){
                    const {
                        sessionData = {}
                    } = authorized;
                    req.session.user.empDataExpiry = sessionData.empDataExpiry;
                    req.session.user.token = sessionData.token;
                    req.session.user.access_token = authorized.newEsToken ? sessionData.generatedElastiSearchToken.access_token : sessionData.access_token;
                    req.session.user.expiryTime = authorized.newEsToken ? sessionData.generatedElastiSearchToken.expiryTime : sessionData.expiryTime;
                }
                return next();
            }else{
                res.status(401).send({ result:'Not Authorized' }) 
            }
        }else if(req.headers.authtoken){
            let header = {
                'authtoken': req.headers.authtoken
            };
            let tokenObject = await validateAuthToken(header);
            const {
                isAuthenticate = false,
                data = {}
            } = tokenObject;
            
            if(isAuthenticate){
                let authorized = await isAuthorized({
                    ...data,
                    authToken : req.headers['authtoken']
                }, req);
                if(authorized.pass){
                    if(authorized.setSession){
                        const {
                            sessionData = {}
                        } = authorized;
                        req.session.user = {};
                        req.session.user.empDataExpiry = sessionData.empDataExpiry;
                        req.session.user.token = sessionData.token;
                        req.session.user.access_token = authorized.newEsToken ? sessionData.generatedElastiSearchToken.access_token : sessionData.access_token;
                        req.session.user.expiryTime = authorized.newEsToken ? sessionData.generatedElastiSearchToken.expiryTime : sessionData.expiryTime;
                    }   
                    return next();
                }else{
                    res.status(401).send({ result: 'Not Authorized' })
                    
                }
            }else{
                if(tokenObject.error && tokenObject.error.message!='')
                {
                    res.status(401).send({ result: tokenObject.error.message })
                }
                else{
                    res.status(401).send({ result:'Not Authorized' })
                }
                
            }
        }else{
            res.status(500).send({ result: 'Not Authorized' })
        }
    }catch (error) {
        console.log("Session validator catch block error", error);
        logger.error(error);
        res.status(500).send({ result: 'Not Authorized' })
    }
}