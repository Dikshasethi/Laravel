const postRequest = require('../utils/fetch/postRequest');
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
module.exports = async (req, res, next) => {
    try{
        let emp_data_ms_url = properties.get('mongo.employeedata_ms_url');
        let accessToken = req.headers.msalaccesstoken;
        if(!accessToken || (
                req.session && 
                req.session.user && 
                Object.keys(req.session.user).length > 0
            )
        ){
            return next();
        }else{
            let reqHeader = {};
            reqHeader['msalaccesstoken'] = accessToken;
            let url = emp_data_ms_url+'/api/employeedata/generateToken';
            let response = await postRequest(url, {}, reqHeader);
            if(response.error){
                res.status(401).send({ result: 'Not Authorized' })
            }else{
                req.session.user = response;
                return next();
            }
        }
    }catch(e){
        console.log('hasMsalAccessToken catch block error', e);
        res.status(401).send({ result: 'Not Authorized' })
        // return res.send({
        //     error : {
        //         message : 'Not Authorized'
        //     }
        // })
    }
}