const generateAuthToken = require('../utils/token/regenerateAuthToken');
//const config = require('../config/config')();
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');

module.exports = async (loginData = {}, req) => {
    try {
        const {
            empDataExpiry = 0, 
            expiryTime = 0, 
            token = '',
            access_token = ''
        } = loginData;
        let currentTime = new Date().getTime() / 1000;    
        let tokenIsActive = currentTime <  empDataExpiry;
        if(tokenIsActive){
            let esTokenIsActive = currentTime < expiryTime;
                if(esTokenIsActive){
                    return {
                    pass : true,
                    setSession : true,
                    newEsToken : false,
                    sessionData : {
                        token,
                        empDataExpiry,
                        expiryTime,
                        access_token
                    }
                };
            }else{

                let app = properties.get('Login.app');
                let userSessionObject = req.session.user;
                let payload = { 'login': userSessionObject.login ? userSessionObject.login:userSessionObject.emp_username, 'userroles': userSessionObject.userroles,
                    'access_token': userSessionObject.access_token
                };
                let reqBody = { login: userSessionObject.login ? userSessionObject.login:userSessionObject.emp_username, app:app, payload: payload };
                let regeneratedTokenObject = await generateAuthToken(reqBody);
  
                 if(regeneratedTokenObject.error){
                     return {
                         pass : false
                     };
                }else{
                    return {
                        pass : true,
                        setSession : true,
                        newEsToken : true,
                        sessionData : regeneratedTokenObject
                    };
                }

            }
        }else{
            return {
                pass : false
            };
        }       
    } catch (error) {
        console.log('isAuthorized catch block error', error);
        logger.info('isAuthorized catch block error');
        logger.error(error.stack);
        return {
            pass : false
        };
    }    
}