// const generateEmpServiceToken = require('../utils/token/generateServicesToken')
// var PropertiesReader = require('properties-reader');
// var properties = PropertiesReader('./config.properties');
// const validateAuthToken = require('../utils/token/validateAuthToken');
// const moment = require('moment');
// let jwt = require('jsonwebtoken');
// module.exports = async (req, res, next) => {
//     if (req.session && req.session.empService) {
//         if(!req.session.empService && !req.session.empService.empServiceToken) {
//             res.status(401).send("Unauthorized");
//         }
//         else {
//             let now = moment(new Date());
//             let expiration = moment.unix(req.session.empService.expiryTime);
//             let diff = expiration.diff(now);
//             let diffDuration = moment.duration(diff);
//             let min = diffDuration.asMinutes();
//             if (min <= 1 && min > 0) {
//                 let header = {
//                     'authtoken': req.session.empService.empServiceToken
//                 };
//                 let  tokenObject= await validateAuthToken(header);
//                 const apiEndPoint = properties.get('mongo.employeedata_ms_url') + "/api/employeedata/generateToken"
//                 let empServiceObj = await generateEmpServiceToken(apiEndPoint, req.session, tokenObject.data.password)
//             }
//             next();
//         }
//     }
//     else{
//         res.status(401).send("Unauthorized");
//     }
// };

