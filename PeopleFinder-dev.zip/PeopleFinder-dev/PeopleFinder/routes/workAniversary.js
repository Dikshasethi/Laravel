var express = require('express');
const Router = express.Router();
//const appMiddleware = require('../middleware/appMiddleware');
//const empServiceMiddleware = require('../middleware/empServiceMiddleware');
const workAniversary = require('../controller/hireDateController')
const hasMsalCookie = require('../middleware/hasMsalCookie')
const hasMsalAccessToken = require('../middleware/hasMsalAccessToken')
const sessionValidator = require('../middleware/sessionValidator')

Router.post('/getWorkAniversaries', hasMsalCookie, hasMsalAccessToken,sessionValidator, workAniversary.GetWorkAniversaries);
module.exports = Router;