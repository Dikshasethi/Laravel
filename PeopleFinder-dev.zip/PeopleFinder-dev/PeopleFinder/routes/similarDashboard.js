const Router = require('express').Router()
//const appMiddleware = require('../middleware/appMiddleware');
//const empServiceMiddleware = require('../middleware/empServiceMiddleware');
const similarDashboard = require('../controller/similarDashboardController')

Router.post('/dashboard/similarDashboard',similarDashboard.similarDashboard)

module.exports = Router