const suggester = require('./suggester')
const similarDashboard = require('./similarDashboard')
const image = require('./image')
const workAniversary = require('./workAniversary')
module.exports =   [
    suggester,
    similarDashboard,
    image,
    workAniversary
]