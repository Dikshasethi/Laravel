const Router = require('express').Router();
//const appMiddleware = require('../middleware/appMiddleware');
//const empServiceMiddleware = require('../middleware/empServiceMiddleware');
const Suggester = require('../controller/suggesterController')

Router.post('/suggester/getSuggester', Suggester.fetchSuggester);
Router.post('/suggester/getCountrySuggester',  Suggester.countrySuggester);
module.exports = Router;