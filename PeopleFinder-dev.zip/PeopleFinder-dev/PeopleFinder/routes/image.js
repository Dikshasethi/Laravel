const Router = require('express').Router();
//const appMiddleware = require('../middleware/appMiddleware');
//const empServiceMiddleware = require('../middleware/empServiceMiddleware');
const ImageController = require('../controller/imageController')

Router.post('/image/getImages',  ImageController.getempimages);
Router.post('/image/uploadempimage', ImageController.uploadempimage);
Router.post('/image/deleteempimage', ImageController.deleteempimage);

module.exports = Router;