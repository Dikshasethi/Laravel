var soap = require('soap');
var fetch = require('node-fetch');
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
var dateFormat = require('dateformat');
const generateJWTToken = require('../utils/token/generateJWTToken');
const generateEmpServiceToken = require('../utils/token/generateServicesToken')
const logger = require('../logger/logger');
const jwt = require('jsonwebtoken');
const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');
const mdsPostRequest = require('../utils/fetch/mdsPostRequest');

module.exports.authenticateold = async function (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	var url = properties.get('Login.url');
	if (!reqBody.user || !reqBody.password) {
		res.status(422).send({ result: 'user or password fields missing' })
	}
	var username = Buffer.from(reqBody.user, 'base64').toString();
	var password = Buffer.from(reqBody.password, 'base64').toString();
	const appSecret = properties.get('Login.app-token-secret');
	const appExpiry = properties.get('Login.app-token-life');
	var args = {
		user: username,
		password: password
	};
	//	return new Promise((resolve,reject)=>{
	try {
		let response = await mdsPostRequest(url + '/Login', args);
		if (!response.error && response.NovellUser["diffgr:diffgram"]) {
			const { login: [login], employee_id: [employee_id], last_name: [last_name], first_name: [first_name] } = response.NovellUser["diffgr:diffgram"][0].NovellUser[0].Users[0];
			req.session.pplfinder = {};
			req.session.empService = {};
			req.session.pplfinder.user = username;
			req.session.empService.user = username;
			req.session.pplfinder.visited = dateFormat(new Date(), "isoDateTime");
			user = first_name + ' ' + last_name;
			let userData = {
				userName: username
			}
			const appToken = jwt.sign(userData, appSecret, { expiresIn: appExpiry });
			req.session.pplfinder.jwtAppToken = appToken;
			req.session.pplfinder.jwtAppDuration = appExpiry;
			req.session.pplfinder.jwtExpiryTime = Math.floor(Date.now() / 1000) + req.session.pplfinder.jwtAppDuration;
			req.session.pplfinder.state = "alive";
			// end

			let tokenObject = await generateJWTToken(req.session);
			req.session.empService = {};
			req.session.empService.user = username;
			const apiEndPoint = properties.get('mongo.employeedata_ms_url') + "/api/employeedata/generateToken"
			let empServiceObj = await generateEmpServiceToken(apiEndPoint, req.session)

			if (req.session.pplfinder.EWLJ != undefined && req.session.empService.empServiceToken != undefined) {
				res.json({ 'result': 'authorized', 'emp_name': user, 'employee_id': employee_id, 'expiry': req.session.pplfinder.jwtExpiryTime, userroles: req.session.empService.userroles });
			} else {
				res.json({ 'result': 'unauthorized' });
			}
		} else {
			res.json({ 'result': 'unauthorized' });
		}
	} catch (err) {
		res.json({ 'result': 'err' });
	}
	res.end;
};

module.exports.ssoAuthentication = async function (req, res) {
	var url = properties.get('Login.url');
	var username = res.getHeaders()['sso_user'];
	const appSecret = properties.get('Login.app-token-secret');
	const appExpiry = properties.get('Login.app-token-life');
	var args = {
		userID: username
	};
	try {
		let response = await mdsPostRequest(url + '/GetUserInfo', args);
		if (!response.error && response.NovellUser["diffgr:diffgram"]) {
			const { login: [login], employee_id: [employee_id], last_name: [last_name], first_name: [first_name] } = response.NovellUser["diffgr:diffgram"][0].NovellUser[0].Users[0];
			req.session.pplfinder = {};
			req.session.empService = {};
			req.session.pplfinder.user = username;
			req.session.empService.user = username;
			req.session.pplfinder.visited = dateFormat(new Date(), "isoDateTime");
			user = first_name + ' ' + last_name;
			let userData = {
				userName: username
			}
			const appToken = jwt.sign(userData, appSecret, { expiresIn: appExpiry });
			req.session.pplfinder.jwtAppToken = appToken;
			req.session.pplfinder.jwtAppDuration = appExpiry;
			req.session.pplfinder.jwtExpiryTime = Math.floor(Date.now() / 1000) + req.session.pplfinder.jwtAppDuration;
			req.session.pplfinder.state = "alive";
			// end

			let tokenObject = await generateJWTToken(req.session);
			req.session.empService = {};
			req.session.empService.user = username;
			const apiEndPoint = properties.get('mongo.employeedata_ms_url') + "/api/employeedata/generateToken"
			let empServiceObj = await generateEmpServiceToken(apiEndPoint, req.session)

			if (req.session.pplfinder.EWLJ != undefined && req.session.empService.empServiceToken != undefined) {
				res.json({ 'result': 'authorized', 'emp_name': user, 'employee_id': employee_id, 'expiry': req.session.pplfinder.jwtExpiryTime, userroles: req.session.empService.userroles });
			} else {
				res.json({ 'result': 'unauthorized' });
			}
		} else {
			res.json({ 'result': 'unauthorized' });
		}
	} catch (err) {
		res.json({ 'result': 'err' });
	}
	res.end;
};

function isEmptyObject(obj) {
	for (var key in obj) {
		if (Object.prototype.hasOwnProperty.call(obj, key)) {
			return true;
		}
	}
	return false;
}

module.exports.authenticate = async (req, res) => {
    try{
		var url = properties.get('Login.url');
		let reqBody = recursiveSanitizer(req.body, sanitizer);
		const appSecret = properties.get('Login.app-token-secret');
		const appExpiry = properties.get('Login.app-token-life');
		let username='',password='';
		req.session.empService = {};
		req.session.pplfinder = {};
		if(reqBody && (reqBody.username!=undefined || reqBody.password!=undefined))
		{
			username = reqBody.username;
			password = reqBody.password;
			req.session.empService.user = username;
			
		}
		req.session.pplfinder.msalaccesstoken = req.headers.msalaccesstoken || req.cookies.msalaccesstoken;
		
		const apiEndPoint = properties.get('mongo.employeedata_ms_url') + "/api/employeedata/generateToken"
		let empServiceObj = await generateEmpServiceToken(apiEndPoint, req.session, password);
		if(reqBody && (reqBody.username!=undefined || reqBody.password!=undefined))
		{ req.session.user = empServiceObj; }
		username = empServiceObj.emp_username;
		req.session.pplfinder.user = username;
		req.session.empService.user = username;
		req.session.pplfinder.visited = dateFormat(new Date(), "isoDateTime");
		// let userData = {
		// 	userName: username
		// }
		var args = {
			userID: empServiceObj.emp_username
		};
		
		let response = await mdsPostRequest(url + '/GetUserInfo', args);
		
		// const appToken = jwt.sign(userData, appSecret, { expiresIn: appExpiry });
		// req.session.pplfinder.jwtAppToken = appToken;
		// req.session.pplfinder.jwtAppDuration = appExpiry;
		// req.session.pplfinder.jwtExpiryTime = Math.floor(Date.now() / 1000) + req.session.pplfinder.jwtAppDuration;
		// req.session.pplfinder.state = "alive";

		//let tokenObject = await generateJWTToken(req.session);

		if (!response.error && response.NovellUser["diffgr:diffgram"])
		{
			const { employee_id: [employee_id], last_name: [last_name], first_name: [first_name]} = response.NovellUser["diffgr:diffgram"][0].NovellUser[0].Users[0];
			user = first_name + ' ' + last_name;
			if (req.session.empService.empServiceToken != undefined)
			{
				res.json({ 'result': 'authorized', 'emp_username': username, 'empDataExpiry':empServiceObj.empDataExpiry,'token':empServiceObj.token,'access_token':empServiceObj.access_token,'expiryTime':empServiceObj.expiryTime,
				'emp_name': user ,'employee_id': employee_id, userroles: req.session.empService.userroles });
			} else {
				res.json({ 'result': 'unauthorized' });
			}
		}
		else {
			res.json({ 'result': 'unauthorized' });
		}
      
	} catch(e){
			console.log('loggedInUser catch block error', e);
			logger.info('loggedInUser catch block error');
			logger.error(e.stack);
			return res.send({
				error : {
					message : 'An error occured. Please try again'
				}
			});
		}
}
