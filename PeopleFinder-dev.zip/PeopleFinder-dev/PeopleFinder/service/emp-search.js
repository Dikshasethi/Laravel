var session = require('express-session');
const bodyParser = require('body-parser');
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const elasticSearchAddDetails = require('../utils/elasticSearch/elasticSearchAddDetails');
const generateJWTToken = require('../utils/token/generateJWTToken');
var dateFormat = require('dateformat');
const postRequest = require('../utils/fetch/postRequest');
const picasapirequest = require('../utils/fetch/picasapirequest');
const logger = require('../logger/logger');
const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');

module.exports.getEmpInfo = async function (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	var search_string = reqBody.search_string;
	var searchSelect = reqBody.searchSelect;
	var refindBy = reqBody.filter;
	var current_date = dateFormat(new Date(), "isoDateTime");
	//logger.info(" Date :: " + current_date + ' && ' + req.session.pplfinder.visited);
	var args = {
		"page_size": reqBody.pageSize,
		"from": reqBody.from,
		"app_name": properties.get('Login.app'),
		"aggs": [
			{
				"agg_type": "count",
				"agg_name": "empservicelinecount",
				"agg_field": "empserviceline"
			},
			{
				"agg_type": "count",
				"agg_name": "empjobfunctionCount",
				"agg_field": "empjobfunction"
			},
			{
				"agg_type": "count",
				"agg_name": "empjobsubfuncioncount",
				"agg_field": "empjobsubfuncion"
			},
			{
				"agg_type": "count",
				"agg_name": "LocationCount",
				"agg_field": ["empcity", "empcountry"]
			}
		]
	};

	//args["access_token"] = session.EWLJ;
	args = elasticSearchAddDetails(searchSelect, search_string, args, refindBy);
	searchEmpInfo(args, req, res);


};

const searchEmpInfo = async (data, req, res) => {
	var empsearchurl = properties.get('Elastic-Search.search-url');
	let reqHeader = {};
	if(req.session && req.session.pplfinder && req.session.pplfinder.EWLJ)
	{
		reqHeader['EWLJToken'] = req.session.pplfinder.EWLJ;
	}else 
	{
		reqHeader['EWLJToken'] = req.session.user.access_token;
	}
	
	searchDetail = await postRequest(empsearchurl, data, reqHeader);
	return res.json(searchDetail);
}

