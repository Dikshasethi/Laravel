const logger = require('../logger/logger');
const PropertiesReader = require('properties-reader');
const properties = PropertiesReader('./config.properties');
const postEmpServiceRequest = require('../utils/fetch/postEmpServiceRequest');
//let session = require('express-session');

module.exports.logout = async (req, res) => {
    try {
        let logoutResponse={};
        if(req.session.user){
            let url =  properties.get('mongo.employeedata_ms_url') + '/api/employeedata/revokeUser';
            let access_token = req.session.user.access_token;
            let dataObj = { access_token };
            logoutResponse = await postEmpServiceRequest(url, dataObj, req);
            req.session.destroy();
        }
        return res.send({message:"logout success!",logoutResponse:logoutResponse});
    }
    catch (err) {
        logger.error(err.stack)
    }
}


module.exports.sessionExtend =  (req,res) =>{
    if(req.session.pplfinder && req.session.pplfinder.state){
        res.json({state:req.session.pplfinder.state,newExpiry:req.session.pplfinder.jwtExpiryTime});
    }
    else{
        res.status(401).send("Unauthorized");
    }
}