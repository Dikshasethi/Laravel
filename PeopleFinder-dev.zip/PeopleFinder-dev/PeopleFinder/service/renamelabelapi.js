var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const postRequest = require('../utils/fetch/postRequest');
const postEmpServiceRequest = require('../utils/fetch/postEmpServiceRequest');

const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');

module.exports.renameemplavel = async function (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	data = {
		"labelfrom": reqBody.labelfrom,
		"labelto": reqBody.labelto,
		"empid": reqBody.empid
	};
	var renamelabelurl = properties.get('mongo.employeedata_ms_url');
	if (renamelabelurl.lastIndexOf('/') == renamelabelurl.length - 1) {
		renamelabelurl = renamelabelurl + 'api/employeedata/rename/label';

	} else {
		renamelabelurl = renamelabelurl + '/api/employeedata/rename/label';
	}
	let reqHeader = {};
	//reqHeader['EWLJToken'] = req.session.pplfinder.EWLJ;
	//	details = await postRequest(renamelabelurl, data, reqHeader);	
	details = await postEmpServiceRequest(renamelabelurl, data, req);
	if (details.statusCode == 401) {
		if(details.error && details.error.message!=''){
			res.status(401).send({ result: details.error.message })
		}else {
			res.status(401).send({ result: 'Not Authorized' })
		}
	}
	return res.json(details);
};