var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
//var sendTo = properties.get('contactEmail.email_id');
let soap = require("soap");
const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');


module.exports.sendEmail = function (req, res) {
    let reqBody = recursiveSanitizer(req.body, sanitizer);
    let sendTo = reqBody.toAddrs;
    var fromAddress = reqBody.fromAddress;
    var fromDisplayName = reqBody.fromDisplayName;
    var subject = reqBody.subject;
    var body = reqBody.body;
    if (subject.includes('anniversary')) {
        let fname = body.frstName;
        let job = body.designation;
        let ename = body.fullName;
        let compltdYrs = body.totalYrs;
        body = '<table width="100%" bgcolor="#1e3849" overflow-x:auto;><tr><th style="color: white;" width="100%" height="100"> Hi ' +
            fname + '<br/>In Appreciation & Recognition for <strong>' +
            compltdYrs + ' years</strong> of Dedicated Service at Oceaneering International.</th></tr><tr><th style="color:white;"><img style="border-radius: 10%;" width="30%" height="300" src="' + properties.get('work-anniversary.congrats-img-url') + '"/><br/>' +
            ename + '<br>' + job + '</th><tr><th style="color: white;">Sent from OII<a href="' + properties.get('work-anniversary.pplfinderhref') + '"> People Finder </a>Application</th></tr></table>';
    }
    try {
        const url = properties.get('contactEmail.send-mail-url');
        const sendmailflag = properties.get('contactEmail.send-mail-flag');
        if (sendmailflag) {
            soap.createClient(url, function (err, client) {
                if (err) {
                    res.send({ "status": "Failed" });
                }
                else {
                    try {
                        client.EmailClient.EmailClientSoap.SendEmail(
                            {
                                fromAddress: fromAddress, fromDisplayName: fromDisplayName,
                                toAddresses: [{ string: sendTo }], subject: subject, body: body, isBodyHtml: true
                            }, async (err, response) => {
                                res.send({ "status": "Success" });
                            })
                    } catch (err) {
                    }
                }
            });
        } else {
            res.send({ "status": "error" });
        }
    } catch (err) {
    }
}
