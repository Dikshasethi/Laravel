var fetch = require('node-fetch');
//var session = require('express-session');
const bodyParser = require('body-parser');
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
var dateFormat = require('dateformat');
const generateJWTToken = require('../utils/token/generateJWTToken');
const savePeopleDetail = require('../utils/wsapi/savePeopleDetail');
const logger = require('../logger/logger');
const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');

module.exports.updateRecords = async function (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);

	try {
		var eswdocument = reqBody.eswdocument;
		var wsapicontent = reqBody.wsapicontent;

		var current_date = dateFormat(new Date(), "isoDateTime");
		// timeDifference = (Math.abs(new Date(current_date).getTime() - new Date(session.visited).getTime())/(1000 * 3600));
		// timeDifference2 = (Math.abs(new Date(current_date).getTime() - new Date(session.visited).getTime())/(1000 ));
		var args = {
			"app_name": properties.get('Login.app'),
			"document": eswdocument
		};
		// if(timeDifference2 >= session.timeout || session.EWLJ == undefined ){
		// 	  await generateJWTToken(req.body.user);
		// }
		//args["access_token"] = session.EWLJ;
		await savePeopleDetail(args, wsapicontent, req, res);
		var timeDifference2 = (Math.abs(new Date(dateFormat(new Date(), "isoDateTime")).getTime() - new Date(current_date).getTime()) / (1000));
		logger.info('Total time taken while saving the records api : ' + timeDifference2);
	} catch (err) {
		logger.error('Exception while calling update api please check vpn connection.');
		res.send({ 'result': 'err' });
	}

};