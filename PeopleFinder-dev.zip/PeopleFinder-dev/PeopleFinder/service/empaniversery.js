var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
var dateFormat = require('dateformat');
const postRequest = require('../utils/fetch/postRequest');
const logger = require('../logger/logger');
var dateFormat = require('dateformat');
var _ = require('underscore');

module.exports.getEmpHireInfo = async function (req, res) {
	var arr = [];

	/**
	 * @author Nitin Jadaun
	 * @description This code is commented due to work aniverisary elasticsearch issue
	 */
	/*
	var filter = {
		"page_size": 600,
		"refined_by": {
			"not": {
				"like": {
					"empbusinesstitle": {
						"value": "Contingent Worker.*",
						"boost": 1.2
					}
				}
			},	

			"script": "int datediff = " + dateFormat(new Date(), "yyyy") + " - doc.hiredate.date.getYear();return doc.hiredate.date.getMonthOfYear() == " + parseInt(dateFormat(new Date(), "mm")) + "&& doc.hiredate.date.getDayOfMonth() >=" + parseInt(dateFormat(new Date(), "dd")) +" && (datediff == 2 || datediff%5 == 0) && (doc.hiredate.date.getYear()!=" + dateFormat(new Date(), "yyyy") + ")"
		}
	}   
	var filter1	 =	{
		// "debug": true,
		"page_size": 10,
		"refined_by": {
			"not": {
				"like": {
					"empbusinesstitle": {
						"value": "Contingent Worker.*",
						"boost": 1.2
					}
				}
			},
			"hireDateMonth": 10,
			"range":[{
				"field": "hireDateDay", 
				"to": 13,
				"from": 1
			}],
			"script": "int yeardiff = 2020-doc.hiredate.date.getYear(); return yeardiff == 2 || yeardiff%5 == 0"
		}
	}

	let reqHeader = {};
	if (req.session.pplfinder.EWLJ != undefined) {
		reqHeader['EWLJToken'] = req.session.pplfinder.EWLJ;
	}
	
	details = await postRequest(properties.get('Elastic-Search.search-url'), filter1, reqHeader);

	if (details.data != undefined && details.data.hits != undefined && details.data.hits.hits.length > 0) {
		for (let i = 0; i < details.data.hits.hits.length; i++) {
			let timeDifference = Math.abs((new Date(dateFormat(new Date(), "yyyy-mm-dd"))).getTime() - (new Date(details.data.hits.hits[i]._source.hiredate)).getTime());
			let differentYears = Math.ceil(timeDifference / (1000 * 3600 * 24 * 365));
			if (differentYears % 5 == 0 || differentYears == 2) {
				arr.push({
					"_id": details.data.hits.hits[i]._id,
					"empjobfunction": details.data.hits.hits[i]._source.empbusinesstitle,
					"employeename": details.data.hits.hits[i]._source.employeename,
					"employeemail": details.data.hits.hits[i]._source.employeeemail,
					"appointedyears": differentYears
				});
			}
		}
		arr = _.sortBy(arr,"employeename")
	}
	*/
	return res.json(arr);
};