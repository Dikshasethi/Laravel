var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const postRequest = require('../utils/fetch/postRequest');
const postEmpServiceRequest = require('../utils/fetch/postEmpServiceRequest');
const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');
module.exports.fetchemplevalsreco = async function (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	data = {
		"label": reqBody.label,
		"labelto": reqBody.labelto,
		"empid": reqBody.empid
	};

	var fetchlabelurl = properties.get('mongo.employeedata_ms_url');


	if (fetchlabelurl.lastIndexOf('/') == fetchlabelurl.length - 1) {
		fetchlabelurl = fetchlabelurl + 'api/employeedata/fetch/labels';

	} else {
		fetchlabelurl = fetchlabelurl + '/api/employeedata/fetch/labels';
	}
	let reqHeader = {};
	//reqHeader['EWLJToken'] = req.session.pplfinder.EWLJ;
	//details = await postRequest(fetchlabelurl, data, reqHeader);
	details = await postEmpServiceRequest(fetchlabelurl, data, req);
	if (details.statusCode == 401) {
		if(details.error && details.error.message!=''){
			res.status(401).send({ result: details.error.message })
		}else {
			res.status(401).send({ result: 'Not Authorized' })
		}
	}

	return res.json(details);
};