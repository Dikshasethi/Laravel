var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const logger = require('../logger/logger');
const getRequest = require('../utils/fetch/getRequest');

module.exports.getEmpOrgChart = async function (req, res) {
    var empId = req.body.emp_Id;
    var args = {
        'username': properties.get('adeptia.username'),
        'password': properties.get('adeptia.password')
    }
    getOrgChartDetails(args, empId, req, res);
}

const getOrgChartDetails = async (data, id, req, res) => {
    var orgchartUrl = properties.get('org-chart.orgchart-url') + '?employeeid=' + id;
    logger.info(' orgchart Request : ', orgchartUrl);
    orgchartDetails = await getRequest(orgchartUrl, data);
    return res.json(orgchartDetails);
}