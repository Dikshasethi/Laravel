var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const postRequest = require('../utils/fetch/postRequest');
const postEmpServiceRequest = require('../utils/fetch/postEmpServiceRequest');
const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');

module.exports.deleteemplavelreco = async function (req, res) {
    let reqBody = recursiveSanitizer(req.body, sanitizer);
    data = {
        "label": reqBody.label,
        "empid": reqBody.empid,
        "employee": reqBody.employee
    };
    var deletelabelurl = properties.get('mongo.employeedata_ms_url');
    if (deletelabelurl.lastIndexOf('/') == deletelabelurl.length - 1) {
        deletelabelurl = deletelabelurl + 'api/employeedata/delete/label';

    } else {
        deletelabelurl = deletelabelurl + '/api/employeedata/delete/label';
    }
    let reqHeader = {};
   // reqHeader['EWLJToken'] = req.session.pplfinder.EWLJ;
    // details = await postRequest(deletelabelurl, data, reqHeader);	
    details = await postEmpServiceRequest(deletelabelurl, data, req);
    if (details.statusCode == 401) {
        if(details.error && details.error.message!=''){
			res.status(401).send({ result: details.error.message })
		}else {
			res.status(401).send({ result: 'Not Authorized' })
		}
    }
    return res.json(details);
};






