var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const postRequest = require('../utils/fetch/postRequest');
const postEmpServiceRequest = require('../utils/fetch/postEmpServiceRequest');
const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');

//------------ fetching images using google api
/* module.exports.getEmpImage = async function (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	let imageUrl = properties.get('google-photos.img-service-url');
	let data = {
		"email_id": reqBody.emailId
	}
	let reqHeader = {};
	if(req.session && req.session.pplfinder && req.session.pplfinder.EWLJ)
	{
		reqHeader['EWLJToken'] = req.session.pplfinder.EWLJ;
	}else 
	{
		reqHeader['EWLJToken'] = req.session.user.access_token;
	}
	
	empImage = await postRequest(imageUrl, data, reqHeader);
	return res.json(empImage);
}; */

//------------ fetching images using Mongo service
module.exports.getEmpImageByEmpId = async function (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	let baseUrl = properties.get('mongo.employeedata_ms_url');
	let getImageUrl = baseUrl + '/api/employeedata/getemployeesimages';
	let data = {
		"employeeids": reqBody.empIds
	}
	let reqHeader = {};
	//reqHeader['EWLJToken'] = req.session.pplfinder.EWLJ;
	empImages = await postEmpServiceRequest(getImageUrl, data, req);
	if (empImages.statusCode == 401) {
		res.status(401).send({ result: 'Not Authorized' })
	}

	return res.json(empImages);
};

//------------ change/remove employee profile image using mongo service
module.exports.updateEmpImage = async function (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	let baseUrl = properties.get('mongo.employeedata_ms_url');
	let updateImageUrl = baseUrl + '/api/employeedata/uploademployeeimage';
	let data = {
		"base64Image": reqBody.base64Img,
		"imageType": reqBody.imgType,
		"employeeid": reqBody.empId,
		"devicekey": "W",
		"emailid": reqBody.emailId,
		"user": reqBody.empName,
		"isDelete": reqBody.isDel
	}
	let reqHeader = {};
//	reqHeader['EWLJToken'] = req.session.pplfinder.EWLJ;
	//updateImgRes = await postRequest(updateImageUrl, data, reqHeader);
	updateImgRes = await postEmpServiceRequest(updateImageUrl, data, req);
	if (updateImgRes.statusCode == 401) {
		if(details.error && details.error.message!=''){
			res.status(401).send({ result: details.error.message })
		}else {
			res.status(401).send({ result: 'Not Authorized' })
		}
	}
	return res.json(updateImgRes);
}