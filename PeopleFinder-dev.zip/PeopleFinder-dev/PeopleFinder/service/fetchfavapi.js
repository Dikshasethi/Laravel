var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const postRequest = require('../utils/fetch/postRequest');
const postEmpServiceRequest = require('../utils/fetch/postEmpServiceRequest');

const sanitizer = require('sanitizer');
const { recursiveSanitizer } = require('../utils/sanitizer/sanitizerFunction');

module.exports.fetchempfavreco = async function (req, res) {
	let reqBody = recursiveSanitizer(req.body, sanitizer);
	data = {
		"empid": reqBody.empid
	};
	var fetchfavurl = properties.get('mongo.employeedata_ms_url');


	if (fetchfavurl.lastIndexOf('/') == fetchfavurl.length - 1) {

		fetchfavurl = fetchfavurl + '/api/employeedata/fetch/fav';

	} else {
		fetchfavurl = fetchfavurl + '/api/employeedata/fetch/fav';
	}

	/* let reqHeader = {};
    reqHeader['EWLJToken'] = req.session.pplfinder.EWLJ; */
	details = await postEmpServiceRequest(fetchfavurl, data, req);
	if (details.statusCode == 401) {
		if(details.error && details.error.message!=''){
			res.status(401).send({ result: details.error.message })
		}else {
			res.status(401).send({ result: 'Not Authorized' })
		}
		
	} else
		return res.json(details);
};
