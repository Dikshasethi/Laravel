import { Directive,ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appMoveToNextInput]'
})
export class MoveToNextInputDirective {
    obj : any = ["Comma","Semicolon"]
    angular: any;
    constructor(private _el: ElementRef) { }
    @HostListener('keyup', ['$event']) onKeyDown(e: any) { 
        if (this.obj.indexOf(e.code) !== -1) {
            e.preventDefault();
            e.srcElement.value= e.srcElement.value.slice(0,-1)
            let nextControl: any = e.srcElement.closest('.mat-form-field-appearance-outline').nextElementSibling;
            nextControl = nextControl.querySelector('.mat-input-element')
            if(nextControl !==null) {
                nextControl.focus();
            }
        }
    }
}
