import { MoveToNextInputDirective } from './move-to-next-input.directive';

describe('MoveToNextInputDirective', () => {
  it('should create an instance', () => {
    const directive = new MoveToNextInputDirective();
    expect(directive).toBeTruthy();
  });
});
