import { Injectable } from '@angular/core';
import { Observable  } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class SimilarDashboardService {

  API_URL = '/api/dashboard/similarDashboard'
  constructor( private http : HttpClient ) { }

  getSimilarDashboard( args ) : Observable<any> {
    return this.http.post(this.API_URL, args )
    .pipe( map( res => res ) )
  }
}
