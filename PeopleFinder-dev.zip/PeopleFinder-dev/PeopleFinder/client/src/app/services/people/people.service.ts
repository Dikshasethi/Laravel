
import { Injectable, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Ipeople } from '../people/people';
import { NgxSpinnerService } from 'ngx-spinner';
import { map } from 'rxjs/operators';
import { AuthenticationService } from '../auth.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class PeopleService {
  peoples: Ipeople[];
  globvarsearchselect: string;
  globvarsearchkey: string;
  serachpageval: string;

  getserachpageval() {
    return this.serachpageval;
  }

  setserachpageval(serachpageval) {
    this.serachpageval = serachpageval;
  }

  constructor(private http: HttpClient, private spinner: NgxSpinnerService, private router: Router, private authService: AuthenticationService) {

  }



  setglobalvar(globvarsearchselect, globvarsearchkey) {
    this.globvarsearchkey = globvarsearchkey;
    this.globvarsearchselect = globvarsearchselect;
  }
  getglobvar() {
    return this.globvarsearchselect + '~' + this.globvarsearchkey;
  }

  getProfile() {

    let obj = {
      from: 0,
      searchSelect: 'peoplefinder',
      search_string: "'" + JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + "'"
    }
    return this.http.post('/api/people/searchempinfo', obj)
      .pipe(map(res => res))

  }

  public getuserwithadv(from, keyword, searchselect, pageSize, filter): Promise<any> {
    return new Promise((resolve, reject) => {
      var obj = {
        search_string: keyword,
        searchSelect: searchselect,
        from: from,
        pageSize: pageSize
      }
      if (filter != undefined) {
        obj['filter'] = filter
      }
      this.http.post('/api/people/searchempinfo', obj).subscribe((response) => {
        resolve(response);
      }, (err) => {
        reject(err);
      });
    })
      .catch((err) => {
        throw err;
      });
  }

  public getEmpImage(emailId): Promise<any> {
    return new Promise((resolve, reject) => {
      var obj = {
        emailId: emailId
      }
      this.http.post('/api/people/getEmpImage', obj).subscribe((response) => {
        resolve(response);
      }, (err) => {
        this.spinner.hide();
        reject(err);
      });
    })
      .catch((err) => {
        throw err;
      });
  }

  public getEmpImageById(empIDs): Promise<any> {
    return new Promise((resolve, reject) => {
      var obj = {
        empIds: Array.isArray(empIDs) ? empIDs : [ empIDs ]
      }
      this.http.post('/api/image/getImages', obj).subscribe((response) => {
        resolve(response);
      }, (err) => {
        this.spinner.hide();
        reject(err);
      });
    }).catch((err) => {
      throw err;
    });
  }

  public updateEmpImage(base64String, emailid, empid, imgtype, user,firstname,lastname): Promise<any> {
    return new Promise((resolve, reject) => {
      var obj = {
        emailId: emailid,
        empId: empid,
        base64Img: base64String,
        imgType: imgtype,
        empName: user,
        firstname: firstname,
        lastname: lastname,
      }
      this.http.post('/api/image/uploadempimage', obj).subscribe((response) => {
        resolve(response);
      }, (err) => {
        reject(err);
      });
    }).catch((err) => {
      throw err;
    });
  }
public deleteEmpImage( employeeid : string) : Promise<any> {
  return new Promise((resolve, reject) => {
    let data = {
      employeeid,
    }
    return this.http.post('/api/image/deleteempimage',data).subscribe((response) => {
      resolve(response);
    }, (err) => {
      reject(err);
    });
  }).catch((err) => {
    throw err;
  });
}
  public getEmpOrgchart(empId): Promise<any> {
    return new Promise((resolve, reject) => {
      var obj = {
        emp_Id: empId
      }
      this.http.post('/api/people/getEmpOrgChart', obj).subscribe((response) => {
        resolve(response);
      }, (err) => {
        reject(err);
      });
    })
      .catch((err) => {
        throw err;
      });
  }

  savePeople(eswjson: object) {
    let obj = {
      user: eswjson['user'],
      eswdocument: eswjson['eswdocument'],
      wsapicontent: eswjson['wsapicontent']
    };
    return this.http.post('/api/save/updaterecord', obj).pipe(map(res => res))
  }

  public getrefineduser(from, keyword, searchselect, filter): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post('/api/people/searchempinfo', {
        searchSelect: searchselect,
        from: from,
        search_string: keyword,
        user: localStorage.getItem('isLoggedin'),
        filter
      }).subscribe((response) => {
        resolve(response);
      }, (err) => {
        reject(err);
      });
    })
      .catch((err) => {
        throw err;
      });
  }

  // save either fav or label
  public saveFavouriteOrLabel(profile_id, type, emp_id, label): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post('/api/mydb/save', {
        "empid": profile_id,
        "employee": emp_id,
        "type": type,
        "label": label
      })
        .subscribe((response) => {
          resolve(response);
        }, (err) => {
          reject(err);
        });
    })
      .catch((err) => {
        throw err;
      });
  }

  //delete favourite
  public deleteFav(profile_id, emp_id): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post('/api/mydb/delete/fav', {
        "empid": profile_id,
        "employee": emp_id
      })
        .subscribe((response) => {
          resolve(response);
        }, (err) => {
          reject(err);
        });
    })
      .catch((err) => {
        throw err;
      });
  }

  //fetch all favourite
  public fetchFavouriteData(emp_id): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post('/api/mydb/fetch/fav', {
        'empid': emp_id
      })
        .subscribe((response: any) => {
          if (response.error != undefined && response.error.code == 'ECONNREFUSED') {
            response = JSON.parse('{"empfavcollection": [],"empfavouriteslist": []}');
          }
          resolve(response);
        }, (err) => {
          reject(err);
        });
    })
      .catch((err) => {
        throw err;
      });
  }
  // fetch labels
  public fetchLabel(empid, label): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post('/api/mydb/fetch/labels', {
        'empid': empid,
        'label': label
      })
        .subscribe((Response) => {
          resolve(Response)
        }, (err) => {
          reject(err);
        })
    }).catch((err) => {
      throw err;
    });
  }

  //update label name  
  public updateLabel(empid, oldlabelname, newLabelName): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post('/api/mydb/rename/label', {
        'empid': empid,
        'labelto': newLabelName,
        'labelfrom': oldlabelname
      })
        .subscribe((Response) => {
          resolve(Response)
        }, (err) => {
          reject(err);
        })
    }).catch((err) => {
      throw err;
    });
  }

  //delete label name  
  public deleteLabelForEmployee(empid, employee, labelName): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post('/api/mydb/delete/label', {
        'empid': empid,
        'employee': employee,
        'label': labelName
      })
        .subscribe((Response) => {
          resolve(Response)
        }, (err) => {
          reject(err);
        })
    }).catch((err) => {
      throw err;
    });
  }


  // delete label 
  public deleteLabel(empid, labelName): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post('/api/mydb/delete/label', {
        'empid': empid,
        'label': labelName
      })
        .subscribe((Response) => {
          resolve(Response)
        }, (err) => {
          reject(err);
        })
    }).catch((err) => {
      throw err;
    });
  }


  //send contact-HR Email 
  public sendeEmail(from: any, to: any, displayname: any, subject: any, body: any) {
    return this.http.post('/api/email/sendemail', {
      'fromAddress': from,
      'fromDisplayName': displayname,
      'subject': subject,
      'body': body,
      'toAddrs': to
    })
      .pipe(map(res => res))
  }
  //work Anniversary

  public workAnniversary() {
    return this.http.post('/api/getWorkAniversaries', "")
      .pipe(map(res => res))
  }
  public getSuggesters(data) {

    return this.http.post('/api/suggester/getSuggester',data)
      .pipe(map(res =>res))
  }
  public getCountrySuggesters(data) {
    return this.http.post('/api/suggester/getCountrySuggester', data)
      .pipe( map ( res => res ) )
  }
}