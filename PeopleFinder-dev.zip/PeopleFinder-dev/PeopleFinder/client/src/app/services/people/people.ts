export interface Ipeople {
    data: string;
    userid: number;
    emplocation: string;
    empjobfunction: string;
    empcommunities: string;
    employeeemail: string;
    // emppersonalcertifications: [];
    empsubserviceline: string;
    empjobsubfuncion: string;
    empfax: string;
    // empgoogleplusdetails: [];
    // emplinkedindetails: [];
    // empeducation: [];
    // empcountriesworked: [];
    // empexperiences: [];
    empspokenlanguage: string;
    empsuffix: string;
    // empinteresthobbies: [];
    // empaboutme: [];
    empoiispeeddial: string;
    empbusinessline: string;
    empcountry: string;
    emptradesassociation: string;
    empoibusnphone: string;
    empserviceline: string;
    employeename: string;
    checked: boolean;
}
