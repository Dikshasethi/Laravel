import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';
import { MsalService } from '@azure/msal-angular';
@Injectable({
  providedIn: 'root'
})

export class AuthenticationService {
  isAutoLogout = false;
  redirectUrl = '';
  resp: any;
  constructor(
      private http: HttpClient,
      private cookieservice:CookieService,
      private msalService: MsalService
    ) {
  }

  /**
   * logout 
   * 
   */
  logout() {
    // return <any>this.http.get("http://localhost:3002/api/auth/session/logout").pipe(map(data => {
    return <any>this.http.get("/api/auth/session/logout").pipe(map(data => {
      localStorage.clear();
      if (this.cookieservice.get('remember') == "false") {
        this.cookieservice.delete('password', '/');
      }
      this.cookieservice.delete('expiry','/');
      return data;
    }),
      catchError((err: HttpErrorResponse) => {
        return throwError(err.error);
      })

    );
  }
 
  sessionRenew(){
    return <any>this.http.get("/api/auth/session/renew").pipe(map(data => {
    // return <any>this.http.get("http://localhost:3002/api/auth/session/renew").pipe(map(data => {
      return data;
    }),
      catchError((err: HttpErrorResponse) => {
        return throwError(err.error);
      })

    );
  }
   /* Used for MSAL Logout*/
   removeMsalToken() {
    for (const key of Object.keys(localStorage)) {
      if (key.includes('"authority":') || key.includes('msal.')) {
        localStorage.removeItem(key);
      }
    }
  }

  getMSALTokenSilentguard() {
      var token= false;
        if (this.checkMsalSilent()) {
          const a = {
            scopes: [
              'user.read'
            ]
          };
          try {
            this.msalService.acquireTokenSilent(a).then((result) => {
              token= true;
            }).catch((reason) => {
              token= false;
            });
          } catch (err) {
            console.log(err);
            token= false;
          }
          token= true;
        } else {
          token= true;
        }
     return token;   
  }

  checkMsalSilent() {
      let flag = false;
      for (const key of Object.keys(localStorage)) {
        if (key.includes('"authority":')) {
  
          flag = true;
        }
      }
      return flag;
    }

    getMSALTokenSilent() {
      return new Promise((resolve, reject) => {
        if (this.checkMsalSilent()) {
          const a = {
            scopes: [
              'user.read'
            ]
          };
          try {
            this.msalService.acquireTokenSilent(a).then((result) => {
              resolve(result);
            }).catch((reason) => {
              reject(reason);
            });
          } catch (err) {
            reject(err);
          }
        } else {
          resolve('');
        }
      });
  
    }


    errorHandler(error: Response) {
      return throwError(error);
    }
  

}
