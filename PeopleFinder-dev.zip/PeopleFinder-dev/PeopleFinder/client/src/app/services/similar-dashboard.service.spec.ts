import { TestBed } from '@angular/core/testing';

import { SimilarDashboardService } from './similar-dashboard.service';

describe('SimilarDashboardService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SimilarDashboardService = TestBed.get(SimilarDashboardService);
    expect(service).toBeTruthy();
  });
});
