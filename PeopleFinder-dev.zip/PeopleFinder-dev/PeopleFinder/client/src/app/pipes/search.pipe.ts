import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  	transform(suggestionArr: any, searchValue: string) {
		if (!suggestionArr) {
			return [];
		}
		if (!searchValue) {
			return suggestionArr;
		}
		if (suggestionArr && searchValue) {
			return suggestionArr.filter(suggestion => {
				return suggestion.country.toLowerCase().includes(searchValue.toLowerCase());
			});
		}
  	}

}
