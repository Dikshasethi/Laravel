import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LandingComponent } from './components/landing/landing.component';
import { ProfileComponent } from './components/profile/profile.component';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { PagelayoutComponent } from './components/pagelayout/pagelayout.component';
import { PeopleComponent } from './components/people/people.component';
import { AuthGuard } from './guard/auth.guard';
import { CustomMsalGuard } from './guard/custom-msal.guard';
import { LabelComponent } from './components/label/label.component';
import { MsalGuard } from '@azure/msal-angular';
// const routes: Routes = [
//   {
//     path: '', component: LandingComponent,canActivate: [AuthGuard],
//     // path: '', component: LandingComponent,
//     children: [
//       { path: '', component: SearchComponent },
//       { path: 'search', component: SearchComponent },
//       { path: 'myprofile', component: ProfileComponent },
//       // { path: 'people/:name', component: PeoplesComponent },
//       { path: 'people', component: PeoplefinderComponent }
//       // { path: '**', component: PeoplesComponent }
//     ]
//   },
//   { path: 'login', component: LoginComponent },
//   { path: '**', component: LandingComponent},
//   // { path: '**', component: not-found },
// ];

const appRoutes: Routes = [

  {
    path: '',
    component: PagelayoutComponent,
    children: [
      { path: 'people', component: PeopleComponent, canActivate: [AuthGuard] },
      { path: 'login', component: LoginComponent },
      { path: 'landing', component: LandingComponent, canActivate: [AuthGuard,CustomMsalGuard,MsalGuard] },
      { path: 'myprofile', component: ProfileComponent, canActivate: [AuthGuard] },
      { path: 'mylabel', component: LabelComponent, canActivate: [AuthGuard] },
      { path: '', redirectTo: 'login', pathMatch: 'full' },

    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(
      appRoutes,
      // { enableTracing: false } // <-- debugging purposes only
    )
  ],
  declarations: []
})
export class AppRoutingModule { }
export const routingcomponent = [LandingComponent, LoginComponent, ProfileComponent, PeopleComponent];
