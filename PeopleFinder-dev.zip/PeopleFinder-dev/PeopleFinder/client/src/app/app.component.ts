// import { Component } from '@angular/core';
// import { NgxSpinnerService } from 'ngx-spinner';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })
// export class AppComponent {
//   title = 'peoplefinder';
//   constructor(private spinner : NgxSpinnerService) { };
// }

import * as moment from 'moment';
import { Component,AfterViewInit, OnDestroy } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { environment } from '../environments/environment';
import { MsalService, BroadcastService } from '@azure/msal-angular';
import { CookieService } from 'ngx-cookie-service';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { copyStyles } from '@angular/animations/browser/src/util';

declare var gtag;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements  OnDestroy {
  title = 'peoplefinder';
  updateLoading=false;
  authDurationRefrence : any = 0; 
  elastiDurationRefrence : any = 0; 
  userDetails: any = {};
  timeoutDetails : any = {}
  intervalTimer: any;
  _isTimeout : boolean = false;
  sesionStorageRefrence : any;
  timeoutHash : String = "";
  isLoggedIn : boolean = false
  chainRefresh : boolean = false;
  elastiRefresh : boolean = true;
  currentUser : String;
  remainingDuration : any;
  route: string;
  routeCacheSubscription : any;
  loginRouteString : String = '/login';
  userDetailsLoading=false;
  disableRefreshButton=false;
  refreshInAction=false;
  resp: any;
  loading = false;
  returnUrl: string;
  error = '';
  isfetch: boolean = false;
  isIframe = false;

//  constructor(private spinner : NgxSpinnerService) { };
  //constructor(private spinner : NgxSpinnerService){}
  constructor(private spinner : NgxSpinnerService, private router: Router,    private authService: MsalService,
    private broadcastService: BroadcastService,    private http: HttpClient,
    private cookieService: CookieService) {
    // ITTPPRD-1539
    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://www.googletagmanager.com/gtag/js?id=' + environment.gtmCode;
    document.head.prepend(script);
    // ITTPPRD-1539
    const navEndEvents = router.events.pipe(
      filter(event => event instanceof NavigationEnd),
    );
    navEndEvents.subscribe((event: NavigationEnd) => {
      gtag('config', environment.gtmCode, {
        'page_path': event.urlAfterRedirects
      });
    });
    window.addEventListener('focus', event => {
      this.checkAccount();
    });
  };

  ngOnInit() {
    this.checkAccount();
    if (localStorage.getItem('isLoggedin') || localStorage.getItem('isLoggedin') != null) {
      //this.validateMsalToken();
      this.initTimeCheckFunction();
      this.isfetch=true;
      this.userDetailsLoading=this.isfetch
    }
    else
    {
        this.isfetch=false;
        this.userDetailsLoading=this.isfetch
        this.logoutFunction();
    }
  }

  ngOnDestroy() {
    this.routeCacheSubscription.unsubscribe();
  }

  checkAccount = async () => {
    let loggedIn = !!this.authService.getAccount();
   // console.log(loggedIn);
    if(loggedIn){
      if(!this.userDetailsLoading && !this.refreshInAction){
       // console.log('refreshTokenFunction');
        this.refreshInAction = true;
        this.disableRefreshButton = true;
        this.refreshTokenFunction(); 
      }
    }else{
      this.isTimeOutCheck();
    }
  }

  msalLoginRedirect() {
    const a = {
      scopes: [
        'user.read'
      ]
    };
    try {
      this.authService.loginPopup(a);
    } catch (error) {
    }
  }


  refreshTokenFunction = async () => {
    let currentTime = Math.floor(Date.now()/1000);
    let authTokenExpirationTimeString = this.cookieService.get('authTokenExpiryTime');
    let authTokenExpirationTime = authTokenExpirationTimeString ? Number(authTokenExpirationTimeString) : currentTime;
    let auth_difference  = authTokenExpirationTime - currentTime;

  // let expiryTime: any = this.cookieService.get('authTokenExpiryTime');
  // console.log(moment.unix(expiryTime).toDate().getMinutes());
  // let now = moment(new Date());
  // let currentTime = Math.floor(Date.now()/1000);
  // console.log(moment.unix(currentTime).toDate().getMinutes());
  // console.log(now);
  // let expiration = moment.unix(expiryTime);

  // let diff = expiration.diff(now);
  // let diffDuration = moment.duration(diff);
  // let min = diffDuration.asMinutes();
    //console.log(currentTime);
   // console.log(authTokenExpirationTime);
    //console.log(auth_difference);
    let min = moment.unix(auth_difference).toDate().getMinutes();
    if(
      auth_difference <= 299
    ){
      try {
        this.authService.acquireTokenSilent({
          scopes: ["user.read"]
        }).then((token) => {
         //console.log('new token aaaaa')
          this.cookieService.set('msalaccesstoken', token.accessToken);
          this.cookieService.set('msalaccesstokenexpiration', `${new Date(token.expiresOn).getTime()}`);
          this.cookieService.set('authTokenExpiryTime', `${new Date(token.expiresOn).getTime() / 1000}`);
          this.validateMsalToken();
        }) .catch((error) => {
            if (error.errorCode === "consent_required" || error.errorCode === "interaction_required" || error.errorCode === "login_required") 
            {
              this.authService.acquireTokenPopup({
                scopes: ["user.read"]}).then(function (response) {
                  this.cookieService.set('msalaccesstoken', response.accessToken);
                  this.cookieService.set('msalaccesstokenexpiration', `${new Date(response.expiresOn).getTime()}`);
                  this.cookieService.set('expiry', `${new Date(response.expiresOn).getTime() / 1000}`);
                  this.validateMsalToken();

                }).catch(function (error) {
                    console.log(error);
                });
            }
          });
                
      } catch (err) {
       // console.log(err);
        this.removeMsalToken();
        this.msalLoginRedirect();
      }  
   // }; 
  }
    this.refreshInAction = false;
  }


  validateMsalToken() {
    this.spinner.show();
    try {
    let body={};
    this.http.post('/api/user/login',body)
      .subscribe(
      (res) => {
        this.resp = res;
        if (this.resp.result === 'authorized') {   
          this.spinner.hide();
    
          localStorage.setItem('isLoggedin', JSON.stringify(this.resp));
          localStorage.setItem('loggedinUser', this.resp.emp_username);
          this.cookieService.set('expiry', this.resp.expiry); 
          this.cookieService.set('authTokenExpiryTime',this.resp.empDataExpiry);
          this.cookieService.set('authToken', this.resp.token);
          this.router.navigate(['/landing']);
        } else if (this.resp.result === 'unauthorized') {
          this.error = 'Unauthorized';
          this.loading = false;
          this.spinner.hide();
        } else if (res === 'Error') {
          this.error = 'Something Went Wrong';
          this.loading = false;
        }
      },
      err => {
            this.error = 'none';
            this.error = 'Something Went Wrong';
            this.loading = false;
          }
        );
    } catch (error) {
    }
  }

  removeMsalToken() {
    for (const key of Object.keys(localStorage)) {
      if (key.includes('"authority":') || key.includes('msal.')) {
        localStorage.removeItem(key);
      }
    }
  }
  isTimeOutCheck(){    

    let expiryTime: any = this.cookieService.get('authTokenExpiryTime');
    let now = moment(new Date());
    let expiration = moment.unix(expiryTime);
    let diff = expiration.diff(now);
    let diffDuration = moment.duration(diff);
    let min = diffDuration.asMinutes();
   // console.log(min);
    if (min <= 0 ){
      this.logoutFunction();
    }else if(min <= 2){
        this.checkAccount();
    }
  }

  clearMsalCache = () => {
    this.cookieService.delete('msalaccesstoken');
    this.cookieService.delete('msalaccesstokenexpiration');
    this.cookieService.delete('authTokenExpiryTime');
    this.cookieService.delete('authToken');
  }


  logoutFunction(){
    clearInterval(this.intervalTimer);
    this.intervalTimer = undefined;
    localStorage.clear();
    this.clearMsalCache();
    //localStorage.removeItem('timeoutHash');
    this.router.navigate(['/login']);
  }

  initTimeCheckFunction = () => {
    if(!this.intervalTimer){
      this.intervalTimer = setInterval(() =>{ 
        this.isTimeOutCheck();
      }, 1000);
    }
  }

  refreshSession(){
    this.checkAccount();
  }
  
}
