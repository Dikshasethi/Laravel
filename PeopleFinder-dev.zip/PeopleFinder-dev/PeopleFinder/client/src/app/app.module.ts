import { BrowserModule } from '@angular/platform-browser';
import { ImageCropperModule } from 'ngx-image-cropper';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatSidenavModule } from '@angular/material/sidenav';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule, MatButtonModule, MatIconModule, MatListModule, MatAutocompleteModule } from '@angular/material';
import { MatMenuModule } from '@angular/material/menu';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { AppRoutingModule } from './app-routing.module';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { HeaderComponent } from './components/header/header.component';
import { AuthGuard } from './guard/auth.guard';
import { FooterComponent } from './components/footer/footer.component';
import { LandingComponent } from './components/landing/landing.component';
import { LoginComponent } from './components/login/login.component';
import { MatDialogModule, MatTableModule, MatProgressSpinnerModule } from '@angular/material';
import { ProfileComponent } from './components/profile/profile.component';
import { HttpClientModule } from '@angular/common/http';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { NgxSpinnerModule } from 'ngx-spinner';
import { CookieService } from 'ngx-cookie-service';
import { SnotifyModule, SnotifyService, ToastDefaults } from '../../node_modules/ng-snotify';
import { PagelayoutComponent } from './components/pagelayout/pagelayout.component';
import { SearchFieldComponent } from './components/search-field/search-field.component';
import { SearchFieldLandingComponent } from './components/search-field-landing/search-field-landing.component';
import { RefinedByComponent } from './components/refined-by/refined-by.component';
import { PeopleComponent } from './components/people/people.component';
import { PeopleListComponent } from './components/people-list/people-list.component';
import { SearchInfoComponent } from './components/search-info/search-info.component';
import { SpLangComponent } from './components/myprofilepopus/sp-lang/sp-lang.component';
import { NetworksComponent } from './components/myprofilepopus/networks/networks.component';
import { ExperianceComponent } from './components/myprofilepopus/experiance/experiance.component';
import { IntrHobbiesComponent } from './components/myprofilepopus/intr-hobbies/intr-hobbies.component';
import { EducationComponent } from './components/myprofilepopus/education/education.component';
import { CompworkedComponent } from './components/myprofilepopus/compworked/compworked.component';
import { CertificateComponent } from './components/myprofilepopus/certificate/certificate.component';
import { TradeComponent } from './components/myprofilepopus/trade/trade.component';
import { CommunitesComponent } from './components/myprofilepopus/communites/communites.component';
import { AboutMeComponent } from './components/myprofilepopus/askmeabt/askmeabt.component';
import { AlPhoneComponent } from './components/myprofilepopus/alphone/alphone.component';
import { SeatLocComponent } from './components/myprofilepopus/seatloc/seatloc.component';
import { MatTooltipModule } from '@angular/material';
import { EncrDecrService } from '../../src/app/services/EncrDecrService';
import { JwtTokenInterceptor } from './interceptors/jwt.interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AdvancedSearchComponent } from './components/advanced-search/advanced-search.component';
import { ContactHrComponent } from './components/myprofilepopus/contact-hr/contact-hr.component';
import { LabelComponent } from './components/label/label.component';
import { OrgChartComponent } from './components/org-chart/org-chart.component';
import { LinebreakPipe } from './components/filter/linebreak.pipe';
import { smepopupComponent } from '@/components/people-list/popups/sme/sme.component';
import { MoveToNextInputDirective } from './directives/move-to-next-input.directive';
import { SearchPipe } from './pipes/search.pipe';
import { SimilarDashboardComponent } from './components/similar-dashboard/similar-dashboard.component';
import { MsalModule, MsalInterceptor } from '@azure/msal-angular';
import { MsalSettings } from '../assets/configuration/msalConfig';
const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;
import { CustomMsalGuard } from './guard/custom-msal.guard';


@NgModule({
  declarations: [
    AppComponent,

    HeaderComponent,
    FooterComponent,
    LandingComponent,
    LoginComponent,

    ProfileComponent,
    PagelayoutComponent,
    SearchFieldComponent,
    SearchFieldLandingComponent,
    RefinedByComponent,
    PeopleComponent,
    PeopleListComponent,
    SearchInfoComponent,
    SpLangComponent,
    NetworksComponent,
    ExperianceComponent,
    IntrHobbiesComponent,
    EducationComponent,
    CompworkedComponent,
    CertificateComponent,
    TradeComponent,
    CommunitesComponent,
    AboutMeComponent,
    AlPhoneComponent,
    SeatLocComponent,
    AdvancedSearchComponent,
    ContactHrComponent,
    LabelComponent,
    OrgChartComponent,
    LinebreakPipe,
    smepopupComponent,
    MoveToNextInputDirective,
    SearchPipe,
    SimilarDashboardComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    InfiniteScrollModule,
    ReactiveFormsModule,
    NgxSpinnerModule,
    BrowserAnimationsModule,
    MatSidenavModule,
    FormsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    MatMenuModule,
    MatProgressBarModule,
    MatGridListModule,
    MatCardModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatCheckboxModule,
    AppRoutingModule,
    MatDialogModule,
    MatTableModule,
    MatProgressSpinnerModule,
    RouterModule,
    MatTooltipModule,
    ImageCropperModule,
    MatAutocompleteModule,
    MsalModule.forRoot({
      auth: MsalSettings.auth,
      cache: {
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: isIE,
      },
      system: { loadFrameTimeout: 35000 },
    },
      MsalSettings.extras
    )
  ],
  providers: [AuthGuard, CustomMsalGuard/* , { provide: HTTP_INTERCEPTORS, useClass: JwtTokenInterceptor, multi: true } */,{
    provide: HTTP_INTERCEPTORS,
    useClass: MsalInterceptor,
    multi: true
}, { provide: 'SnotifyToastConfig', useValue: ToastDefaults }, SnotifyService, CookieService, EncrDecrService],
  bootstrap: [AppComponent]
})
export class AppModule {
  // shouldRun = [/(^|\.)plnkr\.co$/, /(^|\.)stackblitz\.io$/].some(h => h.test(window.location.host));
}

