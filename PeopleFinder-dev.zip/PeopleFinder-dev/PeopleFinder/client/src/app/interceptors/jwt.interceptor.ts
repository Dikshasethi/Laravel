import { Injectable } from '@angular/core';
import {
  HttpInterceptor, HttpEvent, HttpRequest, HttpHandler, HttpSentEvent, HttpHeaderResponse, HttpProgressEvent,
  HttpResponse, HttpUserEvent, HttpErrorResponse
} from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators';
import { AuthenticationService } from '../services/auth.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Injectable()
export class JwtTokenInterceptor implements HttpInterceptor {

  /***
   *
   * @param router
   * 
   */
  constructor(
    private router: Router,
    private authService: AuthenticationService,
    public dialog: MatDialog
  ) {
  }


  /**
   * @param req 
   * @param next 
   */
  intercept(req: HttpRequest<any>, next: HttpHandler):
    Observable<HttpSentEvent | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
    if (req.url.indexOf('/login') > 0) {
      return next.handle(req);
    }
    let authReq = req;

    return next.handle(authReq).pipe(tap(
      (event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          // do stuff with response if you want         
        }
      },
      (err: any) => {
        if (err instanceof HttpErrorResponse) {
          if (err.status === 401 || err.error.status == 401) {
            this.authService.logout()
              .pipe()
              .subscribe(data => {
                this.dialog.closeAll()
                this.router.navigate(['/login']);
              },
                error => {
                  this.dialog.closeAll()
                  this.router.navigate(['/login']);
                });
          }
        }
      }
    ));
  }
}