import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild } from '@angular/router';
import { Observable, of, from } from 'rxjs';
import { catchError, mergeMap } from 'rxjs/operators';
import { AuthenticationService } from 'src/app/services/auth.service';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable()

export class CustomMsalGuard implements CanActivate, CanActivateChild {
    constructor(private authService: AuthenticationService,private router: Router) { }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const value = this.authService.getMSALTokenSilentguard();
        if(value==true) { return true }
      
        this.router.navigate(['login'], { queryParams: { returnUrl: state.url } });
        return false;
       
    }

    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {  
        const value = this.authService.getMSALTokenSilentguard();
        if(value==true) { return true }
      
        this.router.navigate(['login'], { queryParams: { returnUrl: state.url } });
        return false;
    }
   
}
