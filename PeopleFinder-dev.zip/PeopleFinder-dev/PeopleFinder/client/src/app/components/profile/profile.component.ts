import { Component, OnInit, Inject, ViewChild, ViewChildren, ContentChild, TemplateRef, Input } from '@angular/core';
import { PeopleService } from '../../services/people/people.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { SnotifyService, SnotifyPosition, SnotifyToastConfig } from 'ng-snotify';
import { NgxSpinnerService } from 'ngx-spinner';
import { ExperianceComponent } from '../myprofilepopus/experiance/experiance.component';
import { SpLangComponent } from '../myprofilepopus/sp-lang/sp-lang.component';
import { Location } from '@angular/common';
import { async } from 'q';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { appConfigurationService } from '@/services/appConfigurationService';


export interface DialogData {
  animal: string;
  name: string;
}

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  id: string;
  Ipeople: any = {
    data: {
      aggregations: {
        LocationCount: { buckets: [] },
        empjobfunctionCount: { buckets: [] },
        empservicelinecount: { buckets: [] },
        empjobsubfuncioncount: { buckets: [] }
      },
      hits: {
        hits: [],
      },
    }, success: []
  };
  experiance: any = [];
  spokenlang: any = [];
  network: any = [];
  hobbies: any = [];
  education: any = [];
  countries: any = [];
  certification: any = [];
  trade: any = [];
  comm: any = [];
  hobbaaarr: any;
  aboutme: any = [];
  sme: any = [];
  alphn: any;
  seatloc: any;
  empid: string;
  currentProfileImg: string;
  //uploadedProfileImg: string;
  updatedImgType: string;
  uploadedImageFileName: string = null;
  emailId: string;
  profileEmpId: string;
  base64textString: string;
  invalidImageType: boolean = false;
  invalidImgResponse: boolean = false;
  userLoggedIn: string;
  imageNotFound: boolean = false;
  imgurlofimp: string = "/assets/images/img-avatar.png";
  imageChangedEvent: any = '';
  croppedImage: any = '';
  suggesters : any = {}
  configData: any = [];
  isConfigDataAvailable = false;
  empfirstname : string;
  emplastname : string;
  
  @ViewChild(ExperianceComponent) ExperianceComponent: ExperianceComponent;
  @ViewChild(SpLangComponent) SpLangComponent: SpLangComponent;
  constructor(public dialog: MatDialog, private router: Router, private peopleservice: PeopleService, private route: ActivatedRoute, private snotifyService: SnotifyService, private spinner: NgxSpinnerService, private location: Location, private appconfig: appConfigurationService) { }
  ngOnInit() {
    if (localStorage.getItem('isLoggedin') == null || localStorage.getItem('isLoggedin').toString() == '') {
      this.router.navigate(['/login']);
    } else {


      // .subscribe(params => {
      this.spinner.show();
      // console.log(params); // {order: "popular"}
      // this.id = params.id;
      // console.log(this.name); // popular
      // console.log("Param Name:::" + params.searchSelect);
      // if (params.searchSelect === undefined) {
      //   console.log("in if");
      //   this.getPeople(this.currentsize, this.name);
      //   // this.searchkey =this.name;
      // } else {
      //   console.log("in else");
      //   this.searchSelect = params.searchSelect;
      //   this.getPeoplewithadv(this.currentsize, this.name, this.searchSelect);
      // }
      this.getProfile();
      this.empid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id;
      this.userLoggedIn = localStorage.getItem('loggedinUser');
      this.appconfig.getJSON().subscribe(data => {
        this.configData = data;
        this.isConfigDataAvailable = true;
      });
    }

    // });
  }

  getSpokenLangarry() {
    return this.spokenlang;
  }
  getExperianceArray() {
    return this.experiance;
  }
  getNetworkArray() {
    /* 	this.netwrkarr.empgoogleplusdetails.push(this.gplus);
      this.netwrkarr.emplinkedindetails.push(this.network);
      return this.netwrkarr; */
    //	console.log('network  ' + JSON.stringify(this.network));
    return this.network;
  }
  getAlphoneArray() {
    return this.alphn;
  }
  getSeatLocArray() {
    return this.seatloc;
  }
  getHobbiesArray() {
    this.hobbaaarr = this.hobbies;
    // console.log("getHobbiesArray::::"+JSON.stringify(this.hobbaaarr));
    return this.hobbaaarr;

  }
  getEducationArray() {
    return this.education;
  }
  getCoutriesArray() {
    return this.countries;
  }
  getCertificateArray() {
    return this.certification;
  }
  getTradeArray() {
    return this.trade;
  }
  getCommunityArray() {
    return this.comm;
  }
  getAskmeabtArray() {
    return this.aboutme;
  }
  getSMEArray() {
    return this.sme;
  }
  getProfile() {
    this.peopleservice.getProfile().subscribe(Ipeople => {
      this.Ipeople = Ipeople
      this.spinner.hide();
      if (this.Ipeople.data.hits.total == 0) {
        return;
      } else {
        this.Ipeople.data.hits.hits[0]._source['empimage'] = this.imgurlofimp;
        this.croppedImage = this.imgurlofimp


        this.peopleservice.getEmpImageById(Ipeople['data'].hits.hits[0]._source.empid).then(
          (IpeopleImage) => {
            this.spinner.hide();
            if (IpeopleImage.error) {
              Ipeople['data'].hits.hits[0]._source['empimage'] = this.imgurlofimp;
              this.croppedImage = this.imgurlofimp

            } else {
              if (IpeopleImage.data.length > 0 ) {
                this.Ipeople.data.hits.hits[0]._source['empimage'] = IpeopleImage.data[0].signedUrl_compressed
                this.imgurlofimp = IpeopleImage.data[0].signedUrl_compressed
                this.croppedImage = this.imgurlofimp
              } else {
                this.Ipeople.data.hits.hits[0]._source['empimage'] = this.imgurlofimp;
                this.croppedImage = this.imgurlofimp
              }
            }
          }
        ), error => {
          this.Ipeople.data.hits.hits[0]._source['empimage'] = this.imgurlofimp;
        };
        this.network = this.Ipeople.data.hits.hits[0]._source;
        this.emailId = this.Ipeople.data.hits.hits[0]._source.employeeemail;
        this.empfirstname = this.network.empfirstname
        this.emplastname = this.network.emplastname
        this.profileEmpId = this.Ipeople.data.hits.hits[0]._source.empid;
        if (this.Ipeople.data.hits.hits[0]._source.empexperiences != undefined) {
          this.Ipeople.data.hits.hits[0]._source.empexperiences.sort(function (obj1, obj2) {
            if (obj1 != null && obj2 != null) {
              return obj1.experienceshasorder - obj2.experienceshasorder;
            }
          });
          this.experiance = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source.empexperiences));
          for (let k = 0, len = this.experiance.length; k < len; k++) {
            if (this.experiance.indexOf(null) > -1) {
              this.experiance.splice(this.experiance.indexOf(null), 1);
            }
          }
          for (let k = 0; k < this.experiance.length; k++) {

            if (this.experiance[k].experienceshasorder == undefined ||
              this.experiance[k].experienceshasorder == 'undefined' ||
              new String(this.experiance[k].experienceshasorder).length == 0 ||
              this.experiance[k].id == undefined ||
              this.experiance[k].id.length == 0) {
              this.experiance.splice(k, 1);
              k = k - 1;
            }
          }
        }
        else {
          this.experiance = [];
        }
        if (this.Ipeople.data.hits.hits[0]._source.empsplanguage != undefined) {
          this.Ipeople.data.hits.hits[0]._source.empsplanguage.sort(function (obj1, obj2) {
            if (obj1 != null && obj2 != null) {
              return obj1.splanguagehasorder - obj2.splanguagehasorder;
            }
          });

          this.spokenlang = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source.empsplanguage));
          for (let k = 0, len = this.spokenlang.length; k < len; k++) {
            if (this.spokenlang.indexOf(null) > -1) {
              this.spokenlang.splice(this.spokenlang.indexOf(null), 1);
            }
          }
          for (let k = 0; k < this.spokenlang.length; k++) {

            if (this.spokenlang[k].splanguagehasorder == undefined ||
              this.spokenlang[k].splanguagehasorder == 'undefined' ||
              new String(this.spokenlang[k].splanguagehasorder).length == 0 ||
              this.spokenlang[k].id == undefined ||
              this.spokenlang[k].id.length == 0) {
              this.spokenlang.splice(k, 1);
              k = k - 1;
            }
          }
        }
        else {
          this.spokenlang = [];
        }

        if (this.Ipeople.data.hits.hits[0]._source.empinteresthobbies != undefined) {
          this.Ipeople.data.hits.hits[0]._source.empinteresthobbies.sort(function (obj1, obj2) {
            if (obj1 != null && obj2 != null) {
              return obj1.interesthobbieshasorder - obj2.interesthobbieshasorder;
            }
          });
          this.hobbies = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source.empinteresthobbies));
          for (let k = 0, len = this.hobbies.length; k < len; k++) {
            if (this.hobbies.indexOf(null) > -1) {
              this.hobbies.splice(this.hobbies.indexOf(null), 1);
            }
          }
          for (let k = 0; k < this.hobbies.length; k++) {

            if (this.hobbies[k].interesthobbieshasorder == undefined ||
              this.hobbies[k].interesthobbieshasorder == 'undefined' ||
              new String(this.hobbies[k].interesthobbieshasorder).length == 0 ||
              this.hobbies[k].id == undefined ||
              this.hobbies[k].id.length == 0) {
              this.hobbies.splice(k, 1);
              k = k - 1;
            }
          }
        } else {
          this.hobbies = [];
        }

        if (this.Ipeople.data.hits.hits[0]._source.empeducation != undefined) {
          this.Ipeople.data.hits.hits[0]._source.empeducation.sort(function (obj1, obj2) {
            if (obj1 != null && obj2 != null) {
              return obj1.educationhasorder - obj2.educationhasorder;
            }
          });
          this.education = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source.empeducation));
          for (let k = 0, len = this.education.length; k < len; k++) {
            if (this.education.indexOf(null) > -1) {
              this.education.splice(this.education.indexOf(null), 1);
            }
          }
          for (let k = 0; k < this.education.length; k++) {

            if (this.education[k].educationhasorder == undefined ||
              this.education[k].educationhasorder == 'undefined' ||
              new String(this.education[k].educationhasorder).length == 0 ||
              this.education[k].id == undefined ||
              this.education[k].id.length == 0) {
              this.education.splice(k, 1);
              k = k - 1;
            }
          }
        }
        else {
          this.education = [];
        }
        if (this.Ipeople.data.hits.hits[0]._source.empcountriesworked != undefined) {
          this.Ipeople.data.hits.hits[0]._source.empcountriesworked.sort(function (obj1, obj2) {
            if (obj1 != null && obj2 != null) {
              return obj1.countriesworkedhasorder - obj2.countriesworkedhasorder;
            }
          });
          this.countries = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source.empcountriesworked));
          for (let k = 0, len = this.countries.length; k < len; k++) {
            if (this.countries.indexOf(null) > -1) {
              this.countries.splice(this.countries.indexOf(null), 1);
            }
          }
          for (let k = 0; k < this.countries.length; k++) {

            if (this.countries[k].countriesworkedhasorder == undefined ||
              this.countries[k].countriesworkedhasorder == 'undefined' ||
              new String(this.countries[k].countriesworkedhasorder).length == 0 ||
              this.countries[k].id == undefined ||
              this.countries[k].id.length == 0) {
              this.countries.splice(k, 1);
              k = k - 1;
            }
          }
        }
        else {
          this.countries = [];
        }
        if (this.Ipeople.data.hits.hits[0]._source.empcertification != undefined) {
          this.Ipeople.data.hits.hits[0]._source.empcertification.sort(function (obj1, obj2) {
            if (obj1 != null && obj2 != null) {
              return obj1.certificationhasorder - obj2.certificationhasorder;
            }
          });
          this.certification = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source.empcertification));
          for (let k = 0, len = this.certification.length; k < len; k++) {
            if (this.certification.indexOf(null) > -1) {
              this.certification.splice(this.certification.indexOf(null), 1);
            }
          }
          for (let k = 0; k < this.certification.length; k++) {

            if (this.certification[k].certificationhasorder == undefined ||
              this.certification[k].certificationhasorder == 'undefined' ||
              new String(this.certification[k].certificationhasorder).length == 0 ||
              this.certification[k].id == undefined ||
              this.certification[k].id.length == 0) {
              this.certification.splice(k, 1);
              k = k - 1;
            }
          }
        } else {
          this.certification = [];
        }

        if (this.Ipeople.data.hits.hits[0]._source.emptradesassociation != undefined) {
          this.Ipeople.data.hits.hits[0]._source.emptradesassociation.sort(function (obj1, obj2) {
            if (obj1 != null && obj2 != null) {
              return obj1.tradesassociationhasorder - obj2.tradesassociationhasorder;
            }
          });
          this.trade = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source.emptradesassociation));
          for (let k = 0, len = this.trade.length; k < len; k++) {
            if (this.trade.indexOf(null) > -1) {
              this.trade.splice(this.trade.indexOf(null), 1);
            }
          }
          for (let k = 0; k < this.trade.length; k++) {

            if (this.trade[k].tradesassociationhasorder == undefined ||
              this.trade[k].tradesassociationhasorder == 'undefined' ||
              new String(this.trade[k].tradesassociationhasorder).length == 0 ||
              this.trade[k].id == undefined ||
              this.trade[k].id.length == 0) {
              this.trade.splice(k, 1);
              k = k - 1;
            }
          }
        }
        else {
          this.trade = [];
        }

        if (this.Ipeople.data.hits.hits[0]._source.empcommunities != undefined) {
          this.Ipeople.data.hits.hits[0]._source.empcommunities.sort(function (obj1, obj2) {
            if (obj1 != null && obj2 != null) {
              return obj1.communitieshasorder - obj2.communitieshasorder;
            }
          });
          this.comm = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source.empcommunities));
          for (let k = 0, len = this.comm.length; k < len; k++) {
            if (this.comm.indexOf(null) > -1) {
              this.comm.splice(this.comm.indexOf(null), 1);
            }
          }
          for (let k = 0; k < this.comm.length; k++) {

            if (this.comm[k].communitieshasorder == undefined ||
              this.comm[k].communitieshasorder == 'undefined' ||
              new String(this.comm[k].communitieshasorder).length == 0 ||
              this.comm[k].id == undefined ||
              this.comm[k].id.length == 0) {
              this.comm.splice(k, 1);
              k = k - 1;
            }
          }

        }
        else {
          this.comm = [];
        }

        if (this.Ipeople.data.hits.hits[0]._source.empaboutme != undefined) {
          this.Ipeople.data.hits.hits[0]._source.empaboutme.sort(function (obj1, obj2) {
            if (obj1 != null && obj2 != null) {
              return obj1.aboutmehasorder - obj2.aboutmehasorder;
            }
          });

          this.aboutme = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source.empaboutme));

          for (let k = 0, len = this.aboutme.length; k < len; k++) {
            if (this.aboutme.indexOf(null) > -1) {
              this.aboutme.splice(this.aboutme.indexOf(null), 1);
            }
          }
          for (let k = 0; k < this.aboutme.length; k++) {

            if (this.aboutme[k].aboutmehasorder == undefined ||
              this.aboutme[k].aboutmehasorder == 'undefined' ||
              new String(this.aboutme[k].aboutmehasorder).length == 0 ||
              this.aboutme[k].id == undefined ||
              this.aboutme[k].id.length == 0) {
              this.aboutme.splice(k, 1);
              k = k - 1;
            }
          }

        }
        else {

          this.aboutme = [];
        }
       // console.log(this.Ipeople.data.hits.hits[0]._source.empsme );
        if (this.Ipeople.data.hits.hits[0]._source.empsme != undefined && Array.isArray(this.Ipeople.data.hits.hits[0]._source.empsme)) {
          this.Ipeople.data.hits.hits[0]._source.empsme.sort(function (obj1, obj2) {
            if (obj1 != null && obj2 != null) {
              return obj1.smehasorder - obj2.smehasorder;
            }
          });
          this.sme = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source.empsme));
          for (let k = 0, len = this.sme.length; k < len; k++) {
            if (this.sme.indexOf(null) > -1) {
              this.sme.splice(this.sme.indexOf(null), 1);
            }
          }
          for (let k = 0; k < this.sme.length; k++) {
            if (!this.sme[k].smehasorder ||
              !this.sme[k].id) {
              this.sme.splice(k, 1);
              k = k - 1;
            }
          }
        }
        else {
          this.sme = [];
        }
        if (this.Ipeople.data.hits.hits[0]._source.empaltnumber != undefined) {
          this.alphn = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source.empaltnumber));//console.log(' this.alphn'+  JSON.stringify(this.alphn));
          /* for(let k = 0; k < this.alphn.length; k++){ 
              if( this.alphn[k].altnumberhasorder == undefined || 
                 this.alphn[k].altnumberhasorder == 'undefined' || 
                 new String(this.alphn[k].altnumberhasorder).length == 0 ||
                 this.alphn[k].id == undefined ||
                 this.alphn[k].id.length == 0)  {  
                     this.alphn.splice(k, 1);
                     k = k-1; 
                 }
          } */
        }
        else {
          this.alphn = [];
        }
        //  console.log(' this.alphn'+  JSON.stringify(this.alphn));
        this.seatloc = JSON.parse(JSON.stringify(this.Ipeople.data.hits.hits[0]._source));//console.log(' this.seatloc 123 '+ JSON.stringify(this.seatloc));
      }
      /* for(let k = 0; k < this.seatloc.length; k++){ 
        if(this.seatloc[k].seatlocationhasorder == undefined || 
           this.seatloc[k].seatlocationhasorder == 'undefined' || 
           new String(this.seatloc[k].seatlocationhasorder).length == 0 ||
           this.seatloc[k].id == undefined ||
           this.seatloc[k].id.length == 0)  {  
               this.seatloc.splice(k, 1);
               k = k-1; 
           } 
      } */
      //  console.log('this.seatloc 456 '+  JSON.stringify(this.seatloc));
      // this.ExperianceComponent.populateexp();
      // this.ExperianceComponent.populateexp(this.experiance)
      // this.SpLangComponent.populateSpLang(Ipeople.data.hits.hits[0]._source.empexperiences)

    })
  }

  saveData(data) {
    this.peopleservice.savePeople(data).subscribe(res => {

      this.getProfile(); this.dialog.closeAll();
    }),
      error => {
        alert(error)
      };
  }

  onNoClickfrall(): void {
    const dialogRef = this.dialog.closeAll();
  }

  openDialogfrspklang(myspoklangtemplate): void {
    const dialogRef = this.dialog.open(myspoklangtemplate, {
      width: '700px',

    });
    dialogRef.afterClosed().subscribe(result => {
      this.getProfile();

    });
  }
  openDialogfrcommunity(community): void {
    const dialogRef = this.dialog.open(community, {
      width: '700px',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.getProfile();

    });
  }

  shareService() {
  }
  openDialogfrnw(nw): void {
    const dialogRef = this.dialog.open(nw, {
      width: '700px',
    });
    dialogRef.afterClosed().subscribe(result => {
      
      this.getProfile();

    });
  }
  openDialogfrggl(ggl): void {
    const dialogRef = this.dialog.open(ggl, {
      width: '700px',
    });
    dialogRef.afterClosed().subscribe(result => {
      
      this.getProfile();

    });
  }
  openDialogfrexp(exp): void {
    const dialogRef = this.dialog.open(exp, {
      width: '700px',
    });
    dialogRef.afterClosed().subscribe(result => {

      
      this.getProfile();

    });
  }
  openDialogfrinhobb(inhobb): void {
    const dialogRef = this.dialog.open(inhobb, {
      width: '700px',
    });
    dialogRef.afterClosed().subscribe(result => {
      
      this.getProfile();

    });
  }
  openDialogfredu(edu): void {
    const dialogRef = this.dialog.open(edu, {
      width: '700px',
    });
    dialogRef.afterClosed().subscribe(result => {
      
      this.getProfile();

    });
  }
  openDialogfrcntrwrk(cntr): void {
    const dialogRef = this.dialog.open(cntr, {
      width: '700px',
    });
    dialogRef.afterClosed().subscribe(result => {
      
      this.getProfile();

    });
  }
  openDialogfrcert(cert): void {
    const dialogRef = this.dialog.open(cert, {
      width: '700px',
    });
    dialogRef.afterClosed().subscribe(result => {
      
      this.getProfile();

    });
  }


  openDialogfrtrade(trade): void {
    const dialogRef = this.dialog.open(trade, {
      width: '700px',
    });
    dialogRef.afterClosed().subscribe(result => {
      
      this.getProfile();

    });
  }

  openDialogfrabtme(abtme): void {
    const dialogRef = this.dialog.open(abtme, {
      width: '700px',
    });

  }
  /*openSmeDialog(sme): void {
    const dialogRef = this.dialog.open(sme, {
      width: '700px',
    });

  }*/
  openDialogaltphn(altphn): void {

    const dialogRef = this.dialog.open(altphn, {
      width: '700px',
    });
    dialogRef.afterClosed().subscribe(result => {
      
      this.getProfile();


    });

  }

  openDialogseatloc(myseatloc): void {

    const dialogRef = this.dialog.open(myseatloc, {
      width: '700px',
    });
    dialogRef.afterClosed().subscribe(result => {
      
      this.getProfile();

    });
  }

  openDialogchngpic(mychngpic): void {
    const dialogRef = this.dialog.open(mychngpic, {
      width: '450px',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.imageNotFound = false;
      this.invalidImageType = false;
      this.invalidImgResponse = false;
      this.uploadedImageFileName = null;
      this.croppedImage = this.imgurlofimp;
      this.imageChangedEvent = ''
      
      //this.getProfile();
    });
    
  }

  chngpiccls() {
    
    this.base64textString = null;
    this.updatedImgType = null;
    this.uploadedImageFileName = null;
    this.invalidImageType = false;
    this.invalidImgResponse = false;
    this.imageNotFound = false;

    this.dialog.closeAll();
  }

  onSelectClick(searchkey) {
    //  console.log('onSelectClick searchkey : '+ searchkey);
    this.router.navigate(['/people/'], { queryParams: { name: searchkey, searchSelect: 'peoplefinder' } });
  }

  filterItemsOfType() {
    return this.comm.filter(x => new String(x.keyword).length != 0);
  }
  openDialogalForContact(contact): void {

    const dialogRef = this.dialog.open(contact, {
      width: '1000px',
    });
    dialogRef.afterClosed().subscribe(result => {
      
    })
  }

  onFileSelected(event) {
    
    var files = event.target.files;
    var file = files[0];
    this.invalidImageType = false;
    this.invalidImgResponse = false;
    this.imageNotFound = false;
    if (files && file) {
      var reader = new FileReader();
      this.updatedImgType = file.type.split('/').pop();
      if (this.updatedImgType == 'jpg' || this.updatedImgType == 'jpeg' || this.updatedImgType == 'png' || this.updatedImgType == 'gif') {
        reader.onload = this._handleReaderLoaded.bind(this);
        reader.readAsBinaryString(file);
      } else {
        this.invalidImageType = true;
      }
    }
  }

  _handleReaderLoaded(readerEvt) {
    var binaryString = readerEvt.target.result;
    this.base64textString = btoa(binaryString);
    this.uploadedImageFileName = 'data:image/'.concat(this.updatedImgType).concat(';base64,').concat(this.base64textString);
    this.croppedImage = this.uploadedImageFileName
  }

  cancelImageUpdate() {
    this.imageNotFound = false;
    this.base64textString = null;
    this.updatedImgType = null;
    this.uploadedImageFileName = null;
    this.invalidImageType = false;
    this.invalidImgResponse = false;
    this.croppedImage = this.imgurlofimp;
    this.imageChangedEvent = ''
    this.dialog.closeAll();
  }

  // saveUpdatedImage() {
  //   if (this.base64textString != null || this.base64textString != '') {
  //     this.spinner.show();
  //     this.peopleservice.updateEmpImage(this.base64textString, this.emailId, this.profileEmpId, this.updatedImgType, this.userLoggedIn, false).then((updateImgRes) => {
  //       if (updateImgRes.error) {
  //         this.invalidImgResponse = true;
  //         this.spinner.hide();
  //       } else {
  //         this.imageNotFound = false;
  //         this.invalidImgResponse = false;
  //         this.uploadedImageFileName = null;
  //         this.emailId = null;
  //         this.base64textString = null;
  //         this.updatedImgType = null;
  //         this.invalidImageType = false;
  //         this.profileEmpId = null;
  //         this.getProfile();
  //         this.dialog.closeAll();
  //       }
  //     }), error => {
  //       this.invalidImgResponse = true;
  //       this.spinner.hide();
  //     };
  //   }
  // }

  saveUpdatedImage() {
    if (this.base64textString != null || this.base64textString != '') {
      this.spinner.show();
      let previous_image = this.imgurlofimp;
      this.imgurlofimp = null;
      this.peopleservice.updateEmpImage(this.base64textString, this.emailId, this.profileEmpId, this.updatedImgType, this.userLoggedIn, this.empfirstname, this.emplastname).then((updateImgRes) => {
        if (updateImgRes.error) {
          this.invalidImgResponse = true;
          this.spinner.hide();
          this.imgurlofimp = previous_image
        } else {
          this.imageNotFound = false;
          this.invalidImgResponse = false;
          this.uploadedImageFileName = null;
          this.croppedImage = updateImgRes.data[0].signedUrl_normal;
          this.updatedImgType = null;
          this.invalidImageType = false;
          this.imgurlofimp = updateImgRes.data[0].signedUrl_normal
          this.spinner.hide();
          this.dialog.closeAll();
        }
      }), error => {
        this.invalidImgResponse = true;
        this.spinner.hide();
      };
    }
  }

  removeProfileImg() {
    this.spinner.show();
    this.peopleservice.deleteEmpImage( this.profileEmpId ).then((updateImgRes) => {
      if (updateImgRes.error) {
        this.invalidImgResponse = true;
        this.imageNotFound = false;
        this.spinner.hide();
      } else {
        this.imageNotFound = false;
        this.invalidImgResponse = false;
        this.uploadedImageFileName = null;
        this.base64textString = null;
        this.updatedImgType = null;
        this.invalidImageType = false;
        this.croppedImage = null;
        this.imgurlofimp = "/assets/images/img-avatar.png";
        this.getProfile();
        this.dialog.closeAll();
      }
    }), error => {
      this.invalidImgResponse = true;
      this.spinner.hide();
    };
  
  }
  fileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
  }
  // imageFile(event: ImageCroppedEvent) {
  //   console.log('image file---------------', event.file)
  // }
  imageCropped(event: ImageCroppedEvent) {
    var file = event.file;

    if (file) {
      var reader = new FileReader();
      this.updatedImgType = file.type.split('/').pop();
      if (this.updatedImgType == 'jpg' || this.updatedImgType == 'jpeg' || this.updatedImgType == 'png' || this.updatedImgType == 'gif') {
        reader.onload = this._handleReaderLoaded.bind(this);
        this.croppedImage = reader.readAsBinaryString(file);
      } else {
        this.invalidImageType = true;
      }
    }

  }
  imageLoaded() {
    // show cropper
  }
  cropperReady() {
    // cropper ready
  }
  loadImageFailed() {
    // show message
  }
  // ITTPPRD-1404
  sendForSuggesters(data) {
    this.peopleservice.getSuggesters(data).subscribe(res => {
      this.suggesters = res;
    }),
      error => {
        alert(error)
      };
  }
  getSuggesters(){
    return this.suggesters.data;
  }
  // ITTPPRD-1404
}
