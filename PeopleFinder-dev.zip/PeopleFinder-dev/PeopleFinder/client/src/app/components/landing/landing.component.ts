import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { appConfigurationService } from '@/services/appConfigurationService';
@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  constructor( private router: Router,private appconfig: appConfigurationService) { }
  isConfigDataAvailable = false;
	configData: any = [];

  ngOnInit() {
	  
	    if(localStorage.getItem('isLoggedin') == null || localStorage.getItem('isLoggedin').toString() == '')
		{ 
			this.router.navigate(['/login']);
    }
    this.appconfig.getJSON().subscribe(data => {
			this.configData = data;
			this.isConfigDataAvailable = true;
		});
		
  }

}
