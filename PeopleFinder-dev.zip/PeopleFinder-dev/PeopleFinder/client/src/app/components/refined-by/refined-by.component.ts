import { PeopleService } from './../../services/people/people.service';
import { Router } from '@angular/router';
import { Component, OnInit, ViewChild, HostListener, Input, EventEmitter, Output } from '@angular/core';
import { MatCheckbox } from '@angular/material';
import { isJsObject } from '@angular/core/src/change_detection/change_detection_util';
import { SelectionModel } from '@angular/cdk/collections';
import { SnotifyService, SnotifyPosition, SnotifyToastConfig } from 'ng-snotify';
import { filter, subscribeOn, map } from 'rxjs/operators';
import { ActivatedRoute } from "@angular/router";
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { PeopleListComponent } from '../people-list/people-list.component';
import { NgxSpinnerService } from 'ngx-spinner';
import { trigger, state, style, animate, group, transition } from '@angular/animations';




@Component({
  selector: 'app-refined-by',
  templateUrl: './refined-by.component.html',
  styleUrls: ['./refined-by.component.css'],
    animations:[
trigger('slideInOut', [
  state('in', style({
      'max-height': '100%', 'opacity': '1', 'visibility': 'visible'
  })),
  state('out', style({
      'max-height': '106px', 'opacity': '1', 'visibility': 'visible' , 'overflow': 'hidden', 'display':'inherit'
  })),
  transition('in => out', [group([
      animate('200ms ease-in-out', style({
          'opacity': '1'
      })),
      animate('300ms ease-in-out', style({ 
          'max-height': '106px'
      })),
      animate('200ms ease-in-out', style({
          'visibility': 'visible'
      }))
  ] 
  )]),
  transition('out => in', [group([
      animate('400ms ease-in-out', style({
          'visibility': 'visible'
      })),
      animate('600ms ease-in-out', style({
          'max-height': '1100px'
      })),
      animate('700ms ease-in-out', style({
          'opacity': '1'
      }))
  ]
  )])
])

  ]
})
export class RefinedByComponent implements OnInit {

  selectedValue: string;

  @ViewChild(PeopleListComponent) peopleListComponent: PeopleListComponent;
  @Output()  test = new EventEmitter();
  @Output()  resetPeopleList = new EventEmitter();
  refined_by: any = {

    empjobfunction: [],
    empjobsubfunction: [],
    filter: { empcity: [], empcountry: [] }
  };
  empserfunction1 = [];
  empsubfunction1 = [];
  distejfunc1 = [];
  response: any;
  searchkey: any;
  location: any;
  jobarr=[];
  username = localStorage.getItem('isLoggedin');
  subjobarr=[];
  locaarr=[];
  aggarrrr = [];
  distejfunc = [];
  fullJobarr = [];
  displayedJobarr = [];
  fullSerarr = [];
  displayedSerarr = [];
  fullSubjobarr = [];
  displayedSubjobarr = [];
  fullLocaarr = [];
  displayedLocaarr = []; 
  empsubfunction = [];
  empserfunction = [];
  empjobsubfunction = [];
  empserviceline = [];
  emplocation: any;
  emplocation1 = [];
  serarr=[];
  filter: any = { empcity: [], empcountry: [] };
  filter1: any = { empcity: [], empcountry: [] };
  showClearAll = false;

  finalrequest: any = {
    empjobfunction: [],
    empjobsubfuncion: [],
    empserviceline: [],
    locaarr: [],
  };
  selectedJobArr = [];
  selectedSubJob = [];
  selectedServiceLine = [];
  selectedLoc = [];
  selectedFilter = {
    parameter: '',
    value: []
  }
  refinedByKeys : Object = {
     "serviceLine" : 1,"job" : 2,"sub-job" : 3
  }
  constructor(
    private route: ActivatedRoute,
    public peopleService: PeopleService, private http: HttpClient,
    private router: Router, private snotifyService: SnotifyService, private spinner: NgxSpinnerService) {

  }

  ngOnInit() {
  }
  
  serrarrAnimationState = 'out';
  serrarrText = "Show More...";
  jobfunarrAnimationState = 'out';
  jobfunarrText = "Show More...";
  jobsubfunarrAnimationState = 'out';
  jobsubfunarrText = "Show More...";
  locarrrrAnimationState = 'out';
  locarrrrText = "Show More...";


 toggleShowDiv(divName,event) {  
    
    switch (divName) {
      case 'serrarr':
        this.serarr = this.serrarrText === "Show More..."?this.fullSerarr:this.displayedSerarr; 
        this.serrarrText = this.serrarrText === "Show More..."?"Show Less...":"Show More..."; 
        break;
      case 'jobfunarr':
        this.jobarr = this.jobfunarrText === "Show More..."?this.fullJobarr:this.displayedJobarr;
        this.jobfunarrText = this.jobfunarrText === "Show More..."?"Show Less...":"Show More..."; 
        break;
      case 'jobsubfunarr':
        this.subjobarr = this.jobsubfunarrText === "Show More..."?this.fullSubjobarr:this.displayedSubjobarr;
        this.jobsubfunarrText = this.jobsubfunarrText === "Show More..."?"Show Less...":"Show More..."; 
        break;
      case 'locarrrr':
        this.locaarr = this.locarrrrText === "Show More..."?this.fullLocaarr:this.displayedLocaarr;
        this.locarrrrText = this.locarrrrText === "Show More..."?"Show Less...":"Show More..."; 
        break;
  }
}
  populateRefinedByInfo(aggsdetails) {
    if(this.selectedJobArr.length>0 || this.selectedLoc.length >0 || this.selectedServiceLine.length >0 || this.selectedSubJob.length)
      this.showClearAll = true;
    else
      this.showClearAll = false;

    if(this.selectedFilter.parameter == "job"){
      let tempArr = this.selectedFilter.value;
      let selectedJobArr = this.selectedJobArr;
      selectedJobArr.forEach(function (e) {
        if (tempArr.length > 0 && tempArr.some(s => s.key != undefined && (s.key == e.key))) {
          let index = tempArr.findIndex(x => x.key ===e.key);
          tempArr.splice(index, 1);
        }
      });
      this.fullJobarr = [...selectedJobArr,...tempArr];
      this.displayedJobarr = this.fullJobarr.slice(0, 5);      
      this.displayedJobarr = this.fullJobarr.slice(0, 5);      
      this.jobarr = this.displayedJobarr;
    }     
    else {
      let tempArr = aggsdetails.empjobfunctionCount.buckets;
       // ITTPPRD-1439
       let keyword =  this.router['currentUrlTree'].queryParams.name;
       let refinedBy = this.router['currentUrlTree'].queryParams.refinedBy
       if(refinedBy == this.refinedByKeys["job"] ){
         for (let key in tempArr ) {
             if(tempArr[key].key.toLowerCase() === keyword.toLowerCase() ){
                tempArr[key].checked =true;
                this.selectedJobArr.push({key:keyword,checked:true}) 
                this.showClearAll = true;
             }
           
         }
       }
       // ITTPPRD-1439
      let selectedJobArr = this.selectedJobArr;
      selectedJobArr.forEach(function (e) {
        if (tempArr.length > 0 && tempArr.some(s => s.key != undefined && (s.key == e.key))) {
          let index = tempArr.findIndex(x => x.key ===e.key);
          tempArr.splice(index, 1);
        }
      });
     
      let sortArray =  tempArr.sort(this.dynamicSort('key'));
      this.fullJobarr = [...selectedJobArr,...sortArray];
      this.displayedJobarr = this.fullJobarr.slice(0, 5);      
      this.jobarr = this.displayedJobarr;
    }

    if (this.selectedFilter.parameter == "serviceLine"){
      let tempserarr = this.selectedFilter.value;
      let selectedServiceLine = this.selectedServiceLine;
      selectedServiceLine.forEach(function (e) {
        if (tempserarr.length > 0 && tempserarr.some(s => s.key != undefined && (s.key == e.key))) {
          let index = tempserarr.findIndex(x => x.key ===e.key);
          tempserarr.splice(index, 1);
        }
      });
      this.fullSerarr = [...selectedServiceLine,...tempserarr];
      this.displayedSerarr = this.fullSerarr.slice(0, 5);      
      this.serarr = this.displayedSerarr;
    }      
    else {
      // ITTPPRD-1439
      let tempserarr = aggsdetails.empservicelinecount.buckets;
      let keyword =  this.router['currentUrlTree'].queryParams.name;
      let refinedBy = this.router['currentUrlTree'].queryParams.refinedBy
      if(refinedBy == this.refinedByKeys["serviceLine"]){
        for (let key in tempserarr ) {
            if(tempserarr[key].key.toLowerCase() === keyword.toLowerCase() ){
                tempserarr[key].checked =true;
                this.selectedServiceLine.push({key:keyword,checked:true}) 
                this.showClearAll = true;
            }
          
        }
      }
      // ITTPPRD-1439
      let selectedServiceLine = this.selectedServiceLine;
      selectedServiceLine.forEach(function (e) {
        if (tempserarr.length > 0 && tempserarr.some(s => s.key != undefined && (s.key == e.key))) {
          let index = tempserarr.findIndex(x => x.key ===e.key);
          tempserarr.splice(index, 1);
        }
      });
      
      let sortArray  =  tempserarr.sort(this.dynamicSort('key'));
      this.fullSerarr = [...selectedServiceLine,...sortArray];
      this.displayedSerarr = this.fullSerarr.slice(0, 5);   
      this.serarr = this.displayedSerarr;
    }

    if (this.selectedFilter.parameter == "sub-job"){
      let tempsubjobarr = this.selectedFilter.value;
      let selectedSubJob = this.selectedSubJob;
      selectedSubJob.forEach(function (e) {
        if (tempsubjobarr.length > 0 && tempsubjobarr.some(s => s.key != undefined && (s.key == e.key))) {
          let index = tempsubjobarr.findIndex(x => x.key ===e.key);
          tempsubjobarr.splice(index, 1);
        }
      });
      this.fullSubjobarr = [...selectedSubJob,...tempsubjobarr];
      this.displayedSubjobarr = this.fullSubjobarr.slice(0, 5);      
      this.subjobarr = this.displayedSubjobarr;
    }      
    else {
      let tempsubjobarr = aggsdetails.empjobsubfuncioncount.buckets;
      // ITTPPRD-1439
      let keyword =  this.router['currentUrlTree'].queryParams.name;
      let refinedBy = this.router['currentUrlTree'].queryParams.refinedBy
      if(refinedBy == this.refinedByKeys["sub-job"]){
        for (let key in tempsubjobarr ) {
            if(tempsubjobarr[key].key.toLowerCase() === keyword.toLowerCase() ){
                this.selectedSubJob.push({key:keyword,checked:true}) 
                this.showClearAll = true;
            }
          
        }
      }
      // ITTPPRD-1439

      let selectedSubJob = this.selectedSubJob;
      selectedSubJob.forEach(function (e) {
        if (tempsubjobarr.length > 0 && tempsubjobarr.some(s => s.key != undefined && (s.key == e.key))) {
          let index = tempsubjobarr.findIndex(x => x.key ===e.key);
          tempsubjobarr.splice(index, 1);
        }
      });
    
      
      let sortArray =  tempsubjobarr.sort(this.dynamicSort('key'));
      this.fullSubjobarr = [...selectedSubJob,...sortArray];
      this.displayedSubjobarr = this.fullSubjobarr.slice(0, 5);      
      this.subjobarr = this.displayedSubjobarr;
    }

    if (this.selectedFilter.parameter == "location"){
      let templocaarr = this.selectedFilter.value;
      let selectedLoc = this.selectedLoc;
      selectedLoc.forEach(function (e) {
        if (templocaarr.length > 0 && templocaarr.some(s => s.key != undefined && (s.key == e.key))) {
          let index = templocaarr.findIndex(x => x.key ===e.key);
          templocaarr.splice(index, 1);
        }
      });
      this.fullLocaarr = [...selectedLoc,...templocaarr];
      this.displayedLocaarr = this.fullLocaarr.slice(0, 5);      
      this.locaarr = this.displayedLocaarr;
    }
      
    else {
      let templocaarr = aggsdetails.LocationCount.buckets;
      let selectedLoc = this.selectedLoc;
      selectedLoc.forEach(function (e) {
        if (templocaarr.length > 0 && templocaarr.some(s => s.key != undefined && (s.key == e.key))) {
          let index = templocaarr.findIndex(x => x.key ===e.key);
          templocaarr.splice(index, 1);
        }
      });
      this.fullLocaarr = [...selectedLoc,...templocaarr];
      var sortArray =  this.fullLocaarr.sort(this.dynamicSort('key'));
      this.displayedLocaarr = sortArray.slice(0, 5);      
      this.locaarr = this.displayedLocaarr;
    }
  }

  changechkfunction(arrtype, i, event) {
    //ITTPPRD-1439
    this.router['currentUrlTree'].queryParams.refinedBy = ''
    //ITTPPRD-1439
    this.selectedFilter.parameter = '';
    this.selectedFilter.value = [];
    if (arrtype === 'empjobfunction') {
      this.fullJobarr[i].checked = event.checked;
      this.selectedJobArr = this.fullJobarr.filter(item => { return item.checked; });
      this.distejfunc = this.selectedJobArr.map(arr => { return arr.key; });
      if(this.selectedJobArr.length>0){
        this.selectedFilter.parameter = 'job';
        this.selectedFilter.value = this.fullJobarr;
      
      }
      
    } else if (arrtype === 'empjobsubfuncion') {
      this.fullSubjobarr[i].checked = event.checked;
      this.selectedSubJob = this.fullSubjobarr.filter(item => { return item.checked; });
      this.empsubfunction = this.selectedSubJob.map(arr => { return arr.key; });
      if(this.selectedSubJob.length>0){
        this.selectedFilter.parameter = 'sub-job';
        this.selectedFilter.value = this.fullSubjobarr;
      
      }
    } else if (arrtype === 'empserviceline') {
      this.fullSerarr[i].checked = event.checked;
      this.selectedServiceLine = this.fullSerarr.filter(item => { return item.checked; });
      this.empserfunction = this.selectedServiceLine.map(arr => { return arr.key; });
      if(this.selectedServiceLine.length>0){
        this.selectedFilter.parameter = 'serviceLine';
        this.selectedFilter.value = this.fullSerarr;
   
      }
    } else if (arrtype === 'emplocfuncion') {
      this.fullLocaarr[i].checked = event.checked;
      this.selectedLoc = this.fullLocaarr.filter(item => { return item.checked; });
      if(this.selectedLoc.length>0){
        this.selectedFilter.parameter = 'location';
        this.selectedFilter.value = this.fullLocaarr;
    
      }
      this.filter.empcity = this.selectedLoc.map(arr => { return arr.key.split('-')[0] });
      this.filter.empcountry = this.selectedLoc.map(arr => { return arr.key.split('-')[1] });
    }
    this.jobarr=[];
    this.subjobarr=[];
    this.serarr=[];
    this.locaarr=[];
    this.resetPeopleList.next("reset list");
    this.spinner.show();
    this.fetchData(0,10);
    this.jobfunarrText = "Show More...";
	  this.locarrrrText = "Show More...";
	  this.serrarrText = "Show More...";
	  this.jobsubfunarrText = "Show More...";
  }

  fetchData(fromCount,pageSize) {
    this.finalrequest = {
      empjobfunction: this.distejfunc.length > 0 ? this.distejfunc : null,
      empjobsubfuncion: this.empsubfunction.length > 0 ? this.empsubfunction : null,
      empserviceline: this.empserfunction.length > 0 ? this.empserfunction : null,
      filter: this.filter.empcity.length > 0 && this.filter.empcountry.length > 0 ? this.filter : null,
    };

    if (this.finalrequest.empjobfunction == null) {
      delete this.finalrequest.empjobfunction;
    } if (this.finalrequest.empjobsubfuncion == null) {
      delete this.finalrequest.empjobsubfuncion;
    } if (this.finalrequest.empserviceline == null) {
      delete this.finalrequest.empserviceline;
    } if (this.finalrequest.filter == null) {
      delete this.finalrequest.filter;
      if (this.finalrequest.emplocation == null)
        delete this.finalrequest.emplocation;
    }


     let keyword =  this.router['currentUrlTree'].queryParams.name;
      let searchselect = this.router['currentUrlTree'].queryParams.searchSelect;
      let refinedByFilters = this.finalrequest;
      
       this.peopleService.getuserwithadv(fromCount, keyword, searchselect,pageSize,refinedByFilters).then(
      (Ipeople) => {
        if(Ipeople.error){
          alert("Their is some technical error in the application. Please contact the system administrator.");
        }else{
         this.test.emit(Ipeople);
         this.spinner.hide();
        }
      }
    ), error => {
      
        alert("Their is some technical error in the application. Please contact the system administrator.");
      
    }; 
    this.jobfunarrText = "Show More...";
	  this.locarrrrText = "Show More...";
	  this.serrarrText = "Show More...";
	  this.jobsubfunarrText = "Show More...";
   }

  clearFilters(param){
     //ITTPPRD-1439
     this.router['currentUrlTree'].queryParams.refinedBy = ''
     //ITTPPRD-1439
      this.selectedFilter.parameter = '';
      this.selectedFilter.value = [];
      switch (param) {
        case "job":
          this.selectedJobArr = [];        
          this.distejfunc = []
          break;
        case "sub-job":
          this.selectedSubJob = [];        
          this.empsubfunction = []
          break;  

        case "serviceLine":
          this.selectedServiceLine = [];        
          this.empserfunction = []
          break; 
          
        case "location":
          this.selectedLoc = [];        
          this.filter = { empcity: [], empcountry: [] };
          break;

        case "all":
          this.selectedJobArr = [];        
          this.distejfunc = []
          this.selectedLoc = [];   
          this.selectedSubJob = [];        
          this.empsubfunction = []
          this.selectedServiceLine = [];        
          this.empserfunction = []     
          this.filter = { empcity: [], empcountry: [] };
          this.finalrequest = [];
          break;  
      }   
      this.resetPeopleList.next("reset list");
      this.spinner.show();
      this.fetchData(0,10);
      this.jobfunarrText = "Show More...";
      this.locarrrrText = "Show More...";
      this.serrarrText = "Show More...";
      this.jobsubfunarrText = "Show More...";
    
  }

 dynamicSort(property) {
    var sortOrder = 1;

    if(property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }

    return function (a,b) {
        if(sortOrder == -1){
            return b[property].localeCompare(a[property]);
        }else{
            return a[property].localeCompare(b[property]);
        }        
    }
}
}
