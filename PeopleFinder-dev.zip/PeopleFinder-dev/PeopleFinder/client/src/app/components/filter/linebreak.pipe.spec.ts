import { LinebreakPipe } from './linebreak.pipe';

describe('LinebreakPipe', () => {
  it('create an instance', () => {
    const pipe = new LinebreakPipe();
    expect(pipe).toBeTruthy();
  });
});
