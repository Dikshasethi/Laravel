import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AdvFields } from './advfields';
import _ from 'underscore';

@Component({
  selector: 'app-advanced-search',
  templateUrl: './advanced-search.component.html',
  styleUrls: ['./advanced-search.component.css']
})
export class AdvancedSearchComponent implements OnInit {
  advSearchFields: AdvFields[] = [
    { id: 'askmeabout', name: 'Ask me about' },
    { id: 'certificate', name: 'Certification' },
    { id: 'countries', name: 'Countries worked in' },
    { id: 'education', name: 'Education' },
    { id: 'communities', name: 'G+ Communities and Collections' },
    { id: 'hobbies', name: 'Interests and hobbies' },
    { id: 'empname', name: 'Name' },
    { id: 'spklang', name: 'Spoken Languages' },
    { id: 'sme', name: 'SME' },
    { id: 'trade', name: 'Trade association affiliations' }
  ];

  selectedField: AdvFields;


  @Output() messageEvent = new EventEmitter<AdvFields>();
  constructor() { }

  ngOnInit() {
    this.advSearchFields = _.sortBy(this.advSearchFields, "name")
  }

  onSelect(fieldSel: AdvFields): void {
    this.selectedField = fieldSel;
    this.messageEvent.emit(this.selectedField);
  }
}
