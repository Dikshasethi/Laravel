export class AdvFields {
    id: string;
    name: string;
}