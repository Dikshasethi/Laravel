import { Component, OnInit, TemplateRef } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TestBed } from '@angular/core/testing';
import { PeopleService } from 'src/app/services/people/people.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { stringify } from 'querystring';
import _ from 'underscore';

@Component({
  selector: 'app-label',
  templateUrl: './label.component.html',
  styleUrls: ['./label.component.css']
})
export class LabelComponent implements OnInit {

  displayedColumns: string[];
  dataSource;
  addlabel = '';
  temp;
  confirm: false;
  profileId: any;
  employee_id
  labelName;
  labelCount;
  labelList;
  result
  label: any;
  employeeID = "";
  people: any;
  ELEMENT_DATA = [];
  oldLabel = "";
  emp_id: any;
  records = false;
  message: string;
  labelAlreadyExist = false;
  mailData;
  currentIndex;
  isMailIconClicked = false;
  arr = []
  selectedLabel;
  totalCount = 0;
  skip = 0;
  limit = 15;
  labelToEmpIdsMap = {};
  emailDetails = {};
  emailIDsForLabel: Array<string> = [];
  isLoading = false;
  imageloaded : boolean = false
  constructor(public dialog: MatDialog, public peopleService: PeopleService, private router: Router, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    if (localStorage.getItem('isLoggedin') == null || localStorage.getItem('isLoggedin').toString() == '') {
      this.router.navigate(['/login']);
    }
    this.currentIndex = '0';
    this.profileId = JSON.parse(localStorage.getItem('isLoggedin')).employee_id;
    this.spinner.show();
    this.peopleService.fetchFavouriteData(this.profileId).then(
      (Response) => {
        this.result = Response
        if (this.result.empfavcollection[0] != undefined && this.result.empfavcollection[0].emplabels != undefined && this.result.empfavcollection[0].emplabels) {
          // Cannot read property 'emplabels' of undefined
          for (var i = 0; i < this.result.empfavcollection.length; i++) {
            this.labelList = this.result.empfavcollection[0].emplabels;


            this.labelName = Object.keys(this.labelList)

            let val = Object.values(this.labelList)
            for (let j = 0; j < val.length; j++) {
              this.arr.push({
                labelName: this.labelName[j],
                count: Object.keys(val[j]).length
              })

            }

            if (this.labelName != null && this.labelName.length > 0) {
              this.arr = _.sortBy(this.arr, 'labelName')
            }

          }
          if (this.isEmpty(this.labelList)) {
            this.records = true;
            this.spinner.hide();
          }
          else {
            this.fetchLabelData(this.arr[0].labelName, '');
            this.spinner.hide();
          }
          this.spinner.hide();
        }
        else {
          this.records = true;
          this.spinner.hide()
        }

      })
  }
  onReset() {
    this.addlabel = ''
  }


  openDialogfraddlbl(addLabelTemplate): void {
    this.addlabel = ''
    this.labelAlreadyExist = false;
    const dialogRef = this.dialog.open(addLabelTemplate, {
      width: '700px',
    });
  }

  openDialogremovelbl(removeLabelTemplate, removeLabel): void {
    this.label = removeLabel
    this.dialog.closeAll();
    const dialogRef = this.dialog.open(removeLabelTemplate, {
      width: '400px'
    });
  }

  openDialogforDelete(deleteEmployeefromLabelTemplate, employee_id, label): void {
    this.label = label;
    this.emp_id = employee_id
    this.dialog.closeAll();
    const dialogRef = this.dialog.open(deleteEmployeefromLabelTemplate, {
      width: '400px'
    });
  }

  openEditDialog(editLabelTemplate, editLabel): void {
    this.labelAlreadyExist = false;
    this.oldLabel = editLabel;
    this.label = editLabel;
    this.dialog.closeAll();
    const dialogRef = this.dialog.open(editLabelTemplate, {
      width: '400px'
    });
  }

  openDialogEmailToLabelIds(contacthrTemplate, labelname): void {
    let empIdsForLabel = this.labelToEmpIdsMap[labelname];
    this.emailIDsForLabel = [];
    let body = "";
    //let subject = "PeopleFinder : "+labelname+" label";
    let subject = "";
    this.getEmailIdsForLabel(empIdsForLabel);
    this.emailDetails['toAddresses'] = this.emailIDsForLabel;
    this.emailDetails['bodyContent'] = body;
    this.emailDetails['sub'] = subject;
    const dialogRef = this.dialog.open(contacthrTemplate, {
      width: '1000px'
    });
  }

  async getEmailIdsForLabel(empIds) {
    this.emailIDsForLabel = [];
    var length;
    if (empIds != '') {
      length = empIds.split(",").length;
    }
    if (length > 0) {
      await this.peopleService.getuserwithadv('0', empIds, 'peoplefinder', length, '').then(
        (res) => {
          if (res.data.hits.total != 0) {
            for (var i = 0; i < res.data.hits.hits.length; i++) {
              this.emailIDsForLabel.push(res.data.hits.hits[i]._source['employeeemail']);
            }
          }
        }), error => {
          alert("Something Went Wrong, Please try in sometime")
        };
    }
  }
  closelabel(addLabelTemplate) {
    this.dialog.closeAll();
  }
  removelabel(removeLabelTemplate) {
    this.dialog.closeAll();
  }

  isEmpty(obj) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key))
        return false;
    }
    return true;
  }

  async    saveLabel(label) {
    
    this.labelAlreadyExist = false;
    this.spinner.show();
    var type = "emplabels",
      empid = '';
    for (var i = 0; i < this.result.empfavcollection.length; i++) {
      this.labelList = this.result.empfavcollection[0].emplabels;
      if (this.labelList != null && this.labelList != undefined) {
        this.labelName = Object.keys(this.labelList);
        if (this.labelName != null && this.labelName.length > 0) {
          this.labelName.sort();
        }
      }

    }
    if (this.labelName != undefined && this.labelName.length > 0) {
      for (var i = 0; i < this.labelName.length; i++) {
        if (this.labelName[i] == label) {
          this.spinner.hide();
          this.labelAlreadyExist = true;
          break;
        }
      }
    }
    if (!this.labelAlreadyExist) {
      await this.peopleService.saveFavouriteOrLabel(this.profileId, type, empid, label).then(
        (Response) => {
        }
      ), error => alert("Something Went Wrong,Please try in sometime")
      await this.peopleService.fetchFavouriteData(this.profileId).then(
        (Response) => {
          this.result = Response;
          this.spinner.hide();
          for (var i = 0; i < this.result.empfavcollection.length; i++) {
            this.arr = [];
            this.labelList = this.result.empfavcollection[0].emplabels;
            this.labelName = Object.keys(this.labelList)
          }
        })
      this.spinner.hide();
      this.dialog.closeAll();
    }
    if (!this.labelAlreadyExist) {	
      this.ngOnInit();	
    }
  }

  async  fetchLabelData(label, id) {
    this.skip = 0;
    this.limit = 20;
    this.selectedLabel = label
    let emails = ''
    if (id.length == 0) {
      id = 0;
    }
    this.currentIndex = id;
    var btns = document.getElementsByClassName("label-selected");
    for (var i = 0; i < btns.length; i++) {
      var current = document.getElementsByClassName("label-selected");
      current[i].className = current[i].className.replace("label-selected", "");
    }
    this.spinner.show();
    this.employeeID = "";
    this.ELEMENT_DATA = [];
    this.dataSource = ""
    await this.peopleService.fetchFavouriteData(this.profileId).then(
      (Response) => {
        this.result = Response
        let labelKeys = Object.keys(this.result.empfavcollection[0].emplabels);
        for (var loop = 0; loop < labelKeys.length; loop++) {
          let empIDs = "";
          for (var idx = 0; idx < this.result.empfavcollection[0].emplabels[labelKeys[loop]].length; idx++) {
            let empid = this.result.empfavcollection[0].emplabels[labelKeys[loop]][idx].empid;
            if (empid != undefined) {
              if (empIDs != '') {
                empIDs = empIDs + "," + empid;
              } else {
                empIDs = empid;
              }
            }
          }
          this.labelToEmpIdsMap[labelKeys[loop]] = empIDs;
        }
        if (this.result.empfavcollection[0].emplabels[label] != undefined) {
          for (var i = 0; i < this.result.empfavcollection[0].emplabels[label].length; i++) {
            if (i == 0) this.employeeID = this.result.empfavcollection[0].emplabels[label][i].empid;
            else
              this.employeeID = this.employeeID + "," + this.result.empfavcollection[0].emplabels[label][i].empid;
          }

          if (this.employeeID != "") {
            this.records = false;
            this.displayedColumns = ['imgIcon', 'name', 'email', 'phonenumber', 'businesstitle', 'deleIcon'];
            this.peopleService.getuserwithadv(this.skip, this.employeeID, 'peoplefinder', this.limit, '').then(
              (res) => {
                let empIdsForimage = []
                this.people = res;
                if (this.people.data.hits.total != 0) {
                  this.totalCount = this.people.data.hits.total
                  for (i = 0; i < this.people.data.hits.hits.length; i++) {
                    empIdsForimage.push(this.people.data.hits.hits[i]._id)
                    let obj = {
                      'id': this.people.data.hits.hits[i]._id,
                      'name': this.people.data.hits.hits[i]._source['employeename'],
                      'email': this.people.data.hits.hits[i]._source['employeeemail'],
                      'phonenumber': this.people.data.hits.hits[i]._source['empoiispeeddial'],
                      'businesstitle': this.people.data.hits.hits[i]._source['empbusinesstitle'],
                      'label': label
                    }
                    this.ELEMENT_DATA.push(obj)
                  }
                  this.spinner.hide();
                  this.dataSource = this.ELEMENT_DATA;
                  this.isLoading = false;
                  if(id>=0) {
                    const element = document.getElementById(id);
                    element.classList.add("label-selected");
                  }
                  this.peopleService.getEmpImageById(empIdsForimage)
                    .then (empImageResponse => {
                     for(let empimg of empImageResponse.data){
                        const indx = empIdsForimage.indexOf(empimg.employeeId);
                        empIdsForimage.splice(indx, 1);
                        let empObj = this.ELEMENT_DATA.find((item) => item.id == empimg.employeeId);
                        if (empObj && empimg.signedUrl_compressed) {
                          empObj['empimage'] = empimg.signedUrl_compressed;
                        } else {
                          empObj['empimage'] = "/assets/images/img-avatar.png";
                        }
                      }
                      if (empIdsForimage.length > 0) {
                        for (let j = 0; j < empIdsForimage.length; j++) {
                          let empObj = this.ELEMENT_DATA.find((item) => item.id == empIdsForimage[j]);
                          empObj['empimage'] = "/assets/images/img-avatar.png";
                        } 
                      }
                      this.imageloaded = true
                    }).catch ( error =>{
                      for (let j = 0; j < empIdsForimage.length; j++) {
                        let empObj = this.ELEMENT_DATA.find((item) => item.id == empIdsForimage[j]);
                        empObj['empimage'] = "/assets/images/img-avatar.png";
                        this.imageloaded = true
                      }
                    })
                }
              }), error => {
                this.spinner.hide()
                alert("Something Went Wrong, Please try in sometime")

              };
          } else {
            this.spinner.hide()
            this.displayedColumns = [];
            this.records = true;

          }
        }

      }), error => {
        this.spinner.hide()
        alert("Something Went Wrong, Please try in sometime")

      };
    if(id>=0){
      const element = document.getElementById(id);
      element.classList.add("label-selected");
    }
  }

  async deleteLabel() {
    this.spinner.show();
    let deletedIndex = this.arr.findIndex(x => x.labelName === this.label);
    await this.peopleService.deleteLabel(this.profileId, this.label).then(
      (Response) => {
      }
    ), error => alert("Something Went Wrong, Please try in sometime")
    this.profileId = JSON.parse(localStorage.getItem('isLoggedin')).employee_id;
    await this.peopleService.fetchFavouriteData(this.profileId).then(
      (Response) => {
        this.result = Response
        this.spinner.hide()
        this.displayedColumns = [];
        this.records = true;
        this.message = "No Record Found"
        this.arr = []

        for (var i = 0; i < this.result.empfavcollection.length; i++) {
          this.labelList = this.result.empfavcollection[0].emplabels;

          this.labelName = Object.keys(this.labelList);
          let val = Object.values(this.labelList)

          for (let j = 0; j < val.length; j++) {
            this.arr.push({
              labelName: this.labelName[j],
              count: Object.keys(val[j]).length
            })

          }
          if (this.labelName != null && this.labelName.length > 0) {
                  this.arr = _.sortBy(this.arr, 'labelName')
                  if(this.currentIndex == deletedIndex)
                     this.fetchLabelData(this.arr[0].labelName, 0);
                    else if(this.currentIndex < deletedIndex)
                    this.fetchLabelData(this.arr[this.currentIndex].labelName, this.currentIndex);
                    else if(this.currentIndex > deletedIndex)
                    this.fetchLabelData(this.arr[this.currentIndex-1].labelName, this.currentIndex-1);
                    else
                      this.fetchLabelData(this.arr[0].labelName, 0);
          }
          else
          {
           this.fetchLabelData('', -1);
          }
        }
      })
    this.dialog.closeAll();
    this.spinner.hide();

  }

  async editLabel() {
    this.spinner.show();
    this.labelAlreadyExist = false;
    await this.peopleService.fetchFavouriteData(this.profileId).then(
      (Response) => {
        this.result = Response
        for (var i = 0; i < this.result.empfavcollection.length; i++) {
          this.labelList = this.result.empfavcollection[0].emplabels;


          this.labelName = Object.keys(this.labelList);
          if (this.labelName != null && this.labelName.length > 0) {
            this.labelName.sort();
          }

        }
      })
    for (var i = 0; i < this.labelName.length; i++) {

      if (this.labelName[i] == this.label) {
        this.spinner.hide();
        this.labelAlreadyExist = true;
        break;
      }
    }
    if (!this.labelAlreadyExist) {

      await this.peopleService.updateLabel(this.profileId, this.oldLabel, this.label).then(
        (Response) => {

        }
      ), error => alert("Something Went Wrong, Please try in sometime")
      await this.peopleService.fetchFavouriteData(this.profileId).then(
        (Response) => {
          this.result = Response
          this.spinner.hide();
          this.arr = []

          for (var i = 0; i < this.result.empfavcollection.length; i++) {
            this.labelList = this.result.empfavcollection[0].emplabels
            this.labelName = Object.keys(this.labelList);

            let val = Object.values(this.labelList)
            for (let j = 0; j < val.length; j++) {
              this.arr.push({
                labelName: this.labelName[j],
                count: Object.keys(val[j]).length
              })

            }

            if (this.labelName != null && this.labelName.length > 0) {
              this.arr = _.sortBy(this.arr, 'labelName')
            }

            // if (this.labelName != null && this.labelName.length > 0) {
            //   this.labelName.sort();
            // }
          }


        })
      this.spinner.hide();
      this.dialog.closeAll();
    }

  }

  async deleteEmployee() {
    await this.peopleService.deleteLabelForEmployee(this.profileId, this.emp_id, this.label).then(
      (Response) => {
      }
    ), error => alert("Something Went Wrong, Please try in sometime")
    let x = this.arr.findIndex(x => x.labelName === this.label);
    this.arr[x].count = this.arr[x].count - 1;
    this.fetchLabelData(this.label, x);
    this.dialog.closeAll();
  }
  onSelectClick(searchkey) {

    this.router.navigate(['/people/'], { queryParams: { name: searchkey, searchSelect: 'peoplefinder', noRecoFav: "notext" } });
  }
  onScroll(event) {

    if (this.skip < this.totalCount) {
      this.skip += this.limit;

      if (this.employeeID != "") {
        // this.spinner.show()
        
        this.records = false;
        this.displayedColumns = ['imgIcon', 'name', 'email', 'phonenumber', 'businesstitle', 'deleIcon'];
        this.peopleService.getuserwithadv(this.skip, this.employeeID, 'peoplefinder', this.limit, '').then(
          
          (res) => {

            this.people = res;
            if (this.people.data.hits.hits && this.people.data.hits.total != 0) {
              for (let i = 0; i < this.people.data.hits.hits.length; i++) {

                let obj = {
                  'id': this.people.data.hits.hits[i]._id,
                  'name': this.people.data.hits.hits[i]._source['employeename'],
                  'email': this.people.data.hits.hits[i]._source['employeeemail'],
                  'phonenumber': this.people.data.hits.hits[i]._source['empoiispeeddial'],
                  'businesstitle': this.people.data.hits.hits[i]._source['empbusinesstitle'],
                  'label': this.selectedLabel
                }
                this.dataSource.push(obj)

              }
              this.spinner.hide()
              this.dataSource = [...this.dataSource];
              this.isLoading = false;
              // this.dataSource = this.ELEMENT_DATA

              this.isMailIconClicked = false

            }
            this.spinner.hide();
          }), error => {
            this.spinner.hide();
            alert("Something Went Wrong, Please try in sometime")

          };

      } else {
        this.spinner.hide()
        this.displayedColumns = [];
        this.records = true;

      }
    }
  }
}  
