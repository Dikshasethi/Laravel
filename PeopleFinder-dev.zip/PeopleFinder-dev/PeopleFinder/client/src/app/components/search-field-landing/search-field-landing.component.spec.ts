import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFieldLandingComponent } from './search-field-landing.component';

describe('SearchFieldLandingComponent', () => {
  let component: SearchFieldLandingComponent;
  let fixture: ComponentFixture<SearchFieldLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchFieldLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFieldLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
