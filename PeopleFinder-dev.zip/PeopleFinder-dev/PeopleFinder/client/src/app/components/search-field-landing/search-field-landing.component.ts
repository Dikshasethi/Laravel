import { Component, OnInit, HostListener,Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { SnotifyService, SnotifyPosition, SnotifyToastConfig } from '../../../../node_modules/ng-snotify';
// import { SnotifyService, SnotifyPosition, SnotifyToastConfig } from 'ng-snotify';
import { PeopleService } from '../../services/people/people.service';
import { AdvFields } from '../advanced-search/advfields'
import { appConfigurationService } from '@/services/appConfigurationService';

@Component({
  selector: 'app-search-field-landing',
  templateUrl: './search-field-landing.component.html',
  styleUrls: ['./search-field-landing.component.css']
})
export class SearchFieldLandingComponent implements OnInit {
  // ITTPPRD-1439
//	@ViewChild('matAutocompleteTrigger') auto : MatAutocompleteTrigger
  
  // ITTPPRD-1439
  selectedValue: string;
  searchkey = '';
  myId = '02034027';
  inputparam: any;
  isShowTopSearchbar: boolean;
  removedquotes: string;
  removedquotesarr = [];
  loggedinuser: string;
  message: any;
  shareparam: any;
  selected: string;
  id: string;
  username = localStorage.getItem('isLoggedin');
  isAdvSearch = "none";
  fieldSelect: AdvFields = { id: 'defaultField', name: 'Advanced Search' };
  selectedName: string = 'Search people, attributes, skills, etc.';
  isFocusInsideComponent = false;
  isComponentClicked = false;
  suggesters : any = []
  configData: any = [];
  refinedByKey : string = '';
  selectedOption : string = 'peoplefinder'
  @HostListener('click')
  clickInside() {
    if (!this.isFocusInsideComponent && this.isComponentClicked && this.isAdvSearch == "none") {
      this.isAdvSearch = "none";
    }
    this.isFocusInsideComponent = true;
    this.isComponentClicked = true;


  }

  @HostListener('document:click')
  clickout() {
    if (!this.isFocusInsideComponent && this.isComponentClicked) {
      this.isAdvSearch = "none";
      this.isComponentClicked = false;
    }
    this.isFocusInsideComponent = false;
  }

  constructor(public peopleService: PeopleService, private router: Router, private snotifyService: SnotifyService, private appconfig: appConfigurationService) { }

  ngOnInit() {
    // this.selectedValue="Advance Search";
    this.selectedValue = 'peoplefinder';
    this.appconfig.getJSON().subscribe(data => {
      this.configData = data;
    });
  }
  AddAdvCritiria(attr) {

    if ("defaultField" == attr) {
      document.getElementById('tickpeoplefinder').classList.add('advsrchTick');
    }
    if (this.isAdvSearch == "block") {
      this.isAdvSearch = "none";
      this.isComponentClicked = false;
      this.isFocusInsideComponent = false;
      document.getElementById('arrowid').classList.remove('upArw');
    }
    else {
      this.isAdvSearch = "block";
      document.getElementById('arrowid').classList.add('upArw');
    }
  }
  hideAdvCriteria() {
    if (this.isAdvSearch == "block") {
      this.isAdvSearch = "none";
      document.getElementById('arrowid').classList.remove('upArw');
    }
  }
  setfoucs() {
    let objMat = document.getElementById('searchppl');
    if (objMat != null) {
      objMat.focus();
    }
  }
  selectedAdvField($event) {
    this.fieldSelect = $event;
    this.selectedName = 'Search by ' + this.fieldSelect.name;
    this.selectedValue = this.fieldSelect.id;
    var lights = document.getElementsByClassName("advsrchTick");
    while (lights.length)
      lights[0].classList.remove("advsrchTick");
    document.getElementById('tick' + this.fieldSelect.id).classList.add('advsrchTick');
  }

  searchPeople() {

    try {
      if (this.searchkey.includes('"')) {
        if (this.searchkey.includes(',')) {
          if (this.selectedValue === 'peoplefinder') {
            this.snotifyService.error('You cant search multiple people from basic search');
            return false;
          }
          const newStr = this.searchkey.substring(0, this.searchkey.length - 1);
          this.router.navigate(['/people/'], { queryParams: { name: '"' + newStr.slice(1).replace('"', '').replace('"', '').replace(',', '","') + '"', searchSelect: this.selectedValue } });
        } else {
          const newStr = this.searchkey.substring(0, this.searchkey.length - 1);
          this.router.navigate(['/people/'], { queryParams: { name: '"' + newStr.slice(1) + '"', searchSelect: this.selectedValue,refinedBy :this.refinedByKey } });
        }
      } else {
        if (this.searchkey.includes(',')) {
          this.router.navigate(['/people/'], { queryParams: { name: this.searchkey, searchSelect: this.selectedValue } });
        } else {
          this.router.navigate(['/people/'], { queryParams: { name: this.searchkey, searchSelect: this.selectedValue ,refinedBy :this.refinedByKey} });
        }
      }
    } catch (e) {
    }
  }
 
  // ITTPPRD-1439
    getSuggesters() {
        let keycode = this.configData.suggesters[this.selectedValue].keycode
        let dataObj = {
            keycode : keycode,
            value : this.searchkey
        }
        if(this.searchkey !=='' ){
			this.peopleService.getSuggesters(dataObj).subscribe(res => {
				this.suggesters = res['data'];
			}),
			error => {
				alert(error)
			};
		} else {
			this.suggesters = [];
		}
    }
    searchedIn(suggester, withoutIn = false ){
      if(!withoutIn){
		this.searchkey = suggester.val
		let key = this.getKey(this.configData.suggesters,suggester.label);  
		this.selectedValue = key !==undefined ? key : this.selectedOption;
		key = this.getKey(this.configData.refinedBy,suggester.label);  
		this.refinedByKey = this.selectedValue === this.selectedOption && key !==undefined ? key : ''
      }
      this.searchPeople()
    }
    getKey = (obj : Object ,val : String) => Object.keys(obj).find(key => obj[key].label === val);

    // ITTPPRD-1439
}
