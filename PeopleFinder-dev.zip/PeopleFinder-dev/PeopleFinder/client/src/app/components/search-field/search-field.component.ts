
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { SnotifyService, SnotifyPosition, SnotifyToastConfig } from '../../../../node_modules/ng-snotify';
// import { SnotifyService, SnotifyPosition, SnotifyToastConfig } from 'ng-snotify';
import { PeopleService } from '../../services/people/people.service';
import _ from 'underscore';
import { ProfileComponent } from "../profile/profile.component"; 
import { appConfigurationService } from '@/services/appConfigurationService';
@Component({
  selector: 'app-search-field',
  templateUrl: './search-field.component.html',
  styleUrls: ['./search-field.component.css']

})
export class SearchFieldComponent implements OnInit {
  selectedValue: string;
  searchkey = '';
  myId = '02034027';
  inputparam: any;
  isShowTopSearchbar: boolean;
  removedquotes: string;
  removedquotesarr = [];
  loggedinuser: string;
  message: any;
  shareparam: any;
  selected: string;
  id: string;
  username = localStorage.getItem('isLoggedin');
  SelectTitle: string = "People Finder";
  @ViewChild('searchDropdown') nameInputRef: ElementRef;
  configData: any = [];
  suggesters : any = [];
  selectedOption : string = 'peoplefinder'
  refinedByKey : string = '';
  advSearchFields = [
    // { id: 'peoplefinder', name: 'PeopleFinder' },
    { id: 'askmeabout', name: 'Ask me about' },
    { id: 'certificate', name: 'Certification' },
    { id: 'countries', name: 'Countries worked in' },
    { id: 'education', name: 'Education' },
    { id: 'communities', name: 'G+ Communities and Collections' },
    { id: 'hobbies', name: 'Interests and hobbies' },
    { id: 'empname', name: 'Name' },    
    { id: 'sme', name: 'SME' },
    { id: 'spklang', name: 'Spoken Languages' },
    { id: 'trade', name: 'Trade association affiliations' }
  ];

  constructor(public peopleService: PeopleService, private router: Router, private snotifyService: SnotifyService, private appconfig: appConfigurationService) { }

  ngOnInit() {
    this.advSearchFields = _.sortBy(this.advSearchFields, "name")


    this.selectedValue = this.router['currentUrlTree'].queryParams.searchSelect;
    if (this.router['currentUrlTree'].queryParams.noRecoFav != 'notext') {
      this.searchkey = this.router['currentUrlTree'].queryParams.name;
    }
    if (this.selectedValue == undefined) {
      this.selectedValue = 'peoplefinder'
	}
	this.appconfig.getJSON().subscribe(data => {
		this.configData = data;
	});
  }
  searchPeople() {
    if (this.selectedValue == undefined) {
      this.selectedValue = 'peoplefinder'
    }
    try {
      if (this.searchkey == undefined)
        this.searchkey = ''
      if (this.selectedValue === 'peoplefinder' && this.searchkey.includes(',')) {
        this.snotifyService.error('You cant search multiple people from basic search');
        return false;
      } else {
        this.router.routeReuseStrategy.shouldReuseRoute = function () { return false; };

        let currentUrl = this.router.url;

        this.router.navigateByUrl(currentUrl)
          .then(() => {
            this.router.navigated = false;
            this.router.navigate(['/people/'], { queryParams: { name: this.searchkey, searchSelect: this.selectedValue ,refinedBy :this.refinedByKey} });
          });
      }
    } catch (e) {
    }
  }

  onChangeSearchSelect(data) {
    let trigger = data.trigger;
    setTimeout(() => {
      let title = trigger.nativeElement.textContent;
      this.SelectTitle = title;
	}, 100)
	this.clearSuggesters()
  }
	// ITTPPRD-1439
	clearSuggesters( ){
		this.suggesters = [];
	}
	getSuggesters() {
		let keycode = this.configData.suggesters[this.selectedValue].keycode
		let dataObj = {
			keycode : keycode,
			value : this.searchkey
		}
		if(this.searchkey !=='' ){
			this.peopleService.getSuggesters(dataObj).subscribe(res => {
				this.suggesters = res['data'];
			}),
			error => {
				alert(error)
			};
		} else {
			this.suggesters = [];
		}
	}
	searchedIn(suggester, withoutIn = false ){
		if(!withoutIn){
			this.searchkey = suggester.val
			let key = this.getKey(this.configData.suggesters,suggester.label);  
			this.selectedValue = key !==undefined ? key : this.selectedOption;
			key = this.getKey(this.configData.refinedBy,suggester.label);  
			this.refinedByKey = this.selectedValue === this.selectedOption && key !==undefined ? key : ''
		} 
    	this.searchPeople()
  	}
	getKey = (obj : Object ,val : String) => Object.keys(obj).find(key => obj[key].label === val);

	// ITTPPRD-1439
}
