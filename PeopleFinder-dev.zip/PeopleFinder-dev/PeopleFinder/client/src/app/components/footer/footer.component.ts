import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  public dispblock: string = 'hide';

  constructor(private router: Router) { }
  routerUrl: any;
  copyrightYear: any;
  isShowFooter: boolean = true;
  ngOnInit() {
    this.copyrightYear = new Date().getFullYear();
    this.routerUrl = this.router.url;
    if (this.routerUrl.includes("/landing")
      || this.routerUrl.includes("/myprofile")
      || this.routerUrl.includes("/mylabel")
      || this.routerUrl.includes("/people")) {
      this.isShowFooter = false;
    }
  }
}
