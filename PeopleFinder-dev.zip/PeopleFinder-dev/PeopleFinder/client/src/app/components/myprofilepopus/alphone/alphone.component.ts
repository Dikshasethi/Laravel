import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PeopleService } from '../../../services/people/people.service';
import { formatDate } from '@angular/common';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { Component, OnInit, Inject, ViewChild, ViewChildren, ContentChild, TemplateRef, Input, Output, EventEmitter } from '@angular/core';

@Component({
	selector: 'app-alphone',
	templateUrl: './alphone.component.html',
	styleUrls: ['./alphone.component.css']
})
export class AlPhoneComponent implements OnInit {
	@Input() alphn: any;
	@Output() alternatePhonesaveData = new EventEmitter()
	hobbarrreplica: any = [{
		'altnumber': '',
		'id': '-1',
		'altnumberhasorder': ''
	}
	];
	alphoneKeyCode = 12;
	hobbBaselength: Number;
	formfieldlength: Number;
	UpdateCount = 0;
	InsertCount = 0;
	saveresponse = "";
	today = new Date();
	FinalJSON: any = {
		user: JSON.parse(localStorage.getItem('isLoggedin').toString()).emp_name,
		eswdocument: {
			empaltnumber: [{
				'altnumber': '',
				'id': '',
				'altnumberhasorder': ''
			}
			],
		},
		wsapicontent: {
			insertions: 0,
			updations: 0,
			array: [{
				'uniqueid': '',
				'ID': '',
				'device': 'W',
				'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
				'keycode': '12',
				'keyword': 'Alternative phone number',
				'txtvalue': '',
				'hasorder': '',
				'isdeleted': '0',
				'modifiedby': '',
				'modifiedate': '',
				'createdby': '',
				'createddate': ''

			}]
		}
	};

	constructor(public dialog: MatDialog, private peopleService: PeopleService, private router: Router, private spinner: NgxSpinnerService, private location: Location) {
	}
	ngOnInit() {
		if (this.alphn != undefined) {
			if (Array.isArray(this.alphn)) {
				if (this.alphn[0] != undefined && this.alphn[0].length != undefined && this.alphn[0].length > 0) {
					this.hobbarrreplica.splice(0, 1);
					this.hobbarrreplica.push(JSON.parse(JSON.stringify(this.alphn[0])));
				}
				if (this.hobbarrreplica.length < 1) {
					this.hobbarrreplica.push({
						'altnumber': '', 'id': '-1',
						'altnumberhasorder': this.hobbarrreplica.length + 1 + ''
					});
				}
			} else {
				if (this.isEmptyObject(this.alphn)) {
					this.hobbarrreplica = [JSON.parse(JSON.stringify(this.alphn))];
				}
			}
		}

	}
	onNoClickfrall() {
		this.dialog.closeAll();
	}
	isEmptyObject(obj) {
		for (var key in obj) {
			if (Object.prototype.hasOwnProperty.call(obj, key)) {
				return true;
			}
		}
		return false;
	}
	createupdateArr(event: any, hobb, currentindex, baseindex) {
		let flag1 = false;
		if (hobb.altnumber == '') {
			for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
				this.FinalJSON.wsapicontent.array[i].isdeleted = '1';
				this.FinalJSON.wsapicontent.array[i].txtvalue = hobb.altnumber;
				this.FinalJSON.wsapicontent.array[i].hasorder = '1';
				this.FinalJSON.wsapicontent.array[i].device = 'W';
				this.FinalJSON.wsapicontent.array[i].uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.alphoneKeyCode + currentindex;
				this.FinalJSON.wsapicontent.array[i].modifiedby = (localStorage.getItem('loggedinUser').toString());
				this.FinalJSON.wsapicontent.array[i].modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
				this.FinalJSON.wsapicontent.array[i].keycode = this.alphoneKeyCode;
				this.FinalJSON.wsapicontent.array[i].keyword = 'Alternative phone number';
				this.FinalJSON.wsapicontent.updations = '1';
				this.FinalJSON.wsapicontent.insertions = '0';
				delete this.FinalJSON.wsapicontent.array[i]["ID"];
				this.FinalJSON.eswdocument.empaltnumber[i].delete = true;
				this.FinalJSON.eswdocument.empaltnumber[i].altnumberhasorder = '1';
				this.FinalJSON.eswdocument.empaltnumber[i].id = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.alphoneKeyCode + '1';
			}
		} else {
			for (const entry of this.FinalJSON.wsapicontent.array) {
				flag1 = true;
				entry.txtvalue = hobb.altnumber;
				entry.isdeleted = '0';
				entry.uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.alphoneKeyCode + currentindex;
				entry.ID = hobb.id;
				entry.keycode = this.alphoneKeyCode + '';
				entry.employeeid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id;
				entry.uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.alphoneKeyCode + currentindex;
				entry.keyword = 'Alternative phone number';
				entry.hasorder = currentindex + '';
				entry.device = 'W';
				if (hobb.id != '-1') {
					entry.modifiedby = (localStorage.getItem('loggedinUser').toString());
					entry.modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
					delete entry["ID"];
				} else {
					entry.createdby = (localStorage.getItem('loggedinUser').toString());
					entry.createddate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
				}
				this.FinalJSON.wsapicontent.updations = (hobb.id == '-1') ? '0' : '1';
				this.FinalJSON.wsapicontent.insertions = (hobb.id == '-1') ? '1' : '0';
			}
		}

		let deleteflag = false;
		for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			this.FinalJSON.eswdocument.empaltnumber.splice(i, 1);
			if (this.FinalJSON.wsapicontent.array[i].isdeleted == '1') {
				deleteflag = true;
			}
			if (deleteflag) {
				this.FinalJSON.eswdocument.empaltnumber.push({
					'altnumber': this.FinalJSON.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
					'altnumberhasorder': this.FinalJSON.wsapicontent.array[i].hasorder,
					'delete': true,
				});
			} else {
				this.FinalJSON.eswdocument.empaltnumber.push({
					'altnumber': this.FinalJSON.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
					'altnumberhasorder': this.FinalJSON.wsapicontent.array[i].hasorder,
				});
			}
		}
	}

	onOkClick() {
		if (this.FinalJSON.wsapicontent.updations > 0 || this.FinalJSON.wsapicontent.insertions > 0) {
			let jp: any = this.FinalJSON.eswdocument.empaltnumber[0];
			this.FinalJSON.eswdocument.empaltnumber.splice(0, 1);
			this.FinalJSON.eswdocument.empaltnumber = jp;
			this.spinner.show();
			this.alternatePhonesaveData.emit(this.FinalJSON);
		}
	}
	onReset() {
		let i = 0;
		for (i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			this.FinalJSON.wsapicontent.array[i].isdeleted = '1';
			this.FinalJSON.wsapicontent.array[i].txtvalue = '';
			this.FinalJSON.wsapicontent.array[i].hasorder = '1';
			this.FinalJSON.wsapicontent.array[i].uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.alphoneKeyCode + '1';
			this.FinalJSON.wsapicontent.array[i].modifiedby = (localStorage.getItem('loggedinUser').toString());
			this.FinalJSON.wsapicontent.array[i].modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
			delete this.FinalJSON.wsapicontent.array[i]["ID"];
			this.FinalJSON.eswdocument.empaltnumber[i].delete = true;
			this.FinalJSON.eswdocument.empaltnumber[i].altnumber = '';
			this.FinalJSON.eswdocument.empaltnumber[i].altnumberhasorder = '1';
			this.FinalJSON.eswdocument.empaltnumber[i].id = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.alphoneKeyCode + '1';
		}
		this.FinalJSON.wsapicontent.updations = i;
		this.FinalJSON.wsapicontent.insertions = 0;
		for (let j = 0; j < this.hobbarrreplica.length; j++) {
			this.hobbarrreplica[j].altnumber = '';
		}
	}
}

