import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { strict } from 'assert';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PeopleService } from '../../../services/people/people.service';
import { ProfileComponent } from '../../profile/profile.component';
import { formatDate } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Location } from '@angular/common';

@Component({
	selector: 'app-networks',
	templateUrl: './networks.component.html',
	styleUrls: ['./networks.component.css']
})
export class NetworksComponent implements OnInit {
	@Output() networksSaveData = new EventEmitter()
	@Input() nwarr: any;
	hobbarrreplica: any = [{
		'emplinkedin': '',
		'id': '-1',
		'emplinkedinhasorder': '1'
	}
	];
	hobbarrreplicagpls: any = [{
		'empgoogleplus': '',
		'id': '-1',
		'empgoogleplushasorder': '1'
	}
	];
	linkedInKeyCode = 7;
	gplsKeyCode = 8;
	hobbBaselength: Number;
	formfieldlength: Number;
	UpdateCount = 0;
	InsertCount = 0;
	saveresponse = "";
	today = new Date();
	FinalJSON: any = {
		user: JSON.parse(localStorage.getItem('isLoggedin').toString()).emp_name,
		eswdocument: {
			emplinkedindetails: [{
				'emplinkedin': '',
				'id': '',
				'emplinkedinhasorder': ''
			}
			],
		},
		wsapicontent: {
			insertions: 0,
			updations: 0,
			array: [{
				'uniqueid': '',
				'ID': '',
				'device': 'W',
				'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
				'keycode': '7',
				'keyword': 'LinkedIn',
				'txtvalue': '',
				'hasorder': '',
				'isdeleted': '0',
				'modifiedby': '',
				'modifiedate': '',
				'createdby': '',
				'createddate': ''

			}]
		}
	};
	FinalJSONGPls: any = {
		user: JSON.parse(localStorage.getItem('isLoggedin').toString()).emp_name,
		eswdocument: {
			empgoogleplusdetails: [{
				'empgoogleplus': '',
				'id': '',
				'empgoogleplushasorder': ''
			}
			],
		},
		wsapicontent: {
			insertions: 0,
			updations: 0,
			array: [{
				'uniqueid': '',
				'ID': '',
				'device': 'W',
				'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
				'keycode': '8',
				'keyword': 'Google Plus',
				'txtvalue': '',
				'hasorder': '',
				'isdeleted': '0',
				'modifiedby': '',
				'modifiedate': '',
				'createdby': '',
				'createddate': ''

			}]
		}
	};

	idmatchcard: boolean = false;

	constructor(public dialog: MatDialog, private peopleService: PeopleService, private router: Router, private spinner: NgxSpinnerService, private location: Location) {
		// this.hobbBaselength=this.hobbarrreplica.length;
	}
	ngOnInit() {
		if (this.isEmptyObject(this.nwarr.emplinkedindetails)) {
			for (let k = 0; k < this.nwarr.emplinkedindetails.length; k++) {

				if (this.nwarr.emplinkedindetails[k].emplinkedinhasorder == undefined ||
					this.nwarr.emplinkedindetails[k].emplinkedinhasorder == 'undefined' ||
					new String(this.nwarr.emplinkedindetails[k].emplinkedinhasorder).length == 0 ||
					this.nwarr.emplinkedindetails[k].id == undefined ||
					this.nwarr.emplinkedindetails[k].id.length == 0) {
					this.nwarr.emplinkedindetails.splice(k, 1);
					k = k - 1;
				}

			}
			if (this.isEmptyObject(this.nwarr.emplinkedindetails)) {
				if (Array.isArray(this.nwarr.emplinkedindetails)) {
					this.hobbarrreplica = JSON.parse(JSON.stringify(this.nwarr.emplinkedindetails));
				} else {
					this.hobbarrreplica = [JSON.parse(JSON.stringify(this.nwarr.emplinkedindetails))];
				}
			}

		}
		if (this.isEmptyObject(this.nwarr.empgoogleplusdetails)) {
			for (let k = 0; k < this.nwarr.empgoogleplusdetails.length; k++) {

				if (this.nwarr.empgoogleplusdetails[k].empgoogleplushasorder == undefined ||
					this.nwarr.empgoogleplusdetails[k].empgoogleplushasorder == 'undefined' ||
					new String(this.nwarr.empgoogleplusdetails[k].empgoogleplushasorder).length == 0 ||
					this.nwarr.empgoogleplusdetails[k].id == undefined ||
					this.nwarr.empgoogleplusdetails[k].id.length == 0) {
					this.nwarr.empgoogleplusdetails.splice(k, 1);
					k = k - 1;
				}

			}
			if (this.isEmptyObject(this.nwarr.empgoogleplusdetails)) {
				if (Array.isArray(this.nwarr.empgoogleplusdetails)) {
					this.hobbarrreplicagpls = JSON.parse(JSON.stringify(this.nwarr.empgoogleplusdetails));
				} else {
					this.hobbarrreplicagpls = [JSON.parse(JSON.stringify(this.nwarr.empgoogleplusdetails))];
				}
			}
		}
	}
	onNoClickfrall() {
		const dialogRef = this.dialog.closeAll();
	}
	isEmptyObject(obj) {

		for (var key in obj) {
			if (Object.prototype.hasOwnProperty.call(obj, key)) {
				return true;
			}
		}
		return false;
	}
	createupdateArr(event: any, hobb, currentindex, baseindex) {
		let flag1 = false;
		if (hobb.empgoogleplus == '') {
			for (let i = 0; i < this.FinalJSONGPls.wsapicontent.array.length; i++) {

				this.FinalJSONGPls.wsapicontent.array[i].isdeleted = '1';
				this.FinalJSONGPls.wsapicontent.array[i].txtvalue = hobb.empgoogleplus;
				this.FinalJSONGPls.wsapicontent.array[i].hasorder = hobb.empgoogleplushasorder;
				this.FinalJSONGPls.wsapicontent.array[i].uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.gplsKeyCode + currentindex;
				this.FinalJSONGPls.wsapicontent.array[i].modifiedby = (localStorage.getItem('loggedinUser').toString());
				this.FinalJSONGPls.wsapicontent.array[i].modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
				this.FinalJSONGPls.wsapicontent.array[i].keycode = this.gplsKeyCode;
				this.FinalJSONGPls.wsapicontent.array[i].keyword = 'Google Plus';
				this.FinalJSONGPls.wsapicontent.array[i].device = 'W';
				delete this.FinalJSONGPls.wsapicontent.array[i].ID;
				delete this.FinalJSONGPls.wsapicontent.array[i].createddate;
				delete this.FinalJSONGPls.wsapicontent.array[i].createdby;
				this.FinalJSONGPls.wsapicontent.updations = '1';
				this.FinalJSONGPls.wsapicontent.insertions = '0';
			}
		} else {
			if (hobb.id == '-1') {
			}
			for (const entry of this.FinalJSONGPls.wsapicontent.array) {
				flag1 = true;
				entry.txtvalue = hobb.empgoogleplus;
				entry.isdeleted = '0';
				entry.uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.gplsKeyCode + currentindex;
				entry.ID = hobb.id;
				entry.device = 'W';
				entry.keycode = this.gplsKeyCode + '';
				entry.employeeid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id;
				entry.keyword = 'Google Plus';
				entry.hasorder = hobb.empgoogleplushasorder + '';
				if (hobb.id != '-1') {
					entry.modifiedby = (localStorage.getItem('loggedinUser').toString());
					entry.modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
					delete entry["ID"];
				} else {
					entry.createdby = (localStorage.getItem('loggedinUser').toString());
					entry.createddate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
				}
				this.FinalJSONGPls.wsapicontent.updations = (hobb.id == '-1') ? '0' : '1';
				this.FinalJSONGPls.wsapicontent.insertions = (hobb.id == '-1') ? '1' : '0';
			}

		}

		let deleteflag = false;
		for (let i = 0; i < this.FinalJSONGPls.wsapicontent.array.length; i++) {
			this.FinalJSONGPls.eswdocument.empgoogleplusdetails.splice(i, 1);
			if (this.FinalJSONGPls.wsapicontent.array[i].isdeleted == '1') {
				deleteflag = true;
			}
			if (deleteflag) {
				this.FinalJSONGPls.eswdocument.empgoogleplusdetails.push({
					'empgoogleplus': this.FinalJSONGPls.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSONGPls.wsapicontent.array[i].uniqueid,
					'empgoogleplushasorder': this.FinalJSONGPls.wsapicontent.array[i].hasorder,
					'delete': true,
				});
			} else {
				this.FinalJSONGPls.eswdocument.empgoogleplusdetails.push({
					'empgoogleplus': this.FinalJSONGPls.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSONGPls.wsapicontent.array[i].uniqueid,
					'empgoogleplushasorder': this.FinalJSONGPls.wsapicontent.array[i].hasorder,
				});
			}
		}


	}
	createupdateArrLnkin(event: any, hobb, currentindex, baseindex) {
		let flag1 = false;
		if (hobb.emplinkedin == '') {
			for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
				this.FinalJSON.wsapicontent.array[i].isdeleted = '1';
				this.FinalJSON.wsapicontent.array[i].txtvalue = hobb.emplinkedin;
				this.FinalJSON.wsapicontent.array[i].hasorder = hobb.emplinkedinhasorder;
				this.FinalJSON.wsapicontent.array[i].uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.linkedInKeyCode + currentindex;
				this.FinalJSON.wsapicontent.array[i].modifiedby = (localStorage.getItem('loggedinUser').toString());
				this.FinalJSON.wsapicontent.array[i].modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
				this.FinalJSON.wsapicontent.array[i].keycode = this.linkedInKeyCode;
				this.FinalJSON.wsapicontent.array[i].keyword = 'LinkedIn';
				this.FinalJSON.wsapicontent.array[i].device = 'W';
				delete this.FinalJSON.wsapicontent.array[i].ID;
				delete this.FinalJSON.wsapicontent.array[i].createddate;
				delete this.FinalJSON.wsapicontent.array[i].createdby;
				this.FinalJSON.wsapicontent.updations = '1';
				this.FinalJSON.wsapicontent.insertions = '0';

			}
		} else {
			for (const entry of this.FinalJSON.wsapicontent.array) {
				flag1 = true;
				entry.txtvalue = hobb.emplinkedin;
				entry.isdeleted = '0';
				entry.uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.linkedInKeyCode + currentindex;
				entry.ID = hobb.id;
				entry.device = 'W';
				entry.keycode = this.linkedInKeyCode + '';
				entry.employeeid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id;
				entry.keyword = 'LinkedIn';
				entry.hasorder = hobb.emplinkedinhasorder;
				if (hobb.id != '-1') {
					entry.modifiedby = (localStorage.getItem('loggedinUser').toString());
					entry.modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
					delete entry["ID"];
					delete entry["createddate"];
					delete entry["createdby"];
				} else {
					entry.createdby = (localStorage.getItem('loggedinUser').toString());
					entry.createddate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
					delete entry["modifiedate"];
					delete entry["modifiedby"];
				}
				this.FinalJSON.wsapicontent.updations = (hobb.id == '-1') ? '0' : '1';
				this.FinalJSON.wsapicontent.insertions = (hobb.id == '-1') ? '1' : '0';
			}

		}

		let deleteflag = false;

		for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			this.FinalJSON.eswdocument.emplinkedindetails.splice(i, 1);
			if (this.FinalJSON.wsapicontent.array[i].isdeleted == '1') {
				deleteflag = true;
			}
			if (deleteflag) {
				this.FinalJSON.eswdocument.emplinkedindetails.push({
					'emplinkedin': this.FinalJSON.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
					'emplinkedinhasorder': this.FinalJSON.wsapicontent.array[i].hasorder,
					'delete': true,
				});
			} else {
				this.FinalJSON.eswdocument.emplinkedindetails.push({
					'emplinkedin': this.FinalJSON.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
					'emplinkedinhasorder': this.FinalJSON.wsapicontent.array[i].hasorder,
				});
			}
		}
	}
	onOkClick() {
		if (this.FinalJSON.wsapicontent.updations > 0 || this.FinalJSON.wsapicontent.insertions > 0) {
			let jp: any = this.FinalJSON.eswdocument.emplinkedindetails[0];
			this.FinalJSON.eswdocument.emplinkedindetails.splice(0, 1);
			this.FinalJSON.eswdocument.emplinkedindetails = jp;
			this.spinner.show();
			this.networksSaveData.emit(this.FinalJSON);
		}

		if (this.FinalJSONGPls.wsapicontent.updations > 0 || this.FinalJSONGPls.wsapicontent.insertions > 0) {
			let jp1: any = this.FinalJSONGPls.eswdocument.empgoogleplusdetails[0];
			this.FinalJSONGPls.eswdocument.empgoogleplusdetails.splice(0, 1);
			this.FinalJSONGPls.eswdocument.empgoogleplusdetails = jp1;
			this.spinner.show();
			this.networksSaveData.emit(this.FinalJSONGPls);
		}
	}

	onReset() {
		let i = 0;
		this.FinalJSON.wsapicontent.array = [];
		this.FinalJSON.eswdocument.emplinkedindetails = [];
		this.FinalJSONGPls.wsapicontent.array = [];
		this.FinalJSONGPls.eswdocument.empgoogleplusdetails = [];
		for (i = 0; i < this.hobbarrreplica.length; i++) {
			this.FinalJSON.wsapicontent.array.push({
				'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.linkedInKeyCode + this.hobbarrreplica[i].emplinkedinhasorder,
				'device': 'W',
				'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
				'keycode': this.linkedInKeyCode + '',
				'keyword': 'LinkedIn',
				'txtvalue': '',
				'hasorder': this.hobbarrreplica[i].emplinkedinhasorder + '',
				'isdeleted': '1',
				'modifiedby': (localStorage.getItem('loggedinUser').toString()),
				'modifiedate': formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530')

			});
			this.FinalJSON.eswdocument.emplinkedindetails.push({
				'emplinkedin': this.hobbarrreplica[i].emplinkedin,
				'id': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.linkedInKeyCode + this.hobbarrreplica[i].emplinkedinhasorder,
				'emplinkedinhasorder': this.hobbarrreplica[i].emplinkedinhasorder + '',
				'delete': true
			});
			this.hobbarrreplica[i].emplinkedin = '';
		}
		this.FinalJSON.wsapicontent.updations = i;
		this.FinalJSON.wsapicontent.insertions = 0;
		for (i = 0; i < this.hobbarrreplicagpls.length; i++) {
			this.FinalJSONGPls.wsapicontent.array.push({
				'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.gplsKeyCode + this.hobbarrreplicagpls[i].empgoogleplushasorder,
				'device': 'W',
				'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
				'keycode': this.gplsKeyCode + '',
				'keyword': 'Google Plus',
				'txtvalue': '',
				'hasorder': this.hobbarrreplicagpls[i].empgoogleplushasorder + '',
				'isdeleted': '1',
				'modifiedby': (localStorage.getItem('loggedinUser').toString()),
				'modifiedate': formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530')
			});
			this.FinalJSONGPls.eswdocument.empgoogleplusdetails.push({
				'empgoogleplus': this.hobbarrreplicagpls[i].empgoogleplus,
				'id': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.gplsKeyCode + this.hobbarrreplicagpls[i].empgoogleplushasorder,
				'empgoogleplushasorder': this.hobbarrreplicagpls[i].empgoogleplushasorder + '',
				'delete': true
			});
			this.hobbarrreplicagpls[i].empgoogleplus = '';
		}
		this.FinalJSONGPls.wsapicontent.updations = i;
		this.FinalJSONGPls.wsapicontent.insertions = 0;
	}

}

