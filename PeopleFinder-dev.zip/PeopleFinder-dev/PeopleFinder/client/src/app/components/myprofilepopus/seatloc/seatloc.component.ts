import { Component, OnInit,ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { strict } from 'assert';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatAutocompleteTrigger } from '@angular/material';
import { PeopleService } from '../../../services/people/people.service';
import { ProfileComponent } from '../../profile/profile.component';
import { formatDate } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
	selector: 'app-seatloc',
	templateUrl: './seatloc.component.html',
	styleUrls: ['./seatloc.component.css']
})
export class SeatLocComponent implements OnInit {
	// ITTPPRD-1404
	@ViewChild('matAutocompleteTrigger') auto : MatAutocompleteTrigger
	@Output() sendSuggesterRequestData = new EventEmitter();
	@Input() suggesters :any
	// ITTPPRD-1404
	@Input() seatLoc: any;
	@Output() seatLocsaveData = new EventEmitter()
	hobbarrreplica: any = [{
		'seatlocation': '',
		'id': '-1',
		'seatlocationhasorder': ''
	}
	];
	seatlocKeyCode = 13;

	hobbBaselength: Number;
	formfieldlength: Number;
	UpdateCount = 0;
	InsertCount = 0;
	saveresponse = "";
	today = new Date();
	FinalJSON: any = {
		user: JSON.parse(localStorage.getItem('isLoggedin').toString()).emp_name,
		eswdocument: {
			empseatlocation: [{
				'seatlocation': '',
				'id': '',
				'seatlocationhasorder': ''
			}
			],
		},
		wsapicontent: {
			insertions: 0,
			updations: 0,
			array: [{
				'uniqueid': '',
				'ID': '',
				'device': 'W',
				'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
				'keycode': '13',
				'keyword': 'Seat location',
				'txtvalue': '',
				'hasorder': '',
				'isdeleted': '0',
				'modifiedby': '',
				'modifiedate': '',
				'createdby': '',
				'createddate': ''

			}]
		}
	};

	constructor(public dialog: MatDialog, private peopleService: PeopleService, private router: Router, private spinner: NgxSpinnerService, private location: Location) {
		// this.hobbBaselength=this.hobbarrreplica.length;
	}

	ngOnInit() {
	// ITTPPRD-1404
	this.suggesters = [];
	// ITTPPRD-1404
		if (this.seatLoc.empseatlocation != undefined) {

			if (Array.isArray(this.seatLoc.empseatlocation)) {
				if (this.seatLoc.empseatlocation.length != undefined && this.seatLoc.empseatlocation.length > 0) {
					this.hobbarrreplica.splice(0, 1);
					this.hobbarrreplica.push(JSON.parse(JSON.stringify(this.seatLoc.empseatlocation[0])));
				}

				if (this.hobbarrreplica.length < 1) {
					this.hobbarrreplica.push({
						'seatlocation': '', 'id': '-1',
						'seatlocationhasorder': this.hobbarrreplica.length + 1 + ''
					});
				}
			} else {

				if (this.isEmptyObject(this.seatLoc.empseatlocation)) {

					this.hobbarrreplica = [JSON.parse(JSON.stringify(this.seatLoc.empseatlocation))];
				}
			}
		}

	}
	onNoClickfrall() {
		const dialogRef = this.dialog.closeAll();
	}

	isEmptyObject(obj) {

		for (var key in obj) {
			if (Object.prototype.hasOwnProperty.call(obj, key)) {
				return true;
			}
		}
		return false;
	}
	createupdateArr(event: any, hobb, currentindex, baseindex) {
		let flag1 = false;
		if (hobb.seatlocation == '') {
			for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
				/* if(hobb.id != '-1' ){ */
				this.FinalJSON.wsapicontent.array[i].isdeleted = '1';
				this.FinalJSON.wsapicontent.array[i].txtvalue = hobb.seatlocation;
				this.FinalJSON.wsapicontent.array[i].hasorder = '1';
				/* this.FinalJSON.wsapicontent.array[i].ID = hobb.id; */
				this.FinalJSON.wsapicontent.array[i].uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.seatlocKeyCode + currentindex;
				this.FinalJSON.wsapicontent.array[i].modifiedby = (localStorage.getItem('loggedinUser').toString());
				this.FinalJSON.wsapicontent.array[i].modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
				this.FinalJSON.wsapicontent.array[i].keycode = this.seatlocKeyCode;
				this.FinalJSON.wsapicontent.array[i].keyword = 'Seat location';
				this.FinalJSON.wsapicontent.array[i].device = 'W';
				delete this.FinalJSON.wsapicontent.array[i]["ID"];
				this.FinalJSON.wsapicontent.updations = '1';
				this.FinalJSON.wsapicontent.insertions = '0';
				this.FinalJSON.eswdocument.empseatlocation[i].delete = true;
				this.FinalJSON.eswdocument.empseatlocation[i].seatlocationhasorder = '1';
				this.FinalJSON.eswdocument.empseatlocation[i].id = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.seatlocKeyCode + '1';
			}
		} else {
			for (const entry of this.FinalJSON.wsapicontent.array) {
				flag1 = true;
				entry.txtvalue = hobb.seatlocation;
				entry.isdeleted = '0';
				entry.uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.seatlocKeyCode + currentindex;
				entry.ID = hobb.id;
				entry.device = 'W';
				entry.keycode = this.seatlocKeyCode + '';
				entry.employeeid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id;
				entry.uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.seatlocKeyCode + currentindex;
				entry.keyword = 'Seat location';
				entry.hasorder = currentindex + '';
				if (hobb.id != '-1') {
					entry.modifiedby = (localStorage.getItem('loggedinUser').toString());
					entry.modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
					delete entry["ID"];
				} else {
					entry.createdby = (localStorage.getItem('loggedinUser').toString());
					entry.createddate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
				}
				this.FinalJSON.wsapicontent.updations = (hobb.id == '-1') ? '0' : '1';
				this.FinalJSON.wsapicontent.insertions = (hobb.id == '-1') ? '1' : '0';
			}

		}

		let deleteflag = false;

		for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			this.FinalJSON.eswdocument.empseatlocation.splice(i, 1);
			if (this.FinalJSON.wsapicontent.array[i].isdeleted == '1') {
				deleteflag = true;
			}
			if (deleteflag) {
				this.FinalJSON.eswdocument.empseatlocation.push({
					'seatlocation': this.FinalJSON.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
					'seatlocationhasorder': this.FinalJSON.wsapicontent.array[i].hasorder,
					'delete': true,
				});
			} else {
				this.FinalJSON.eswdocument.empseatlocation.push({
					'seatlocation': this.FinalJSON.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
					'seatlocationhasorder': this.FinalJSON.wsapicontent.array[i].hasorder,
				});
			}
		}
	}
	async  onOkClick() {
		if (this.FinalJSON.wsapicontent.updations > 0 || this.FinalJSON.wsapicontent.insertions > 0) {
			let jp: any = this.FinalJSON.eswdocument.empseatlocation[0];
			this.FinalJSON.eswdocument.empseatlocation.splice(0, 1);
			this.FinalJSON.eswdocument.empseatlocation = jp;
			this.spinner.show();
			this.seatLocsaveData.emit(this.FinalJSON);
		}
	}

	onReset() {
		let i = 0;
		for (i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			this.FinalJSON.wsapicontent.array[i].isdeleted = '1';
			this.FinalJSON.wsapicontent.array[i].txtvalue = '';
			this.FinalJSON.wsapicontent.array[i].hasorder = '1';
			this.FinalJSON.wsapicontent.array[i].uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.seatlocKeyCode + '1';
			this.FinalJSON.wsapicontent.array[i].modifiedby = (localStorage.getItem('loggedinUser').toString());
			this.FinalJSON.wsapicontent.array[i].modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
			delete this.FinalJSON.wsapicontent.array[i]["ID"];
			this.FinalJSON.eswdocument.empseatlocation[i].delete = true;
			this.FinalJSON.eswdocument.empseatlocation[i].seatlocation = '';
			this.FinalJSON.eswdocument.empseatlocation[i].seatlocationhasorder = '1';
			this.FinalJSON.eswdocument.empseatlocation[i].id = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.seatlocKeyCode + '1';


		}
		this.FinalJSON.wsapicontent.updations = i;
		this.FinalJSON.wsapicontent.insertions = 0;
		for (let j = 0; j < this.hobbarrreplica.length; j++) {
			this.hobbarrreplica[j].seatlocation = '';
		}
	}
	// ITTPPRD-1404
	clearSuggesters( trigger : MatAutocompleteTrigger ){
		setTimeout( () => {
			this.suggesters = [];
			trigger.closePanel()
        }, 300);
	}
	getSuggesters( value){
		this.sendSuggesterRequestData.emit({keycode: this.seatlocKeyCode,value : value})
	}
	// ITTPPRD-1404
}

