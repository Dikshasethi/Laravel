import { Component, OnInit, Inject, ViewChild, ViewChildren, ContentChild, TemplateRef, Input, ElementRef, Output, EventEmitter } from '@angular/core';
import { strict } from 'assert';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PeopleService } from '../../../services/people/people.service';
import { formatDate } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import {FormControl, FormGroup, ValidatorFn,AbstractControl} from '@angular/forms';

@Component({
	selector: 'app-compworked',
	templateUrl: './compworked.component.html',
	styleUrls: ['./compworked.component.css']
})
export class CompworkedComponent implements OnInit {

	// ITTPPRD-1461
	suggesters :any = [];
	public addCountryFormGroup: FormGroup;
	isValid = [];
	// ITTPPRD-1461
	@Input() cntryarr: any;    // original oBject
	cntryarract :any;
	@Output() countriesSaveData = new EventEmitter()
	hobbarrreplica: any;
	hobbiesKeyCode = 5;
	hobbBaselength: number;
	formfieldlength: number;
	UpdateCount = 0;
	InsertCount = 0;
	saveresponse = "";
	today = new Date();
	FinalJSON: any = {
		user: JSON.parse(localStorage.getItem('isLoggedin').toString()).emp_name,
		eswdocument: {
			empcountriesworked: [{
				'countriesworked': '',
				'id': '',
				'countriesworkedhasorder': ''
			}
			],
		},
		wsapicontent: {
			insertions: 0,
			updations: 0,
			array: [{
				'uniqueid': '',
				'ID': '',
				'device': 'W',
				'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
				'keycode': '5',
				'keyword': 'countries worked in',
				'txtvalue': '',
				'hasorder': '',
				'isdeleted': '0',
				'modifiedby': '',
				'modifiedate': '',
				'createdby': '',
				'createddate': ''
			}]
		}
	};
	elref: boolean = true;

	idmatchcard: boolean = false;
	max: any;
	newmaxorder: number = 0;
	focusfalg: boolean = true;

	@ViewChild("myInput") inputEl: ElementRef;

	constructor(public dialog: MatDialog, private peopleService: PeopleService, private router: Router, private spinner: NgxSpinnerService, private location: Location) {
		// this.hobbBaselength = this.hobbarrreplica.length;
	}
	ngOnInit() {
		// ITTPPRD-1461
		this.getCountrySuggesters('')
		// ITTPPRD-1461
		this.cntryarract = JSON.parse(JSON.stringify(this.cntryarr));
		let data1 = this.cntryarract.find(ob => ob['countriesworkedhasorder'] === '1');
		let data2 = this.cntryarract.find(ob => ob['countriesworkedhasorder'] === '2');
		let data3 = this.cntryarract.find(ob => ob['countriesworkedhasorder'] === '3');

		if (data1 == undefined) {
			this.cntryarract.push({ 'countriesworked': '', 'id': '-1', 'countriesworkedhasorder': '1' , 'countryFormcontrol' : 1 });
		}
		if (data2 == undefined) {
			this.cntryarract.push({ 'countriesworked': '', 'id': '-1', 'countriesworkedhasorder': '2', 'countryFormcontrol' : 2 });
		}
		if (data3 == undefined) {
			this.cntryarract.push({ 'countriesworked': '', 'id': '-1', 'countriesworkedhasorder': '3', 'countryFormcontrol' : 3 });
		}
		this.hobbarrreplica = JSON.parse(JSON.stringify(this.cntryarract.sort(function (obj1, obj2) {
			return obj1.countriesworkedhasorder - obj2.countriesworkedhasorder;
		})));

		const hobbBaselengthaa = this.hobbarrreplica.length;
		this.formfieldlength = hobbBaselengthaa;

		if (this.formfieldlength >= 33) {
			this.elref = false;
		}

		if (this.hobbarrreplica.length > 0) {
			this.max = this.hobbarrreplica.reduce((prev, current) => (Number(prev.countriesworkedhasorder) > Number(current.countriesworkedhasorder)) ? prev : current);
			this.hobbBaselength = JSON.parse(this.max.countriesworkedhasorder);
		}
		// ITTPPRD-1461
		this.hobbarrreplica.forEach(element => {
			element.countryFormcontrol = new FormControl('', [ this.checkCountry(element.countriesworkedhasorder) ]);
		})
		this.addCountryFormGroup = new FormGroup({	})	
		// ITTPPRD-1461

	}
	ngAfterContentChecked() {
		if (this.focusfalg == false) {
			this.max = this.hobbarrreplica.reduce((prev, current) => (Number(prev.countriesworkedhasorder) > Number(current.countriesworkedhasorder)) ? prev : current);
			let objMat = document.getElementById(JSON.parse(this.max.countriesworkedhasorder));
			if (objMat != null) {
				objMat.focus();
				this.focusfalg = true;
				const objDiv = document.getElementById('idcompwrd');
				objDiv.scrollTop = objDiv.scrollHeight - objDiv.clientHeight;
			}
		}
	}

	geninput(event: any, preindex) {
		this.formfieldlength = this.hobbarrreplica.length;
		this.max = this.hobbarrreplica.reduce((prev, current) => (Number(prev.countriesworkedhasorder) > Number(current.countriesworkedhasorder)) ? prev : current);
		this.newmaxorder = (JSON.parse(this.max.countriesworkedhasorder));

		if (this.newmaxorder > this.hobbBaselength) {
			this.hobbarrreplica.push({ 'countriesworked': '', 'id': '-1', 'countriesworkedhasorder': (this.newmaxorder + 1) + '' , 'countryFormcontrol' : new FormControl('', this.checkCountry(this.newmaxorder + 1)) });  //Added
		}
		else {
			this.hobbarrreplica.push({ 'countriesworked': '', 'id': '-1', 'countriesworkedhasorder': (this.hobbBaselength + 1) + '', 'countryFormcontrol' : new FormControl('', this.checkCountry(this.newmaxorder + 1))});
		}

		this.max = this.hobbarrreplica.reduce((prev, current) => (prev.countriesworkedhasorder > current.countriesworkedhasorder) ? prev : current);
		const objDiv = document.getElementById('idcompwrd');
		objDiv.scrollTop = objDiv.scrollHeight - 100;
		if (this.formfieldlength >= 32) {
			this.elref = false;
		}
		this.focusfalg = false;
	}
	deletecontroll(id, currentindex, hobb, baseindex) {
		var hasordertobeupd = 0;
		
		this.isValid.splice(currentindex,1);
		for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			if (this.FinalJSON.wsapicontent.array[i].hasorder == hobb.countriesworkedhasorder) {
				if (this.FinalJSON.wsapicontent.array[i].ID == '-1') {

					this.FinalJSON.wsapicontent.insertions = parseInt(this.FinalJSON.wsapicontent.insertions) - 1;
					hasordertobeupd = this.FinalJSON.wsapicontent.array[i].hasorder;


				} else {
					this.FinalJSON.wsapicontent.updations = parseInt(this.FinalJSON.wsapicontent.updations) - 1;
				}
				this.FinalJSON.wsapicontent.array.splice(i, 1);
			}
			if (this.FinalJSON.wsapicontent.array[i] != undefined && hasordertobeupd != 0
				&& (hasordertobeupd < parseInt(this.FinalJSON.wsapicontent.array[i].hasorder))) {
				if (id == '-1') {   //Added

					this.FinalJSON.wsapicontent.array[i].hasorder = parseInt(this.FinalJSON.wsapicontent.array[i].hasorder) - 1 + '';
					this.FinalJSON.wsapicontent.array[i].uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + this.FinalJSON.wsapicontent.array[i].hasorder;
				}   //Added
			}
		}

		for (let i = 0; i <= this.hobbarrreplica.length - 1; i++) {
			if (this.hobbarrreplica[i].id === id && this.hobbarrreplica[i].countriesworkedhasorder === hobb.countriesworkedhasorder) {
				this.hobbarrreplica[i].delete = 'true';
				this.hobbarrreplica.splice(i, 1);
				this.formfieldlength = this.formfieldlength - 1;
				this.elref = true;

				if (id != '-1') {
					this.FinalJSON.wsapicontent.array.push({
						'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + hobb.countriesworkedhasorder,
						'device': 'W',
						'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
						'keycode': this.hobbiesKeyCode + '',
						'keyword': 'countriesworked',
						'txtvalue': hobb.countriesworked,
						'hasorder': hobb.countriesworkedhasorder + '',
						'isdeleted': '1',
						'modifiedby': (localStorage.getItem('loggedinUser').toString()),
						'modifiedate': formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530')
					});
				}
			}

		}
		if (id == '-1') {   //Added

			for (let j = 0; j <= this.hobbarrreplica.length - 1; j++) {
				if (Number(this.hobbarrreplica[j].countriesworkedhasorder) > Number(hobb.countriesworkedhasorder)) {
					this.hobbarrreplica[j].countriesworkedhasorder = Number(this.hobbarrreplica[j].countriesworkedhasorder) - 1 + '';

				}

			}
		} 		//Added

		this.updateparameters(this.FinalJSON);
	}
	onNoClickfrall() {
		const dialogRef = this.dialog.closeAll();
	}
	isdeleted() {
		for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			if (this.FinalJSON.wsapicontent.array[i] != undefined && ((this.FinalJSON.wsapicontent.array[i].ID == '-1' && this.FinalJSON.wsapicontent.array[i].isdeleted == '1') || this.FinalJSON.wsapicontent.array[i].uniqueid == '')) {
				this.FinalJSON.wsapicontent.array.splice(i, 1);
				this.FinalJSON.wsapicontent.updations = parseInt(this.FinalJSON.wsapicontent.updations) - 1;
			}
		}
	}

	onOkClick() {
		this.isdeleted();
		let valid = true;
		this.isValid.forEach((val)=>{
			if(val instanceof Object){
				valid = false;
			}
		})
		if ( valid && (this.FinalJSON.wsapicontent.updations > 0 || this.FinalJSON.wsapicontent.insertions > 0)) {
			this.spinner.show();
			this.countriesSaveData.emit(this.FinalJSON);
		}

	}
	createupdateArr(event: any, hobb, currentindex, baseindex) {
		let flag = false;
		let flag1 = false;

		if (hobb.countriesworked == '') {
			for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
				var hasord = this.FinalJSON.wsapicontent.array[i].hasorder;
				if (hasord == hobb.countriesworkedhasorder) {
					flag = true;
					this.FinalJSON.wsapicontent.array[i].isdeleted = '1';
				}
				if (this.FinalJSON.wsapicontent.array[i].id == '-1') {
					this.FinalJSON.wsapicontent.array.splice(i, 1);
				}
			}
			if (!flag) {
				this.FinalJSON.wsapicontent.array.push({
					'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + hobb.countriesworkedhasorder,
					'device': 'W',
					'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
					'keycode': this.hobbiesKeyCode + '',
					'keyword': 'countriesworked',
					'txtvalue': hobb.countriesworked,
					'hasorder': hobb.countriesworkedhasorder + '',
					'isdeleted': '1',
				});
			}
		} else {

			for (const entry of this.FinalJSON.wsapicontent.array) {
				if (parseInt(entry.hasorder) === parseInt(hobb.countriesworkedhasorder)) {
					flag1 = true;
					entry.txtvalue = hobb.countriesworked;
					entry.isdeleted = '0';
					entry.device = 'W';
					entry.ID = hobb.id;
					break;
				}
			}
			if (!flag1) {
				for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
					if (this.FinalJSON.wsapicontent.array[i].hasorder == '') {
						this.FinalJSON.wsapicontent.array.splice(i, 1);
					}
				}
				this.FinalJSON.wsapicontent.array.push({
					'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + hobb.countriesworkedhasorder, // GLOBLE VAR
					'ID': hobb.id,
					'device': 'W',
					'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
					'keycode': this.hobbiesKeyCode + '',
					'keyword': 'countriesworked',
					'txtvalue': hobb.countriesworked,
					'hasorder': hobb.countriesworkedhasorder + '',
					'isdeleted': '0',
				});
			}
		}

		this.updateparameters(this.FinalJSON);

	}
	updateparameters(updatejsonparam) {
		var updcount = 0;
		var intsertcount = 0;
		let deleteflag = false;
		this.FinalJSON.eswdocument.empcountriesworked = [];
		this.isdeleted();
		for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			if (this.FinalJSON.wsapicontent.array[i].ID == '-1') {
				this.FinalJSON.wsapicontent.array[i].createdby = (localStorage.getItem('loggedinUser').toString());
				this.FinalJSON.wsapicontent.array[i].createddate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
				intsertcount += 1;
			} else {
				var isdelt = this.FinalJSON.wsapicontent.array[i].isdeleted;
				if (isdelt == '1') {
					deleteflag = true;
				}
				this.FinalJSON.wsapicontent.array[i].modifiedby = (localStorage.getItem('loggedinUser').toString());
				this.FinalJSON.wsapicontent.array[i].modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
				delete this.FinalJSON.wsapicontent.array[i]["ID"];
				updcount += 1;

			}
			if (!deleteflag) {
				this.FinalJSON.eswdocument.empcountriesworked.push({
					'countriesworked': this.FinalJSON.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
					'countriesworkedhasorder': this.FinalJSON.wsapicontent.array[i].hasorder

				});
			} else {
				this.FinalJSON.eswdocument.empcountriesworked.push({
					'countriesworked': this.FinalJSON.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
					'countriesworkedhasorder': this.FinalJSON.wsapicontent.array[i].hasorder,
					'delete': deleteflag
				});
			}
			deleteflag = false;
		}
		this.FinalJSON.wsapicontent.insertions = intsertcount;
		this.FinalJSON.wsapicontent.updations = updcount;
	}
	inputclick(hobbar) {
		//  this.inputEl.nativeElement.focus();

	}

	onReset() {
		let i = 0;
		this.FinalJSON.wsapicontent.array = [];
		this.FinalJSON.eswdocument.empcountriesworked = [];
		for (i = 0; i < this.hobbarrreplica.length; i++) {
			this.FinalJSON.wsapicontent.array.push({
				'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + this.hobbarrreplica[i].countriesworkedhasorder,
				'device': 'W',
				'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
				'keycode': this.hobbiesKeyCode + '',
				'keyword': 'countriesworked',
				'txtvalue': this.hobbarrreplica[i].countriesworked,
				'hasorder': this.hobbarrreplica[i].countriesworkedhasorder + '',
				'isdeleted': '1',
				'modifiedby': (localStorage.getItem('loggedinUser').toString()),
				'modifiedate': formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530')

			});
			this.FinalJSON.eswdocument.empcountriesworked.push({
				'countriesworked': this.hobbarrreplica[i].countriesworked,
				'id': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + this.hobbarrreplica[i].countriesworkedhasorder,
				'countriesworkedhasorder': this.hobbarrreplica[i].countriesworkedhasorder + '',
				'delete': true
			});
			this.hobbarrreplica[i].countriesworked = '';
		}
		this.FinalJSON.wsapicontent.updations = i;
		this.FinalJSON.wsapicontent.insertions = 0;

	}
	// ITTPPRD-1461
	checkCountry(control) : ValidatorFn {
		return (currentControl: AbstractControl):any => {
			let temp = {invalid: true};
			if( !this.suggesters.length || this.suggesters.some(suggester => suggester.country == currentControl.value ) || currentControl.value == '') {
				temp = null;
			}
			this.isValid[control] = temp 
			return temp;
		}
	}
	 
	getCountrySuggesters( value){
		this.peopleService.getCountrySuggesters( { value : value }).subscribe(res => {
			this.suggesters = res['countries'];
		}),
		error => {
			alert(error)
		};
	}
	// ITTPPRD-1461
}

