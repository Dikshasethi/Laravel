import { Component, OnInit, Inject, ViewChild, ViewChildren, ContentChild, TemplateRef, Input, ElementRef, Output, EventEmitter } from '@angular/core';
import { strict } from 'assert';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatAutocompleteTrigger } from '@angular/material';
import { PeopleService } from '../../../services/people/people.service';
import { formatDate } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
	selector: 'app-trade',
	templateUrl: './trade.component.html',
	styleUrls: ['./trade.component.css']
})
export class TradeComponent implements OnInit {

	// ITTPPRD-1404
	@ViewChild('matAutocompleteTrigger') auto : MatAutocompleteTrigger
	@Output() sendSuggesterRequestData = new EventEmitter();
	@Input() suggesters :any
	// ITTPPRD-1404
	@Input() tradearr: any;
	tradearract :any ;
	@Output() tradeSaveData = new EventEmitter()
	hobbarrreplica: any;
	hobbiesKeyCode = 6;
	hobbBaselength: number;
	formfieldlength: number;
	UpdateCount = 0;
	InsertCount = 0;
	saveresponse = "";
	today = new Date();
	FinalJSON: any = {
		user: JSON.parse(localStorage.getItem('isLoggedin').toString()).emp_name,
		eswdocument: {
			emptradesassociation: [{
				'tradesassociation': '',
				'id': '',
				'tradesassociationhasorder': ''
			}
			],
		},
		wsapicontent: {
			insertions: 0,
			updations: 0,
			array: [{
				'uniqueid': '',
				'ID': '',
				'device': 'W',
				'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
				'keycode': '6',
				'keyword': 'trade and association',
				'txtvalue': '',
				'hasorder': '',
				'isdeleted': '0',
				'modifiedby': '',
				'modifiedate': '',
				'createdby': '',
				'createddate': ''

			}]
		}
	};
	elref: boolean = true;

	idmatchcard: boolean = false;
	max: any;
	newmaxorder: number = 0;
	focusfalg: boolean = true;

	@ViewChild("myInput") inputEl: ElementRef;


	constructor(public dialog: MatDialog, private peopleService: PeopleService, private router: Router, private spinner: NgxSpinnerService, private location: Location) {
		// this.hobbBaselength = this.hobbarrreplica.length;
	}
	ngOnInit() {
		// ITTPPRD-1404
		this.suggesters = [];
		// ITTPPRD-1404
		this.tradearract = JSON.parse(JSON.stringify(this.tradearr));
		let data1 = this.tradearract.find(ob => ob['tradesassociationhasorder'] === '1');
		let data2 = this.tradearract.find(ob => ob['tradesassociationhasorder'] === '2');
		let data3 = this.tradearract.find(ob => ob['tradesassociationhasorder'] === '3');

		if (data1 == undefined) {
			this.tradearract.push({ 'tradesassociation': '', 'id': '-1', 'tradesassociationhasorder': '1' });
		}
		if (data2 == undefined) {
			this.tradearract.push({ 'tradesassociation': '', 'id': '-1', 'tradesassociationhasorder': '2' });
		}
		if (data3 == undefined) {
			this.tradearract.push({ 'tradesassociation': '', 'id': '-1', 'tradesassociationhasorder': '3' });
		}
		this.hobbarrreplica = JSON.parse(JSON.stringify(this.tradearract.sort(function (obj1, obj2) {
			return obj1.tradesassociationhasorder - obj2.tradesassociationhasorder;
		})));

		const hobbBaselengthaa = this.hobbarrreplica.length;
		this.formfieldlength = hobbBaselengthaa;

		if (this.formfieldlength >= 33) {
			this.elref = false;
		}

		if (this.hobbarrreplica.length > 0) {
			this.max = this.hobbarrreplica.reduce((prev, current) => (Number(prev.tradesassociationhasorder) > Number(current.tradesassociationhasorder)) ? prev : current);
			this.hobbBaselength = JSON.parse(this.max.tradesassociationhasorder);
		}


	}
	ngAfterContentChecked() {
		if (this.focusfalg == false) {
			this.max = this.hobbarrreplica.reduce((prev, current) => (Number(prev.tradesassociationhasorder) > Number(current.tradesassociationhasorder)) ? prev : current);
			let objMat = document.getElementById(JSON.parse(this.max.tradesassociationhasorder));
			if (objMat != null) {
				objMat.focus();
				this.focusfalg = true;
				const objDiv = document.getElementById('idtrade');
				objDiv.scrollTop = objDiv.scrollHeight - objDiv.clientHeight;
			}
		}
	}
	geninput(event: any, preindex) {
		this.formfieldlength = this.hobbarrreplica.length;
		this.max = this.hobbarrreplica.reduce((prev, current) => (Number(prev.tradesassociationhasorder) > Number(current.tradesassociationhasorder)) ? prev : current);
		this.newmaxorder = (JSON.parse(this.max.tradesassociationhasorder));

		if (this.newmaxorder > this.hobbBaselength) {
			this.hobbarrreplica.push({ 'tradesassociation': '', 'id': '-1', 'tradesassociationhasorder': (this.newmaxorder + 1) + '' });  //Added
		}
		else {
			this.hobbarrreplica.push({ 'tradesassociation': '', 'id': '-1', 'tradesassociationhasorder': (this.hobbBaselength + 1) + '' });
		}

		this.max = this.hobbarrreplica.reduce((prev, current) => (prev.tradesassociationhasorder > current.tradesassociationhasorder) ? prev : current);
		const objDiv = document.getElementById('idtrade');
		objDiv.scrollTop = objDiv.scrollHeight - 100;
		if (this.formfieldlength >= 32) {
			this.elref = false;
		}
		this.focusfalg = false;
	}
	deletecontroll(id, currentindex, hobb, baseindex) {
		var hasordertobeupd = 0;
		for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			if (this.FinalJSON.wsapicontent.array[i].hasorder == hobb.tradesassociationhasorder) {
				if (this.FinalJSON.wsapicontent.array[i].ID == '-1') {

					this.FinalJSON.wsapicontent.insertions = parseInt(this.FinalJSON.wsapicontent.insertions) - 1;
					hasordertobeupd = this.FinalJSON.wsapicontent.array[i].hasorder;


				} else {
					this.FinalJSON.wsapicontent.updations = parseInt(this.FinalJSON.wsapicontent.updations) - 1;
				}
				this.FinalJSON.wsapicontent.array.splice(i, 1);
			}
			if (this.FinalJSON.wsapicontent.array[i] != undefined && hasordertobeupd != 0
				&& (hasordertobeupd < parseInt(this.FinalJSON.wsapicontent.array[i].hasorder))) {
				if (id == '-1') {   //Added

					this.FinalJSON.wsapicontent.array[i].hasorder = parseInt(this.FinalJSON.wsapicontent.array[i].hasorder) - 1 + '';
					this.FinalJSON.wsapicontent.array[i].uniqueid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + this.FinalJSON.wsapicontent.array[i].hasorder;
				}   //Added
			}
		}

		for (let i = 0; i <= this.hobbarrreplica.length - 1; i++) {
			if (this.hobbarrreplica[i].id === id && this.hobbarrreplica[i].tradesassociationhasorder === hobb.tradesassociationhasorder) {
				this.hobbarrreplica[i].delete = 'true';
				this.hobbarrreplica.splice(i, 1);
				this.formfieldlength = this.formfieldlength - 1;
				this.elref = true;

				if (id != '-1') {
					this.FinalJSON.wsapicontent.array.push({
						'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + hobb.tradesassociationhasorder,
						'device': 'W',
						'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
						'keycode': this.hobbiesKeyCode + '',
						'keyword': 'trade and association',
						'txtvalue': hobb.tradesassociation,
						'hasorder': hobb.tradesassociationhasorder + '',
						'isdeleted': '1',
						'modifiedby': (localStorage.getItem('loggedinUser').toString()),
						'modifiedate': formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530')
					});
				}
			}

		}
		if (id == '-1') {   //Added

			for (let j = 0; j <= this.hobbarrreplica.length - 1; j++) {
				if (Number(this.hobbarrreplica[j].tradesassociationhasorder) > Number(hobb.tradesassociationhasorder)) {
					this.hobbarrreplica[j].tradesassociationhasorder = Number(this.hobbarrreplica[j].tradesassociationhasorder) - 1 + '';

				}

			}
		} 		//Added

		this.updateparameters(this.FinalJSON);
	}
	onNoClickfrall() {

		const dialogRef = this.dialog.closeAll();

	}
	isdeleted() {
		for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			if (this.FinalJSON.wsapicontent.array[i] != undefined && ((this.FinalJSON.wsapicontent.array[i].ID == '-1' && this.FinalJSON.wsapicontent.array[i].isdeleted == '1') || this.FinalJSON.wsapicontent.array[i].uniqueid == '')) {
				this.FinalJSON.wsapicontent.array.splice(i, 1);
				this.FinalJSON.wsapicontent.updations = parseInt(this.FinalJSON.wsapicontent.updations) - 1;
			}
		}
	}

	onOkClick() {
		this.isdeleted();
		if (this.FinalJSON.wsapicontent.updations > 0 || this.FinalJSON.wsapicontent.insertions > 0) {
			this.spinner.show();
			this.tradeSaveData.emit(this.FinalJSON);
		}
	}
	createupdateArr(event: any, hobb, currentindex, baseindex) {
		let flag = false;
		let flag1 = false;
		if (hobb.tradesassociation == '') {
			for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
				var hasord = this.FinalJSON.wsapicontent.array[i].hasorder;
				if (hasord == hobb.tradesassociationhasorder) {
					flag = true;
					this.FinalJSON.wsapicontent.array[i].isdeleted = '1';
				}
				if (this.FinalJSON.wsapicontent.array[i].id == '-1')   //Added start
				{
					this.FinalJSON.wsapicontent.array.splice(i, 1);
				}   				  //Added End
			}
			if (!flag) {
				this.FinalJSON.wsapicontent.array.push({
					'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + hobb.tradesassociationhasorder,
					'device': 'W',
					'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
					'keycode': this.hobbiesKeyCode + '',
					'keyword': 'trade and association',
					'txtvalue': hobb.tradesassociation,
					'hasorder': hobb.tradesassociationhasorder + '',
					'isdeleted': '1',
				});
			}
		} else {

			for (const entry of this.FinalJSON.wsapicontent.array) {
				if (parseInt(entry.hasorder) === parseInt(hobb.tradesassociationhasorder)) {
					flag1 = true;
					entry.txtvalue = hobb.tradesassociation;
					entry.isdeleted = '0';
					entry.device = 'W';
					entry.ID = hobb.id;
					break;
				}
			}
			if (!flag1) {
				for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
					if (this.FinalJSON.wsapicontent.array[i].hasorder == '') {
						this.FinalJSON.wsapicontent.array.splice(i, 1);
					}
				}
				this.FinalJSON.wsapicontent.array.push({
					'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + hobb.tradesassociationhasorder, // GLOBLE VAR
					'ID': hobb.id,
					'device': 'W',
					'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
					'keycode': this.hobbiesKeyCode + '',
					'keyword': 'trade and association',
					'txtvalue': hobb.tradesassociation,
					'hasorder': hobb.tradesassociationhasorder + '',
					'isdeleted': '0',
				});
			}
		}

		this.updateparameters(this.FinalJSON);

	}
	updateparameters(updatejsonparam) {
		var updcount = 0;
		var intsertcount = 0;
		let deleteflag = false;
		this.FinalJSON.eswdocument.emptradesassociation = [];
		this.isdeleted();
		for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			if (this.FinalJSON.wsapicontent.array[i].ID == '-1') {
				this.FinalJSON.wsapicontent.array[i].createdby = (localStorage.getItem('loggedinUser').toString());
				this.FinalJSON.wsapicontent.array[i].createddate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
				intsertcount += 1;
			} else {
				var isdelt = this.FinalJSON.wsapicontent.array[i].isdeleted;
				if (isdelt == '1') {
					deleteflag = true;
				}
				this.FinalJSON.wsapicontent.array[i].modifiedby = (localStorage.getItem('loggedinUser').toString());
				this.FinalJSON.wsapicontent.array[i].modifiedate = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
				delete this.FinalJSON.wsapicontent.array[i]["ID"];
				updcount += 1;

			}
			if (!deleteflag) {
				this.FinalJSON.eswdocument.emptradesassociation.push({
					'tradesassociation': this.FinalJSON.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
					'tradesassociationhasorder': this.FinalJSON.wsapicontent.array[i].hasorder

				});
			} else {
				this.FinalJSON.eswdocument.emptradesassociation.push({
					'tradesassociation': this.FinalJSON.wsapicontent.array[i].txtvalue,
					'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
					'tradesassociationhasorder': this.FinalJSON.wsapicontent.array[i].hasorder,
					'delete': deleteflag
				});
			}
			deleteflag = false;
		}
		this.FinalJSON.wsapicontent.insertions = intsertcount;
		this.FinalJSON.wsapicontent.updations = updcount;
	}
	inputclick(hobbar) {
		//  this.inputEl.nativeElement.focus();

	}

	onReset() {
		let i = 0;
		this.FinalJSON.wsapicontent.array = [];
		this.FinalJSON.eswdocument.emptradesassociation = [];
		for (i = 0; i < this.hobbarrreplica.length; i++) {
			this.FinalJSON.wsapicontent.array.push({
				'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + this.hobbarrreplica[i].tradesassociationhasorder,
				'device': 'W',
				'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
				'keycode': this.hobbiesKeyCode + '',
				'keyword': 'trade and association',
				'txtvalue': this.hobbarrreplica[i].tradesassociation,
				'hasorder': this.hobbarrreplica[i].tradesassociationhasorder + '',
				'isdeleted': '1',
				'modifiedby': (localStorage.getItem('loggedinUser').toString()),
				'modifiedate': formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530')

			});
			this.FinalJSON.eswdocument.emptradesassociation.push({
				'tradesassociation': this.hobbarrreplica[i].tradesassociation,
				'id': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.hobbiesKeyCode + this.hobbarrreplica[i].tradesassociationhasorder,
				'tradesassociationhasorder': this.hobbarrreplica[i].tradesassociationhasorder + '',
				'delete': true
			});
			this.hobbarrreplica[i].tradesassociation = '';
		}
		this.FinalJSON.wsapicontent.updations = i;
		this.FinalJSON.wsapicontent.insertions = 0;

	}
	// ITTPPRD-1404
	clearSuggesters( trigger : MatAutocompleteTrigger ){
		setTimeout( () => {
			this.suggesters = [];
			trigger.closePanel()
        }, 300);
	}
	getSuggesters( value){
		this.sendSuggesterRequestData.emit({keycode: this.hobbiesKeyCode,value : value})
	}
	// ITTPPRD-1404
}

