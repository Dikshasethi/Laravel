import { Component, OnInit, Input } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import { PeopleService } from 'src/app/services/people/people.service';
import { NgxSpinnerService } from 'ngx-spinner';


@Component({
  selector: 'app-contact-hr',
  templateUrl: './contact-hr.component.html',
  styleUrls: ['./contact-hr.component.css']
})
export class ContactHrComponent implements OnInit {

  empEmail: string;
  @Input() emailDetails: any;
  toAddrs: any;
  body: any;
  subject: string;
  displayName;
  username: any;
  constructor(public dialog: MatDialog, private http: HttpClient, public peopleService: PeopleService,
    private spinner: NgxSpinnerService) { }


  ngOnInit() {
    this.toAddrs = this.emailDetails.toAddresses;
    this.body = this.emailDetails.bodyContent;
    this.subject = this.emailDetails.sub;
    const loggedinUser = localStorage.getItem('isLoggedin');
    if (typeof loggedinUser !== 'undefined' && loggedinUser !== null) {
      this.username = JSON.parse(loggedinUser.toString()).emp_name;
      this.empEmail = localStorage.getItem('loggedinUser') + '@oceaneering.com';
    }
  }

  customEmail() {
    let custEmail = this.toAddrs;
    this.toAddrs = [...(custEmail.split(","))];
  }

  onNoClickfrall() {
    this.dialog.closeAll();
  }

  public sendMail() {
    if ((this.toAddrs).constructor === String) {
      let custEmail = (this.toAddrs).split(",");
      this.toAddrs = [...custEmail];
    }
    this.spinner.show();
    this.displayName = this.username;
    this.peopleService.sendeEmail(this.empEmail, this.toAddrs, this.displayName, this.subject, this.body).subscribe
      (Response => {
        this.spinner.hide();
        this.onNoClickfrall();
      })
  }

}
