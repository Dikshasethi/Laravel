import { Component, OnInit, Inject, ViewChild, ViewChildren, ContentChild, TemplateRef, Input ,ElementRef, Output, EventEmitter } from '@angular/core';
import { strict } from 'assert';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatAutocompleteTrigger } from '@angular/material';
import { PeopleService } from '../../../services/people/people.service';
import { ProfileComponent } from '../../profile/profile.component';
import {formatDate } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
 
@Component({
  selector: 'app-communites',
  templateUrl: './communites.component.html',
  styleUrls: ['./communites.component.css']
})
export class CommunitesComponent implements OnInit {
	// ITTPPRD-1404
	@ViewChild('matAutocompleteTrigger') auto : MatAutocompleteTrigger
	@Output() sendSuggesterRequestData = new EventEmitter();
	@Input() suggesters :any
	// ITTPPRD-1404
 
	@Input()commarr: any;
	commarract :any;
	@Output() communitiesSaveData = new EventEmitter()
	
  hobbarrreplica: any;
  commKeyCode = 3;
  hobbBaselength: number= 0;
  formfieldlength : number ;
  UpdateCount = 0;
  InsertCount = 0;
  saveresponse ="";
  today = new Date();
  FinalJSON: any = {
    user: JSON.parse(localStorage.getItem('isLoggedin').toString()).emp_name,
    eswdocument: {
      empcommunities: [{
        'empyplinks': '',
        'id': '',
        'communitieshasorder': '',
		'keyword': ''
      }
      ],
    },
    wsapicontent: {
      insertions: 0,
      updations: 0,
      array: [{
       'uniqueid': '',
        'ID': '',
		'device' : 'W',
        'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
        'keycode': '3',
        'keyword': '',
        'txtvalue': '',
        'hasorder': '',
        'isdeleted': '0',
        'modifiedby': '',
        'modifiedate': '',
		'createdby':'',
		'createddate':''	
      }]
    }
  };
elref : boolean =true;  
max :any ;
idmatchcard : boolean = false; 
newmaxorder:number = 0;
focusfalg : boolean = true; 
 
  @ViewChild("myInput") inputEl: ElementRef;
  @ViewChild(ProfileComponent) profileComponent: ProfileComponent;
  
  constructor(public dialog: MatDialog,private peopleService: PeopleService,private router: Router,private spinner: NgxSpinnerService,private location: Location) {
    // this.hobbBaselength = this.hobbarrreplica.length;
  }
  ngOnInit() {
	 // ITTPPRD-1404
	 this.suggesters = [];
	 // ITTPPRD-1404
 
	 this.commarract = JSON.parse(JSON.stringify(this.commarr));
	 let data1 = this.commarract.find(ob => ob['communitieshasorder'] === '1');
	 let data2 = this.commarract.find(ob => ob['communitieshasorder'] === '2');
	 let data3 = this.commarract.find(ob => ob['communitieshasorder'] === '3');
	  
	 if(data1 == undefined)
	 {
		  this.commarract.push({ 'empyplinks': '', 'id': '-1','communitieshasorder': '1','keyword': ''});
	 }
	  if(data2 == undefined)
	 {
		  this.commarract.push({ 'empyplinks': '', 'id': '-1','communitieshasorder': '2','keyword': ''});
	 }
	  if(data3 == undefined)
	 {
		  this.commarract.push({ 'empyplinks': '', 'id': '-1','communitieshasorder': '3','keyword': ''});
	 }
     this.hobbarrreplica = JSON.parse(JSON.stringify(this.commarract.sort(function (obj1, obj2) {
		return obj1.communitieshasorder - obj2.communitieshasorder;
    })));   
	
    const hobbBaselengthaa = this.hobbarrreplica.length;
    console.log('hobbBaselength:::' + hobbBaselengthaa);
	this.formfieldlength =  hobbBaselengthaa;
	
	if(this.formfieldlength >= 33 ){
		this.elref =false;
	}

	if(this.hobbarrreplica.length > 0 ){ 
		this.max = this.hobbarrreplica.reduce((prev, current) => (Number(prev.communitieshasorder) > Number(current.communitieshasorder)) ? prev : current);
		this.hobbBaselength = JSON.parse(this.max.communitieshasorder) ;
	}
    console.log('this.max ::::' + this.hobbBaselength);
    console.log('this.hobbarrreplica.length::::' + this.hobbarrreplica.length);
	console.log('hobbarrreplica json :: ' +JSON.stringify(this.hobbarrreplica));
 
  }
  ngAfterContentChecked()	 
  {	 
  
	         if(this.focusfalg == false){
  			   this.max = this.hobbarrreplica.reduce((prev, current) => (Number(prev.communitieshasorder) > Number(current.communitieshasorder)) ? prev : current);
 			   let objMat = document.getElementById(JSON.parse(this.max.communitieshasorder));
			   if(objMat != null){
	             
				 objMat.focus();
				 this.focusfalg = true;
				 const objDiv = document.getElementById('idcommunities');
				 objDiv.scrollTop = objDiv.scrollHeight - objDiv.clientHeight;
			  }    
			 }
  }   
  
  
  geninput(event: any,preindex) {
	this.formfieldlength = this.hobbarrreplica.length;
	this.max = this.hobbarrreplica.reduce((prev, current) => (Number(prev.communitieshasorder) > Number(current.communitieshasorder)) ? prev : current);
	this.newmaxorder = (JSON.parse(this.max.communitieshasorder)) ;
	console.log(' geninput: this.max   ' + this.newmaxorder  ); 
    console.log('geninput index::::' + this.formfieldlength);
	if(this.newmaxorder > this.hobbBaselength){
    this.hobbarrreplica.push({ 'empyplinks': '', 'id': '-1'  , 'communitieshasorder':  (this.newmaxorder + 1) +'','keyword': ''});  
	}
    else{
		this.hobbarrreplica.push({ 'empyplinks': '', 'id': '-1'  , 'communitieshasorder':  (this.hobbBaselength + 1) +'','keyword': ''});
	}
	
	this.max = this.hobbarrreplica.reduce((prev, current) => (prev.communitieshasorder > current.communitieshasorder) ? prev : current);
    
    console.log('hobbarrreplica Array:::' + JSON.stringify(this.hobbarrreplica)); 
	if(this.formfieldlength >= 32 ){
		this.elref =false;
	}
	this.focusfalg = false; 
  }
  deletecontroll(id, currentindex, hobb, baseindex) {
	var hasordertobeupd = 0;
	console.log('hobb.communitieshasorder' + hobb.communitieshasorder);
	for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
          if (this.FinalJSON.wsapicontent.array[i].hasorder == hobb.communitieshasorder ) {
			  if(this.FinalJSON.wsapicontent.array[i].ID  == '-1' )
			  {
				  
				  this.FinalJSON.wsapicontent.insertions = parseInt(this.FinalJSON.wsapicontent.insertions)-1;
				   hasordertobeupd = this.FinalJSON.wsapicontent.array[i].hasorder ;
				    
				  
			  }else{
				  this.FinalJSON.wsapicontent.updations  = parseInt(this.FinalJSON.wsapicontent.updations)-1;
			  }  
              this.FinalJSON.wsapicontent.array.splice(i,1);				  
         }	
		if(this.FinalJSON.wsapicontent.array[i] !=  undefined && hasordertobeupd !=0 
				&& (hasordertobeupd < parseInt(this.FinalJSON.wsapicontent.array[i].hasorder))){
					    if(id == '-1' ){    
						 
						this.FinalJSON.wsapicontent.array[i].hasorder = parseInt(this.FinalJSON.wsapicontent.array[i].hasorder) -1 + '';
						this.FinalJSON.wsapicontent.array[i].uniqueid =  JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.commKeyCode + this.FinalJSON.wsapicontent.array[i].hasorder;
						console.log('hasordertobeupd' + hasordertobeupd);
						}    
		}
    }
	  
	console.log('this.hobbarrreplica.length :: ' + this.hobbarrreplica.length);
    for (let i = 0; i <= this.hobbarrreplica.length -1 ; i++) {
      if (this.hobbarrreplica[i].id === id && this.hobbarrreplica[i].communitieshasorder ===  hobb.communitieshasorder) {
		console.log(this.hobbarrreplica[i].id + ' hjkfdfdjk ' +id);
		this.hobbarrreplica[i].delete = 'true';    
	    console.log('deleting from splice ' + i);
		this.hobbarrreplica.splice(i, 1); 
		this.formfieldlength = this.formfieldlength -1;
		this.elref = true;
		if(id != '-1'){
			console.log('id != -1 ' + id);
				this.FinalJSON.wsapicontent.array.push({
				  'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.commKeyCode + hobb.communitieshasorder,
				  'device' : 'W',
				  'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
				  'keycode': this.commKeyCode + '',
				  'keyword': hobb.keyword,
				  'txtvalue': hobb.empyplinks,
				  'hasorder': hobb.communitieshasorder + '',
				  'isdeleted': '1',
				  'modifiedby': (localStorage.getItem('loggedinUser').toString()),
				  'modifiedate': formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530')
				});
		} 
      } 
    }
	  if(id == '-1' ){    
		 for (let j = 0; j <= this.hobbarrreplica.length -1 ; j++) {
			  if(Number(this.hobbarrreplica[j].communitieshasorder) > Number(hobb.communitieshasorder))
			  {
				this.hobbarrreplica[j].communitieshasorder = Number(this.hobbarrreplica[j].communitieshasorder) - 1 + '';			 
			  }
		}
	  } 	 
	  this.updateparameters(this.FinalJSON);
  }
  onNoClickfrall() {
    const dialogRef = this.dialog.closeAll(); 
  }
  isdeleted()
  {
	  for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
	   if(this.FinalJSON.wsapicontent.array[i] !=  undefined && ((this.FinalJSON.wsapicontent.array[i].ID == '-1'  &&  this.FinalJSON.wsapicontent.array[i].isdeleted == '1') || this.FinalJSON.wsapicontent.array[i].uniqueid =='')){
			   this.FinalJSON.wsapicontent.array.splice(i,1);
			   this.FinalJSON.wsapicontent.updations  = parseInt(this.FinalJSON.wsapicontent.updations)-1;
		 }
	  }
  }

 onOkClick() {
	  this.isdeleted();
	  if(this.FinalJSON.wsapicontent.updations > 0 || this.FinalJSON.wsapicontent.insertions > 0){
      this.spinner.show();
			this.communitiesSaveData.emit(this.FinalJSON);
	  } 
  }
  createupdateArr(event: any, hobb, currentindex, baseindex) {
     
	console.log('eswdocument length ::'+this.FinalJSON.eswdocument.empcommunities.length);
	
    
    let flag = false;
    let flag1 = false;
 
     if (hobb.empyplinks == ''  && hobb.keyword == '') {
		console.log('Empty....' + hobb.empyplinks);
	    console.log('Empty....' + hobb.communitieshasorder);
   //   this.FinalJSON.eswdocument.empcommunities.push(hobb);
		for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
			var hasord = this.FinalJSON.wsapicontent.array[i].hasorder ;
			if(hasord == hobb.communitieshasorder){
				flag = true;
				this.FinalJSON.wsapicontent.array[i].isdeleted = '1';
			}
			if(this.FinalJSON.wsapicontent.array[i].id == '-1')    
			{
			 this.FinalJSON.wsapicontent.array.splice(i,1);
			}   				   
		}
		if(!flag){
			  this.FinalJSON.wsapicontent.array.push({
			  'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.commKeyCode + hobb.communitieshasorder, 
			  'device' : 'W',
			  'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
			  'keycode': this.commKeyCode + '',
			  'keyword': hobb.keyword,
			  'txtvalue': hobb.empyplinks,
			  'hasorder': hobb.communitieshasorder + '',
			  'isdeleted': '1',
			}); 
		}
    } else {
   
      for (const entry of this.FinalJSON.wsapicontent.array) {
        console.log('entry.hasorder' + JSON.stringify(entry.hasorder));
        if (parseInt(entry.hasorder) === parseInt(hobb.communitieshasorder)) {
          console.log('parseInt(entry.hasorder) === parseInt(hobb.communitieshasorder) === true');
          flag1 = true;
          entry.txtvalue = hobb.empyplinks;
		  entry.keyword = hobb.keyword;
		  entry.isdeleted = '0';
		  entry.device = 'W';
		  entry.ID = hobb.id;
          break;
        } else {
          console.log('parseInt(entry.hasorder) === parseInt(hobb.communitieshasorder) === false');
        }
      }
      if (!flag1) {
        for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
          if (this.FinalJSON.wsapicontent.array[i].hasorder == '') {
            this.FinalJSON.wsapicontent.array.splice(i, 1);
          }
        }
      this.FinalJSON.wsapicontent.array.push({
          'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.commKeyCode + hobb.communitieshasorder, // GLOBLE VAR
          'ID': hobb.id,
		  'device' : 'W',
          'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
          'keycode': this.commKeyCode + '',
          'keyword': hobb.keyword,
          'txtvalue': hobb.empyplinks,
          'hasorder': hobb.communitieshasorder + '',
          'isdeleted': '0',
        }); 
      } 
    }
	 
	this.updateparameters( this.FinalJSON);
 
  }
  updateparameters(updatejsonparam) {
	  var updcount = 0;
	  var intsertcount = 0;
	  let deleteflag = false;
	  this.FinalJSON.eswdocument.empcommunities = [];
	  this.isdeleted();
	  console.log('eswdocument length ::'+this.FinalJSON.eswdocument.empcommunities.length);
	  for (let i = 0; i < this.FinalJSON.wsapicontent.array.length; i++) {
          if (this.FinalJSON.wsapicontent.array[i].ID == '-1') {
			  this.FinalJSON.wsapicontent.array[i].createdby = (localStorage.getItem('loggedinUser').toString() );
			  this.FinalJSON.wsapicontent.array[i].createddate =   formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
              intsertcount += 1;
          }else  {
			  var isdelt = this.FinalJSON.wsapicontent.array[i].isdeleted;
			  if(isdelt == '1'){
					deleteflag = true;  
			  } 
			  this.FinalJSON.wsapicontent.array[i].modifiedby = (localStorage.getItem('loggedinUser').toString() );
			  this.FinalJSON.wsapicontent.array[i].modifiedate =   formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530');
			  delete  this.FinalJSON.wsapicontent.array[i]["ID"];
			  updcount += 1;
			  
          }
		  if(!deleteflag){
			  this.FinalJSON.eswdocument.empcommunities.push({
			  'empyplinks': this.FinalJSON.wsapicontent.array[i].txtvalue,
			  'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
			  'communitieshasorder':  this.FinalJSON.wsapicontent.array[i].hasorder,
			  'keyword' : this.FinalJSON.wsapicontent.array[i].keyword,
			 
			  });		 
		  }else{
			  this.FinalJSON.eswdocument.empcommunities.push({
			  'empyplinks': this.FinalJSON.wsapicontent.array[i].txtvalue,
			  'id': this.FinalJSON.wsapicontent.array[i].uniqueid,
			  'communitieshasorder':  this.FinalJSON.wsapicontent.array[i].hasorder,
			  'keyword' : this.FinalJSON.wsapicontent.array[i].keyword,
			  'delete' : deleteflag
			  });		 
		  }
		deleteflag = false;		  
	  }
	  this.FinalJSON.wsapicontent.insertions = intsertcount;
	  this.FinalJSON.wsapicontent.updations  = updcount;
	  console.log('from updated json '+JSON.stringify(this.FinalJSON));
  }
  inputclick(hobbar) {
	  console.log('this.inputEl.nativeElement.focus();');
 

  }

  onReset(){
    let i =0;
	this.FinalJSON.wsapicontent.array = [];
	this.FinalJSON.eswdocument.empcommunities = [];
    for (i = 0; i < this.hobbarrreplica.length; i++) {	
		this.FinalJSON.wsapicontent.array.push({
          'uniqueid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.commKeyCode + this.hobbarrreplica[i].communitieshasorder,
		  'device' : 'W',
          'employeeid': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id,
          'keycode': this.commKeyCode + '',
          'keyword': this.hobbarrreplica[i].keyword,
          'txtvalue':this.hobbarrreplica[i].empyplinks,
          'hasorder': this.hobbarrreplica[i].communitieshasorder + '',
          'isdeleted': '1',
		  'modifiedby': (localStorage.getItem('loggedinUser').toString() ),
          'modifiedate': formatDate(this.today, 'yyyy-MM-dd hh:mm:ss a', 'en-US', '+0530')

        });
		this.FinalJSON.eswdocument.empcommunities.push({
			  'empyplinks': this.hobbarrreplica[i].empyplinks,
			  'id': JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id + this.commKeyCode + this.hobbarrreplica[i].communitieshasorder,
			  'communitieshasorder':  this.hobbarrreplica[i].communitieshasorder + '',
			  'keyword' :this.hobbarrreplica[i].keyword,
			  'delete' : true
	   });	
       this.hobbarrreplica[i].empyplinks = '';	
	   this.hobbarrreplica[i].keyword = '';		   
	}
	this.FinalJSON.wsapicontent.updations  =  i;
    this.FinalJSON.wsapicontent.insertions = 0;
	 
	console.log(JSON.stringify(this.FinalJSON));
  }
  	// ITTPPRD-1404
	clearSuggesters( trigger : MatAutocompleteTrigger ){
		setTimeout( () => {
			this.suggesters = [];
			trigger.closePanel()
        }, 300);
	}
	getSuggesters( value){
		this.sendSuggesterRequestData.emit({keycode: this.commKeyCode,value : value})
	}
	// ITTPPRD-1404
}

