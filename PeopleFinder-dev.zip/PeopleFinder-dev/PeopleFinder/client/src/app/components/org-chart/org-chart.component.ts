import { Component, OnInit, Inject, Input} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PeopleService } from '../../services/people/people.service';

@Component({
  selector: 'app-org-chart',
  templateUrl: './org-chart.component.html',
  styleUrls: ['./org-chart.component.css']
})
export class OrgChartComponent implements OnInit {
  @Input('employeeId') employeeId: any;
  isDataLoading: boolean = true;
  orgchartlist: Array<any> = [];
  directsAvl: boolean = false;
  orgchartAvl: boolean = true;
  levelTwoLength: number = 0;
  levelThreeLength: number = 0;
  levelTwoSrt: Array<any> = [];
  levelTwoArrows: boolean = true;
  levelTwoPrev: boolean = false;
  levelTwoNext: boolean = false;
  levelTwoPrevData: Array<any> = [];
  levelTwoNextData: Array<any> = [];
  levelThreeSrt: Array<any> = [];
  levelThreeArrows: boolean = true;
  levelOne: Array<any> = [];
  levelTwo: Array<any> = [];
  levelThree: Array<any> = [];
  searchedIdData: any;
  levelThreeExists: boolean = false;
  levelThreeNextData: Array<any> = [];
  levelThreePrevData: Array<any> = [];
  levelThreeNext: boolean = false;
  levelThreePrev: boolean = false;
  expandmoreicon: boolean = false;
  expandlessicon: boolean = false;

  constructor(public dialog: MatDialog, private peopleService: PeopleService) { }

  ngOnInit() {
    this.getOrgChartData(this.employeeId);
  }

  onNoClickfrall() {
    this.dialog.closeAll();
  }

  getOrgChartData(emp_id){
    this.peopleService.getEmpOrgchart(emp_id).then(orgchartResponse => {
      if(orgchartResponse != null && orgchartResponse != undefined){
        this.orgchartlist =  orgchartResponse.row;
        if((this.orgchartlist != null && this.orgchartlist != undefined ) && this.orgchartlist.length > 0 ){
          for(let i = 0; i < this.orgchartlist.length; i++){
            let level = this.orgchartlist[i].TREELEVEL;
            if(this.orgchartlist[i] != undefined && level == 1){
              this.levelOne.push(this.orgchartlist[i]);
            }else if(this.orgchartlist[i] != undefined && level == 2){
              this.levelTwoLength += 1;
              if(this.orgchartlist[i].EMPLID == this.employeeId){
                this.searchedIdData = this.orgchartlist[i];
              }else{
                this.levelTwo.push(this.orgchartlist[i]);
                }
              }else if(this.orgchartlist[i] != undefined && level == 3){
                this.levelThreeLength += 1;
                this.expandmoreicon = true;
                this.levelThreeExists = true;
                this.levelThree.push(this.orgchartlist[i]);
                }
            }
          if(this.levelTwo != null && this.levelTwo != undefined){
            if(this.levelTwo.length > 2){
              this.levelTwoSrt.push(this.levelTwo[0]);
              if(this.searchedIdData != null){
                this.levelTwoSrt.push(this.searchedIdData);
                this.levelTwoSrt.push(this.levelTwo[1]);
                //this.levelTwoNext = true;
                for(let j = 2; j < this.levelTwo.length; j++){
                  this.levelTwoNextData.push(this.levelTwo[j]);
                }
              } else{
                  this.levelTwoSrt.push(this.levelTwo[1]);
                  this.levelTwoSrt.push(this.levelTwo[2]);
                  for(let j = 3; j < this.levelTwo.length; j++){
                    this.levelTwoNextData.push(this.levelTwo[j]);
                  }
                }
              if(this.levelTwoNextData != null && this.levelTwoNextData.length > 0){
                this.levelTwoNext = true;
              }
            }else if( this.levelTwo.length <= 2 && this.levelTwo.length > 0){
              this.levelTwoArrows = false;
              if(this.searchedIdData != null){
                this.levelTwo.splice(1,0,this.searchedIdData);
              }
            }else if(this.searchedIdData != null){
              this.levelTwoArrows = false;
              this.levelTwo.push(this.searchedIdData);
            }
          }
          if(this.levelThree != null && this.levelThree != undefined){
            if(this.levelThree.length > 3){
              this.levelThreeNext = true;
              this.levelThreeArrows = true;
              this.levelThreeSrt.push(this.levelThree[0]);
              this.levelThreeSrt.push(this.levelThree[1]);
              this.levelThreeSrt.push(this.levelThree[2]);
              for(let j = 3; j < this.levelThree.length; j++){
                this.levelThreeNextData.push(this.levelThree[j]);
              }
            }else if(this.levelThree.length <= 3 && this.levelThree.length > 0){
              this.levelThreeArrows = false;
            }
          }
          this.isDataLoading = false;
        }else{
          this.isDataLoading = false;
          this.orgchartAvl = false;
        }
        this.isDataLoading = false;
      }else{
        this.isDataLoading = false;
        this.orgchartAvl = false;
      }
      this.isDataLoading = false;
    }, error => {
      this.isDataLoading = false;
      this.orgchartAvl = false;
      
    });
  }

  loadL2NextData(){
    this.directsAvl = false;
    this.expandmoreicon = true;
    this.expandlessicon = false;
    if(this.levelTwoNextData.length <= 1){
      this.levelTwoNext = false;
    }
    this.levelTwoPrevData.push(this.levelTwoSrt[0]);
    this.levelTwoPrev = true;
    this.levelTwoSrt[0] = this.levelTwoSrt[1];
    this.levelTwoSrt[1] = this.levelTwoSrt[2];
    this.levelTwoSrt[2] = this.levelTwoNextData[0];
    this.levelTwoNextData.splice(0,1);
  } 
  
  loadL2PrevData(){
    this.directsAvl = false;
    this.expandmoreicon = true;
    this.expandlessicon = false;
    let lengthPrevData = this.levelTwoPrevData.length;
    if(lengthPrevData <= 1){
      this.levelTwoPrev = false;
    }
    this.levelTwoNextData.splice(0,0,this.levelTwoSrt[2]);
    this.levelTwoNext = true;
    this.levelTwoSrt[2] = this.levelTwoSrt[1];
    this.levelTwoSrt[1] = this.levelTwoSrt[0];
    this.levelTwoSrt[0] = this.levelTwoPrevData[lengthPrevData - 1];
    this.levelTwoPrevData.splice(lengthPrevData - 1, 1);
  }

  loadL3NextData(){
    if(this.levelThreeNextData.length <= 1){
      this.levelThreeNext = false;
    }
    this.levelThreePrevData.push(this.levelThreeSrt[0]);
    this.levelThreePrev = true;
    this.levelThreeSrt[0] = this.levelThreeSrt[1];
    this.levelThreeSrt[1] = this.levelThreeSrt[2];
    this.levelThreeSrt[2] = this.levelThreeNextData[0];
    this.levelThreeNextData.splice(0,1);
  }

  loadL3PrevData(){
    let lengthL3Prev = this.levelThreePrevData.length;
    if(lengthL3Prev <= 1){
      this.levelThreePrev = false;
    }
    this.levelThreeNextData.splice(0,0,this.levelThreeSrt[2]);
    this.levelThreeNext = true;
    this.levelThreeSrt[2] = this.levelThreeSrt[1];
    this.levelThreeSrt[1] = this.levelThreeSrt[0];
    this.levelThreeSrt[0] = this.levelThreePrevData[lengthL3Prev - 1];
    this.levelThreePrevData.splice(lengthL3Prev - 1, 1);
  }

  showDirects(){
    this.directsAvl = true;
    this.expandmoreicon = false;
    this.expandlessicon = true;
  }

  hideDirects(){
    this.directsAvl = false;
    this.expandmoreicon = true;
    this.expandlessicon = false;
  }

  getOrgChartOnNodeClick(emp_id){
    this.isDataLoading = true;
    this.orgchartlist= [];
    this.directsAvl = false;
    this.orgchartAvl = true;
    this.levelTwoLength = 0;
    this.levelThreeLength = 0;
    this.levelTwoSrt = [];
    this.levelTwoArrows = true;
    this.levelTwoPrev = false;
    this.levelTwoNext = false;
    this.levelTwoPrevData = [];
    this.levelTwoNextData = [];
    this.levelThreeSrt = [];
    this.levelThreeArrows = true;
    this.levelOne = [];
    this.levelTwo = [];
    this.levelThree = [];
    this.searchedIdData = null;
    this.employeeId = emp_id;
    this.levelThreeExists = false;
    this.levelThreeNextData = [];
    this.levelThreePrevData = [];
    this.levelThreeNext = false;
    this.levelThreePrev = false;
    this.expandmoreicon = false;
    this.expandlessicon = false;
    this.getOrgChartData(emp_id);
   }
}