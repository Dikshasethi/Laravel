import { Component, OnInit } from '@angular/core';
@Component({
	selector: 'app-search-info',
	templateUrl: './search-info.component.html',
	styleUrls: ['./search-info.component.css']
})
export class SearchInfoComponent implements OnInit {
	total: string;
	outof: string;
	searchkey: string;
	suggesstion: any;
	options: any;
	value: string;
	score: any;
	searchselect: string;
	flag: Boolean = false;
	flagdidumean: Boolean = false;;
	url: string;
	isModifySearchText = false;
	norecochk = false;
	constructor() { }

	ngOnInit() {

	}
	populateSearchInfo(total, outof, searchkey, suggest, searchslect, noRecoFav) {

		this.isModifySearchText = false;
		this.total = total;
		this.outof = outof;
		if (noRecoFav != "notext") {
			this.searchkey = searchkey;
		}
		this.value = '';
		this.flag = false;

		if (suggest != undefined && suggest != '') {
			this.suggesstion = suggest.suggestions;
			this.options = this.suggesstion[0].options;
			this.searchselect = searchslect;
			this.score = 0;
			if (outof == 0 && this.searchselect == 'peoplefinder') {

				if (this.options.length > 0) {
					for (let i = 0; i < this.options.length; i++) {
						if (this.score < parseFloat(this.options[i].score)) {
							this.value = this.options[i].text;
							this.score = parseFloat(this.options[i].score);
						}
					}
				} else {
					this.value = this.suggesstion[0].text;
					this.isModifySearchText = true;
				}
			}
		}

		if (this.value == '') {
			this.flag = true;
			this.flagdidumean = false;
		} else {
			this.flagdidumean = true;
		}
		this.url = document.location.protocol + '//' + document.location.hostname + ':' + document.location.port + '/people?name=' + this.value + '&searchSelect=peoplefinder';


	}
	populateSearchInfoNoRecord(norecochk) {

		this.norecochk = norecochk;


	}
}
