import { Component, OnInit,AfterViewInit } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { first } from 'rxjs/operators';
import { NgxSpinnerService } from 'ngx-spinner';
import { CookieService } from 'ngx-cookie-service';
import * as CryptoJS from 'crypto-js';
import { EncrDecrService } from '../../../app/services/EncrDecrService';
// import { UsersService } from './../shared/services/users/users.service';
import { MsalService, BroadcastService } from '@azure/msal-angular';
import { Logger, CryptoUtils } from 'msal';
import { Subscription, interval } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements AfterViewInit {


  resp: any;
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  error = '';
  sso_user: any;
  hide = true;
  name: string;
  searchSelect: string;
  appfidner: string = '';
  username = localStorage.getItem('isLoggedin');
  ssoLogout = localStorage.getItem('ssoLogout') ? localStorage.getItem('ssoLogout') : 'false';
  password: any;
  rememberMe: any = false;
  public Formdata: any = {};
  encryptSecretKey: any;
  encPassword: any;
  decPassword: any;

  userDetailSubscription;
  message = "";
  modalDisplay = "none";
  loginFail : boolean = false;
  loggedIn = false;
  subscriptions: Subscription[] = [];
  isIframe = false;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private spinner: NgxSpinnerService,
    private http: HttpClient,
    private cookieservice: CookieService,
    private EncrDecr: EncrDecrService,

    private authService: MsalService,
    private broadcastService: BroadcastService,
  ) {
   // this.isIframe = window !== window.parent && !window.opener;

  };


  ngAfterViewInit() {
    
    
    let loginSuccessSubscription: Subscription;
    let loginFailureSubscription: Subscription;
    let TokenSuccessSubscription: Subscription;
    let tokenFailureSubscription: Subscription;
    this.checkLoginStatus();

    loginSuccessSubscription=this.broadcastService.subscribe('msal:loginSuccess', () => {
      this.checkAccount();
    });
    loginFailureSubscription= this.broadcastService.subscribe('msal:loginFailure', (error) => {
     // console.log('Login Fails222:', error);
    });

    TokenSuccessSubscription= this.broadcastService.subscribe("msal:acquireTokenSuccess", payload => {
     // console.log('TokenSuccess:', payload);
    });
  
    tokenFailureSubscription =this.broadcastService.subscribe("msal:acquireTokenFailure", payload => {
      //console.log('TokenFailure:', payload);
    
   });

   this.subscriptions.push(loginSuccessSubscription);
   this.subscriptions.push(loginFailureSubscription);
   this.subscriptions.push(TokenSuccessSubscription);
   this.subscriptions.push(tokenFailureSubscription);


    this.authService.handleRedirectCallback((authError, response) => {
      if (authError) {
        console.error('Redirect Error: ', authError.errorMessage);
        return;
      }
      this.checkAccount();
    });
    if (localStorage.getItem('isLoggedin') || localStorage.getItem('isLoggedin') != null) {
      this.router.navigate(['/landing']);
      this.modalDisplay = "block";
    }
    else{
      this.modalDisplay = "none";
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }

  removeMsalToken() {
    for (const key of Object.keys(localStorage)) {
      if (key.includes('"authority":') || key.includes('msal.')) {
        localStorage.removeItem(key);
      }
    }
  }

  login() {
    const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;
    if (isIE) {
      this.authService.loginRedirect({
        extraScopesToConsent: ["user.read", "openid", "profile"]
      });
    } else {
      this.authService.loginPopup({
        extraScopesToConsent: ["user.read", "openid", "profile"]
      });
    }
  }

  checkLoginStatus = async () => {
    this.loggedIn = !!this.authService.getAccount();
   // console.log( this.loggedIn);
  }

  msalLoginRedirect() {
    const a = {
      scopes: [
        'user.read'
      ]
    };
    try {
      this.authService.loginPopup(a);
    } catch (error) {
    //  localStorage.setItem('login-retry', 'Y');
    }
  }

  checkAccount = async () => {
    let loggedIn = !!this.authService.getAccount();
    if(loggedIn){
         try {    
          const a = { scopes: ['user.read'] };
          
          this.authService.acquireTokenSilent(a).then((token) => {
              this.cookieservice.set('msalaccesstoken', token.accessToken);
              this.cookieservice.set('msalaccesstokenexpiration', `${new Date(token.expiresOn).getTime()}`);
              this.validateMsalToken();
          })
         .catch((error) => {
            if (error.errorCode === "consent_required" || error.errorCode === "interaction_required" || error.errorCode === "login_required") 
              {
                this.authService.acquireTokenPopup({
                  scopes: ["user.read"]}).then(function (response) {

                    this.cookieservice.set('msalaccesstoken', response.accessToken);
                    this.cookieservice.set('msalaccesstokenexpiration', `${new Date(response.expiresOn).getTime()}`);
                    this.cookieservice.set('expiry', `${new Date(response.expiresOn).getTime() / 1000}`);
                    this.validateMsalToken();

                  }).catch(function (error) {
                      console.log(error);
                  });
              }
        });
      } catch (err) {
        this.modalDisplay = 'none';
        this.removeMsalToken();
        this.msalLoginRedirect();
      }
    }else{
      
    }
  }

  validateMsalToken() {
      this.spinner.show();
      try {
      let body={};
      this.http.post('/api/user/login',body)
        .subscribe(
        (res) => {
          this.resp = res;
          if (this.resp.result === 'authorized') {   
            this.spinner.hide();
            localStorage.setItem('isLoggedin', JSON.stringify(this.resp));
            localStorage.setItem('loggedinUser', this.resp.emp_username);
            this.cookieservice.set('expiry', this.resp.expiry); 
            this.cookieservice.set('authTokenExpiryTime',this.resp.empDataExpiry);
            this.cookieservice.set('authToken', this.resp.token);
            this.router.navigate(['/landing']);
          } else if (this.resp.result === 'unauthorized') {
            this.error = 'Unauthorized';
            this.loading = false;
            this.spinner.hide();
          } else if (res === 'Error') {
            this.error = 'Something Went Wrong';
            this.loading = false;
          }
        },
        err => {
              this.error = 'none';
              this.error = 'Something Went Wrong';
              this.loading = false;
            }
          );
      } catch (error) {
      }
    }
 
}


