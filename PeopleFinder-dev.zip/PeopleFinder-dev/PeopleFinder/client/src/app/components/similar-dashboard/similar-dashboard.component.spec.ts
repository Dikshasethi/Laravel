import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SimilarDashboardComponent } from './similar-dashboard.component';

describe('SimilarInterestComponent', () => {
  let component: SimilarDashboardComponent;
  let fixture: ComponentFixture<SimilarDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SimilarDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SimilarDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
