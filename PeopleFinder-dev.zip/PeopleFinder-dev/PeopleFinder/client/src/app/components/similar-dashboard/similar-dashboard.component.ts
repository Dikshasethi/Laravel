import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { SimilarDashboardService } from "../../services/similar-dashboard.service";
import { PeopleService } from "../../services/people/people.service";
@Component({
	selector: 'app-similar-dashboard',
	templateUrl: './similar-dashboard.component.html',
	styleUrls: ['./similar-dashboard.component.css']
})
export class SimilarDashboardComponent implements OnInit {
	page: number = 1
	itemsPerPage: number = 4;
	similarDataArr: any = [];
	empid: string = '';
	totalItems: number = 0;
	lastPage: number = 0;
	firstPage: number = 1;
	previous_buttons: boolean = true;
	next_buttons: boolean = true;
	imageloaded : boolean = false;
	@Input() keycode: number;
	@Input() title: string;
	similarData: any = [];
	constructor(private similarDashboardService: SimilarDashboardService, private peopleService: PeopleService,private router: Router) { }
	ngOnInit() {
		this.empid = JSON.parse(localStorage.getItem('isLoggedin').toString()).employee_id;
		this.getSimilarDashboard();
	}
	getSimilarDashboard() {
		let args = {
			empid: this.empid,
			page: this.page,
			items: this.itemsPerPage,
			keycode: this.keycode
		}
		this.imageloaded = false
		this.similarDashboardService.getSimilarDashboard(args).subscribe(res => {
			this.similarData = res['data']
			this.totalItems = res['count'] !== undefined ? res['count'] : this.totalItems
			this.updatePaginationLinks()
			let empIds = []
			for (const emp of this.similarData) {
				empIds.push(emp._id)
			}
			
			this.peopleService.getEmpImageById(empIds)
				.then (empImageResponse => {
					for(let empimg of empImageResponse.data){
						const indx = empIds.indexOf(empimg.employeeId);
						empIds.splice(indx, 1);
						let empObj = this.similarData.find((item) => item._id == empimg.employeeId);
						if (empObj && empimg.signedUrl_compressed) {
							empObj['empimage'] = empimg.signedUrl_compressed;
						} else {
							empObj['empimage'] = "/assets/images/img-avatar.png";
						}
					}
					if (empIds.length > 0) {
						for (let j = 0; j < empIds.length; j++) {
							let empObj = this.similarData.find((item) => item._id == empIds[j]);
							empObj['empimage'] = "/assets/images/img-avatar.png";
						}
					}
					this.imageloaded = true 
				}).catch ( error =>{
					for (let j = 0; j < empIds.length; j++) {
						let empObj = this.similarData.find((item) => item._id == empIds[j]);
						empObj['empimage'] = "/assets/images/img-avatar.png";
						this.imageloaded = true
					}
				})
				
		}),	error => {
			alert(error)
		};
	}
	

	updatePaginationLinks() {
		if (this.totalItems > this.itemsPerPage) {
			this.lastPage = Math.ceil(this.totalItems / this.itemsPerPage)
			this.next_buttons = this.page < this.lastPage ? false : true;
		}

	}
	updateData(pageNum) {
		this.page = pageNum
		this.previous_buttons = this.page > this.firstPage ? false : true
		this.next_buttons = this.page < this.lastPage ? false : true;
		this.getSimilarDashboard()

	}

	onSelectClick(searchkey) {
		this.router.navigate(['/people/'], { queryParams: { name: searchkey, searchSelect: 'peoplefinder', noRecoFav: "notext" } });
	}
}
