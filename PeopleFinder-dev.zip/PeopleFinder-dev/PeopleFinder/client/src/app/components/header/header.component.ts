import * as moment from 'moment';
import { CookieService } from 'ngx-cookie-service';
import { Component, OnInit, HostListener } from '@angular/core';
import { PeopleService } from '../../services/people/people.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthenticationService } from 'src/app/services/auth.service';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/internal/operators';
import { SnotifyService, SnotifyPosition, SnotifyToastConfig } from '../../../../node_modules/ng-snotify';
import { MsalService, BroadcastService } from '@azure/msal-angular';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  extralinkblck = false;
  public dispblock: string = 'hide';
  searchkey: any;
  selectedValue: string;
  myId = '02034620';
  inputparam: any;
  isShowTopSearchbar: boolean;
  removedquotes: string;
  removedquotesarr = [];
  loggedinuser: string;
  message: any;
  shareparam: any;
  selected: string;
  id: string;
  routerUrl;
  // username = JSON.parse(localStorage.getItem('isLoggedin').toString()).emp_name;
  username;
  isSessionReneweActive = false;
  profileId: any;
  favEmployeeList: any;
  workAnniversary: any;
  notificationCount: any;
  notificationSeen = false;
  modalDisplay: string;
  isLargeScreen = false;
  notification = false;
  imageloaded : Boolean= false
  @HostListener('window:click', ['$event'])
  @HostListener('window:mousemove', ['$event'])
  @HostListener('window:scroll', ['$event'])
  onTap(e) {
    //this.listen(e);
  }
  isFocusInsideComponent = false;
  isComponentClicked = false;
  @HostListener('click')
  clickInside() {
    if (!this.isFocusInsideComponent && this.isComponentClicked && this.notification) {
      this.notification = false;
    }
    this.isFocusInsideComponent = true;
    this.isComponentClicked = true;
  }

  @HostListener('document:click')
  clickout() {
    if (!this.isFocusInsideComponent && this.isComponentClicked) {
      this.notification = false;
      this.isComponentClicked = false;
    }
    this.isFocusInsideComponent = false;
  }

  emplist = "";
  favorite = false;
  employee_id: any;
  constructor(public peopleService: PeopleService,
    private router: Router,
    private snotifyService: SnotifyService,
    private location: Location,
    private spinner: NgxSpinnerService,
    private authService: AuthenticationService,
    private cookieService: CookieService,
    private msalService: MsalService,
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };
    if (window.screen.width >= 1360) {
      this.isLargeScreen = true;
    }
    window.onresize = () => this.isLargeScreen = window.innerWidth >= 1360;
  }
  delayedObservable = of(['']).pipe(delay(2000));

  ngOnInit() {
    this.routerUrl = this.router.url;
    this.routerUrl = this.routerUrl.trim();
    this.routerUrl = this.routerUrl.split('?')[0];
    this.selectedValue = 'peoplefinder';
    this.peopleService.setglobalvar(this.selectedValue, this.searchkey);
    this.peopleService.setglobalvar(this.selectedValue, this.searchkey);
    this.id = '38870';
    const loggedinUser = localStorage.getItem('isLoggedin');

    if (typeof loggedinUser !== 'undefined' && loggedinUser !== null) {
      this.username = JSON.parse(loggedinUser.toString()).emp_name;
      this.profileId = JSON.parse(localStorage.getItem('isLoggedin')).employee_id;
      this.peopleService.workAnniversary().
        subscribe(
          (Response) => {
           // console.log("!!!!",Response);
            this.notificationCount = Object.keys(Response).length
            if (this.notificationCount > 0) {
              this.notificationCount
            }
            else {
              // this.notificationCount = "";
              this.notificationSeen = true
            }
          }), error => alert("Something Went Wrong, Please try in sometime")
    }
  }

  listen(event) {
    if (localStorage.getItem('isLoggedin') && !this.isSessionReneweActive) {

      this.isSessionReneweActive = true;
     // console.log(this.cookieService.get('expiry'));
      let expiryTime: any = this.cookieService.get('expiry');
      console.log(expiryTime);
      if (expiryTime) {
        let now = moment(new Date());
        let expiration = moment.unix(expiryTime);
        // get the difference between the moments
        let diff = expiration.diff(now);
        //express as a duration
        let diffDuration = moment.duration(diff);
        let min = diffDuration.asMinutes();
       // console.log(min);
        if (min <= 1) {
          this.authService.sessionRenew()
            .pipe()
            .subscribe(data => {
              if (data.state && data.state == "extend") {
                this.cookieService.set('expiry', data.newExpiry);
                this.isSessionReneweActive = false;
              }
            },
              error => {
                this.spinner.hide();
                this.isSessionReneweActive = false;

              });
        }
        else {
          this.isSessionReneweActive = false;
        }
      }
      else {
        this.isSessionReneweActive = false;
      }
    }
  }

  logout() {
    var urls = this.router.url;
    var req = new XMLHttpRequest(); req.open('GET', urls, false); req.send(null);
    var sso_user = req.getResponseHeader('sso_user');
    if(sessionStorage.getItem('lastRoute')){
      sessionStorage.removeItem('lastRoute') 
    }
    this.spinner.show();
    this.clearMsalCache();
    localStorage.clear();
    this.authService.logout()
      .pipe()
      .subscribe(data => {
        this.spinner.hide();
        if (sso_user) {
          localStorage.setItem('ssoLogout', 'true');
        }
        this.router.navigate(['/login']);
      },
        error => {
          this.spinner.hide();

        });
    this.delayedObservable.subscribe(d => {
      this.msalService.logout();
    });
       
  }
  clearMsalCache = () => {
    this.cookieService.delete('msalaccesstoken');
    this.cookieService.delete('msalaccesstokenexpiration');
    this.cookieService.delete('authToken');
    this.cookieService.delete('es_access_token');
    this.cookieService.delete('es_token_expiry_time');
    this.cookieService.delete('authTokenExpiryTime');
  }
  changetext() {
    this.peopleService.setglobalvar(this.selectedValue, this.searchkey);
  }
  changeadvsearch() {
    this.peopleService.setglobalvar(this.selectedValue, this.searchkey);
  }
  gotomyprofile() {
    this.router.navigate(['/myprofile/'], { queryParams: { searchSelect: this.selectedValue } });
  }
  showHide1(): void {
    this.dispblock = this.dispblock === 'hide' ? 'show' : 'hide';
  }
  advsearch() {
    try {

      if (this.searchkey === undefined || this.searchkey === '') {
        this.snotifyService.info('Please Enter something to search...');
        return false;
      }
      if (this.searchkey.includes('"')) {
        if (this.searchkey.includes(',')) {
          if (this.selectedValue === 'peoplefinder') {
            this.snotifyService.error('You cant search multiple people from basic search');
            return false;
          }
          const newStr = this.searchkey.substring(0, this.searchkey.length - 1);
          this.router.navigate(['/people/'], { queryParams: { name: '"' + newStr.slice(1).replace('"', '').replace('"', '').replace(',', '","') + '"', searchSelect: this.selectedValue } });
        } else {
          const newStr = this.searchkey.substring(0, this.searchkey.length - 1);
          this.router.navigate(['/people/'], { queryParams: { name: '"' + newStr.slice(1) + '"', searchSelect: this.selectedValue } });
        }
      } else {
        if (this.searchkey.includes(',')) {
          this.router.navigate(['/people/'], { queryParams: { name: this.searchkey, searchSelect: this.selectedValue } });
        } else {
          this.router.navigate(['/people/'], { queryParams: { name: this.searchkey, searchSelect: this.selectedValue } });
        }
      }
    } catch (e) {
    }
  }
  gotoHome() {
    this.router.navigate(['/']);
  }

  goToLabel() {
    this.router.navigate(['/mylabel/']);
  }

  async getMyFavorite() {
    await this.peopleService.fetchFavouriteData(this.profileId).then(
      (res) => {
        this.favEmployeeList = res.empfavouriteslist;
      }), error => {
        alert("Their is some error.");
      };
    for (var i = 0; i < this.favEmployeeList.length; i++) {
      this.emplist = this.emplist + ',' + this.favEmployeeList[i]
    }


    if (this.emplist != "") {
      this.router.navigate(['/people/'], { queryParams: { name: this.emplist, searchSelect: "peoplefinder", noRecoFav: "notext" } });
    } else
      if (this.emplist == "") {
        this.router.navigate(['/people/'], { queryParams: { name: '', searchSelect: "peoplefinder", noRecoFav: "myFav" } });
      }
      else {
        this.router.navigate(['/people/'], { queryParams: { name: '', searchSelect: "peoplefinder", noRecoFav: "myFav" } });
      }

  }

  getNotification() {
    this.notification = !this.notification;
    if (this.notification) {
      this.modalDisplay = "show"
      this.isComponentClicked = false;
      this.isFocusInsideComponent = false;

    }
    this.peopleService.workAnniversary().
      subscribe(
        (Response) => {
          this.modalDisplay = "none"
          this.workAnniversary = Response;
          this.notificationSeen = true;
          this.getImages()
        }), error => alert("Something Went Wrong, Please try in sometime")
  }

  addClassMat(action) {
    var element = document.getElementsByClassName("cdk-overlay-pane")[0];
    if (element != undefined && action == "search") {
      element.classList.add("search");
    }
    else if (element != undefined && action == "nav") {
      element.classList.add("nav");

    }
  }
  onSelectClick(searchkey) {
    this.router.navigate(['/people/'], { queryParams: { name: searchkey, searchSelect: 'peoplefinder', noRecoFav: "notext" } });
  }
  menufavlinks() {
    this.extralinkblck = !this.extralinkblck;

  }

  public sendMail(ename, jobfunc, years, toAdr) {
    let fname = ename.split(" ", 1);
    let subject = "Congratulations on work anniversary!!!"
    let displayName = this.username;
    let body = {
      frstName: fname,
      designation: jobfunc,
      fullName: ename,
      totalYrs: years,
    };
    let toaddr = toAdr;
    let frmAddr;
    if (localStorage.getItem('loggedinUser') != null) {
      frmAddr = localStorage.getItem('loggedinUser') + '@oceaneering.com';
      this.peopleService.sendeEmail(frmAddr, toaddr, displayName, subject, body).subscribe
        (Response => {
        })
    } else {
      //redirect to login page.
    }
  }
  public getImages() {
    let empIds: Array<string> = []
    for (const iterator of this.workAnniversary ) {
      empIds.push(iterator._id);
    }
    this.peopleService.getEmpImageById(empIds).then((empImageResponse) => {
      for(let empimg of empImageResponse.data){
        const indx = empIds.indexOf(empimg.employeeId);
				empIds.splice(indx, 1);
        let empObj = this.workAnniversary.find((item) => item._id == empimg.employeeId);
        if (empObj && empimg.signedUrl_compressed) {
          empObj['empimage'] = empimg.signedUrl_compressed;
        } else {
          empObj['empimage'] = "/assets/images/img-avatar.png";
        }
        if (empIds.length > 0) {
          for (let j = 0; j < empIds.length; j++) {
            let empObj = this.workAnniversary.find((item) => item._id == empIds[j]);
            empObj['empimage'] = "/assets/images/img-avatar.png";
          }
        }
        this.imageloaded = true 
      }
    })
  }
}
