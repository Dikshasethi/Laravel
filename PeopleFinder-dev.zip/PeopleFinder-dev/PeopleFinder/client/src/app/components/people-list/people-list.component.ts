import { subscribeOn } from 'rxjs/operators';
import { Component, OnInit, EventEmitter, ViewChild, Output } from '@angular/core';
import { DOCUMENT } from "@angular/platform-browser";
import { Inject, HostListener } from "@angular/core";
import { Injectable } from "@angular/core";
import { PeopleService } from '../../services/people/people.service';
import { ProfileComponent } from '../../components/profile/profile.component';
import { NgxSpinnerService } from 'ngx-spinner';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../environments/environment';
import { containsElement } from '@angular/animations/browser/src/render/shared';
import { MatDialog } from '@angular/material';
import { forEach } from '@angular/router/src/utils/collection';
import { appConfigurationService } from '@/services/appConfigurationService';


@Injectable()

@Component({
	selector: 'app-people-list',
	templateUrl: './people-list.component.html',
	styleUrls: ['./people-list.component.css']
})
export class PeopleListComponent implements OnInit {

	peoples = [];
	private dom: Document;
	employee_id: any;
	environment: any;
	requestOptions: any;
	experiance: any;
	@Output() scrollEvent = new EventEmitter<string>();
	@Output() refreshPeopleList = new EventEmitter();
	profileId: any;
	userroles: any;
	public show: boolean = false;
	public index;
	public labelindex;
	result: false;
	labelList: any;
	labelName = false;
	empEmail: any;
	sme: any = [];
	isConfigDataAvailable = false;
	configData: any = [];
	Ipeople: any = {
		data: {
			aggregations: {
				LocationCount: { buckets: [] },
				empjobfunctionCount: { buckets: [] },
				empservicelinecount: { buckets: [] },
				empjobsubfuncioncount: { buckets: [] }
			},
			hits: {
				hits: [],
			},
		}, success: []
	};
	favEmployeeList: any;
	emplist = "";
	temp;
	labelsnames: string[];
	tempIndex: any;
	arrLabelList = [];
	modalDisplay = "none";
	favrecords = "";
	isFocusInsideComponent = false;
	isComponentClicked = false;
	checkClick = false;
	// ITTPPRD-1404
	suggesters : any = {}
	// ITTPPRD-1404
	@HostListener('click')
	clickInside() {
		if (!this.isFocusInsideComponent && this.isComponentClicked && this.show) {
			this.show = false
		}
		if (this.checkClick) {
			this.show = true
		}
		this.isFocusInsideComponent = true;
		this.isComponentClicked = true;
	}

	@HostListener('document:click')
	clickout() {
		if (!this.isFocusInsideComponent && this.isComponentClicked) {
			this.show = false
			this.isComponentClicked = false;
		}
		this.checkClick = false;
		this.isFocusInsideComponent = false;
	}



	constructor(@Inject(DOCUMENT) dom: Document, private peopleservice: PeopleService,
		private spinner: NgxSpinnerService, private http: HttpClient, private router: Router, private route: ActivatedRoute,
		public dialog: MatDialog, public peopleService: PeopleService, private appconfig: appConfigurationService) { }

	ngOnInit() {
		this.appconfig.getJSON().subscribe(data => {
			this.configData = data;
			this.isConfigDataAvailable = true;
		});
		this.route.queryParams
			.subscribe(params => {
				this.favrecords = params.noRecoFav;
			});
		this.profileId = JSON.parse(localStorage.getItem('isLoggedin')).employee_id;
		this.userroles = JSON.parse(localStorage.getItem('isLoggedin')).userroles;	
		/* this.peopleservice.getProfile().subscribe( Ipeople => {
			this.Ipeople = Ipeople
			this.empEmail = this.Ipeople.data.hits.hits[0]._source.employeeemail;
		}) */


	}

	manageToggle() {
		this.checkClick = true;
	}

	openOrgChartDialog(orgcharttemplate): void {
		const dialogRef = this.dialog.open(orgcharttemplate, {
			height: '700px',
			width: '950px'
		});
	}

	openSMEDialog(smetemplate): void {
		const dialogRef = this.dialog.open(smetemplate, {
			height: '400px',
			width: '950px'
		});
	}
	/* getEmployeeEmail(){
		return this.empEmail;
	  } */

	getSMEArray(smearr) {
		if (smearr != undefined && smearr != null)
			this.sme = smearr;
		else
			this.sme = [];
		return this.sme;
	}


	populatePeopleListInfo(lisrarr, favList, labellist) {
		if (lisrarr != undefined) {
			for (var i = 0; i < lisrarr.length; i++) {
				lisrarr[i]['labelList'] = labellist;
			}
			if (favList.length > 0) {
				for (var a = 0; a < lisrarr.length; a++) {
					for (var j = 0; j < favList.length; j++) {
						if (lisrarr[a]._id == favList[j]) {
							lisrarr[a].flag = true;
							break;
						}
						else {
							lisrarr[a].flag = undefined
						}
					}
				}
			}
			this.peoples = this.peoples.concat(lisrarr);
			if (this.peoples != [] && this.peoples.length > 0) {
				this.getSortedList();
			}
			for (let i = 0; i < this.peoples.length; i++) {
				if (this.peoples[i]._source.isImagePresent == undefined) {
					this.peoples[i]._source['empimage'] = "/assets/images/img-avatar.png";
				}
			}
			if (this.peoples.length < 10) {
				this.fetchImageByIndex(0, this.peoples.length - 1);
			}
			else {
				this.fetchImageByIndex(this.peoples.length - 10, this.peoples.length - 1);
			}
		}
	}


	fetchImageByIndex(startIndex, endIndex) {
		let empids: Array<string> = []
		for (let i = startIndex; i <= endIndex; i++) {
			empids.push(this.peoples[i]._source.empid);
		}
		this.peopleService.getEmpImageById(empids).then((empImageResponse) => {
			for (let j = 0; j < empImageResponse.data.length; j++) {
				const indx = empids.indexOf(empImageResponse.data[j].employeeId);
				empids.splice(indx, 1);
				let empObj = this.peoples.find((item) => item._source.empid == empImageResponse.data[j].employeeId);
				if (empObj && empImageResponse.data[j].signedUrl_compressed) {
					empObj._source['empimage'] = empImageResponse.data[j].signedUrl_compressed;
				} else {
					empObj._source['empimage'] = "/assets/images/img-avatar.png";
				}
				empObj._source['isImagePresent'] = true;
			}
			if (empids.length > 0) {
				for (let j = 0; j < empids.length; j++) {
					let empObj = this.peoples.find((item) => item._id == empids[j]);
					empObj._source['empimage'] = "/assets/images/img-avatar.png";
					empObj._source['isImagePresent'] = true;
				}
			}
		}), error => {
			this.spinner.hide();
			for (let j = 1; j <= empids.length; j++) {
				this.peoples[j]._source['empimage'] = "/assets/images/img-avatar.png";
				this.peoples[j]._source['isImagePresent'] = true;
			}
		};
	}


	populatePeopleListscrollInfo(listarr: []) {
		this.peoples.push.apply(this.peoples, listarr);
		if (this.peoples != [] && this.peoples.length > 0) {
			this.getSortedList();
		}
	}

	shareService() {

	}

	onScroll() {
		this.scrollEvent.next('componentScrolled');
	}

	copyToClipboard(ppl, id, type) {
		var aux: any;
		aux = document.createElement("input");
		let divId = id;
		if (type === 'email') {
			divId = 'email' + id;
			aux.value = ppl;
		}
		else {
			if (document.location.port) {
				aux.value = document.location.protocol + '//' + document.location.hostname + ':' + document.location.port + "/people?name=" + ppl._id + "&searchSelect=peoplefinder";
			} else {
				aux.value = document.location.protocol + '//' + document.location.hostname + "/people?name=" + ppl._id + "&searchSelect=peoplefinder";
			}
		}

		//aux.value = document.location.protocol + '//' + document.location.hostname + ':' + document.location.port + "/people?name=" + ppl._id + "&searchSelect=peoplefinder";
		document.body.appendChild(aux);
		aux.focus();
		aux.select();
		document.execCommand("copy");
		aux.style.display = 'none';
		const objDiv = document.getElementById(divId);
		objDiv.style.visibility = "visible";
		setTimeout(() => {
			objDiv.style.visibility = "hidden";
		}, 2000);
	}

	onSelectClick(searchkey) {

		this.router.navigate(['/people/'], { queryParams: { name: searchkey, searchSelect: 'peoplefinder' } });
	}

	getSortedList() {
		if (this.peoples != undefined) {
			for (let i = 0; i < this.peoples.length; i++) {

				if (this.peoples[i] != undefined && this.peoples[i]._source != undefined && this.peoples[i]._source.empexperiences != undefined) {

					if (this.peoples[i]._source.empexperiences.length > 0) {
						this.peoples[i]._source.empexperiences.sort(function (obj1, obj2) {
							if (obj1 != null && obj2 != null) {
								return obj1.experienceshasorder - obj2.experienceshasorder;
							}
						});
					}
				}
				if (this.peoples[i] != undefined && this.peoples[i]._source != undefined && this.peoples[i]._source.empsplanguage != undefined) {
					if (this.peoples[i]._source.empsplanguage.length > 0) {
						this.peoples[i]._source.empsplanguage.sort(function (obj1, obj2) {
							if (obj1 != null && obj2 != null) {
								return obj1.splanguagehasorder - obj2.splanguagehasorder;
							}
						});
					}
				}
				if (this.peoples[i] != undefined && this.peoples[i]._source != undefined && this.peoples[i]._source.empinteresthobbies != undefined) {
					if (this.peoples[i]._source.empinteresthobbies.length > 0) {
						this.peoples[i]._source.empinteresthobbies.sort(function (obj1, obj2) {
							if (obj1 != null && obj2 != null) {
								return obj1.interesthobbieshasorder - obj2.interesthobbieshasorder;
							}
						});
					}
				}
				if (this.peoples[i] != undefined && this.peoples[i]._source != undefined && this.peoples[i]._source.empeducation != undefined) {
					if (this.peoples[i]._source.empeducation.length > 0) {
						this.peoples[i]._source.empeducation.sort(function (obj1, obj2) {
							if (obj1 != null && obj2 != null) {
								return obj1.educationhasorder - obj2.educationhasorder;
							}
						});
					}
				}
				if (this.peoples[i] != undefined && this.peoples[i]._source != undefined && this.peoples[i]._source.empcountriesworked != undefined) {
					if (this.peoples[i]._source.empcountriesworked.length > 0) {
						this.peoples[i]._source.empcountriesworked.sort(function (obj1, obj2) {
							if (obj1 != null && obj2 != null) {
								return obj1.countriesworkedhasorder - obj2.countriesworkedhasorder;
							}
						});
					}
				}
				if (this.peoples[i] != undefined && this.peoples[i]._source != undefined && this.peoples[i]._source.empcertification != undefined) {
					if (this.peoples[i]._source.empcertification.length > 0) {
						this.peoples[i]._source.empcertification.sort(function (obj1, obj2) {
							if (obj1 != null && obj2 != null) {
								return obj1.certificationhasorder - obj2.certificationhasorder;
							}
						});
					}
				}
				if (this.peoples[i] != undefined && this.peoples[i]._source != undefined && this.peoples[i]._source.emptradesassociation != undefined) {
					if (this.peoples[i]._source.emptradesassociation.length > 0) {
						this.peoples[i]._source.emptradesassociation.sort(function (obj1, obj2) {
							if (obj1 != null && obj2 != null) {
								return obj1.tradesassociationhasorder - obj2.tradesassociationhasorder;
							}
						});
					}
				}
				if (this.peoples[i] != undefined && this.peoples[i]._source != undefined && this.peoples[i]._source.empcommunities != undefined) {

					if (this.peoples[i]._source.empcommunities.length > 0) {
						this.peoples[i]._source.empcommunities.sort(function (obj1, obj2) {
							if (obj1 != null && obj2 != null) {
								return obj1.communitieshasorder - obj2.communitieshasorder;
							}
						});
					}
				}
				if (this.peoples[i] != undefined && this.peoples[i]._source != undefined && this.peoples[i]._source.empaboutme != undefined) {
					if (this.peoples[i]._source.empaboutme.length > 0) {
						this.peoples[i]._source.empaboutme.sort(function (obj1, obj2) {
							if (obj1 != null && obj2 != null) {
								return obj1.aboutmehasorder - obj2.aboutmehasorder;
							}
						});
					}
				}
				if (this.peoples[i] != undefined && this.peoples[i]._source != undefined && this.peoples[i]._source.empsme != undefined) {
					if (this.peoples[i]._source.empsme.length > 0) {
						this.peoples[i]._source.empsme.sort(function (obj1, obj2) {
							if (obj1 != null && obj2 != null) {
								return obj1.smehasorder - obj2.smehasorder;
							}
						});
					}
				}

			}
		}
	}

	//toggle for label and fav 
	toggle(i, ppl, label) {
		this.arrLabelList = [];
		this.index = i;
		this.show = !this.show;
		// this.checkClick =!this.checkClick 

		if (ppl.labelList && ppl.labelList.length == 0) {

			let obj = {
				'label': "No Label Created",
				'flag': undefined,
			}
			this.arrLabelList.push(obj);
			this.modalDisplay = "none";
		}
		if (this.show && label && label != undefined && label.length > 0) {
			//	this.spinner.show()
			this.modalDisplay = "show";
			this.isFocusInsideComponent = false;
			this.isComponentClicked = false;


			this.peopleService.fetchFavouriteData(this.profileId).
				then(
					(Response) => {
						this.temp = Response.empfavcollection[0].emplabels;

						if (label != undefined) {
							for (var j = 0; j < label.length; j++) {
								this.result = ((this.temp[label[j]]).some(e => e.empid == ppl._id));

								if (this.result != false) {
									this.spinner.hide()
									let obj = {
										'label': label[j],
										'flag': true,
									}
									this.arrLabelList.push(obj);
								}
								else {
									// this.spinner.hide()
									this.modalDisplay = "none";
									let obj = {
										'label': label[j],
										'flag': false,
									}
									this.arrLabelList.push(obj);
								}
							}

							this.arrLabelList.sort(function (obj1, obj2) {
								if (obj1.label < obj2.label) return -1;
								else if (obj1.label > obj2.label) return 1;
								else return 0;
							});
							// this.spinner.hide()
							this.modalDisplay = "none";
						}
						//this.spinner.hide()
					}), error => {
						alert("Something Went Wrong, Please try in sometime")
						this.spinner.hide()
						this.modalDisplay = "none";
					}
		}
		//this.checkClick = true;
	}


	//add to favourite and Remove from favouirite
	async addToFavourite(ppl, id) {
		// this.index = id;
		if (ppl.flag == false || ppl.flag == undefined) {
			ppl.flag = true;
			var type = 'empfavourites';
			this.peopleService.saveFavouriteOrLabel(this.profileId, type, ppl._id, '').then(
				(Response) => {

				}
			), error => alert("Something Went Wrong,Please try in sometime")

		}
		else {
			//this.spinner.show();
			ppl.flag = false
			await this.peopleService.deleteFav(this.profileId, ppl._id).then(
				(Response) => {
					this.checkClick = true

				}), error => {
					this.spinner.hide();
					alert("Something Went Wrong, Please try in sometime")
				}
			/* if (this.favrecords === 'notext') {

				await this.peopleService.fetchFavouriteData(this.profileId).then(
					(res) => {
						this.spinner.hide()
						this.favEmployeeList = res.empfavouriteslist;

						if (this.favEmployeeList.length >= 0) {
							for (var i = 0; i < this.favEmployeeList.length; i++) {
								this.emplist = this.emplist + ',' + this.favEmployeeList[i]
							}

							if (this.emplist != "") {
								this.router.navigate(['/people/'], { queryParams: { name: this.emplist, searchSelect: "peoplefinder", noRecoFav: "notext" } });
							} else
								if (this.emplist == "") {
									this.router.navigate(['/people/'], { queryParams: { name: '', searchSelect: "peoplefinder", noRecoFav: "myFav" } });
								}
								else {
									this.router.navigate(['/people/'], { queryParams: { name: '', searchSelect: "peoplefinder", noRecoFav: "myFav" } });
								}
						}
						this.spinner.hide()

					}), error => {
						this.spinner.hide()
						alert("Their is some error.");
					}
			} */
			//	this.spinner.hide();



		}
		this.checkClick = true
	}

	addToLabel(ppl, label, j) {
		var type = 'emplabels'
		if (this.arrLabelList[j]['flag'] == false) {
			this.arrLabelList[j]['flag'] = true;
			this.peopleService.saveFavouriteOrLabel(this.profileId, type, ppl._id, label).
				then(
					(Response) => {

					})
		}
		else {
			if (this.arrLabelList[j]['flag'] == true) {
				this.arrLabelList[j]['flag'] = false;
				this.peopleService.deleteLabelForEmployee(this.profileId, ppl._id, label).then(
					(Response) => {

					})
			}
		}
		this.isFocusInsideComponent = false;
		this.isComponentClicked = false;
		this.show = false;
		this.checkClick = true;
	}

	//contact Hr open popup
	openDialogalForContact(contact): void {

		const dialogRef = this.dialog.open(contact, {
			width: '1000px',
		});
		dialogRef.afterClosed().subscribe(result => {

		})
	}
	goToLabel() {
		this.router.navigate(['/mylabel/']);
	}

	saveSMEData(data) {

		let empid = data.empid;
		delete data.empid;
		this.peopleservice.savePeople(data).subscribe(res => {
			setTimeout(() => {
				this.dialog.closeAll();
				this.refreshPeopleList.emit(empid);
				this.spinner.hide();
			}, 2000);
		}),
			error => {
				console.log(error);
				alert(error)
			};
	} 
	// ITTPPRD-1404
	sendForSuggesters(data) {
		this.peopleservice.getSuggesters(data).subscribe(res => {
		  this.suggesters = res;
		}),
		error => {
			alert(error)
		};
	}
	getSuggesters(){
		return this.suggesters.data;
	}
	// ITTPPRD-1404

	get isSME() {
		return this.userroles === this.configData.roles.SME;
	}
	isArray(obj:any):boolean {
		return obj  instanceof Array
	}
}
