import { Component, OnInit, ViewChild, HostListener, Output } from '@angular/core';
import { RefinedByComponent } from '../refined-by/refined-by.component';
import { SearchInfoComponent } from '../search-info/search-info.component';
import { PeopleListComponent } from '../people-list/people-list.component';
import { NgxSpinnerService } from 'ngx-spinner';
import { PeopleService } from '../../services/people/people.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SnotifyService, SnotifyPosition, SnotifyToastConfig } from '../../../../node_modules/ng-snotify';
@Component({
  selector: 'app-people',
  templateUrl: './people.component.html',
  styleUrls: ['./people.component.css']
})

export class PeopleComponent implements OnInit {



  keysearch: string;
  name: string;
  currentsize: number;
  totalCount: number;
  searchSelect: string;
  fromCount = 0;
  pageSize = 10;
  aggs: any;
  appfidner: string;
  Ipeople: any = {
    data: {

      aggregations: {

        LocationCount: { buckets: [] },
        empjobfunctionCount: { buckets: [] },
        empservicelinecount: { buckets: [] },
        empjobsubfuncioncount: { buckets: [] }

      },
      hits: {
        hits: [],
      },
    }, success: []
  };

  showHideStatus: boolean = true;
  showFiller = false;
  isOpened = true;
  showMenubar = false;
  noreco = false;
  noRecoFav: string;
  @ViewChild(SearchInfoComponent) SearchInfoComponent: SearchInfoComponent;
  @ViewChild(RefinedByComponent) refinedByComponent: RefinedByComponent;
  @ViewChild(PeopleListComponent) peopleListComponent: PeopleListComponent;
  profileId
  favEmployeeList
  favList = [];
  labelName: any;
  result: any;
  labelList: string[];
  constructor(public peopleservice: PeopleService, private router: Router, private route: ActivatedRoute, private spinner: NgxSpinnerService, private snotifyService: SnotifyService) { }
  ngOnDestroy() {
    //window.removeEventListener('scroll', this.scrollEvent, true);
  }


  ngOnInit() {

    this.profileId = JSON.parse(localStorage.getItem('isLoggedin')).employee_id;
    this.peopleservice.fetchFavouriteData(this.profileId).then(
      (Response) => {
        this.favList = Response.empfavouriteslist

        this.result = Response
        // if(this.result.empfavcollection[0].emplabels){
        for (var i = 0; i < this.result.empfavcollection.length; i++) {
          this.labelName = this.result.empfavcollection[0].emplabels
          this.labelList = Object.keys(this.labelName)
        }
        //}

      })


    if (localStorage.getItem('isLoggedin') == null || localStorage.getItem('isLoggedin').toString() == '') {
      this.route.queryParams
        .subscribe(params => {
          this.noRecoFav = params.noRecoFav;
          this.name = params.name;
          this.searchSelect = params.searchSelect;
          this.appfidner = 'peoplefinder_WAR_Peoplefinderportlet';
        });
      this.router.navigate(['/login'], { queryParams: { name: this.name, searchSelect: this.searchSelect, appfidner: this.appfidner } });
    } else {
      this.route.queryParams
        .subscribe(params => {
          this.noRecoFav = params.noRecoFav;
          this.name = params.name;
          this.currentsize = 0;
          this.searchSelect = params.searchSelect;

          if ((this.searchSelect != 'peoplefinder' && (this.name === undefined || this.name === ''))) {
            this.noreco = true;
            //alert("Blank search not allowed in advanced search")
            this.SearchInfoComponent.populateSearchInfoNoRecord(this.noreco);
          }
          else if ((this.searchSelect == 'peoplefinder' && this.noRecoFav == 'myFav')) {
            this.noreco = true;
            this.SearchInfoComponent.populateSearchInfoNoRecord(this.noreco);
          }
          else {
            this.spinner.show();
            this.getPeoplewithadv(this.currentsize, this.name, this.searchSelect, this.noRecoFav);
          }

        });
    }

  }
  getPeoplewithadv(from, keyword, searchselect, noRecoFav): void {
    this.keysearch = keyword;
    this.peopleservice.getuserwithadv(from, keyword, searchselect, this.pageSize, undefined).then(
      (Ipeople) => {
        if (Ipeople.error) {
          this.spinner.hide();
          alert("Their is some technical error in the application. Please contact the system administrator.");
        } else {
          this.spinner.hide();
          this.currentsize = Ipeople.data.hits.total < 10 ? Ipeople.data.hits.total : 10;
          this.totalCount = Ipeople.data.hits.total;
          this.SearchInfoComponent.populateSearchInfo(this.totalCount, this.currentsize, keyword, Ipeople.data.suggest, searchselect, noRecoFav);
          this.refinedByComponent.populateRefinedByInfo(Ipeople.data.aggregations);
          this.peopleListComponent.populatePeopleListInfo(Ipeople.data.hits.hits, this.favList, this.labelList);
        }
      }
    ), error => {
      this.spinner.hide();
      alert("Their is some technical error in the application. Please contact the system administrator.");

    };
  }
  getPeoplewithempid(from, empid, searchselect, noRecoFav): void {
    this.keysearch = empid;
    this.peopleservice.getuserwithadv(from, empid, searchselect, this.pageSize, undefined).then(
      (Ipeople) => {
        if (Ipeople.error) {
          this.spinner.hide();
          alert("Their is some technical error in the application. Please contact the system administrator.");
        } else {
          let oldSMEEmpInfo = this.peopleListComponent.peoples.find(p => p._id == empid);
          let index = this.peopleListComponent.peoples.indexOf(oldSMEEmpInfo);
          this.peopleListComponent.peoples[index] = Ipeople.data.hits.hits[0];
          this.peopleListComponent.fetchImageByIndex(index, index);
          setTimeout(() => {
            this.spinner.hide();
          }, 100);

        }
      }
    ), error => {
      this.spinner.hide();
      alert("Their is some technical error in the application. Please contact the system administrator.");

    };
  }

  onScroll(event) {
    if (this.currentsize < this.totalCount) {
      this.fromCount = this.currentsize;
      let difference = this.totalCount - this.fromCount;
      this.pageSize = difference > 10 ? 10 : difference;
      this.refinedByComponent.fetchData(this.fromCount, this.pageSize)
    }
  }

  onResetPeopleList(event) {
    this.peopleListComponent.peoples = [];
    this.fromCount = 0;
    this.pageSize = 10;
  }

  onRefreshPeopleList(empid) {
    this.getPeoplewithempid(0, empid, "peoplefinder", this.noRecoFav);
  }

  peopleTest(data) {
    var result: any = [];
    for (var i in data.data.hits.hits) {
      result.push(data.data.hits.hits[i]);
    }

    this.peopleListComponent.populatePeopleListInfo(result, this.favList, this.labelList);
    this.currentsize = this.peopleListComponent.peoples.length;
    this.totalCount = data.data.hits.total;
    this.refinedByComponent.populateRefinedByInfo(data.data.aggregations);
    this.SearchInfoComponent.populateSearchInfo(this.totalCount, this.currentsize, this.keysearch, '', '', '');

  }

  ngAfterViewInit() {
    let windowWidth = screen.width;
    let windowHeight = screen.height;
    if (windowWidth < 1131 && windowHeight < 780) {
      setTimeout(() => {
        this.showHideStatus = false;
        // let target = document.getElementsByClassName("sidenavbar")[0].classList;
        // target.add("left14");
        // let targetHide = document.getElementsByClassName("rightP")[0].classList;
        // targetHide.add("mleft0")
        this.isOpened = false;
      }, 100);
    }
  }

  showHideNav(status: any) {
    this.showHideStatus = !status;
    if (status) {
      this.isOpened = false;
    }
    else {
      this.isOpened = true;
    }
  }


  onResize(event) {
    let windowWidth = event.target.innerWidth;
    let windowHeight = event.target.innerHeight;
    if (windowWidth < 1023 && windowHeight < 780) {
      this.showHideStatus = false;
      this.showMenubar = true;
      this.showHideNav(true);
    }
    else {
      this.showHideStatus = true;
      this.showMenubar = false;
      this.showHideNav(false);
    }
  }

}

