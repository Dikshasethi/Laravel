import { environment } from '../../environments/environment';

export const protectedResourceMap: [string, string[]][] = [
  ['https://graph.microsoft.com/v1.0/me', ['user.read']]
];

export const MsalSettings = {
  auth: {
    clientId: environment.msalConfig['clientId'],
    authority: 'https://login.microsoftonline.com/' + environment.msalConfig['tenantId'],
    validateAuthority: true,
    redirectUri:  environment.msalConfig['redirectUri'],
    postLogoutRedirectUri:  environment.msalConfig['postLogoutRedirectUri'],
    navigateToLoginRequestUrl: false,
  },
  system: {
    loadFrameTimeout: 35000
  },
  extras: {
    consentScopes: [
      'user.read',
    ],
    protectedResourceMap,
    extraQueryParameters: {
      'lang' : 'en'
    }
  }
};
