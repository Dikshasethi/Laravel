export const environment = {
  production: true,
  NodeUrl: 'http://localhost:3002/api',
  gtmCode : 'G-8D758LZTRC',
  msalConfig: {
    clientId: '81d33181-934b-4cf1-9292-916fc3d7a4ed',	
    tenantId: '97525e9a-595d-472c-8248-0dc58f852d61',
    redirectUri: 'https://peoplefindertest.oii.oceaneering.com/login',
    postLogoutRedirectUri: 'https://peoplefindertest.oii.oceaneering.com/login',
  }
};

