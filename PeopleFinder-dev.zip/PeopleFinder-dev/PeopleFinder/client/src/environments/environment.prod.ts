export const environment = {
  production: true,
  NodeUrl: 'http://localhost:3002/api',
  gtmCode : 'G-K2R45BRF62',
  msalConfig: {
    clientId: '76fbba04-6bd2-4dec-b4e8-137e2a547f2f',	
    tenantId: '97525e9a-595d-472c-8248-0dc58f852d61',
    redirectUri: 'https://peoplefinder.oceaneering.com/login',
    postLogoutRedirectUri: 'https://peoplefinder.oceaneering.com/login',
  }
};
