const graph = require("@microsoft/microsoft-graph-client");
require('isomorphic-fetch');

module.exports = async (accessToken='') => {
    try{
        const client = graph.Client.init({
            authProvider:(done)=>{
                done(null,accessToken);
            }
        });
        const user = await client.api('/me').get();
 
        if(user.mail){
            return {
                ...user,
                username : user.mail.split('@')[0],
                email : user.mail
            }
            
        }else{
            return {
                error : {
                    message : 'Not Authorized'
                }
            }
        }
    }catch(e){
        console.log('error', e)
        return {
            error : {
                message : 'Not Authorized'
            }
        }
    }
}