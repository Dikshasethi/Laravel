const _ = require('lodash');

recursiveSanitizer = (element, sanitizer) => {
    let accumulator;

    if(Array.isArray(element)){
        let subAccum = []
        for (let i = 0; i < element.length; i++){
            let subElement = element[i];
            let sanitized = recursiveSanitizer(subElement, sanitizer);
            subAccum.push(sanitized);
        }
        accumulator = subAccum;
    }else if(!Array.isArray(element) && _.isObject(element)){
        accumulator = {};
        for (let k in element){
            let subElement = element[k];
            accumulator[k] = recursiveSanitizer(subElement, sanitizer);
        }
    }else{
        accumulator = sanitizer.sanitize(element);
        accumulator = typeof accumulator === 'string' ? accumulator.replace(/&amp;/g,"&") : accumulator;
    }   
    return accumulator;
}
module.exports = {
    recursiveSanitizer
}