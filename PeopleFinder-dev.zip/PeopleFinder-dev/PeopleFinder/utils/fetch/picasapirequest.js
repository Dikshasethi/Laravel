const request = require("request-promise");
let fetch = require('node-fetch');
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const logger=require('../../logger/logger');

//var session = require('express-session');
module.exports =  async (emailid) => {

			   var options = {
			    uri: properties.get('google-photos.img-service-url'),
			    method: 'POST',
			    headers: {
			        'Content-Type': 'application/json'
			    },
			    body : {
						'email_id' : emailid,
		        }, 
			    json: true ,
			};

		  return  request(options)
		  .then(function (response) {
				  if(response == "not found" || response == undefined){
					  response = "/assets/images/img-avatar.png";
				  }		  
				  return response;
		  })
		  .catch(function (err) {
			  
			  return  "/assets/images/img-avatar.png";
				
		  });
}
