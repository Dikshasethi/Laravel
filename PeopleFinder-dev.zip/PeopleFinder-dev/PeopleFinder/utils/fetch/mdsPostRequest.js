
let querystring = require('querystring');
let parser = require('xml2js').Parser();
let axios = require('axios');
module.exports = (url, body, header) => {
    if (header == undefined) {
        header = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    }
    const config = {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    }
    let axiosbody = querystring.stringify(body);

    return axios.post(url, axiosbody, config)
        .then(res => {
            if (res.status == 200) {
                let jsonResponse;
                parser.parseString(res.data, (err, result) => {
                    if (err) {
                        jsonResponse = {
                            error: {
                                message: 'An error occured while converting XML to JSOn',
                                errorPayload: res
                            }
                        }
                    }
                    else {
                        jsonResponse = result;
                    }
                });
                return jsonResponse;
            }
            else {
                return {
                    error: {
                        message: 'An error occured',
                        errorPayload: res
                    }
                }
            }
        })
        .catch(err => {
            return {
                error: {
                    message: 'An eror occured',
                    errorPayload: err
                }
            }
        })
}
