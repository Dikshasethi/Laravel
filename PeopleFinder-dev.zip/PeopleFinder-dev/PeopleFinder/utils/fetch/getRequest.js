const request = require('request-promise');
const logger = require('../../logger/logger');

module.exports = (uri, body) => {
	var options = {
		uri: uri,
		method: 'GET',
		auth: {
			username: body.username,
			password: body.password
		},
		rejectUnauthorized: false,
		requestCert: false,
		agent: false,
		json: true
	};
	return request(options)
		.then(function (response) {
			response["statusCode"] = 200;
			return response;
		})
		.catch(function (err) {
			logger.error('Error occured  : ' + uri + '\n' + err);
			return err
		});
}
