const request = require("request-promise");
let fetch = require('node-fetch');
const logger = require('../../logger/logger');
let session = require('express-session');

module.exports = (uri, body, reqheaders,args) => {
	
	let EWLJToken = null, msalaccesstoken=null,authtoken=null;
	if (reqheaders != null) {
		EWLJToken = reqheaders.EWLJToken;
		msalaccesstoken=reqheaders.msalaccesstoken;
		authtoken=reqheaders.authtoken;
	}
	let auth= '';
	if(args!=undefined)
	{
		auth= {
			username: args.username,
			password: args.password
		}
	}
	var options = {
		uri: uri,
		method: 'POST',
		auth,
		headers: {
			'Content-Type': 'application/json',
			'access_token': EWLJToken,
			'msalaccesstoken':msalaccesstoken,
			'authtoken':authtoken
			
		},
		rejectUnauthorized: false,
		requestCert: false,
		agent: false,
		body: body,
		json: true
	};
	return request(options)
		.then(function (response) {
			response["statusCode"] = 200;
			return response;
		})
		.catch(function (err) {
			logger.error('Error occured  : ' + uri + '\n' + err);
			if (err.error && err.status == 401) {
				return err.error
			} else
				return err
		});
}
