const request = require("request-promise");
let fetch = require('node-fetch');
const logger = require('../../logger/logger');
let session = require('express-session');

module.exports = (uri, body, reqheaders) => {
    let Authorization= '';
    // if(reqheaders.headers.authtoken==undefined)
    // { if(reqheaders.session.empService==undefined) { Authorization="Bearer " + '' } else { Authorization="Bearer " +  reqheaders.session.empService.empServiceToken} } 
    // else { Authorization="Bearer " +  reqheaders.headers.authtoken;  }
    if(reqheaders.headers.authtoken!=undefined)
    {
      Authorization = "Bearer "+ reqheaders.headers.authtoken;
    }
    var options = {
        uri: uri,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Cookie': reqheaders.headers.cookie,
             Authorization,
            'access_token': reqheaders.headers.access_token? reqheaders.headers.access_token: reqheaders.session.empService ? reqheaders.session.empService.access_token:'',
            'msalaccesstoken' : reqheaders.headers.msalaccesstoken || ''
        },
        rejectUnauthorized: false,
        requestCert: false,
        agent: false,
        body: body,
        json: true
    };
    return request(options)
        .then(function (response) {
            response["statusCode"] = 200;
            return response;
        })
        .catch(function (err) {
         //console.log(err);
        //    logger.error('Error occured  : ' + uri + '\n' + err);
            if (err.error && err.status == 401) {
                return err.error
            } else
                return err
        });
}
