//var session = require('express-session');
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const logger = require('../../logger/logger');
module.exports = function (searchSelect, search_string, args, refindBy) {
	if (searchSelect == properties.get('Search-Select.basic') && search_string != "") {
		if (search_string[0] === '"' && search_string[search_string.length - 1] === '"') {
			args["search_term"] = search_string.slice(1, -1);
		} else {
			args["search_keyword"] = search_string;
		}
	} else if (search_string != "") {
		var advancesearchkey = properties.get('Search-Select.' + searchSelect);
		myData = [];
		if (search_string[0] === '"' && search_string[search_string.length - 1] === '"') {
			search_string = search_string.replace(new RegExp("\"", 'g'), "");
			myData = search_string.split(",");
			args["advance_search"] = { [advancesearchkey]: { "value": myData, "type": "exact_match" } };
		} else {
			myData = [];
			myData = search_string.split(",");
			args["advance_search"] = { [advancesearchkey]: { "value": myData, "type": "partial_match" } };
		}
	}
	if (refindBy != null) {
		args["refined_by"] = refindBy;
	}

	logger.info('Added more detail :: \n' + JSON.stringify(args));
	return (args);
}
