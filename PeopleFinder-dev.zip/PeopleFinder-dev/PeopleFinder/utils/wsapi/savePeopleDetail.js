//var session = require('express-session');
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');
const postRequest = require('../fetch/postRequest');
const logger=require('../../logger/logger');
var dateFormat = require('dateformat');
module.exports =    async  function  (eswdocument,wsapicontent,req, res) {
	try{
		 var empid = wsapicontent.array[0].employeeid;
		 let reqHeader = {};

		if(req.session && req.session.pplfinder && req.session.pplfinder.EWLJ)
		{
			console.log('EWLJToken');
			reqHeader['EWLJToken'] = req.session.pplfinder.EWLJ;
		}else 
		{
			console.log('access_token');
			reqHeader['EWLJToken'] = req.session.user.access_token;
		}
		var args = {
			'username': properties.get('adeptia.username'),
			'password': properties.get('adeptia.password')
		}

		 logger.info('Empid :: '+empid); 
		 logger.info('eswdocument ' + JSON.stringify(eswdocument));
		 var eswrapperurl = properties.get('Elastic-Search.update-eswrapper-url')+'/'+empid;
		 var sqlserverurl = properties.get('Elastic-Search.update-sqlserver-url');
		 var current_date = dateFormat(new Date(), "isoDateTime");
		 response =  await postRequest(sqlserverurl, wsapicontent, reqHeader,args); 
		 console.log('response update record');
		console.log(response);

		 logger.info('From sql :: '+ JSON.stringify(response));  
		 var timeDifference2 = (Math.abs(new Date(dateFormat(new Date(), "isoDateTime")).getTime() - new Date(current_date).getTime())/(1000 ));
		 logger.info('Time taken by sql service : '  + timeDifference2);
		 var buf = Buffer.from(JSON.stringify(response));		 
			if(response.statusCode == 200){
			logger.info('Calling elsatic.. ');  
			current_date = dateFormat(new Date(), "isoDateTime");
	        result =  await postRequest(eswrapperurl, eswdocument, reqHeader);  //"delete":"false" mandatory in new api  previous - delete not acceptable ,     
			timeDifference2 = (Math.abs(new Date(dateFormat(new Date(), "isoDateTime")).getTime() - new Date(current_date).getTime())/(1000 ));
			logger.info('Time taken by elastic api : '  + timeDifference2);
	        logger.info('From esw :: '+result.data.result);
	        return res.json({"result" : result.data.result});
		 }else{
		  return res.json({"result" : "err"});
		 }
     }
	 catch(err) {
		 logger.error('Error in inserting/updating people detail : '+err);
		 return res.json({"result" : "err1"});
     };
	  
}