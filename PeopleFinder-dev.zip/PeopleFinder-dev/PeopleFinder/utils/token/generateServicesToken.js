const PropertiesReader = require('properties-reader');
const properties = PropertiesReader('config.properties');
const postRequest = require('../fetch/postRequest');
//var session = require('express-session');
const logger = require('../../logger/logger');
module.exports = async (apiEndPoint, reqsessionvar,password) => {

    var tokendetail = '';
    try {
        let reqHeader = {};
        reqHeader['msalaccesstoken'] = reqsessionvar.pplfinder.msalaccesstoken;
        reqHeader['EWLJToken'] = null;
        var body = { "username": reqsessionvar.empService.user, "password": password, "appName": properties.get('Login.app') };
        tokendetail = await postRequest(apiEndPoint, body, reqHeader);
        reqsessionvar.empService.empServiceToken = tokendetail.token;
        reqsessionvar.empService.expiryTime = tokendetail.empDataExpiry
        reqsessionvar.empService.userroles = tokendetail.userroles
        /** Token Details For Elastic Search Returned From employeeDatams */
        reqsessionvar.empService.access_token = tokendetail.access_token;
        reqsessionvar.empService.expiryESToken = tokendetail.expiryTime;
       /** Token Details For Elastic Search Returned From employeeDatams */
        return tokendetail;
    } catch (e) {
        logger.error('Error while generating JWTToken :', e);
        return {
            error: {
                message: 'An error occured',
                errorPayload: e
            }
        }
    }

}