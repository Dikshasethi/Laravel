const postRequest = require('../fetch/postRequest');
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');

module.exports = async (header) => {
    try {
        emp_data_ms_url = properties.get('mongo.employeedata_ms_url');
        let validateAuthTokenUrl = emp_data_ms_url +'/api/employeedata/validateAuthToken';
        let reqBody = {};
        let tokenObject = await postRequest(validateAuthTokenUrl, reqBody, header);
        return tokenObject;
    }
    catch (error) {
        logger.error(error.stack)
        return {
            error: {
                message: 'An error occured',
                errorPayload: e
            }
        }

    }

}