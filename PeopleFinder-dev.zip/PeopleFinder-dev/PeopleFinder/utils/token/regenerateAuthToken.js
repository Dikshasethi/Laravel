const postRequest = require('../fetch/postRequest');
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('./config.properties');

module.exports = async (body) => {
    try{
    let generateTokenUrl = properties.get('mongo.employeedata_ms_url') + '/api/employeedata/regenerateAuthToken';
    let tokenObject = await postRequest(generateTokenUrl, body);
    return tokenObject;
    }
    catch(error){
        logger.error(error.stack)
        return {
            error : {
                message : 'An error occured',
                errorPayload : e
            }
        }

    }
  
}