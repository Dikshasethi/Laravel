const PropertiesReader = require('properties-reader');
const properties = PropertiesReader('config.properties');
const postRequest = require('../fetch/postRequest');
//var session = require('express-session');
const logger = require('../../logger/logger');
module.exports = async (reqsessionvar) => {
    var tokendetail = '';
    try {
        var uri = properties.get('Elastic-Search.authentication-url');
        var body = { "username": reqsessionvar.pplfinder.user, "app_name": properties.get('Login.app'), "roles": ["User"] };
        tokendetail = await postRequest(uri, body, null);
        reqsessionvar.pplfinder.EWLJ = tokendetail.access_token;
        reqsessionvar.pplfinder.timeout = tokendetail.expiry - 120;
        reqsessionvar.pplfinder.expiryTime = Math.floor(Date.now() / 1000) + reqsessionvar.pplfinder.timeout;
        //end 
        logger.info('Initialized session time out:: ' + reqsessionvar.pplfinder.timeout);
        logger.info('Initialized JWT Token:: ' + reqsessionvar.pplfinder.EWLJ);
        return tokendetail;
    } catch (e) {
        logger.error('Error while generating JWTToken :', e);
        return {
            error: {
                message: 'An error occured',
                errorPayload: e
            }
        }
    }

}