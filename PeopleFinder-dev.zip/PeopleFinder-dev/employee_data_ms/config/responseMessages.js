module.exports = {
    ERROR :  {
        INVALID_VALUE : {
            statusCode : 400,
            message : {
                en : "Value is not defined in Api"
            },
            type : 'INVALID_VALUE'
        },
        INVALID_EMP_ID : {
            statusCode : 400,
            message : {
                en : "Employee id is missing."
            },
            type : 'INVALID_EMP_ID'
        },
        INVALID_IMAGEARRAY : {
            statusCode : 400,
            message : {
                en : 'ImageArray is empty or not defined in API'
            },
            type : 'INVALID_IMAGEARRAY'
        },
        INVALID_IMAGELIST : {
            statusCode : 400,
            message : {
                en : 'ImageList is empty or not defined in API'
            },
            type : 'INVALID_IMAGELIST'
        },
        INVALID_IMAGELIST_IMAGEBASE64 : {
            statusCode : 400,
            message : {
                en : 'imageBase64 is empty or not defined in ImageList'
            },
            type : 'INVALID_IMAGELIST_IMAGEBASE64'
        },
        INVALID_IMAGELIST_CATEGORY : {
            statusCode : 400,
            message : {
                en : 'category is empty or not defined in ImageList'
            },
            type : 'INVALID_IMAGELIST_CATEGORY'
        },
        INVALID_IMAGELIST_FILENAME : {
            statusCode : 400,
            message : {
                en : 'fileName is empty or not defined in ImageList'
            },
            type : 'INVALID_IMAGELIST_FILENAME'
        },
        INVALID_IMAGELIST_FILEEXTENSION : {
            statusCode : 400,
            message : {
                en : 'fileExtension is empty or not defined in ImageList'
            },
            type : 'INVALID_IMAGELIST_FILEEXTENSION'
        },
        INVALID_IMAGELIST_FILETYPE : {
            statusCode : 400,
            message : {
                en : 'filetype is empty or not defined in ImageList'
            },
            type : 'INVALID_IMAGELIST_FILETYPE'
        },
        INVALID_DEVICE : {
            statusCode : 400,
            message : {
                en : 'device is empty or not defined in API'
            },
            type : 'INVALID_DEVICE'
        },
        INVALID_EMP_PROFILE_URL : {
            statusCode : 400,
            message : {
                en : 'Empprofileurl is empty or not defined in API'
            },
            type : 'INVALID_EMP_PROFILE_URL'
        }
    }
}