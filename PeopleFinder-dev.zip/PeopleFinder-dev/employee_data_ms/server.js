var http = require('http');
var https = require('https');
var fs = require('fs');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var session = require('express-session');
var path = require('path');

var cors = require('cors');
const expressJwt = require('express-jwt');
const helmet = require('helmet');
const cookieParser = require('cookie-parser')
require('dotenv').config();
const logger = require('./config/logger_config.js');
const config = require('./config/config')();

require('./models/employeeImages');
try {
	var httpflag = config.https;
	var port = config.PORT;
	let sessionOptions = {
		secret: 'secret',
		cookie: { secure: true, path: "/" },
		saveUninitialized: true,
		resave: false
	};
	app.use(helmet());
	app.use(cookieParser())
	app.use(cors());
	app.use(session(sessionOptions));
	// app.use(expressJwt({
	// 	secret: config.jwtSecret
	// }).unless({
	// 	path: ['/api/employeedata/generateToken']
	// }));

	var jsonParser = bodyParser.json({ limit: '10mb', extended: true });
	var urlencodedParser = bodyParser.urlencoded({
		extended: false
	});

	app.use(function (err, req, res, next) {
		if (err.name === 'UnauthorizedError') {
			res.status(401).send({
				status: 401,
				message: "Access token Expired."
			});
			//throw new Error("Session Expired")
		}
	});

	app.use(urlencodedParser);
	app.use(jsonParser);
	app.all('*', function (req, res, next) {
		session = req.session;
		session.EWLJ;
		session.user;
		session.state;
		session.visited;
		session.timeout;
		session.expiryTime;
		session.jwtAppToken;
		session.jwtAppDuration;
		session.jwtExpiryTime;
		res.header('Access-Control-Allow-Origin', '*');
		res.header('Access-Control-Allow-Headers', 'X-Requested-With');
		next();
	});


	// All Routes 
	app.use('/api/employeedata', ...require('./routes'))
	//Db Connection
	require('./dbConnection');
	// Crons
	require('./crons')
	if (httpflag == 'true') {
		let options = {
			key: fs.readFileSync('../../certs/server.key'),
			cert: fs.readFileSync('../../certs/server.crt')
		}
		const httpsServer = https.createServer(options, app);
		httpsServer.listen(port, () => {
			console.log(`API running on https:localhost :${port}`)
			logger.info("API running on localhost:" + port)
		})
	} else if (httpflag == 'false') {
		app.listen(port, function () {
			console.log('CORS-enabled web server listening on port on http:localhost : ' + port);
			logger.info(`app is running on port ${port}`)

		})
	}
}
catch (err) {
	console.log(err);
}

