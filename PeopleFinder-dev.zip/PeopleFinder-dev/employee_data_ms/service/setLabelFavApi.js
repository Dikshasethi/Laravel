const EmpFavCollection = require('../models/empfavcollection');
const logger = require('../config/logger_config');
module.exports = {
    saveempfavreco,
}
async function saveempfavreco ( req, res ) {
    try {
        let newvalues,
		lavelname = req.body.label,
		unixTimestamp = Math.round(new Date().getTime() / 1000),
		nameoflavel = 'emplabels.' + [lavelname],
		checkempid = 'emplabels.' + [lavelname] + ".empid",
		myquery;
		if ("empfavourites" == req.body.type) {
			newvalues = {
				"empfavourites": { "empid": req.body.employee, "addedon": unixTimestamp }
			};
			myquery = { "empid": req.body.empid };
		}
		if ("emplabels" == req.body.type) {
			if (req.body.employee == undefined || req.body.employee == '') {
				newvalues = {
					[nameoflavel]: {}
				};
				myquery = { "empid": req.body.empid };

			} else {
				newvalues = {
					[nameoflavel]: { "empid": req.body.employee, "addedon": unixTimestamp }
				};
				myquery = { $and: [{ "empid": req.body.empid }, { [checkempid]: { $ne: req.body.employee } }] }
			};

		}
        let result = await EmpFavCollection.updateOne(myquery, { $addToSet: newvalues }, { upsert: true });
        console.log("Number of documents inserted" + result.n);

        if (req.body.employee == undefined || req.body.employee == '') {
            await EmpFavCollection.collection.updateOne(myquery, { $pop: { [nameoflavel]: -1 } });
        }
        res.send({ "status": "success" });
			
    } catch (error) {
        logger.error(error.stack);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
}
