const jwt = require('jsonwebtoken')
const config = require('../config/config')();
const mdsPostRequest = require('./mdsPostRequest');
const postRequest = require('./../utils/fetch/postRequest');
const logger = require('../config/logger_config');
const getMdsEmployeeData = require('../utils/employee/getEmployeeData');
module.exports.generateToken = async function (req, res) {
    try {
        /**
         * For Msal Token Details to be fetched.
         */
        let userNameFetched= req.body.username?req.body.username:'';
        let msalaccesstoken='';
        if(req.headers['msalaccesstoken'] && req.headers['msalaccesstoken']!=undefined){
            const {
                username='', givenName='', surname='',
                email='', jobTitle='', officeLocation='',
                accessToken=''
            } = req.user;
            
            if(
                !username || typeof username !== 'string'
            ){
                return res.status(400).send({ result: 'Not Authorized' })
            }
            let decodedMsalAccessToken = jwt.decode(accessToken);
            let authTokenExpiryTime = decodedMsalAccessToken ? decodedMsalAccessToken.exp : 0;
            let employeeData = await getMdsEmployeeData('EmailID', email);
            userNameFetched = username.toLowerCase();
            msalaccesstoken=accessToken;
        }
        const expiry = Math.floor(Date.now() / 1000) + config.tokenExpiry
        const url = process.env.MDS_URL //| config.MDS_URL; 
        const appName = req.body.appName ? req.body.appName : process.env.APP_NAME;
        const userName = req.body.username ? req.body.username : userNameFetched;
        const password = req.body.password ? req.body.password : '';
        if (req.user && req.user !== null) {
            var argsRoles = {
                app: appName,
                login: userName
            };
            var usrRole = "";
            
            let responseRoles = await mdsPostRequest(url + '/GetAppRoles', argsRoles);
            if (responseRoles != undefined && responseRoles.roles !== "") {
                usrRole = responseRoles.roles.role[0].$.name;
            }
            /** Elastic Api Call To generate AccessToken */
            var ElasticApiBody =
            {
                "username": userName,
                "app_name":appName,
                "roles": req.body.roles ? req.body.roles : ["User"]
            }; //roles is optinal field in generateToken Api
            var tokendetail = await postRequest(process.env.ELASTIC_AUTHENTICATION_URL, ElasticApiBody, null);
            req.session.empData = {}
        /* Minus included because we ahve to make the token expiry time
             somewhat less than the expiry of access_token so we reduce it to 2 mins value*/
            req.session.empData.access_token = tokendetail.access_token ;
            req.session.empData.timeout = tokendetail.expiry - 120;
            req.session.empData.expiryTime = Math.floor(Date.now() / 1000) + req.session.empData.timeout;

            var token = jwt.sign({
                login: userName,
                appName: appName,
                access_token : tokendetail.access_token,
                expiryTime :  req.session.empData.expiryTime,
                timeout:tokendetail.expiry,
                empDataExpiry:expiry - 120,
                userroles:usrRole
            }, config.jwtSecret, {
                expiresIn: config.tokenExpiry
            });

            
            req.session.empData.token = token
            req.session.empData.username = userName
            req.session.empData.appname = appName
            req.session.empData.expiry = expiry
           
            /** Elastic Token Details */
            
            // let timeout = tokendetail.expiry-120;
            // let expiryTime = Math.floor(Date.now() / 1000) + timeout;
            /** Elastic Token Details Ends Here*/

            res.json({
                result: 'authorized',
                emp_username: userName,
                empDataExpiry: req.session.empData.expiry,
                token: token,
                userroles: usrRole,
                access_token: tokendetail.access_token,
                expiryTime: req.session.empData.expiryTime

            });
        }
        else {
            res.status(400).send({ result: 'Please supply valid Credentials.' })
        }
    }
    catch (error) {
        logger.error(error.stack);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
};

getRoles = function (username, appname) {
    config.tokenExpiry
};






