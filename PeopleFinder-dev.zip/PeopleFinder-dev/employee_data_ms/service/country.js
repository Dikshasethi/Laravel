const CountriesMaster = require('../models/countriesmaster')

module.exports = {
    fetchCountires
}

async function fetchCountires ( reqData ) {
    try {
        let search_keyword = reqData.value;
        return CountriesMaster.collection.aggregate([
                { $match : { country : { $regex : `^${search_keyword}`,  $options : 'i' } } },
                { $group : { _id : { $toLower : "$country"}, country : { $first : "$country" } } },
                { $sort : { country : 1 } },
                { $project : { _id : 0 } }
            ]).toArray()
    } catch (error) {
        throw error;
    }
}