const EmpFavCollection = require('../models/empfavcollection');
const logger = require('../config/logger_config');
module.exports = {
    fetchempfavreco,
    deleteempfavreco
}
async function fetchempfavreco ( req, res ){
    try {
        let arr = [],
        query = { "empid": req.body.empid };
        let result = await EmpFavCollection.collection.find(query).toArray()
        if(result.length > 0  &&  result[0].empfavourites != undefined && result[0].empfavourites.length > 0){
            for (let i = 0; i < result[0].empfavourites.length; i++) {
                arr.push(result[0].empfavourites[i].empid);
            }
        }
        res.send({"empfavcollection":result,"empfavouriteslist":arr});
    } catch (error) {
        logger.error(error.stack);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
}
async function deleteempfavreco ( req, res) {
    try {
        let arrOfVals = [],
        myquery = { "empid": req.body.empid };
        if(Array.isArray(req.body.employee)){
            arrOfVals = req.body.employee;
        }else{
            arrOfVals.push(req.body.employee);
        }
        for (let i = 0; i < arrOfVals.length ; i++ ){
            let newvalues = { "empfavourites": { "empid": arrOfVals[i] } } ;
            response = await EmpFavCollection.updateOne(myquery,{$pull: newvalues } ,{ upsert: true }) 
            console.log("Number of documents deleted" + JSON.stringify(response.n));
        }
        res.send({"status":"deleted"});
    } catch (error) {
        logger.error(error.stack);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
}