const logger = require('../config/logger_config');
const config = require('../config/config')();
let jwt = require('jsonwebtoken');
const postRequest = require('./../utils/fetch/postRequest');

module.exports = async (req, res) => {
    let response;
    try {
        let header = {
            'Content-Type': 'application/json',
            "access_token": req.body.access_token
        };
        let reqBody = {
            "app_name":  process.env.APP_NAME,
            "access_token": req.body.access_token
        }
        let url = config.elasticTokenRevoke_URL;
        response = await postRequest(url, reqBody, header);
        return res.send(response);
    }
    catch (err) {
        return res.send({
            error: {
                message: 'An eror occured while revoking user',
                errorPayload: err
            }
        })
    }
}