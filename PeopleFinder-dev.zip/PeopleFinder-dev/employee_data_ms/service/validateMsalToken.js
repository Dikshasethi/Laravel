const logger = require('../config/logger_config');
const config = require('../config/config')();
const validateAccessToken = require('../utils/msal/validateAccessToken');
const getMdsEmployeeData = require('../utils/employee/getEmployeeData');
module.exports = async (req, res) => {
    try{
        //console.log(req.headers);
        if(req.headers.msalaccesstoken && req.headers.msalaccesstoken!=undefined){
            let validationResponse = await validateAccessToken(req.headers.msalaccesstoken);
            if(validationResponse.error){
                return res.send(validationResponse);
            }else{
                let msalresponse = {
                    ...validationResponse,
                    accessToken
                };
                
                const {
                    username='', givenName='', surname='',
                    email='', jobTitle='', officeLocation='',
                    accessToken=''
                } = msalresponse;
                if(
                    !username || typeof username !== 'string'
                ){
                    return res.send({
                        error : {
                            message : 'Not Authorized'
                        }
                    })
                }
                var employeeData = await getMdsEmployeeData('EmailID', email);
                res.json({
                    'result': 'authorized', 
                });
            }
        }
        else
        {
            return res.send({
                error : {
                    message : 'Not Authorized'
                }
            })
        }
    }catch(e){
        console.log('validateMsalToken catch block error', e)
        return res.send({
            error : {
                message : 'An error occured while validating MSAL Access Token',
                errorPayload : e
            }
        });
    }
}