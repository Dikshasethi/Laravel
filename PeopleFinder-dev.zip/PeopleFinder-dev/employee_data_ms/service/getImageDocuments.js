const mongoose = require('mongoose');
const sanitizer = require('sanitizer');
const {recursiveSanitizer} = require('../utils/sanitizer/sanitizerFunction');
const config = require('../config/config')();
const logger = require('../config/logger_config');

module.exports = async (req, res) => {
    try{
        let reqBody = recursiveSanitizer(req.body, sanitizer);
        if(!reqBody.employeeids)
        {
            res.statusCode=422;
            return res.send({
                error : {
                    message : `Missing parameter - employeeid(s)`,
                },
            })
        }

        if(reqBody.employeeids.length<=0)
        {
            res.statusCode=422;
            return res.send({
                error : {
                    message : `Missing parameter value for employeeid(s)`,
                },
            })
        }
        const {
            employeeids=[]
        } = reqBody;

        const employeeImages = mongoose.model(config.employeeImageModel);
        let  employeeIdList=[]

        let images = await employeeImages.find({
            _id : {
                    $in : employeeids
                  }
            });
        return res.send(images);
    }catch(e){
        console.log('getImageDocuments catch block error', e);
        logger.error(e.stack);
        return res.send({
            error : {
                message : 'An error occured. Please try again'
            }
        })
    }
}