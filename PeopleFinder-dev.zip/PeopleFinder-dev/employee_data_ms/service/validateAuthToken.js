const logger = require('../config/logger_config');
const config = require('../config/config')();
let jwt = require('jsonwebtoken');
module.exports = async (req, res) => {
    try {
        let token = req.headers.authtoken;
        jwt.verify(token, config.jwtSecret, function (err, decoded) {
            if (err) {
                if(err.message=='jwt expired')
                {
                    return res.send({
                        error : {
                            message : 'Access Token Expired'
                        },
                    });
                }
                else{
                    return res.send({
                        error : {
                            message : 'Not Authorized'
                        },
                    });
                }
               
            }
            else {
                return res.send({ isAuthenticate: true, data: decoded });
            }
        });
    }
    catch (error) {
        logger.error(error);
        return res.send({
            error : {
                message : 'Not Authorized'
            }
        })
    }
}