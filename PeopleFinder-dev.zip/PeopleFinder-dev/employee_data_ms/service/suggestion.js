const EMPLOYEESEARCH = require('../models/employeesearch');

module.exports = {
    fetchYeallowPageSuggestion ,
    fetchLandingPageSuggestion
}
/**
 * Suggester for yellow pages
 * @param { value , suggesters} reqData 
 */ 
async function fetchYeallowPageSuggestion (reqData)  {
    try {
        let suggest_key = reqData.suggesters.suggest_key,
        suggest_field = reqData.suggesters.suggest_field,
        label = reqData.suggesters.label,
        search_val = "^"+reqData.value,
        projects = { $project : { _id : 0 } }
        projects.$project[suggest_field] = 1
        let matchs = { $match : {} } 
        matchs.$match[`${suggest_field}.${suggest_key}`] = { $regex: search_val, $options: 'i' } ,
        limit = reqData.limit !==undefined ? reqData.limit  : 10
        skip = reqData.page !==undefined || reqData.page !==1 ?  limit * (reqData.page - 1) : 0,
       
        pipe = [
            projects,
            { $unwind : `$${suggest_field}` },
            matchs,
            { $group : { _id : null, data: {$addToSet: {val: `$${suggest_field}.${suggest_key}`, label : `${label}` } } } },
            { $unwind: '$data' },
            { $sort: { 'data.val': 1 } },
            { $facet: { 
                count: [ {$count: 'count'} ], 
                data : [
                    { $skip: skip }, { $limit: limit }, {$group: {_id: null, data : {$push: "$data"} } }, { $project: {_id: 0 } } 
                ] } 
            },
            {
                $project: {
                    count: {$arrayElemAt: ["$count.count", 0]},
                    data: {$arrayElemAt: ["$data.data", 0]}
                }
            }
        ];
        return EMPLOYEESEARCH.collection.aggregate(pipe).toArray();
    } catch(error) {
        throw error;
    }
}

 /**
  * Suggester for Basic search
  * @param { value , suggesters } reqData 
  */
async function fetchLandingPageSuggestion (reqData){
    try {
        let  search_val = "^"+reqData.value,
        limit = reqData.limit !==undefined ? reqData.limit  : 10,
        skip = reqData.page !==undefined || reqData.page !==1 ?  limit * (reqData.page - 1) : 0;
        
        let   facets = { $facet : { } },
        whitePageSuggesters = reqData.suggesters.whitePageSuggesters;
        searchObj = { $regex : search_val, $options : 'i' },
        projects =  { $project : { count : 1 } },
        setUnionArrays = [];

        for (let key in whitePageSuggesters ){
            let suggest_field = whitePageSuggesters[key].suggest_field ; 
            let label = whitePageSuggesters[key].label ; 
            facets.$facet[suggest_field] = [ 
                { $project: { _id : 0 } },  
                { $match : {  } }, 
                { $group: { _id: null } }, 
            ]
            facets.$facet[suggest_field][0].$project[`${suggest_field}`] = 1
            facets.$facet[suggest_field][1].$match[`${suggest_field}`] = searchObj
            facets.$facet[suggest_field][2].$group["data"] = { $addToSet: { val : `$${suggest_field}`, label : `${label}` }, }

            projects.$project[suggest_field] = { $cond : [ { $eq : [ `$${suggest_field}` ,[] ] },  [] , { $arrayElemAt :[ `$${suggest_field}.data` ,0 ]} ] }
            setUnionArrays.push( `$${suggest_field}` )
        }
        
        yellowPageSuggesters = reqData.suggesters.yellowPageSuggesters;
      
        for(let key in yellowPageSuggesters ) {
            let suggest_field = yellowPageSuggesters[key].suggest_field ; 
            let suggest_key = yellowPageSuggesters[key].suggest_key ; 
            let label = yellowPageSuggesters[key].label ; 

            facets.$facet[suggest_field] = [ 
                { $project: { _id : 0 } },  
                { $unwind : `$${suggest_field}` },  
                { $match : {  } }, 
                { $group: { _id: null } }, 
            ]
            facets.$facet[suggest_field][0].$project[`${suggest_field}.${suggest_key}`] = 1
            facets.$facet[suggest_field][2].$match[`${suggest_field}.${suggest_key}`] = searchObj
            facets.$facet[suggest_field][3].$group["data"] = { $addToSet: { val : `$${suggest_field}.${suggest_key}`, label : `${label}` } }

            projects.$project[suggest_field] = { $cond : [ { $eq : [ `$${suggest_field}` ,[] ] },[] , { $arrayElemAt : [ `$${suggest_field}.data` ,0 ] } ] }
            setUnionArrays.push( `$${suggest_field}` )
        }
                
        let pipe = [ 
            facets,
            projects,
            { $project: { mergedData : { $setUnion : setUnionArrays } } } ,
            { $unwind: '$mergedData' } ,
            { $facet : {
                    count : [ { $count : 'count'} ],
                    data : [ { $sort : { "mergedData.val" : 1 } }, { $skip : skip }, { $limit : limit }, { $group : { _id: null, data : { $push:  "$mergedData"  } } }, { $project : { _id : 0 } } ]
                } 
            },
            {
                $project: {
                    count: {$arrayElemAt: ["$count.count", 0]},
                    data: {$arrayElemAt: ["$data.data", 0]}
                }
            }
         ]
        return EMPLOYEESEARCH.collection.aggregate(pipe).toArray();;
    } catch (error) {
        throw error;
    }
}