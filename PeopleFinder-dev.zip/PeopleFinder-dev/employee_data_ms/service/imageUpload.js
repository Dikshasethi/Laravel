const mongoose = require('mongoose');
const sanitizer = require('sanitizer');
const {recursiveSanitizer} = require('../utils/sanitizer/sanitizerFunction');
const config = require('../config/config')();
const logger = require('../config/logger_config');

module.exports = async (req, res) => {
    try{
        let reqBody = recursiveSanitizer(req.body, sanitizer);
        if(!reqBody.employeeid)
        {
            res.statusCode=422;
            return res.send({
                error : {
                    message : `Missing parameter - employeeid`,
                },
            })
        }

        if(!reqBody.isDelete && (!reqBody.user || !reqBody.devicekey))
        {
            res.statusCode=422;
            return res.send({
                error : {
                    message : (!reqBody.user)?`Missing parameter - user`:`Missing parameter - devicekey`,
                },
            })
        }
       
        const {
            base64Image='',
            imageType='',
            emailid='',
            employeeid='',
            devicekey='',
            user='',
            isDelete=false
        } = reqBody;

        const EmployeeImage = mongoose.model(config.employeeImageModel);
       
        let updateObject = {};
        let updated ;
        if(isDelete)
        {
            updated = await EmployeeImage.findOneAndRemove(
                {
                   _id:employeeid
                })
                return res.send({
                    success : {
                        message : `Record deleted for ${employeeid}`,
                    }
                })
        }
    
        if(base64Image){
            updateObject['$set'] = {
                employeeImageBase64:base64Image, 
                employeeImageType:imageType,
                emailid:emailid,
                lastUpdatedBy : user,
                devicekey,
                lastUpdatedDate:new Date()
            };
        }

        updated = await EmployeeImage.findOneAndUpdate(
            {
               _id:employeeid
            },
            updateObject,
            {
                new : true,
                upsert : true,
                setDefaultsOnInsert:true
            }
        );
    

        return res.json(updated);
    }catch(e){
        console.log('image upload catch block error', e);
        logger.error(e.stack);
        res.send({
            error : {
                message : 'An error ocurred while uploading image',
                errorPayload : e
            }
        })
    }
}