const logger = require('../config/logger_config');
const config = require('../config/config')();
let jwt = require('jsonwebtoken');
const postRequest = require('./../utils/fetch/postRequest');
module.exports = async (req, res) => {
    try {
        const expiry = Math.floor(Date.now() / 1000) + config.tokenExpiry
        let header = {
            'Content-Type': 'application/json',
            'access_token': req.body.payload.access_token || req.body.access_token
        };
        let reqBody = {};
        let url = config.elasticTokenRevoke_URL;
        // Remove Current Elastic Search Token
        let response = await postRequest(url, reqBody, header);
        //console.log(response);
        // Generate New Elastic Search Token
        var ElasticApiBody =
        {
            "username": req.body.login,
            "app_name":req.body.app,
            "roles": req.body.payload.userroles ? req.body.payload.userroles : ["User"]
        }; 

        var tokendetail = await postRequest(process.env.ELASTIC_AUTHENTICATION_URL, ElasticApiBody, null);
       
        let expiryTime = Math.floor(Date.now() / 1000) + tokendetail.expiry;
       let tokenObject= Object.assign(tokendetail, {expiryTime});
      // tokenDetail['expiryTime']=expiryTime;
        //console.log('tokenObject');
        console.log(tokenObject);
        // Generate New Elastic Search Token
        var token = jwt.sign({
            login: req.body.login,
            appName: req.body.app,
            access_token : req.body.payload.access_token,
            expiryTime : Math.floor(Date.now() / 1000) + tokendetail.expiry,
            timeout:tokendetail.expiry,
            empDataExpiry:expiry - 120,
            userroles:req.body.payload.userroles
        }, config.jwtSecret, {
            expiresIn: config.tokenExpiry
        });
        
        let authTokenObject= {};
        authTokenObject['token']=token;
        authTokenObject['empDataExpiry']=expiry - 120;
        authTokenObject['generatedElastiSearchToken']=tokenObject
        return res.send(authTokenObject);
    }
    catch (error) {
        logger.error(error);
        return res.send({
            error: {
                message: 'An error occured. Please try again',
                errorPayload: error
            },
            hasError: true
        })
    }
}