const EMPLOYEESEARCH = require('../models/employeesearch');
const { Config } = require('aws-sdk');

const CONFIG = require('../config/config')();

module.exports = {
    saveImageUrl,
    deleteImageUrl ,
    getProfileUrls,
    getImages,
    getEmpData
}
/**
 * Save image url to db
 * @param  ,empId , imagUrl 
 */ 
async function saveImageUrl (empId, imagUrl)  {
    try {
        return EMPLOYEESEARCH.findByIdAndUpdate( empId, { empprofileurl:imagUrl }, { new: true, upsert: true } );
    } catch(error) {
        throw error;
    }
}

/**
 * Unset empprofileurl to empty
 * @param {*} empId 
 */
async function deleteImageUrl(empId) {
    try {
        return EMPLOYEESEARCH.findByIdAndUpdate(empId, {$unset : {empprofileurl : ''} }, { new: true })
    } catch (error) {
        throw error
    }
}

/**
 * Get Employee Profile URl 
 * @param {*} employeeids 
 */
async function getProfileUrls(employeeids){
    try {
      return EMPLOYEESEARCH.find({_id : { $in : employeeids }, empprofileurl: { $exists : true }, empstatus : { $ne : CONFIG.EMPLOYEE_TERMINATED_STATUS } }, { empprofileurl : 1 } )
    } catch (error) {
        throw error
    }
}

/**
 *  return cursor to get images for all employee
 */

async function getImages(){
    try {

        let pipes = [
            {
                $match: {
                    empstatus: {
                        $ne: CONFIG.EMPLOYEE_TERMINATED_STATUS
                    },
                    empprofileurl: { 
                        $exists : false 
                    }
                }
            }, {
                $sort : { _id : 1 }
            }, {
                $lookup: {
                    from: 'employeeimages',
                    localField: '_id',
                    foreignField: '_id',
                    as: 'employeeimages'
                }
            }, {
                $unwind : "$employeeimages" 
            }, {
                $match : {
                    "employeeimages.employeeImageBase64" : {
                        $ne : CONFIG.DEFAULT_IMAGE_BASE64
                    }
                }
            }, {
                $project: {
                    empfirstname: 1,
                    emplastname: 1,
                    employeeemail: 1, 
                    employeeimages: 1
                }
            }
        ]
        return EMPLOYEESEARCH.collection.aggregate(pipes, { cursor : { batchSize : 20 } } )
    } catch (error) {
        throw error
    }
}

async function getEmpData() {
    try {
        return EMPLOYEESEARCH.collection.find( {} ).project({ empprofileurl: 1, empstatus: 1 }).batchSize(10000)
    } catch (error) {
        throw error
    }
}