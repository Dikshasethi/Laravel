const EMPLOYEESEARCH = require('../models/employeesearch');
const  { EMPLOYEE_TERMINATED_STATUS } = require('../config/config')()
module.exports = {
    getSimilarDashboard
}

async function getSimilarDashboard( reqData ) {
    
    try {
        let emp_id = reqData.empid,
        limit = reqData.items !==undefined ? reqData.items  : 10
        skip = reqData.page !==undefined || reqData.page !==1 ?  limit * (reqData.page - 1) : 0;
        let suggest_key = reqData.suggesters.suggest_key,
        suggest_field = reqData.suggesters.suggest_field,
       
        projects = { $project : {  } }
        projects.$project[`${suggest_field}.${suggest_key}`] = 1;

        let my_interests = await EMPLOYEESEARCH.collection.aggregate([
                { $match : { "_id" : emp_id } },
                { $unwind :  `$${suggest_field}` },
                projects,
                { $group : { _id : "$_id" , data : { $addToSet : `$${suggest_field}.${suggest_key}` } } }
        ]).toArray();

    
        if(my_interests.length === 0 ) {
            return [ {count : 0, data : [] } ]
        }

        let matchs = { $match : {} } 
        matchs.$match[`${suggest_field}.${suggest_key}`] = { $in : my_interests[0].data }
        matchs.$match['_id'] = { $ne : emp_id }
        matchs.$match['empstatus'] = { $ne : EMPLOYEE_TERMINATED_STATUS }  ;
        
        return EMPLOYEESEARCH.collection.aggregate([
            matchs,
            { $project : { employeename : 1 , empbusinesstitle : 1, empsubserviceline :1 } },
            { $facet : {
                'count' : [ { $count : 'count' } ],
                'data' : [ 
                    { $sort :  { 'employeename': 1 } },
                    { $skip : skip }, 
                    { $limit : limit }, 
                    { $project : { employeename : 1 , empbusinesstitle : 1 , empsubserviceline :1 } }
                ]
            } },             
            { 
                $project : {
                    count : { $arrayElemAt : ['$count.count' , 0] },
                    data :  '$data' 
                }
            }
        ]).toArray(); 
    } catch (error) {
        throw error
    }
}