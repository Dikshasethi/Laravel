const EmpFavCollection = require('../models/empfavcollection');
const logger = require('../config/logger_config');
module.exports = {
    fetchemplabelsreco,
    renameemplabel,
    deleteemplabelreco
}
async function fetchemplabelsreco (req, res) {
    try {
        let lavelname = req.body.label;
        let nameoflavel = 'emplabels.'+ [lavelname]+'.empid';
        let response = await EmpFavCollection.collection.aggregate([
            { $lookup:
                {
                    from: 'employeesearch',
                    localField: nameoflavel,
                    foreignField: 'empid',
                    as: 'employeedetails'
                }
            },
            {"$match": { "empid": req.body.empid } }
            ]).toArray( )
            
        res.send({"emplabels":response});
    } catch (error) {
        logger.error(error.stack);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
        
}

async function renameemplabel( req, res) {
    try {
        let nameofoldlavel = 'emplabels.'+ [req.body.labelfrom];
        let nameofnewlavel = 'emplabels.'+ [req.body.labelto];
        let myquery = { "empid": req.body.empid };
        let response =  await EmpFavCollection.collection.updateOne( myquery,{$rename: {[nameofoldlavel]:nameofnewlavel} },{ upsert: true } )

        if(response != null && response.result.nModified > 0 ){
            res.send({"status":"Label has been remaned to "+req.body.labelto});
        }
        else{
            res.send({"status":"No Matching Records"});
        }
    } catch (error) {
        logger.error(error.stack);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
}

async function deleteemplabelreco( req, res ){
    try {
        var lavelname = [];
        if(Array.isArray(req.body.label)){
            lavelname = req.body.label;
        }else{
            lavelname.push(req.body.label);
        }
        for (let i = 0; i < lavelname.length ; i++ ){
            var nameoflavel = 'emplabels.'+ [lavelname[i]];
            var myquery = { "empid": req.body.empid };
            if(req.body.employee != null){
                data = {
                    $pull: { [nameoflavel] : {"empid": req.body.employee } }
                };
            }else{
                data = {
                    $unset: { [nameoflavel] : 1 }
                }; 
            }
            await EmpFavCollection.collection.updateOne(myquery,  data );
        }
        res.send({"status":"deleted"});
    } catch (error) {
        logger.error(error.stack);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
}