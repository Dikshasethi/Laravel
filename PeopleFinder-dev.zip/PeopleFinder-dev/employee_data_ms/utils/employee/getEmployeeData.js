const config = require('../../config/config')();
const logger = require('../../config/logger_config');
const mdsPostRequest = require('../fetch/mdsPostRequest');
const queryParameters = require('./queryParamters');

module.exports = async (field='', value='') => {
    try{
        let payload = {
            ...queryParameters,
            [field] : value
        }
        let response = await mdsPostRequest(
            config.mdsEmployeeUrl,
            payload
        );
        if(
            response['DataTable'] && 
            response['DataTable']['diffgr:diffgram'] && 
            response['DataTable']['diffgr:diffgram'][0] &&
            response['DataTable']['diffgr:diffgram'][0]['DocumentElement'] && 
            response['DataTable']['diffgr:diffgram'][0]['DocumentElement'][0] &&
            response['DataTable']['diffgr:diffgram'][0]['DocumentElement'][0]['EmpData'] && 
            response['DataTable']['diffgr:diffgram'][0]['DocumentElement'][0]['EmpData'][0]
        ){
            const {
                EmployeeID=[], FirstName=[], 
                MiddleName=[], LastName=[], EmailID=[]
            } = response['DataTable']['diffgr:diffgram'][0]['DocumentElement'][0]['EmpData'][0];
            return {
                first_name : FirstName[0] || '',
                middle_name : MiddleName[0] || '',
                last_name : LastName[0] || '',
                employee_id : EmployeeID[0] || '',
                email : EmailID[0] || ''
            }
        }else{
            return {
                error : {
                    message : 'An error occured while getting user data.'
                }
            }
        }

    }catch(e){
        console.log('/utils/employee/getEmployeeData catch error', e);
        logger.error(e.stack);
        return {
            error : {
                message : 'An error occured while getting user data'
            }
        }
    }
}