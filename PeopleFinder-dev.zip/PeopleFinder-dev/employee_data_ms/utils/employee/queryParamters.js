module.exports = {
    EmployeeID : '',
    FirstName : '',
    MiddleName : '',
    LastName : '',
    EmailID : '',
    TerminationDate : '',
    PhoneNumber : ''
}