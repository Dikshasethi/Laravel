var moment = require('moment');
const logger = require('../../config/logger_config');
const workAnniversaryDefaultPayload = require('../../config/esPayloadConfig.json');
async function getWorkAniversaryPayload(req, res) {
    let currentDate = req.body.dateTime;
    let isdateValid = moment(currentDate, 'YYYY-MM-DD').isValid();
    let formattedDate = currentDate && isdateValid ? moment(currentDate).format('YYYY-MM-DD') : moment(Date.now()).format('YYYY-MM-DD');
     try {
    //     let isValidDate =   moment(formattedDate, 'YYYY-MM-DD').isValid();
    //     if(isValidDate) {
    //       let dateFields= await fetchDateFields(formattedDate);
    //       let payload = await preparePayload(dateFields);
    //       return payload;
    //     }
    //     else{
    //         return null;
    //     }
        return null;
    } catch (err) {
        logger.error(err);
        throw err;
    }
}

const fetchDateFields = async (dateObj) => {
    var day = moment(dateObj).date();
    var month = moment(dateObj).month()+1;
    var year = moment(dateObj).year();
    return { month: month, dayNumber: day, year: year };
}
const preparePayload = async (dateFields) => {
    var filter={
        "page_size": 300,
        "refined_by": {
            "not": {
                "like": {
                    "empbusinesstitle": {
                        "value": "Contingent Worker.*",
                        "boost": 1.2
                    }
                }
            },
            "hireDateMonth":  dateFields.month,
            "range":[{
                "field": "hireDateDay", 
                "to": dateFields.dayNumber,
                "from": 1
            }],
            "script": `int yeardiff = ${dateFields.year}-doc.hiredate.date.getYear(); return yeardiff == 2 || yeardiff%5 == 0`
        }
    }
    return filter;
}
async function setValuesToESPayload(dateObj) {
    try {
        let payload =  workAnniversaryDefaultPayload;
        Object.keys(payload).forEach(function(key,index) { 
            if (typeof payload[key] === 'object') {
                recursivelyFindProp(payload[key], 'inputYear' , dateObj.year);
                recursivelyFindProp(payload[key], 'inputMonth' , dateObj.month);
                recursivelyFindProp(payload[key], 'curentDayNumber' , dateObj.dayNumber);
              }  else {
                if (payload[key] === 'inputYear') payload[key] = dateObj.year;
                if (payload[key] === 'inputMonth') payload[key] = dateObj.month;
                if (payload[key] === 'curentDayNumber') payload[key] = dateObj.dayNumber;
                if (JSON.stringify(payload[key]).indexOf('inputYear') > 0)payload[key] = replacePartOfString(payload[key], 'inputYear',dateObj.year);
                if (JSON.stringify(payload[key]).indexOf('inputMonth') > 0) payload[key] = replacePartOfString(payload[key], 'inputMonth', dateObj.month);
                if (JSON.stringify(payload[key]).indexOf('curentDayNumber') > 0) payload[key] = replacePartOfString(payload[key],'curentDayNumber',dateObj.dayNumber);
              }
        });
        return payload;
    } catch (err) {
        logger.error(err);
        throw err;
    }
}
 function recursivelyFindProp(obj, valueToBeFind, replaceValue) {
    Object.keys(obj).forEach(function (key) {
      if (typeof obj[key] === 'object') {
        recursivelyFindProp(obj[key], valueToBeFind ,replaceValue);
      } else {
         if (obj[key] === valueToBeFind)
         obj[key] = replaceValue;
         if (JSON.stringify(obj[key]).indexOf(valueToBeFind) > 0) 
         obj[key]= replacePartOfString(obj[key],valueToBeFind,replaceValue)
      }
    });
  }
function replacePartOfString(originalValue,valueToBeReplaced ,repalcedWithValue) {
    let str = JSON.stringify(originalValue);
    var newString = str.replace(`${valueToBeReplaced}`, `${repalcedWithValue}`);
    console.log(newString);
    return JSON.parse(newString);
  }
module.exports = {
    getWorkAniversaryPayload: getWorkAniversaryPayload,
    fetchDateFields: fetchDateFields,
    setValuesToESPayload:setValuesToESPayload,
    recursivelyFindProp:recursivelyFindProp,
    replacePartOfString:replacePartOfString,
    preparePayload:preparePayload
}
