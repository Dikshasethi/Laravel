const request = require("request-promise");
let session = require('express-session');

module.exports = (uri, body, reqheaders) => {
	let EWLJToken = null,msalaccesstoken=null;
	if (reqheaders != null) {
		EWLJToken = reqheaders.access_token;
		msalaccesstoken=reqheaders.msalaccesstoken;
	}
	var options = {
		uri: uri,
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			'access_token': EWLJToken,
			'msalaccesstoken':msalaccesstoken
		},
		rejectUnauthorized: false,
		requestCert: false,
		agent: false,
		body: body,
		json: true
	};
	return request(options)
		.then(function (response) {
			response["statusCode"] = 200;
			return response;
		})
		.catch(function (err) {
			if (err.error && err.status == 401) {
				return err.error
			} else
				return err
		});
}
