const postRequest = require('../fetch/postRequest');
module.exports = async (reqsessionvar) => {
    var tokendetail = '';
    try {
        var ElasticApiBody = { "username":   reqsessionvar.empData.username, "app_name": process.env.APP_NAME, "roles": ["User"] };
        var tokendetail = await postRequest(process.env.ELASTIC_AUTHENTICATION_URL, ElasticApiBody, null);
       // console.log("Regenerate Token Called",ElasticApiBody ,tokendetail);
        req.session.empData.access_token = tokendetail.access_token;
        req.session.empData.timeout = tokendetail.expiry - 120;
        req.session.empData.expiryTime = Math.floor(Date.now() / 1000) +  req.session.empData.timeout;
        let timeout = tokendetail.expiry-120;
        let expiryTime = Math.floor(Date.now() / 1000) + timeout;  
        console.log(tokendetail); 
        return tokendetail;
    } catch (e) {
        logger.error('Error while generating JWTToken :', e);
        return {
            error: {
                message: 'An error occured',
                errorPayload: e
            }
        }
    }

}