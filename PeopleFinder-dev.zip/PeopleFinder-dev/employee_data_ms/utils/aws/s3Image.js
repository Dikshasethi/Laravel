const CONFIG = require('../../config/config')();
const AWS = require('aws-sdk');
const axios  =require('axios');

module.exports ={
    generateSignedS3Url,
    uploadImageToS3,
    deleteImageFromS3,
    getImagesFromMultiMedia
} 
/**
 * Generate Signed url for image
 * @param {*} imageArray 
 */
async function generateSignedS3Url(imageArray) {
    try{        
        let imageList = [];
        
        const s3 = new AWS.S3({
            accessKeyId: CONFIG.awsAccessKey,
            secretAccessKey: CONFIG.awsSecretKey
        });
        
        for(let imageObject of imageArray){
            let imageObjClone = JSON.parse(JSON.stringify(imageObject))
            const BUCKET_NORMAL = CONFIG.S3bucketNormal_Images,
            BUCKET_COMPRESSED = CONFIG.S3bucketCompressed_Images,
            signedUrlExpireSeconds = CONFIG.s3ExpirationDurationMinutes;
            
            const signedUrlCompressed = await s3.getSignedUrl('getObject', {
                Bucket: BUCKET_COMPRESSED,
                Key: imageObjClone.empprofileurl,
                Expires: signedUrlExpireSeconds
            })
            const signedUrlNormal = await s3.getSignedUrl('getObject', {
                Bucket: BUCKET_NORMAL,
                Key: imageObjClone.empprofileurl,
                Expires: signedUrlExpireSeconds
            })
            let tempImageObj = {
                employeeId : imageObjClone._id,
                imageUrl : imageObjClone.empprofileurl,
                signedUrl_compressed : signedUrlCompressed || '',
                signedUrl_normal : signedUrlNormal || ''
            }
            imageList.push(tempImageObj)
        }
        return  imageList
    }catch(e){
        throw e;
    }
}

/**
 * Upload Image to S3
 * @param {imageList, device, appId, uploader} req 
 */
async function uploadImageToS3(reqData){
    try {
        let { imageList=[], device, appId, uploader } = reqData,
        multiMediaUploadUrl = CONFIG.MULTIMEDIA_MS_UPLOAD_IMAGE_ENDPOINT ,
        uploadObj = {
            imageList : imageList,
            device : device,
            appId : appId,
            uploader : uploader
        }
        //Call image ms to upload to s3 and image db
        let response =  await axios.post(multiMediaUploadUrl, uploadObj,{timeout: 1000 * 60 * 30, maxContentLength : 10000000000 });
        return response.data
    } catch (error) {
        throw error;
    }
}

/**
 * Delete image from S3
 * @param {imageUrl} imgUrl 
 */
async function deleteImageFromS3(imgUrl) {
    try {
        let multiMediaDeleteUrl = CONFIG.MULTIMEDIA_MS_DELETE_IMAGE_ENDPOINT,
        //call to multimedia ms to delete image from s3
        response = await axios.post(multiMediaDeleteUrl, imgUrl)
        return response.data
    } catch (error) {
        throw error
    }
}

/**
 * Get images for particular tags from Multimedia ms
 * @param {groupid} filters 
 */
async function getImagesFromMultiMedia(filters){
    try {
        let multiMediaGetImageUrl = CONFIG.MULTIMEDIA_MS_GET_IMAGE_ENDPOINT,
        //Call to get image urls from multimedia ms
        response = await axios.post(multiMediaGetImageUrl,filters)
        return response.data
    } catch (error) {
        throw error
    }
}