const logger = require('../config/logger_config');
require('isomorphic-fetch');
const validateAccessToken = require('../utils/msal/validateAccessToken');

module.exports = async (req, res, next) => {
    try{

        if(!req.user){  
        let accessToken = req.headers.msalaccesstoken || req.cookies['msalaccesstoken'];
        let validationResponse = await validateAccessToken(accessToken);

        if(validationResponse.error){
            return res.status(400).send({ result: 'Not Authorized' })
        }else{
            req.user = {
                ...validationResponse,
                accessToken
            };
            next();
        }
    }
    else{
        next();
    }
    }catch(e){
        console.log('validate msal access token catch block error', e)
        logger.error(e.stack);
        res.status(401).send({
            status: 401,
            message: "'Not Authorized"
        });
    }
}