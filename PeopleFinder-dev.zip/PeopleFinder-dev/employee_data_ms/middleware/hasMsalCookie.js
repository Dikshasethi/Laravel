
const config = require('../config/config')();
const logger = require('../config/logger_config');
const postRequest = require('../utils/fetch/postRequest');
const validateAccessToken = require('../utils/msal/validateAccessToken');
const jwt = require('jsonwebtoken');

module.exports = async (req, res, next) => {
    try{
        let msalaccesstoken = req.cookies['msalaccesstoken'];
        let authToken = req.cookies['authToken'];
        if(!msalaccesstoken || !authToken){
            return next();
        }
        let decoded = await jwt.verify(authToken, config.jwtSecret);
        if(decoded)
        {
            let response = await validateAccessToken(msalaccesstoken);
            if(response.error){
                res.status(401).send({
                    status: 401,
                    message: "'Not Authorized"
                });
            
            }
            else { 
                req.tokenObject = {
                    token:msalaccesstoken
                }
                next();  
            }
      }else{
        res.status(401).send({
            status: 401,
            message: "'Not Authorized"
        });
    }
    }
    catch(e)
    {
        console.log("msalCookie validator catch block error", e);
        logger.error(e.stack);
        res.status(401).send({
            status: 401,
            message: "'Not Authorized"
        });
    }
}