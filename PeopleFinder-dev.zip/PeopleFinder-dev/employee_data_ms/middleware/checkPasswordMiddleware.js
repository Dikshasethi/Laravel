//@Author : vanand1

const mdsPostRequest = require('../service/mdsPostRequest');
module.exports = async (req, res, next) => {
        const url = process.env.MDS_URL //| config.MDS_URL; 
        if (req.body.username && req.body.password) {
            var passwordVar ='';
            var checkpassword= Buffer.from(req.body.password, 'base64').toString('base64') === req.body.password
            if(req.body.apptype=='mobile')
            { passwordVar = req.body.password;
            }
            else{
                passwordVar = Buffer.from(req.body.password, 'base64').toString();
            }
            var userPayload = {
                user: req.body.username,
                password: passwordVar
            };
            let responseUser = await mdsPostRequest(url + '/Login', userPayload);
            if (!responseUser.error && responseUser.NovellUser["diffgr:diffgram"]) {
                req.user = responseUser.NovellUser["diffgr:diffgram"][0].NovellUser[0].Users[0];
            }
            else {
                req.user = null;
            }
        }
        next();
}