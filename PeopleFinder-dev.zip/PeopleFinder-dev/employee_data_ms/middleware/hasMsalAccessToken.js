const config = require('../config/config')();
const logger = require('../config/logger_config');
const postRequest = require('../utils/fetch/postRequest');

module.exports = async (req, res, next) => {
    try{
        let accessToken = req.headers.msalaccesstoken;
        if(!accessToken || (
                req.tokenObject && 
                req.tokenObject.token && 
                req.tokenObject.token !=''
            )
        ){
            return next();
        }else{
            let reqHeader = {};
            reqHeader['msalaccesstoken'] = accessToken;
            let url = config.employeedata_ms_url+'/api/employeedata/generateToken';
            let response = await postRequest(url, {}, reqHeader);
            if(response.error){
                res.status(401).send({
                    status: 401,
                    message: "'Not Authorized"
                });
               
            }else{
                req.tokenObject = {
                    token : response.token,
                }
                return next();
            }
        }
    }catch(e){
        logger.error(e.stack);
        console.log('hasMsalAccessToken catch block error', e);
        res.status(401).send({
            status: 401,
            message: "'Not Authorized"
        });
        
    }
}