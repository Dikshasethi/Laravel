let jwt = require('jsonwebtoken');
const moment = require('moment');

const config = require('../config/config')();


module.exports = (req, res, next) => {
    try {
        if(
            req.tokenObject && 
            req.tokenObject.token && 
            req.tokenObject.token !=''
        ){
            return next();  }
        else
        {
            let token = req.headers['authorization'];
            if(token){
                token = token.replace(/^Bearer\s+/, "");
                jwt.verify(token, config.jwtSecret, function (err, decoded) {
                    if (err) {
                        if(err.message=='jwt expired')
                        {
                            res.status(401).send({
                                status: 401,
                                message: "Access token Expired."
                            });
                        }
                        else{

                            res.status(401).send({
                                status: 401,
                                message: "Not Authorized"
                            });
                        }
                       
                    }
                    else {
                        req.tokenObject = {
                            'token' : token
                        }
                        return next();
                    }
                });
            }
            else{

                res.status(401).send({
                    status: 401,
                    message: "Not Authorized"
                });
               
            }
      }
    }
    catch (error) {
        console.log(error);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
};

