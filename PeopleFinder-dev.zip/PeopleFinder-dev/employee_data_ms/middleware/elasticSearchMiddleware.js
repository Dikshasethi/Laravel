//@Author : vanand1
const elasticSearchRegenrateToken = require('../service/generateToken');
const newElasticTokenGeneration = require('../utils/token/newElasticTokenGeneration');
//let session = require('express-session');

module.exports = async (req, res, next) => {
  if (!req.headers.access_token) {
    res.status(401).send("Unauthorized");
  }
  else {
    next();
  }
}