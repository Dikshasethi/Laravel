var Suggestion = require('../service/suggestion');
const SuggesterConfig = require('../config/suggesterConfig.json');
const { ERROR } = require('../config/responseMessages')
module.exports = {
    pagesSuggester : getPagesSuggester,
}
async function getPagesSuggester( req, res )  {
    try {
        let keycode = req.body.keycode,
        data = [];
        if(req.body.value === undefined) {
            res.status(400).json(ERROR.INVALID_VALUE)
        }

        if( keycode !== undefined && SuggesterConfig.yellowPageSuggesters[keycode] !== undefined) {
            req.body.suggesters = SuggesterConfig.yellowPageSuggesters[keycode];
            data = (await Suggestion.fetchYeallowPageSuggestion(req.body))[0];
        } else {
			let suggesters = SuggesterConfig
			if( keycode !== undefined && keycode in SuggesterConfig.whitePageSuggesters ) {
				let data = {
					"yellowPageSuggesters" : {},
					"whitePageSuggesters" : {
						keycode : suggesters.whitePageSuggesters[keycode]
					}
				}
				suggesters = data;
			}
            req.body.suggesters = suggesters;
            data = (await Suggestion.fetchLandingPageSuggestion(req.body))[0]
        }
        
        if("count" in data === false) {
            data = {
                count : 0,
                data : []
            }
        }
        res.status(200).json(data);
    }catch( err) {
       res.status(400).json({'statusCode': 400,'error': err.message })
    };
}
