const S3Image = require('../utils/aws/s3Image')
const { ERROR } = require('../config/responseMessages')
const logger = require('../config/logger_config')
const Image = require('../service/image')
const s3Image = require('../utils/aws/s3Image')
const CONFIG = require('../config/config')()

module.exports = {
    uploadImage,
    deleteImage,
    getImage,
    uploadExistingEmpImage,
    deleteJunkImages
}


async function uploadImage(req, res) {
    try {
        let { imageList, device, employeeid } = req.body
        // Validate request
        if( !imageList || !imageList.length ) {
            return res.status(400).json(ERROR.INVALID_IMAGELIST)
        }
        for( let imageAttr of imageList){
            if (!imageAttr.imageBase64 || imageAttr.imageBase64 === ''){
               return res.status(400).json(ERROR.INVALID_IMAGELIST_IMAGEBASE64)
            } else if(!imageAttr.category || imageAttr.category === ''){
                return res.status(400).json(ERROR.INVALID_IMAGELIST_CATEGORY)
            }else if(!imageAttr.fileName || imageAttr.fileName === ''){
                return res.status(400).json(ERROR.INVALID_IMAGELIST_FILENAME)
            }else if(!imageAttr.fileExtension || imageAttr.fileExtension === ''){
                return res.status(400).json(ERROR.INVALID_IMAGELIST_FILEEXTENSION)
            }else if(!imageAttr.filetype || imageAttr.filetype === ''){
                return res.status(400).json(ERROR.INVALID_IMAGELIST_FILETYPE)
            }
        } 
        if(!device || device === ''){
            return res.status(400).json(ERROR.INVALID_DEVICE)
        } else if ( !employeeid || employeeid === '' ) {
            return res.status(400).json(ERROR.INVALID_EMP_ID)
        }
        //encrpt filename of image
        req.body.imageList[0].fileName = Buffer.from(req.body.imageList[0].fileName).toString('base64')
        // upload image to s3
        let s3Response = await S3Image.uploadImageToS3(req.body);
        if(s3Response && s3Response.successList && s3Response.successList.length ){
            // save image url to db
            let imgResponse =  await Image.saveImageUrl(req.body.employeeid, s3Response.successList[0].url)
            if(imgResponse){
                imageArray = [{
                    _id:imgResponse._id,
                    empprofileurl: imgResponse.empprofileurl
                }]
                data = await S3Image.generateSignedS3Url(imageArray);
                return res.json({ success : true, data : data})
            }
        } else{
            if(s3Response && s3Response.failedList.length) {
                return res.json(s3Response)
            }
            throw new Error(`MultiMedia Error - ${s3Response.error.message}`)
        }
    } catch (error) {
        logger.error(error.stack);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
}

async function deleteImage(req, res) {
    try {
        let { employeeid } = req.body
        // Validations 
        if (!employeeid || employeeid === '') {
            return res.status(400).json(ERROR.INVALID_EMP_ID)
        }
        //get empprofileurl from db
        let empRes = ( await Image.getProfileUrls([employeeid]) )[0]
        //Delete Image from DB and S3
        if (!empRes){
            return res.status(404).json({'statusCode': 404,'message': "Image not found in database"})
        }
        let s3ReqObj = { imageUrl : empRes.empprofileurl },
        imageDeleteResS3 = await S3Image.deleteImageFromS3( s3ReqObj );
        if ( imageDeleteResS3 && imageDeleteResS3.success ){
            imageDeleteResDb = await Image.deleteImageUrl( employeeid )
            if( imageDeleteResDb && !imageDeleteResDb.empprofileurl ){
                return res.json( imageDeleteResS3 )
            }
        } else {
            throw new Error( `MultiMedia Err - ${imageDeleteResS3.error.message}`)
        }
    } catch (error) {
        logger.error(error.stack);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
}

async function getImage( req, res) {
    try {
        let employeeids = req.body.empIds,
        resData = [];
        if( !employeeids || !employeeids.length ){
            return res.status(400).json(ERROR.INVALID_EMP_ID)
        }
        let empimagesurl = await Image.getProfileUrls(employeeids)
        if(empimagesurl.length){
            resData  = await S3Image.generateSignedS3Url(empimagesurl)
        }
        return res.json({ success : true, data : resData} );
       
    } catch (error) {
        logger.error(error.stack);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
}

 
async function uploadExistingEmpImage(req, res) {
    try {
        let counter  = req.body.counter ? req.body.counter : 0
        var empData =  await Image.getImages(),
        i= 1, payload_size = 0,
        multimediaPayload = {
            imageList : [],
            device: 'website',
            appId: "PeopleFinder",
            uploader : "admin" 
        }
        while (doc = await empData.next()) {
            // Payload For S3
            multimediaPayload.imageList.push( {
                imageBase64: doc.employeeimages.employeeImageBase64,
                category: "employee",
                fileName: doc.empfirstname ? Buffer.from(doc.empfirstname).toString('base64') : Buffer.from(doc._id).toString('base64') ,
                groupId: doc._id,
                fileExtension: doc.employeeimages.employeeImageType,
                filetype: "image",
                tags: [ doc.empfirstname, doc.emplastname, doc._id, doc.employeeemail ]
            })
            i++
            if( i > 20 ) {
                break;
            }
        }
        //check payload size, if greater than 10 mb than reduce payload size
        payload_size = Buffer.byteLength(JSON.stringify(multimediaPayload))
        while ( payload_size >= 9800000) {
            multimediaPayload.imageList.pop()
            payload_size = Buffer.byteLength(JSON.stringify(multimediaPayload))
        }
    
        if (!multimediaPayload.imageList.length) {
            logger.info("Uploaded all the images in S3")
            return;
        }
        // upload image to S3 amd multimedia
        let s3Response = await S3Image.uploadImageToS3(multimediaPayload);
        if (s3Response && s3Response.successList && s3Response.successList.length ){
            // save image url to db
            for(let msRes of s3Response.successList){
                let imgResponse =  await Image.saveImageUrl(msRes.groupid, msRes.url)
                if (imgResponse) {  
                    counter++
                    logger.info(`Image Uploaded for empId = ${msRes.groupid}`)
                }
            }
            logger.info(`${counter} images uploaded`)
            multimediaPayload = {}
            req.body.counter = counter
            await uploadExistingEmpImage(req, res)
        } else {
            logger.error(`MultiMedia Error - ${s3Response.error.message}`)
        }
    } catch (error) {
        logger.error(error.stack);
    }
}


async function deleteJunkImages() {
    try {
        let data = await Image.getEmpData(),
        i = 0
        let getImagesPayload = {
            skip: 0,
            limit: 0,
            filters: {
                category: "employee",
                groupid : []
            }
        },
        activeEmpDoc = terminatedEmpDoc =  []

        console.log(data);
        while (imgDoc = await data.next() ) {
            //get multimedia image payload
            imgDoc.empstatus === CONFIG.EMPLOYEE_TERMINATED_STATUS ? terminatedEmpDoc.push(imgDoc) : activeEmpDoc.push(imgDoc)
            getImagesPayload.filters.groupid.push(imgDoc._id)
        }
      
        // call to get multimedia image
        getImageRes = await s3Image.getImagesFromMultiMedia( getImagesPayload )
        if (getImageRes.success && getImageRes.data.length) {
            for (let image of getImageRes.data) {
                if(activeEmpDoc.findIndex( emp => emp._id===image.groupid && emp.empprofileurl === image.url ) === -1 || terminatedEmpDoc.findIndex( emp => emp._id===image.groupid && emp.empstatus !==  CONFIG.EMPLOYEE_TERMINATED_STATUS) === -1   ){
                    let deletPayload = { imageUrl : image.url },
                    // call to delete Image from multiedia and S3
                    deleteMmRes = await s3Image.deleteImageFromS3(deletPayload)
                    if(deleteMmRes && deleteMmRes.success){
                        logger.info(`Unused image deleted for empId = ${image.groupid}`)
                    }
                    i++
                } 
            }
        } else if ( !getImageRes.success ) {
            logger.error(`MultiMedia Error - ${ getImageRes.error.message}`)
        }
        logger.info(`${i} images deleted`);       
    } catch (error) {
        logger.error(error.stack);
    }
}
