var express = require('express');
var authService = require('../service/generateToken.js');
var checkPassword = require('../middleware/checkPasswordMiddleware');
const validateMsalToken = require('../service/validateMsalToken');
const validateAuthToken = require('../service/validateAuthToken');
const regenerateAuthToken = require('../service/regenerateAuthToken');
const revokeUser = require('../service/revokeUser');
const validateAccessToken = require('../middleware/validateAccessToken');

var authController = express.Router();

authController.post('/generateToken', checkPassword,validateAccessToken, authService.generateToken);
authController.post('/validatemsaltoken', validateMsalToken);
authController.post('/regenerateAuthToken', regenerateAuthToken);
authController.post('/validateAuthToken', validateAuthToken);
authController.post('/revokeUser', revokeUser);
//authController.post('/validatemsaltoken', validateMsalToken);

module.exports = authController;


