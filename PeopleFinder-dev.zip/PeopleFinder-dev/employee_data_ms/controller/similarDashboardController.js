const SimilarDashboard =require('../service/similarDashboard')
const { ERROR } = require('../config/responseMessages')
const logger = require('../config/logger_config');
const SuggesterConfig = require('../config/suggesterConfig.json');

module.exports = {
    similarDashboard
}

async function similarDashboard( req, res) {
    try {
        let emp_id = req.body.empid,
        keycode = req.body.keycode;
        if(emp_id === undefined && emp_id === ''){
            res.status(400).json(ERROR.INVALID_EMP_ID)
        }
        if(keycode !== undefined && SuggesterConfig.yellowPageSuggesters[keycode] !== undefined) {
            req.body.suggesters = SuggesterConfig.yellowPageSuggesters[keycode];
            data = (await SimilarDashboard.getSimilarDashboard(req.body))[0];
        } 
        res.json(data)
    } catch (error) {
        logger.error(error.stack);
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
}


