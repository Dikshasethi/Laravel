var express = require('express');
var labels = require('../service/labelApis');
var favourite = require('../service/favouriteApis');
var labelFav = require('../service/setLabelFavApi')
const hasMsalCookie = require('../middleware/hasMsalCookie')
const appMiddleware = require('../middleware/appMiddleware')
const hasMsalAccessToken = require('../middleware/hasMsalAccessToken')
//const middleware = require('../middleware')

var mydbcontroller = express.Router();

mydbcontroller.post('/save', hasMsalCookie, hasMsalAccessToken, appMiddleware, labelFav.saveempfavreco);
mydbcontroller.post('/fetch/fav', hasMsalCookie, hasMsalAccessToken, appMiddleware, favourite.fetchempfavreco);
mydbcontroller.post('/fetch/labels', hasMsalCookie, hasMsalAccessToken, appMiddleware, labels.fetchemplabelsreco);
mydbcontroller.post('/delete/fav', hasMsalCookie, hasMsalAccessToken, appMiddleware, favourite.deleteempfavreco);
mydbcontroller.post('/delete/label', hasMsalCookie, hasMsalAccessToken, appMiddleware, labels.deleteemplabelreco);
mydbcontroller.post('/rename/label', hasMsalCookie, hasMsalAccessToken, appMiddleware, labels.renameemplabel);

module.exports = mydbcontroller;


