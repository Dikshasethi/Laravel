const country = require('../service/country')
const { ERROR } = require('../config/responseMessages')
module.exports = {
    getCountries
}

async function getCountries (req, res) {
    try {
        if(req.body.value === undefined) {
            res.status(400).json(ERROR.INVALID_VALUE)
        }
        let data  = await country.fetchCountires( req.body )
        if( data.length ){
            data = {
                countries : data
            }
        } else {
            data = {
                countries : []
            } 
        }
        res.status(200).json(data)
    } catch (error) {
        res.status(400).json({'statusCode': 400,'error': error.message })
    }
}