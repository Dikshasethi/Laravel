const { ERROR } = require('../config/responseMessages')
var dateFormat = require('dateformat');
const postRequest = require('../utils/fetch/postRequest');
var _ = require('underscore');
var getWorkAniversaryPayload = require('../utils/elastic/payload');
const workAnniversaryDefaultPayload = require('../config/esPayloadConfig.json');
var moment = require('moment');
const logger = require('../config/logger_config');
const { contains } = require('underscore');
module.exports = {
    WorkAniversary: WorkAniversary,

}
async function WorkAniversary(req, res) {
    try {
        var arr = [];

        /**
         * @author Nitin Jadaun
         * @description
         */
        let reqHeader = {};
        if (req.headers.access_token != undefined) {
            reqHeader['access_token'] = req.headers.access_token;
        }
        let updatedFilter = await prepareDefaultPayload(req, res);
        let details = await postRequest(process.env.ELASTIC_SEARCH_URL, updatedFilter, reqHeader);
        if (details.data != undefined && details.data.hits != undefined && details.data.hits.total > 0) {
            for (let i = 0; i < details.data.hits.hits.length; i++) {
                let timeDifference = Math.abs((new Date(dateFormat(new Date(), "yyyy-mm-dd"))).getTime() - (new Date(details.data.hits.hits[i]._source.hiredate)).getTime());
                let differentYears = Math.floor(timeDifference / (1000 * 3600 * 24 * 365));
                    arr.push({
                        "_id": details.data.hits.hits[i]._id,
                        "empjobfunction": details.data.hits.hits[i]._source.empbusinesstitle,
                        "employeename": details.data.hits.hits[i]._source.employeename,
                        "employeemail": details.data.hits.hits[i]._source.employeeemail,
                        "appointedyears": differentYears
                    });

            }
            arr = _.sortBy(arr, "employeename");
        }
       // console.log(arr);
        res.status(200).json(arr);
    } catch (err) {
        res.status(400).json({ 'statusCode': 400, 'error': err.message })
    };
}
async function prepareDefaultPayload(req, res) {
    let currentDate = req.body.dateTime;
    var datedata=  moment(currentDate).format('YYYY-MM-DD');
    let isdateValid = moment(datedata, 'YYYY-MM-DD').isValid();
    let formattedDate = datedata && isdateValid ? moment(currentDate).format('YYYY-MM-DD') : moment(Date.now()).format('YYYY-MM-DD');
    try {
        let isValidDate = moment(formattedDate, 'YYYY-MM-DD').isValid();
        if (isValidDate) {
            let dateFields = await getWorkAniversaryPayload.fetchDateFields(formattedDate);
            let preparedObj = await getWorkAniversaryPayload.setValuesToESPayload(dateFields);
            return preparedObj;
        }
    } catch (err) {
        logger.error(err);
        throw err;
    }
}