const Router = require('express').Router()

const imageUpload = require('../service/imageUpload')
const getImageDocuments = require('../service/getImageDocuments')
const imageController = require('../controller/imageController')
const hasMsalCookie = require('../middleware/hasMsalCookie')
const appMiddleware = require('../middleware/appMiddleware')
const hasMsalAccessToken = require('../middleware/hasMsalAccessToken')

Router.post('/uploademployeeimage', hasMsalCookie, hasMsalAccessToken, appMiddleware, imageUpload)
Router.post('/getemployeesimages', hasMsalCookie, hasMsalAccessToken, appMiddleware, getImageDocuments)
Router.post('/uploadempimage', hasMsalCookie, hasMsalAccessToken, appMiddleware, imageController.uploadImage)
Router.post('/deleteempimage', hasMsalCookie, hasMsalAccessToken, appMiddleware, imageController.deleteImage)
Router.post('/getempimages', hasMsalCookie, hasMsalAccessToken, appMiddleware, imageController.getImage)
Router.post('/uploadExistingEmpImages',hasMsalCookie, hasMsalAccessToken, appMiddleware, imageController.uploadExistingEmpImage)
Router.post('/deletejunkimages',hasMsalCookie, hasMsalAccessToken, appMiddleware, imageController.deleteJunkImages)

module.exports = Router