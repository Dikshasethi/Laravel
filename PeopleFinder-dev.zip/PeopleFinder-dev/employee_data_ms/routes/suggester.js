var express = require('express');
var suggestion = require('../controller/suggesterController');
var Router = express.Router();
const hasMsalCookie = require('../middleware/hasMsalCookie')
const appMiddleware = require('../middleware/appMiddleware')
const hasMsalAccessToken = require('../middleware/hasMsalAccessToken')

Router.post('/suggestion', hasMsalCookie, hasMsalAccessToken, appMiddleware, suggestion.pagesSuggester);
module.exports = Router;