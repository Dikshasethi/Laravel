const Router = require('express').Router()
const hasMsalCookie = require('../middleware/hasMsalCookie')
const appMiddleware = require('../middleware/appMiddleware')
const hasMsalAccessToken = require('../middleware/hasMsalAccessToken')
const similarDashboard = require('../controller/similarDashboardController')

Router.post('/similarDashboard', hasMsalCookie, hasMsalAccessToken, appMiddleware, similarDashboard.similarDashboard)

module.exports = Router