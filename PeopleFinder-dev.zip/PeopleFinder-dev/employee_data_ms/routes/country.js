var express = require('express');
var country = require('../controller/countryController');
var Router = express.Router();
const hasMsalCookie = require('../middleware/hasMsalCookie')
const appMiddleware = require('../middleware/appMiddleware')
const hasMsalAccessToken = require('../middleware/hasMsalAccessToken')


Router.post('/getcountries', hasMsalCookie, hasMsalAccessToken, appMiddleware ,country.getCountries);
module.exports = Router;