const suggester = require('./suggester')
const country = require('./country')
const mydbcontr = require('../controller/dbController');
const authcontr = require('../controller/authController');
const image = require('./image');
const similarDashboard = require('./similarDashboard');
const workAniversary = require('./workAniversary');
module.exports =   [
    mydbcontr,
    authcontr,
    image,
    suggester,
    country,
    similarDashboard,
    workAniversary
]