var express = require('express');
const elasticSearchMiddleware = require('../middleware/elasticSearchMiddleware');
var workAniversary = require('../controller/workAniversaryController');
const hasMsalCookie = require('../middleware/hasMsalCookie')
const appMiddleware = require('../middleware/appMiddleware')
const hasMsalAccessToken = require('../middleware/hasMsalAccessToken')
var Router = express.Router();

Router.post('/getWorkAniversaries', elasticSearchMiddleware, hasMsalCookie, hasMsalAccessToken, appMiddleware , workAniversary.WorkAniversary);
module.exports = Router;