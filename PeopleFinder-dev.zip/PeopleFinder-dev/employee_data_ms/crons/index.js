const cron = require('node-cron');

const ImageController = require('../controller/imageController')

//Cron delete all unused images from multimedia and S3
cron.schedule('0 10 * * Sunday', () => {
    ImageController.deleteJunkImages()
});
