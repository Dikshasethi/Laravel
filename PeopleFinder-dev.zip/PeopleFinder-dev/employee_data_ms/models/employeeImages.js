const mongoose = require('mongoose');
const { Schema } = mongoose;
const config = require('../config/config')();

const imageSchema = new Schema({
    _id:String,
   emailid: String,
    employeeImageBase64: String,
    employeeImageType: String,
    lastUpdatedBy: String,
    lastUpdatedDate: { 
        type: Date, 
        default: Date.now,
        required : true
    },
    devicekey: String,
},{versionKey:false})

module.exports = mongoose.model(config.employeeImageModel, imageSchema);