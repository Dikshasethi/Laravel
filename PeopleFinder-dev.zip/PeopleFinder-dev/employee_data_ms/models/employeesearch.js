const mongoose = require('mongoose');
const { Schema } = mongoose;

const employeesearchSchema = new Schema({
    _id: {type:String},
    empbusinesstitle: {type:String},
    empcountry: {type:String},
    empid:{type:String},
    empjobfunction:{type:String},
    empjobsubfuncion: {type:String},
    emplocation:{type:String},
    employeeemail: {type:String},
    employeename: {type:String},
    empserviceline: {type:String},
    empstatus: {type:String},
    empsubserviceline:{type:String},
    hiredate: {type:String},
    lastupdated: {type:String},
    preffirstname: {type:String},
    supervisiordesignation: {type:String},
    supervisoremail: {type:String},
    supervisorid: {type:String},
    supervisorname: {type:String},
    empprofileurl:{ type:String}
},{versionKey:false}
)

module.exports = mongoose.model("Employeesearch", employeesearchSchema,"employeesearch");