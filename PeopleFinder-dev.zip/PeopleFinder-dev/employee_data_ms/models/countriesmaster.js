const mongoose  = require('mongoose')

const { Schema } = mongoose

const countriesmaster = new Schema({})

module.exports = mongoose.model("CountriesMaster", countriesmaster,"countriesmaster")