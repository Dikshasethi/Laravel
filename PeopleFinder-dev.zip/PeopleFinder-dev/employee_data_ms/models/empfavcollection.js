const mongoose  = require('mongoose')

const { Schema } = mongoose

const empfavcollection = new Schema({
    empid : {type: String, required : true },
    emplabels : { type : Object },
    empfavourites : { type : Array }
}, { versionKey : false } )

module.exports = mongoose.model("EmpFavCollection", empfavcollection,"empfavcollection")