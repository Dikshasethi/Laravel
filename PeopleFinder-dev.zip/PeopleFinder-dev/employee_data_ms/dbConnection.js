const mongoose = require('mongoose');
const config = require('./config/config')();
const murl = `mongodb://${config.mongodb_url}/${config.db_name}?replicaSet=${config.replica_set}&authSource=${config.auth_source}`
let mongoOptions = {
    useNewUrlParser: true,
    useCreateIndex: true,
    autoIndex: false,
    useUnifiedTopology: true
}
//if(process.env.NODE_ENV === 'production' ){
    mongoOptions['user'] = config.mongobd_user,
    mongoOptions['pass'] = config.mongodb_password
//}

mongoose.connect(murl, mongoOptions, (err)=>{
    if(err) {
        process.exit(1);
    }
    console.log("Connected to database");
});
mongoose.set('useFindAndModify', false);
