If client dist has not been built yet
if prod "npm run angular-build-prod"
if uat "npm run angular-build-uat"
if dev "npm run angular-build-dev"

To ensure all dependencies are installed
run "npm install"

Start Up Sscript
run "node server" or "npm start"