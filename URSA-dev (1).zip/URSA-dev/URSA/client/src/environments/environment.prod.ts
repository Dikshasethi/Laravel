export const environment:any = {
  production: true,
  notificationEngineUrl : 'http://localhost:5009',
  msalConfig: {
    clientId: '28c62653-6ad9-4ed7-bcbd-2752f1152f45',
    tenantId: '97525e9a-595d-472c-8248-0dc58f852d61',
    redirectUri: 'https://localhost:4200/login',
    postLogoutRedirectUri: 'https://localhost:4200/login',
  }

};
