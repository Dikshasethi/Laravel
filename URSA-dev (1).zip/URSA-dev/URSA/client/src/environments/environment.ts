// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment :any = {
  production: false,
  notificationEngineUrl : 'http://localhost:5009',
  appName : 'URSA',
  appID :'001',
  msalConfig: {
    clientId: '28c62653-6ad9-4ed7-bcbd-2752f1152f45',
    tenantId: '97525e9a-595d-472c-8248-0dc58f852d61',
    redirectUri: 'https://localhost:4200/login',
    postLogoutRedirectUri: 'https://localhost:4200/login',
  },
  googleAnalyticsId : 'UA-187299409-7'
};
