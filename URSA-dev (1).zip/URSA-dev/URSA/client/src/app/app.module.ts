import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { MsalModule } from '@azure/msal-angular';
import { MsalSettings } from '../msalConfig';
import { CookieService } from "angular2-cookie/services/cookies.service";

import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { UserService } from './service/user.service';
import { GoogleAnalyticsService } from './service/google-analytics.service';
// import { CookieService } from 'ngx-cookie-service';
import { KeywordSearchPipe } from './filters/keyword-search.pipe';
import { DatePipe } from '@angular/common';
import { SearchMoreFilterPipe } from './filters/search-more-filter.pipe';
import { SearchFilterPipe } from './filters/search-filter.pipe';
import { OrderByPipe } from './filters/order-by.pipe';
import { PagelayoutComponent } from './components/pagelayout/pagelayout.component';
import { LoginComponent } from './components/login/login.component';
import { ErrorComponent } from './components/error/error.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { ProductEffects } from './effects/product.effect';
import { AutocompleteEffects } from './effects/autocomplete.effect';
import { ProposalListEffects } from './effects/proposalList.effect';
import { CartEffects } from './effects/cart.effect';
import { WatchListEffects } from './effects/watchlist.effect';
import { CheckInOutEffects } from './effects/checkInOut.effect';
import { reducers } from './reducers';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ProposalPageDataEffects } from './effects/proposalPageData.effect';
import { UserDetailEffects } from './effects/userDetail.effect';
import { CalloutEffects } from './effects/callout.effect';
import { CheckoutEffects } from './effects/checkout.effect';
import { CheckoutCheckinEffects } from './effects/checked-in-assets.effect';
import { FilterPipeModule } from 'ngx-filter-pipe';
import { HardReserveAssetsTableComponent } from './components/hard-reserve-assets-table/hard-reserve-assets-table.component';
import { CheckedOutAssetsTableComponent } from './components/checked-out-assets-table/checked-out-assets-table.component';
import { CheckOutDetailsInputPanelComponent } from './components/check-out-details-input-panel/check-out-details-input-panel.component';
import { ProposalFilterPipe } from './filters/filter-proposal.pipe';
import { TimeoutModalComponent } from './components/custom-components/timeout-modal/timeout-modal.component';
import { UserSearchComponent } from './components/custom-components/user-search/user-search.component';
import { UtilizationEffects } from './effects/utilization.effect';
import { EmoEffects } from './effects/emo.effect';
import { ReceivingEffects } from './effects/receiving.effect';
import { AssetLogEffects } from './effects/assetLog.effect';
import { AssetLogsComponent } from './components/asset-logs/asset-logs.component';
import { NotificationEffects } from './effects/notification.effect';
import { RoleMatrixEffects } from './effects/roleMatrix.effect';
import { DownloadEffects } from './effects/download.effect';
import { AssetHistoryComponent } from './components/asset-history/asset-history.component';
import { ProductHistoryDetailsComponent } from './components/asset-history/product-history-details/product-history-details.component';
import { AssetTransactionLogComponent } from './components/asset-history/asset-transaction-log/asset-transaction-log.component';
import { InformationCardEffects } from './effects/informationCard.effect';
import { SharedModule } from "./shared.module";
import { AppRoutes } from "./app.routes";
import { WorkOrderHistory } from './components/asset-history/work-order-history/work-order-history.component';
import { CertificateHistoryComponent } from './components/asset-history/certificate-history/certificate-history.component';
import { DashboardEffects } from './effects/dashboard.effect';
import { ProposalDataEffects } from './effects/proposalData.effect';
import { ServiceRequestDataEffects } from './effects/serviceRequest.effect';
import { RefinedByPersonalizationEffects } from './effects/refinedBy-personalization.effect';
import { TableColumnPersonalizationEffects } from './effects/tableColumnOrder-personalization.effect';
const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    KeywordSearchPipe,
    SearchMoreFilterPipe,
    SearchFilterPipe,
    ErrorComponent,
    OrderByPipe,
    PagelayoutComponent,
    FooterComponent,
    HardReserveAssetsTableComponent,
    CheckedOutAssetsTableComponent,
    CheckOutDetailsInputPanelComponent,
    ProposalFilterPipe,
    TimeoutModalComponent,
    UserSearchComponent,
    AssetLogsComponent,
    AssetHistoryComponent,
    AssetTransactionLogComponent,
    ProductHistoryDetailsComponent,
    WorkOrderHistory,
    CertificateHistoryComponent
 ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AutoCompleteModule,
    RouterModule.forRoot(AppRoutes),
    FilterPipeModule,
    SharedModule,
    EffectsModule.forRoot([
      ProductEffects,AutocompleteEffects,CartEffects,
      ProposalPageDataEffects,UserDetailEffects,CheckoutEffects,
      ProposalListEffects, CalloutEffects, CheckInOutEffects,CheckoutCheckinEffects,
      UtilizationEffects, EmoEffects,ReceivingEffects,
      AssetLogEffects, NotificationEffects,RoleMatrixEffects,DownloadEffects,InformationCardEffects,WatchListEffects,
      DashboardEffects, ProposalDataEffects, RefinedByPersonalizationEffects,TableColumnPersonalizationEffects, ServiceRequestDataEffects
    ]),
    StoreModule.forRoot(reducers),
    MsalModule.forRoot({
      auth: MsalSettings.auth,
      cache: {
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: isIE
      },
      system: { loadFrameTimeout: 35000 },
    },
      MsalSettings.extras
    )
  ],
  providers: [UserService, CookieService, DatePipe, GoogleAnalyticsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
