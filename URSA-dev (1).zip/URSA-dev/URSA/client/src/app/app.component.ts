import { Component, OnInit, HostListener } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Location } from '@angular/common';
import { Store, select } from '@ngrx/store';
import { AppState } from './models/appState';
import { 
  LogoutUser, UserTimedOut, 
  NewSessionDurationGet, SetUserDetailReducer, GetUserDetail
} from './actions/userDetail.actions';
import { GetUsersNotifications, SetRealTimeNotification } from './actions/notifications.actions';
import { MsalService, BroadcastService } from '@azure/msal-angular';
import { appId,RefineBy } from './utils/config/config';
import * as io from 'socket.io-client';
import {environment} from '../environments/environment';
import * as _ from 'lodash';
import { CookieService } from "angular2-cookie/core";
import { SetFilters } from './actions/refinedBy.actions';
import {summaryRefinedBy, detailsRefinedBy} from './utils/refinedBy/refinedByConstants';
import { productRefinedByList, hardReserveModeRefinedByList } from './utils/product/refinedByList';
declare let gtag: Function;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit{
  userDetailSubscription;
  notificationSubscription;
  updateLoading=false;
  authDurationRefrence : any = 0; 
  elastiDurationRefrence : any = 0; 
  userDetails: any = {};
  timeoutDetails : any = {}
  intervalTimer: any;
  _isTimeout : boolean = false;
  sesionStorageRefrence : any;
  timeoutHash : String = "";
  isLoggedIn : boolean = false
  chainRefresh : boolean = false;
  elastiRefresh : boolean = true;
  currentUser : String;
  remainingDuration : any;
  socket : SocketIOClient.Socket;
  route: string;
  routeCacheSubscription : any;
  loginRouteString : String = '/login';
  userDetailsLoading=false;
  disableRefreshButton=false;
  refreshInAction=false;
  defaultPersonalizationData={};
  refinedBySubscription;
  defaultrefinedByObjData={};
  userView;
  refinedByNgrxKey;
  userSubscription;
  refinedByList=[];
  keyMapper = {};

  constructor(
    private store: Store<AppState>, 
    private router: Router,
    private location: Location,
    private authService: MsalService,
    private broadcastService: BroadcastService,
    private cookieService: CookieService
  ){
    // this.socket = io(environment.notificationEngineUrl);

    //Subscription gets called when route is changed
    this.routeCacheSubscription = this.router.events.subscribe(event => {
      this.checkRouteUrl();
      if(event instanceof NavigationEnd){
        gtag('config', environment.googleAnalyticsId, {
          'page_path' : event.urlAfterRedirects,
          'custom-map' : {
            'dimension1' : 'user-id',
            'dimension2' : 'user-name',
            'dimension3' : 'client-type'
          }
        });

        if(this.userDetails && this.userDetails['employee_id']){
          gtag('set', {'user-id' : this.userDetails['employee_id']});
          gtag('set', {'user-name' : `${this.userDetails['first_name']} ${this.userDetails['last_name']}`});
          gtag('set', {'client-type' : 'Web'});
        }
      }
    });

    window.addEventListener('focus', event => {
      this.refreshInAction = true;
      this.checkAccount();
    });
  }
  
  ngOnInit() {
    this.addGoogleAnalyticsScript();
    this.checkAccount();
    this.refinedByList =productRefinedByList;
    this.setKeyMapper(this.refinedByList);
    
    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(obj => {
      const {details, isloggedOut, isTimeout, isfetch} = obj;
      if(details['employee_id']){
        // this.store.dispatch(new GetUsersNotifications({
        //   userId : details['employee_id'],
        //   appId
        // }));
        // this.socket.emit('Register Client', {
        //   appId,
        //   userId : details['employee_id']
        // });
      }
      this.userDetailsLoading = isfetch;
      this.userDetails = details;
      this.timeoutDetails = {
        _userDetails : details,
        _isLoggedOut: isloggedOut,
        _isTimeout : isTimeout
      }
      

      if(!_.isEmpty(details['personalizations'])) {
          for(let i = 0; i < details['personalizations'].length; i++) {
            if(details['personalizations'][i].personalizationType==RefineBy) {
              this.defaultPersonalizationData=details['personalizations'][i].data;  
              this.setDefaultRefiendByFilter(this.defaultPersonalizationData) ;  
              sessionStorage.setItem('defaultRefiendByPersonalization', JSON.stringify(this.defaultPersonalizationData));
              sessionStorage.setItem('defaultRefiendByExists', JSON.stringify(true));   
            }
          }  
      }

      if(
        details['msal_access_token']
      ){
        this.initTimeCheckFunction();
      }else{
        if(!isfetch && !this.refreshInAction && !_.isEmpty(details)){
          this.logoutFunction();
        }
      }
    });

    this.userSubscription = this.store.pipe(select(state => state.User))
    .subscribe(user => {
      const {userViewPreference=''} = user;
      this.userView = userViewPreference;
      if(['mixed', 'summary'].includes(this.userView)){
        this.refinedByNgrxKey = summaryRefinedBy;
      }else if(['details','hierarchy','utilization', 'forecast'].includes(this.userView)){
        this.refinedByNgrxKey = detailsRefinedBy;
      }
    });

    this.refinedBySubscription = this.store.pipe(select(state => state.RefinedBy))
    .subscribe(refinedByObj => {
      this.defaultrefinedByObjData = refinedByObj[this.refinedByNgrxKey] || {};
    })

    this.notificationSubscription = this.store.pipe(select(state => state.Notification))
    .subscribe(obj => {
      const {
        updateNotificationLoading=false,
        updateNotificationError=false
      } = obj;
      if(
        this.updateLoading &&
        !updateNotificationLoading
      ){
        if(!updateNotificationError){
          this.getNotifications()
        }
      }
      this.updateLoading = updateNotificationLoading;
    });

    // this.socket.on('New Notification', notification => {
    //   this.store.dispatch(new SetRealTimeNotification(notification));
    // });
  }
  setKeyMapper = (refinedByList) => {
    let accumulator = {};
    if(refinedByList){
      for (let i = 0; i < refinedByList.length; i++){
        let refinedBy = refinedByList[i];
        const {label, value} = refinedBy;
        accumulator[label] = value
      }
    }
    this.keyMapper = accumulator;
  }

  initializeListLengthState = (refinedByList) => {
    let accumulator = {};
    if(refinedByList){
      for(let i = 0; i < refinedByList.length; i++){
        let refinedBy = refinedByList[i];
        const {label, value} = refinedBy;
        accumulator[label] = {
          hasSelectedFilters : false,
          fullViewLength : false
        } 
      }
    }
    return accumulator;
  }
  
  setDefaultRefiendByFilter(data) {
    this.defaultrefinedByObjData['listStateTracker']=this.initializeListLengthState(this.refinedByList);
    for (let key in data) {
      let filterKey=Object.keys(this.keyMapper).find(keys => this.keyMapper[keys] === key);
      let list = data[key];
      let newObj = {
        ...this.defaultrefinedByObjData,
        clickTracker : data,
        listStateTracker : {
          ...this.defaultrefinedByObjData['listStateTracker'],
          [filterKey] : {
            ...this.defaultrefinedByObjData['listStateTracker'][filterKey],
            hasSelectedFilters : list && list.length > 0 ? true : false,
            fullViewLength:false
          }
        }
      }
      this.defaultrefinedByObjData=newObj;
    }
   this.store.dispatch(new SetFilters({key : this.refinedByNgrxKey, value :  this.defaultrefinedByObjData}));
  }

  ngOnDestroy() {
    this.routeCacheSubscription.unsubscribe();
    this.notificationSubscription.unsubscribe();
    this.userDetailSubscription.unsubscribe();
  }

  addGoogleAnalyticsScript = () => {
    let node = document.createElement('script');
    node.src = `https://www.googletagmanager.com/gtag/js?id=${environment.googleAnalyticsId}`;
    node.async = true;
    document.getElementsByTagName('head')[0].appendChild(node);
  }

  checkAccount = async () => {
    let loggedIn = !!this.authService.getAccount();
    if(loggedIn){
      if(!this.userDetailsLoading && !this.refreshInAction){
        this.refreshInAction = true;
        this.disableRefreshButton = true;
        this.refreshTokenFunction();
      }
    }else{
      this.isTimeOutCheck();
    }
  }

  refreshTokenFunction = async () => {
    let currentTime = Math.floor(Date.now()/1000);
    let authTokenExpirationTimeString = this.cookieService.get('authTokenExpiryTime');
    let authTokenExpirationTime = authTokenExpirationTimeString ? Number(authTokenExpirationTimeString) : currentTime;
    let auth_difference : Number = authTokenExpirationTime - currentTime;
    if(
      auth_difference <= 299
    ){
      let token = await this.authService.acquireTokenSilent({
        scopes: ["user.read"]
      });
      this.cookieService.put('msalaccesstoken', token.accessToken);
      this.cookieService.put('msalaccesstokenexpiration', `${new Date(token.expiresOn).getTime()}`);
      this.cookieService.put('authTokenExpiryTime', `${new Date(token.expiresOn).getTime() / 1000}`);
      if(token.accessToken){
        this.store.dispatch(new SetUserDetailReducer({
          isTimeout : false,
          isloggedOut : false
        }));
      }
    }
    
    this.store.dispatch(new GetUserDetail({}));
    this.disableRefreshButton = false;
    this.refreshInAction = false;
  }

  getNotifications = () => {
    this.store.dispatch(new GetUsersNotifications({
      userId : this.userDetails['employee_id'] || '',
      appId
    }));
  }

  makeHash(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( let i = 0; i < length; i++ ) {
       result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

  isTimeOutCheck(){    
    let currentTime = Math.floor(Date.now()/1000);
    let authTokenExpirationTimeString = this.cookieService.get('authTokenExpiryTime');
    let last_action_timestamp = this.cookieService.get('last_action_timestamp');
    let authTokenExpirationTime = authTokenExpirationTimeString ? Number(authTokenExpirationTimeString) : currentTime;
    let auth_difference : Number = authTokenExpirationTime - currentTime;
    this.remainingDuration = auth_difference;

    if (auth_difference <= 0 ){
      this.logoutFunction();
    }else if(auth_difference <= 299){
      if(
        last_action_timestamp && 
        (
          (currentTime - Number(last_action_timestamp)) <= 1800
        )
      ){
        this.checkAccount();
      }
      if(auth_difference <= 250 && !this._isTimeout){
        this._isTimeout = true;
        this.store.dispatch(new UserTimedOut());
      }
    }
  }

  clearMsalCache = () => {
    this.cookieService.remove('msalaccesstoken');
    this.cookieService.remove('msalaccesstokenexpiration');
    this.cookieService.remove('es_access_token');
    this.cookieService.remove('es_token_expiry_time');
    this.cookieService.remove('authToken');
    this.cookieService.remove('authTokenExpiryTime');
    this.cookieService.remove('schedulinkToken');
    this.cookieService.remove('schedulinkTokenExpiryTime');
    this.cookieService.remove('adeptia_token');
    this.cookieService.remove('adeptia_tokenExpiryTime');
  }

  checkRouteUrl(){
    let indexOfLastPath =  window.location.href.split('/').slice(0, 3).join('/').length;

    if(
      window.location.href &&
      window.location.href !== '' &&
      window.location.href !== this.route &&
      window.location.href[ indexOfLastPath + 1 ]
    ){
      this.route = window.location.href;
      !window.location.href.toUpperCase().includes(this.loginRouteString.toUpperCase()) ?
        sessionStorage.setItem('lastRoute', window.btoa(this.route.toString())) : 
        null;
    }
  }

  title = 'app';

  logoutFunction(){
    clearInterval(this.intervalTimer);
    this.intervalTimer = undefined;
    localStorage.removeItem('timeoutHash');
    this.store.dispatch(new LogoutUser({}));
    this.clearMsalCache();
    this.router.navigate(['/login']);
  }

  initTimeCheckFunction = () => {
    if(!this.intervalTimer){
      this.intervalTimer = setInterval(() =>{ 
        this.isTimeOutCheck();
      }, 1000);
    }
  }

  refreshSession(event:any){
    this.checkAccount();
  }
}
