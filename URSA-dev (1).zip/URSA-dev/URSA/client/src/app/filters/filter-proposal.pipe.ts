import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
    name: 'proposalfilter',
    pure: false
})
export class ProposalFilterPipe implements PipeTransform {

    format: string = 'dd-MMM-yyyy';
    constructor(private datePipe: DatePipe) { }


    transform(items: any, filter: any) {
        if (items && items.length) {
            return items.filter(item => {
                if (filter.startdate) {
                    let formatdate = this.datePipe.transform(item.startdate, this.format).toLowerCase();
                    if (formatdate.indexOf(filter.startdate.toLowerCase()) === -1)
                        return false;
                }
                if (filter.enddate) {
                    let formatdate = this.datePipe.transform(item.enddate, this.format).toLowerCase();
                    if (formatdate.indexOf(filter.enddate.toLowerCase()) === -1)
                        return false;
                }
                if (filter.projectId && item.projectId.toLowerCase().indexOf(filter.projectId.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.serialnumber && item.serialnumber.toLowerCase().indexOf(filter.serialnumber.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.tagnumber && item.tagnumber.toLowerCase().indexOf(filter.tagnumber.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.assetDesc && item.assetDesc.toLowerCase().indexOf(filter.assetDesc.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.sourcelocation && item.sourcelocation.toLowerCase().indexOf(filter.sourcelocation.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.sourcearea && item.sourcearea.toLowerCase().indexOf(filter.sourcearea.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.category && item.category.toLowerCase().indexOf(filter.category.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.subtype2 && item.subtype2.toLowerCase().indexOf(filter.subtype2.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.businessunit && item.businessunit.toLowerCase().indexOf(filter.businessunit.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.proposalnumber && item.proposalnumber.toLowerCase().indexOf(filter.proposalnumber.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.proposaldescription && item.proposaldescription.toLowerCase().indexOf(filter.proposaldescription.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.crmnumber && item.crmnumber.toLowerCase().indexOf(filter.crmnumber.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.assetid && item.assetid.toLowerCase().indexOf(filter.assetid.toLowerCase()) === -1) {
                    return false;
                }

                if (filter.projectnumber && item.projectnumber.toLowerCase().indexOf(filter.projectnumber.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.assetserialid && item.assetserialid.toLowerCase().indexOf(filter.assetserialid.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.assettagnumber && item.assettagnumber.toLowerCase().indexOf(filter.assettagnumber.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.assetdescription && item.assetdescription.toLowerCase().indexOf(filter.assetdescription.toLowerCase()) === -1) {
                    return false;
                }

                if (filter.destinationlocation) {
                    let location = `${item.destinationlocationdescription}-${item.destinationlocation}`;
                    if (location.toLowerCase().indexOf(filter.destinationlocation.toLowerCase()) === -1)
                        return false;
                }

                if (filter.destinationarea) {
                    let area = `${item.destinationareadescription}-${item.destinationarea}`;
                    if (area.toLowerCase().indexOf(filter.destinationarea.toLowerCase()) === -1)
                        return false;
                }
                if (filter.assetcategory && item.assetcategory.toLowerCase().indexOf(filter.assetcategory.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.peoplesoftcheckoutid && item.peoplesoftcheckoutid.toLowerCase().indexOf(filter.peoplesoftcheckoutid.toLowerCase()) === -1) {
                    return false;
                }

                if (filter.customerreferencenumber && item.customerreferencenumber.toLowerCase().indexOf(filter.customerreferencenumber.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.custodian && item.custodian.toLowerCase().indexOf(filter.custodian.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.proposalDescription && item.proposalDescription.toLowerCase().indexOf(filter.proposalDescription.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.checkoutdate) {
                    let formatdate = this.datePipe.transform(item.checkoutdate, this.format).toLowerCase();
                    if (formatdate.indexOf(filter.checkoutdate.toLowerCase()) === -1)
                        return false;
                }
                if (filter.expectedcheckindate) {
                    let formatdate = this.datePipe.transform(item.expectedcheckindate, this.format).toLowerCase();
                    if (formatdate.indexOf(filter.expectedcheckindate.toLowerCase()) === -1)
                        return false;
                }

                if (filter.actualcheckindate) {
                    let formatdate = this.datePipe.transform(item.actualcheckindate, this.format).toLowerCase();
                    if (formatdate.indexOf(filter.actualcheckindate.toLowerCase()) === -1)
                        return false;
                }

                if (filter.checkinarea) {
                    let area = `${item.checkinareadescription}-${item.checkinarea}`;
                    if (area.toLowerCase().indexOf(filter.checkinarea.toLowerCase()) === -1)
                        return false;
                }

                if (filter.checkinlocation) {
                    let location = `${item.checkinlocationdescription}-${item.checkinlocation}`;
                    if (location.toLowerCase().indexOf(filter.checkinlocation.toLowerCase()) === -1)
                        return false;
                }
                if (filter.checkedinby && item.checkedinby.toLowerCase().indexOf(filter.checkedinby.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.project && item.project.toLowerCase().indexOf(filter.project.toLowerCase()) === -1) {
                    return false;
                }

                if (filter.productcategory && item.productcategory.toLowerCase().indexOf(filter.productcategory.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.oiamsubtype2 && item.oiamsubtype2.toLowerCase().indexOf(filter.oiamsubtype2.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.begindate) {
                    let formatdate = this.datePipe.transform(item.begindate, this.format).toLowerCase();
                    if (formatdate.indexOf(filter.begindate.toLowerCase()) === -1)
                        return false;
                }
                if ((filter.quantity || filter.quantity === 0) && String(item.quantity).toLowerCase().indexOf(String(filter.quantity).toLowerCase()) === -1) {
                    return false;
                }
                if ((filter.hrQty || filter.hrQty === 0) && String(item.hrQty).toLowerCase().indexOf(String(filter.hrQty).toLowerCase()) === -1) {
                    return false;
                }
                if ((filter.coQty || filter.coQty === 0) && String(item.coQty).toLowerCase().indexOf(String(filter.coQty).toLowerCase()) === -1) {
                    return false;
                }
                if (filter.checkoutcustodianname && item.checkoutcustodianname.toLowerCase().indexOf(filter.checkoutcustodianname.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.calloutid && item.calloutid.toLowerCase().indexOf(filter.calloutid.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.projectmanagername && item.projectmanagername.toLowerCase().indexOf(filter.projectmanagername.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.createdby && item.createdby.toLowerCase().indexOf(filter.createdby.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.checkincustodianname) {
                    let custodian = item.checkincustodianname || item.checkoutcustodianname;
                    if (custodian.toLowerCase().indexOf(filter.checkincustodianname.toLowerCase()) === -1)
                        return false;
                }
                if (filter.checkedin) {
                    let checkedin = item.checkedin ? "TRUE" : "FALSE";
                    if (checkedin.toLowerCase().indexOf(filter.checkedin.toLowerCase()) === -1) {
                        return false;
                    }
                }
                if (filter.serialid && item.serialid.toLowerCase().indexOf(filter.serialid.toLowerCase()) === -1) {
                    return false;
                }
                if (filter.pcbusinessunit && item.pcbusinessunit.toLowerCase().indexOf(filter.pcbusinessunit.toLowerCase()) === -1) {
                    return false;
                }
                return true;
            })
        }
        else {
            return items;
        }
    }
}