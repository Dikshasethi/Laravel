import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'keywordSearch'
})
export class KeywordSearchPipe implements PipeTransform {

  transform(items: any, term: any): any {
    if (term === "" || term === undefined) return items;

    return items.filter(function(item) {
      for(let property in item){
        if (item[property] === null|| item[property] === undefined){
          continue;
        }
        if(item[property].toString().toLowerCase().includes(term.toLowerCase())){
          return true;
        }
      }
      return false;
    });
  }

}
