import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchMoreFilter'
})
export class SearchMoreFilterPipe implements PipeTransform {

  transform(items: any, filter: any, filterItems: Array<any>): any {
    if (filter && Array.isArray(items) && filterItems) {
      let filterKeys = Object.keys(filter);
      let checkedItems = filterItems.filter(item => { return item.checked; });
      if (!checkedItems || checkedItems.length === 0) { return items; }
        return items.filter(item => {
          return filterKeys.some((keyName) => {
            return checkedItems.some((checkedItem) => {
              return new RegExp(item[keyName], 'gi').test(checkedItem.key) || checkedItem.key === "";
            });
          });
        });
    } else {
      return items;
    }
  }

}
