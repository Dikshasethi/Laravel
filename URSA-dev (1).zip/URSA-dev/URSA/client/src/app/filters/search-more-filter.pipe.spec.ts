import { SearchMoreFilterPipe } from './search-more-filter.pipe';

describe('SearchMoreFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchMoreFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
