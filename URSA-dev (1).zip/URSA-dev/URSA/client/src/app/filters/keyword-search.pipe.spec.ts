import { KeywordSearchPipe } from './keyword-search.pipe';

describe('KeywordSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new KeywordSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
