import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { UserService } from '../service/user.service';

@Injectable()
export class AuthguardGuard implements CanActivate {
  constructor(private user: UserService, private router: Router) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Promise<boolean> {
    let promise = new Promise<boolean>((resolve, reject) => {

      this.user.validateUser()
        .then((expiresAt) => {

          if (expiresAt == true) {

            resolve(expiresAt);
          }
          else {

            this.router.navigate(['/login'])
            resolve(expiresAt);
          }

        })
        .catch((err) => {
          reject(false);
        });
    });

    return promise;




  }

}