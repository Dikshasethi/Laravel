import {Action} from '@ngrx/store';

export enum PersonalizationActionTypes {
    GetPersonalizationTableColumnData = "[Personalization] Get Personalization Table Column Data",
    SetPersonalizationTableColumnData = "[Personalization] Set Personalization Table Column Data",
    SetError = "[Personalization] Set Error For Personalization Table Column Data",
    AddPersonalizationTableColumnData = "[Personalization] Add Personalization Table Column Data",
    SetAddedPersonalizationTableColumnData= "[Personalization] Set Added Personalization Table Column Data",
    UpdatePersonalizationTableColumnData= "[Personalization] Update Personalization Table Column Data",
    SetUpdatePersonalizationTableColumnData= "[Personalization] Set Update Personalization Table Column Data",
    DeleteTableColumnPersonalizationData= "[Personalization] Delete Table Column Personalization Table Column Data",
    SetDeletedTableColumnPersonalizationData= "[Personalization] Set Deleted Table Column Personalization Table Column Data",
    ResetPersonalizationTableColumnData= "[Personalization] Reset Personalization Table Column Data",
}

export class GetPersonalizationTableColumnData implements Action{    
    readonly type = PersonalizationActionTypes.GetPersonalizationTableColumnData;
    constructor(public payload: any){
    }
}

export class SetPersonalizationTableColumnData implements Action {
    readonly type = PersonalizationActionTypes.SetPersonalizationTableColumnData;
    constructor(public payload: any){}
}

export class AddPersonalizationTableColumnData implements Action{
    readonly type = PersonalizationActionTypes.AddPersonalizationTableColumnData;
    constructor(public payload: any){}
}

export class SetAddedPersonalizationTableColumnData implements Action{
    readonly type = PersonalizationActionTypes.SetAddedPersonalizationTableColumnData;
    constructor(public payload: any){}
}

export class UpdatePersonalizationTableColumnData implements Action{
    readonly type = PersonalizationActionTypes.UpdatePersonalizationTableColumnData;
    constructor(public payload: any){}
}

export class SetUpdatePersonalizationTableColumnData implements Action{
    readonly type = PersonalizationActionTypes.SetUpdatePersonalizationTableColumnData;
    constructor(public payload: any){}
}

export class SetError implements Action {
    readonly type = PersonalizationActionTypes.SetError;
    constructor(public payload: any) { }
}
export class DeleteTableColumnPersonalizationData implements Action{
    readonly type = PersonalizationActionTypes.DeleteTableColumnPersonalizationData;
    constructor(public payload: any){}
}

export class SetDeletedTableColumnPersonalizationData implements Action {
    readonly type = PersonalizationActionTypes.SetDeletedTableColumnPersonalizationData;
    constructor(public payload: any){}
}

export class ResetPersonalizationTableColumnData implements Action{
    readonly type = PersonalizationActionTypes.ResetPersonalizationTableColumnData;
    constructor(){}
}



export type TableColumnPersonalizationActions =  GetPersonalizationTableColumnData | DeleteTableColumnPersonalizationData | SetDeletedTableColumnPersonalizationData|  SetPersonalizationTableColumnData | AddPersonalizationTableColumnData| SetAddedPersonalizationTableColumnData | UpdatePersonalizationTableColumnData| SetUpdatePersonalizationTableColumnData| ResetPersonalizationTableColumnData|SetError;