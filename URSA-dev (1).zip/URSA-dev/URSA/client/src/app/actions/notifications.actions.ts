import { Action } from '@ngrx/store';

export enum NotificationActionTypes {
    GetUsersNotifications = "[Notification] Get Users Notifications",
    SetUsersNotifications = "[Notification] Set Users Notifications",
    SetUpdateNotificationResponse = "[Notification] Set update notification response",
    UpdateNotification = "[Notification] Update Notification",
    SetRealTimeNotification = "[Notification] Set Real Time Notification",
    SetNotificationReducer = "[Notification] Set Notification Reducer",
}

export class GetUsersNotifications implements Action {
    readonly type = NotificationActionTypes.GetUsersNotifications;
    constructor(public payload: any){ }
}

export class SetUsersNotifications implements Action {
    readonly type = NotificationActionTypes.SetUsersNotifications;
    constructor(public payload: any){ }
}

export class UpdateNotification implements Action {
    readonly type = NotificationActionTypes.UpdateNotification;
    constructor(public payload: any){ }
}

export class SetUpdateNotificationResponse implements Action {
    readonly type = NotificationActionTypes.SetUpdateNotificationResponse;
    constructor(public payload: any){ }
}

export class SetRealTimeNotification implements Action {
    readonly type = NotificationActionTypes.SetRealTimeNotification;
    constructor(public payload: any){ }
}

export class SetNotificationReducer implements Action {
    readonly type = NotificationActionTypes.SetNotificationReducer;
    constructor(public payload: any){ }
}

export type NotificationTypes = GetUsersNotifications | SetUsersNotifications | UpdateNotification
| SetUpdateNotificationResponse | SetRealTimeNotification | SetNotificationReducer;