import {Action} from '@ngrx/store';

export enum SearchActionTypes{
    SetSearchKeyword = '[Search] Set Search Keyword',
    SetDateRange = '[Search] Set Date Range',
    SetSearchKeywordLocalStorage = '[Search] Set Local Storage',
    RegisterSearchCount = '[Search] Register Search Count',
    ResetDateRange = "[Search] Reset Date Range"
}

export class SetSearchKeyword implements Action{
    readonly type = SearchActionTypes.SetSearchKeyword;
    constructor(public payload: string){}
}

export class SetSearchKeywordLocalStorage implements Action{
    readonly type = SearchActionTypes.SetSearchKeywordLocalStorage;
    constructor(public payload: string){}
}

export class SetDateRange implements Action{
    readonly type = SearchActionTypes.SetDateRange;
    constructor(public payload: any){}
}

export class ResetDateRange implements Action{
    readonly type = SearchActionTypes.ResetDateRange;
    constructor(){}
}

export class RegisterSearchCount implements Action{
    readonly type = SearchActionTypes.RegisterSearchCount;
    constructor(){}
}

export type SearchTypes = SetSearchKeyword | SetDateRange | SetSearchKeywordLocalStorage | RegisterSearchCount | ResetDateRange;