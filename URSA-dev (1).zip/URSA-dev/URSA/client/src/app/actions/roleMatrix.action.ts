import { Action } from '@ngrx/store';

export enum RoleMatrixActionTypes {
    SetRole = "[RoleMtrix] Set Role",
    GetRole = "[RoleMtrix] Get Role",
    CreatePermission = "[RoleMatrix] Create New Permission",
    EditPermission = "[RoleMatrix] Edit Permission",
    GetPermission = "[RoleMatrix] Get Permission",
    SetPermission = "[RoleMatrix] Set Permission",
    DeletePermission = "[ROleMatrix] Delete Permission",
    GetPermissionByID = "[RoleMatrix] Get Permission By ID",
    SetPermissionByID = "[RoleMatrix] Set Permission By ID",
    CreateRole = "[RoleMatrix] Create Role",
    EditRole = "[RoleMatrix] Edit Role",
    GetRoleByID = "[RoleMatrix] Get Role By ID",
    SetRoleByID = "[RoleMatrix] Set Role By ID",
    DeleteRole = "[RoleMatrix] Delete Role",
    GetUserList = "[RoleMatrix] Get User List",
    SetUserList = "[RolrMatrix] Set User List",
    ReSetUserList = "[RolrMatrix] ReSet User List",
    GetUserInfo = "[RoleMatrix] Get User Info",
    SetUserInfo = "[RoleMatrix] Set User Info",
    CreateUser = "[RoleMatrix] Create User Role",
    GetUserRoleByID = "[RoleMatrix] Get User Role By ID",
    SetUserRoleByID = "[RoleMatrix] Set User Role By ID",
    DeleteUserRole = "[RoleMatrix] Delete User Role",
    GetRestrictions = "[RoleMatrix] Get Restrictions",
    SetRestrictions = "[RoleMatrix] Set Restrictions",
    CreateRestriction = "[RoleMatrix] Create Restriction",
    EditRestriction = "[RoleMatrix] Edit Restriction",
    DeleteRestriction = "[RoleMatrix] Delete Restriction",
    SetUserListFilters = "[RoleMatrix] Set UserList Filters",
    ReSetUserListFilters = "[RoleMatrix] ReSet UserList Filters",
    CloneUserRole = "[RoleMatrix] Clone UserRole From Existing",
    GetUserRolesValidation = "[RoleMatrix] Get UserRole Validation",
    SetUserRolesValidation = "[RoleMatrix] Set UserRoles Validation",
    setError = "[RoleMatrix] Set Error"
}

export class CreatePermission implements Action {
    readonly type = RoleMatrixActionTypes.CreatePermission;
    constructor(public payload: any) { }
}

export class EditPermission implements Action {
    readonly type = RoleMatrixActionTypes.EditPermission;
    constructor(public payload: any) { }
}

export class SetRole implements Action {
    readonly type = RoleMatrixActionTypes.SetRole;
    constructor(public payload: any) { }
}

export class GetRole implements Action {
    readonly type = RoleMatrixActionTypes.GetRole;
    constructor(public payload: any) { }
}

export class SetPermission implements Action {
    readonly type = RoleMatrixActionTypes.SetPermission;
    constructor(public payload: any) { }
}

export class GetPermission implements Action {
    readonly type = RoleMatrixActionTypes.GetPermission;
    constructor(public payload: any) { }
}

export class DeletePermission implements Action {
    readonly type = RoleMatrixActionTypes.DeletePermission;
    constructor(public payload: any) { }
}

export class GetPermissionByID implements Action {
    readonly type = RoleMatrixActionTypes.GetPermissionByID;
    constructor(public payload: any) { }
}

export class SetPermissionByID implements Action {
    readonly type = RoleMatrixActionTypes.SetPermissionByID;
    constructor(public payload: any) { }
}

export class CreateRole implements Action {
    readonly type = RoleMatrixActionTypes.CreateRole;
    constructor(public payload: any) { }
}

export class EditRole implements Action {
    readonly type = RoleMatrixActionTypes.EditRole;
    constructor(public payload: any) { }
}

export class GetRoleByID implements Action {
    readonly type = RoleMatrixActionTypes.GetRoleByID;
    constructor(public payload: any) { }
}

export class SetRoleByID implements Action {
    readonly type = RoleMatrixActionTypes.SetRoleByID;
    constructor(public payload: any) { }
}

export class DeleteRole implements Action {
    readonly type = RoleMatrixActionTypes.DeleteRole;
    constructor(public payload: any) { }
}

export class GetUserList implements Action {
    readonly type = RoleMatrixActionTypes.GetUserList;
    constructor(public payload: any) { }
}

export class SetUserList implements Action {
    readonly type = RoleMatrixActionTypes.SetUserList;
    constructor(public payload: any) { }
}

export class ReSetUserList implements Action {
    readonly type = RoleMatrixActionTypes.ReSetUserList;
}

export class GetUserInfo implements Action {
    readonly type = RoleMatrixActionTypes.GetUserInfo;
    constructor(public payload: any) { }
}

export class SetUserInfo implements Action {
    readonly type = RoleMatrixActionTypes.SetUserInfo;
    constructor(public payload: any) { }
}

export class CreateUser implements Action {
    readonly type = RoleMatrixActionTypes.CreateUser;
    constructor(public payload: any) { }
}

export class GetUserRoleByID implements Action {
    readonly type = RoleMatrixActionTypes.GetUserRoleByID;
    constructor(public payload: any) { }
}

export class SetUserRoleByID implements Action {
    readonly type = RoleMatrixActionTypes.SetUserRoleByID;
    constructor(public payload: any) { }
}

export class GetRestrictions implements Action {
    readonly type = RoleMatrixActionTypes.GetRestrictions;
    constructor(public payload: any) { }
}

export class SetRestrictions implements Action {
    readonly type = RoleMatrixActionTypes.SetRestrictions;
    constructor(public payload: any) { }
}

export class CreateRestriction implements Action {
    readonly type = RoleMatrixActionTypes.CreateRestriction;
    constructor(public payload: any) { }
}

export class EditRestriction implements Action {
    readonly type = RoleMatrixActionTypes.EditRestriction;
    constructor(public payload: any) { }
}

export class DeleteRestriction implements Action {
    readonly type = RoleMatrixActionTypes.DeleteRestriction;
    constructor(public payload: any) { }
}

export class SetuserListFilters implements Action {
    readonly type = RoleMatrixActionTypes.SetUserListFilters;
    constructor(public payload: any) { }
}
export class ReSetUserListFilters implements Action {
    readonly type = RoleMatrixActionTypes.ReSetUserListFilters;
}

export class CloneUserRole implements Action {
    readonly type = RoleMatrixActionTypes.CloneUserRole;
    constructor(public payload: any) { }
}

export class GetUserRolesValidation implements Action {
    readonly type = RoleMatrixActionTypes.GetUserRolesValidation;
    constructor(public payload: any) { }
}

export class SetUserRolesValidation implements Action {
    readonly type = RoleMatrixActionTypes.SetUserRolesValidation;
    constructor(public payload: any) { }
}

export class setError implements Action {
    readonly type = RoleMatrixActionTypes.setError;
    constructor(public payload: any) { }
}

export type RoleMatrixTypes = SetRole | GetRole | CreatePermission | EditPermission | SetPermission
    | GetPermission | DeletePermission | GetPermissionByID | SetPermissionByID
    | CreateRole | EditRole | GetRoleByID | SetRoleByID | DeleteRole | GetUserList
    | SetUserList | ReSetUserList | GetUserInfo | SetUserInfo | CreateUser | GetUserRoleByID | SetUserRoleByID
    | GetRestrictions | SetRestrictions | CreateRestriction | EditRestriction | DeleteRestriction | SetuserListFilters
    | ReSetUserListFilters | GetUserRolesValidation | SetUserRolesValidation | CloneUserRole | setError;

