import {Action} from '@ngrx/store';

export enum EmoActionTypes{
    GetEmoList = "[EmoList] Get Emo List",
    SetEmoList = "[EmoList] Set Emo List",
    ClearEmoList = "[EmoList] Clear Emo List",
    ResetEmoDetails = "[EmoList] Reset Emo List",
    GenerateEmoData = "[Emo] generate save Emo",
    GetEmoData = "[Emo] Get Emo Data",
    SetEmoData = "[Emo] Set Emo Data",
    ShipEmo = "[Emo] ship Emo",
    updateEmo = "[Emo] update Emo",
    setEmoMode = "[Emo] set Emo Mode",
    setEmoRecord = "[Emo] set Emo Record",
    resetEmoMode = "[Emo] reset Emo Mode",
    resetEmoRecord = "[Emo] reset Emo Record"
}

export class GetEmoList implements Action{
    readonly type = EmoActionTypes.GetEmoList;
    constructor(public payload: any){}
}

export class SetEmoList implements Action{
    readonly type = EmoActionTypes.SetEmoList;
    constructor(public payload: any){}
}

export class ClearEmoList implements Action{
    readonly type = EmoActionTypes.ClearEmoList;
    constructor(){}
}

export class ResetEmoDetails implements Action{
    readonly type = EmoActionTypes.ResetEmoDetails;
    constructor(){}
}


export class GenerateEmoData implements Action {
    readonly type = EmoActionTypes.GenerateEmoData;
    constructor(public payload: any) { }
}
export class GetEmoData implements Action {
    readonly type = EmoActionTypes.GetEmoData;
    constructor(public payload: any) { }
}
export class SetEmoData implements Action {
    readonly type = EmoActionTypes.SetEmoData;
    constructor(public payload: any) { }
}

export class ShipEmo implements Action {
    readonly type = EmoActionTypes.ShipEmo;
    constructor(public payload: any) { }
}

export class updateEmo implements Action {
    readonly type = EmoActionTypes.updateEmo;
    constructor(public payload: any) { }
}

export class setEmoMode implements Action {
    readonly type = EmoActionTypes.setEmoMode;
    constructor(public payload: any) { }
}
export class setEmoRecord implements Action {
    readonly type = EmoActionTypes.setEmoRecord;
    constructor(public payload: any) { }
}
export class resetEmoRecord implements Action {
    readonly type = EmoActionTypes.resetEmoRecord;
}

export class resetEmoMode implements Action {
    readonly type = EmoActionTypes.resetEmoMode;
}


export type EmoTypes = GetEmoList | SetEmoList | ResetEmoDetails | GenerateEmoData | GetEmoData | SetEmoData | ShipEmo | updateEmo |
    setEmoMode | setEmoRecord | resetEmoMode | resetEmoRecord | ClearEmoList;