import {Action} from '@ngrx/store';

export enum UserDetailActionTypes{
    LoginUser = '[UserDetail] User Login',
    SetUserDetail = '[UserDetail] Set User Detail',
    GetUserDetail = '[UserDetail] Get User Detail',
    LogoutUser = '[UserDetail] User Logout',
    LogoutViewChange = '[UserDetail] User Logout view Change',
    ClearUserDetail = "[UserDetail] Clear user Detail",
    UserTimedOut = "[UserDetail] Set user timeout to true",
    RefreshUserSessionSet = "[UserDetail] Get refresh funtcions",
    RefreshUserSessionGet = "[UserDetail] Set Responce from refresh",
    NewSessionDurationGet = "[UserDetail] Get new session expiration",
    NewSessionDurationSet = "[UserDetail] Set new session expiration",
    RefreshElasticSearchTokenGet = "[UserDetail] Get Refreshed Elastic Token",
    RefreshElasticSearchTokenSet = "[UserDetail] Set Refreshed Elastic Token",
    SetUserDetailReducer = "[UserDetail] Set User Detail Reducer"
}
export class LoginUser implements Action{
    readonly type = UserDetailActionTypes.LoginUser;
    constructor(public payload: {}){}
}

export class SetUserDetail implements Action {
    readonly type = UserDetailActionTypes.SetUserDetail;
    constructor(public payload: any){}
}

export class GetUserDetail implements Action {
    readonly type = UserDetailActionTypes.GetUserDetail;
    constructor(public payload: any){}
}

export class LogoutUser implements Action {
    readonly type = UserDetailActionTypes.LogoutUser;
    constructor(public payload: any){}
}

export class LogoutViewChange implements Action {
    readonly type = UserDetailActionTypes.LogoutViewChange;
    constructor(public payload: any){}
}

export class ClearUserDetail implements Action {
    readonly type = UserDetailActionTypes.ClearUserDetail;
    constructor(){}
}

export class UserTimedOut implements Action {
    readonly type = UserDetailActionTypes.UserTimedOut;
    constructor(){}
}

export class RefreshUserSessionGet implements Action {
    readonly type = UserDetailActionTypes.RefreshUserSessionGet;
    constructor(public payload: any){}
}

export class RefreshUserSessionSet implements Action {
    readonly type = UserDetailActionTypes.RefreshUserSessionSet;
    constructor(public payload: any){}
}

export class NewSessionDurationGet implements Action {
    readonly type = UserDetailActionTypes.NewSessionDurationGet;
    constructor(public payload: any){}
}

export class NewSessionDurationSet implements Action {
    readonly type = UserDetailActionTypes.NewSessionDurationSet;
    constructor(public payload: any){}
}

export class RefreshElasticSearchTokenGet implements Action {
    readonly type = UserDetailActionTypes.RefreshElasticSearchTokenGet;
    constructor(public payload: any){}
}

export class RefreshElasticSearchTokenSet implements Action {
    readonly type = UserDetailActionTypes.RefreshElasticSearchTokenSet;
    constructor(public payload: any){}
}

export class SetUserDetailReducer implements Action {
    readonly type = UserDetailActionTypes.SetUserDetailReducer;
    constructor(public payload: any){}
} 

export type UserDetailActions = LoginUser | SetUserDetail | GetUserDetail | LogoutUser | LogoutViewChange | ClearUserDetail | UserTimedOut | RefreshUserSessionSet | RefreshUserSessionGet | NewSessionDurationGet | NewSessionDurationSet |RefreshElasticSearchTokenGet | RefreshElasticSearchTokenSet | SetUserDetailReducer;

