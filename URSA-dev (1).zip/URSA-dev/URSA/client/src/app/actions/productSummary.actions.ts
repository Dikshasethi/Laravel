import {Action} from '@ngrx/store';

export enum ProductSummaryActionTypes {
    GetProductSummary = "[ProductSummary] Get Product Summary",
    SetProductSummary = "[ProductSummary] Set Product Summary",
    DestroyProductSummary = "[ProductSummary] Destroy Product Summary",
    SetSearchCriteria = "[ProductSummary] Set Search Criteria",
    SetSummaryStatusAndIndex = "[ProductSummary] Set Status and Index",
    CacheProductSummaryObject = "[ProductSummary] Cache Product Summary Object",
    SetOnlyProductSummaryObject = "[ProductSummary] Set Only Product Summary Object",
    ClearProductSummaryCache = "[ProductSummary] Clear Product Summary Cache",
    GetSummaryProposalData = "[ProductSummary] Get Summary Proposal Data",
    SetSummaryProposalData = "[ProductSummary] Set Summary Proposal Data",
    SetSummaryScrollTop = "[ProductSummary] Set Summary Scroll Top",
}

export class GetProductSummary implements Action {
    readonly type = ProductSummaryActionTypes.GetProductSummary;
    constructor(public payload: {}){}
}

export class SetProductSummary implements Action {
    readonly type = ProductSummaryActionTypes.SetProductSummary;
    constructor(public payload: {}){}
}

export class DestroyProductSummary implements Action {
    readonly type = ProductSummaryActionTypes.DestroyProductSummary;
    constructor(){}
}

export class SetSearchCriteria implements Action {
    readonly type = ProductSummaryActionTypes.SetSearchCriteria;
    constructor(public payload: {}){}
}

export class SetSummaryStatusAndIndex implements Action {
    readonly type = ProductSummaryActionTypes.SetSummaryStatusAndIndex;
    constructor(public payload: {}){}
}

export class CacheProductSummaryObject implements Action {
    readonly type = ProductSummaryActionTypes.CacheProductSummaryObject;
    constructor(){}
}

export class SetOnlyProductSummaryObject implements Action {
    readonly type = ProductSummaryActionTypes.SetOnlyProductSummaryObject;
    constructor(){}
}

export class ClearProductSummaryCache implements Action {
    readonly type = ProductSummaryActionTypes.ClearProductSummaryCache;
    constructor(){}
}

export class GetSummaryProposalData implements Action{
    readonly type = ProductSummaryActionTypes.GetSummaryProposalData;
    constructor(public payload: {}){}
}

export class SetSummaryProposalData implements Action {
    readonly type = ProductSummaryActionTypes.SetSummaryProposalData;
    constructor(public payload: any){}
}
export class SetSummaryScrollTop implements Action {
    readonly type = ProductSummaryActionTypes.SetSummaryScrollTop;
    constructor(public payload: number){}
}

export type ProductSummaryActions = GetProductSummary | SetProductSummary | DestroyProductSummary | SetSearchCriteria | SetSummaryStatusAndIndex 
| CacheProductSummaryObject | SetOnlyProductSummaryObject | ClearProductSummaryCache | GetSummaryProposalData | SetSummaryProposalData | SetSummaryScrollTop;