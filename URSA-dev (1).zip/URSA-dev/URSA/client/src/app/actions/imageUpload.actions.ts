import {Action} from '@ngrx/store';

export enum ImageUploadActionTypes {
    GetImageFile = "[Image] Get Image File",
    SetImageActiveList = "[Image] Set Active List",
    CancelImageUpload = "[Image] Cancel Image Upload",
    SetImageUploadErrorList = "[Image] Set Image Upload Error List",
    SubmitFileToApi = "[Image] Submit file to Api",
    RemoveUploadError = "[Image] Remove upload error",
    RemoveUploadFromLoadingList = "[Image] Remove upload from loading list",
    SetImageUploadResponse = "[Image] Set image upload response",
    ResetImageReducer = "[Image] Reset Image Reducer",
    CallChangeThumbnail = "[Image] Set New Thumbnail",
    ReturnChangeThumbnail = "[Image] Remove Set New Thumbnail From Load List",

    SendRemoveImage = "[Image] Remove image from main images",
    ResponceRemoveImage = "[Image] Responce from SendRemoveImage"
}

export class GetImageFile implements Action{
    readonly type = ImageUploadActionTypes.GetImageFile;
    constructor(public payload: any){}
}

export class SetImageActiveList implements Action{
    readonly type = ImageUploadActionTypes.SetImageActiveList;
    constructor(public payload: any){}
}

export class CancelImageUpload implements Action{
    readonly type = ImageUploadActionTypes.CancelImageUpload;
    constructor(public payload: any){}
}

export class SetImageUploadErrorList implements Action{
    readonly type = ImageUploadActionTypes.SetImageUploadErrorList;
    constructor(public payload: any){}
}

export class RemoveUploadError implements Action{
    readonly type = ImageUploadActionTypes.RemoveUploadError;
    constructor(public payload: any){}
}

export class RemoveUploadFromLoadingList implements Action{
    readonly type = ImageUploadActionTypes.RemoveUploadFromLoadingList;
    constructor(public payload: any){}
}

export class SubmitFileToApi implements Action{
    readonly type = ImageUploadActionTypes.SubmitFileToApi;
    constructor(public payload: any){}
}

export class SetImageUploadResponse implements Action{
    readonly type = ImageUploadActionTypes.SetImageUploadResponse;
    constructor(public payload: any){}
}

export class ResetImageReducer implements Action{
    readonly type = ImageUploadActionTypes.ResetImageReducer;
    constructor(){}
}

export class CallChangeThumbnail implements Action{
    readonly type = ImageUploadActionTypes.CallChangeThumbnail;
    constructor(public payload: any){}
}

export class ReturnChangeThumbnail implements Action{
    readonly type = ImageUploadActionTypes.ReturnChangeThumbnail;
    constructor(public payload: any){}
}

export class SendRemoveImage implements Action{
    readonly type = ImageUploadActionTypes.SendRemoveImage;
    constructor(public payload: any){}
}

export class ResponceRemoveImage implements Action{
    readonly type = ImageUploadActionTypes.ResponceRemoveImage;
    constructor(public payload: any){}
}

export type ImageUploadActions = ResetImageReducer | GetImageFile | SetImageActiveList | CancelImageUpload | SetImageUploadErrorList | SubmitFileToApi | RemoveUploadError | RemoveUploadFromLoadingList | SetImageUploadResponse | CallChangeThumbnail | ReturnChangeThumbnail | SendRemoveImage | ResponceRemoveImage;