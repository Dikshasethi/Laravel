import {Action} from '@ngrx/store';

export enum WatchListActionTypes {
    GetWatchListData = "[WatchList] Get watchlist Data",
    SetWatchListData = "[WatchList] Set watchlist Data",
    ResetWatchListData = "[WatchList] Reset watchlist Data",
    DeleteFromWatchList = "[WatchList] Delete from watchlist",
    SetError = "[WatchList] Set Error For watchlist",
    SetDeletedWatchListData = "[WatchList] Set Deleted WatchList Data",
    AddToWatchList = "[WatchList] Add watchlist Data",
    EditInWatchList = "[WatchList] Edit watchlist Data",
    SetAddedWatchListData = "[Watchlist] Set Added WatchList Data"
}

export class AddToWatchList implements Action{
    readonly type = WatchListActionTypes.AddToWatchList;
    constructor(public payload: any){}
}

export class EditInWatchList implements Action{
    readonly type = WatchListActionTypes.EditInWatchList;
    constructor(public payload: any){}
}

export class SetAddedWatchListData implements Action{
    readonly type = WatchListActionTypes.SetAddedWatchListData;
    constructor(public payload: any){}
}

export class GetWatchListData implements Action{    
    readonly type = WatchListActionTypes.GetWatchListData;
    constructor(public payload: any){}
}

export class ResetWatchListData implements Action{
    readonly type = WatchListActionTypes.ResetWatchListData;
    constructor(){}
}

export class SetWatchListData implements Action {
    readonly type = WatchListActionTypes.SetWatchListData;
    constructor(public payload: any){}
}

export class DeleteFromWatchList implements Action {
    readonly type = WatchListActionTypes.DeleteFromWatchList;
    constructor(public payload: any){}
}

export class SetDeletedWatchListData implements Action {
    readonly type = WatchListActionTypes.SetDeletedWatchListData;
    constructor(public payload: any){}
}

export class SetError implements Action {
    readonly type = WatchListActionTypes.SetError;
    constructor(public payload: any) { }
}

export type WatchListActions = GetWatchListData| SetWatchListData| DeleteFromWatchList| SetDeletedWatchListData| ResetWatchListData| AddToWatchList| SetAddedWatchListData| EditInWatchList|  SetError;