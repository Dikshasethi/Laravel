import {Action} from '@ngrx/store';

export enum UserActionTypes{
    SetViewPreference = '[User] Set View Preference',
    BlockSearchChangeView = '[User] Block Search On View change',
    RemoveBlockSearch = '[User] Remove Block Search'
}
export class SetViewPreference implements Action{
    readonly type = UserActionTypes.SetViewPreference;
    constructor(public payload: string){}
}

export class BlockSearchChangeView implements Action{
    readonly type = UserActionTypes.BlockSearchChangeView;
    constructor(public payload: string){}
}

export class RemoveBlockSearch implements Action{
    readonly type = UserActionTypes.RemoveBlockSearch;
    constructor(){}
}

export type UserTypes = SetViewPreference | BlockSearchChangeView | RemoveBlockSearch;

