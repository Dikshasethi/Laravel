import {Action} from '@ngrx/store';

export enum ProductActionTypes {
    GetProducts = "[Product] Get Products",
    SetProducts = "[Product] Set Products",
    ResetProductList = "[Product] Reset Product List",
    DestroyDataObject = "[Product] Destroy Data Object",
    CacheProductsObject = "[Product] Cache Products Object",
    SetOnlyProductsObject = "[Product] Set Only Products Object",
    ClearProductsObjectCache = "[Product] Clear Products Object Cache",
    GetProductProposalData = "[Product] Get Product Proposal Data",
    SetProductProposalData = "[Product] Set Product Proposal Data",
    InsertImage = "[Product] Insert Image",
    GetProductCalendar = "[Product] Get Specific Product Calendar Data",
    SetProductCalendar = "[Product] Set Specific Product Calendar Data",
    UpdateThumbnail = "[Product] Update Thumbnail Object In Asset",
    ResetCalendarMap = "[Product] Reset CalendarMapForAsset",
    GetHieararchy = "[Product] Get Hierarachy",
    SetHieararchy = "[Product] Set Hierarachy",
    ClearProductsHierarchyObject = "[Product] Clear Products Hierarchy Object",
    GetAssetHistory = "[Product] Get Asset History",
    SetAssetHistory = "[Product] Set Asset History"
}

export class GetProducts implements Action {
    readonly type = ProductActionTypes.GetProducts;
    constructor(public payload: {}){}
}

export class SetProducts implements Action {
    readonly type = ProductActionTypes.SetProducts;
    constructor(public payload: any){}
}

export class ResetProductList implements Action {
    readonly type = ProductActionTypes.ResetProductList;
    constructor(public payload: any){}
}

export class DestroyDataObject implements Action {
    readonly type = ProductActionTypes.DestroyDataObject;
    constructor(){}
}

export class CacheProductsObject implements Action {
    readonly type = ProductActionTypes.CacheProductsObject;
    constructor(){}
}

export class SetOnlyProductsObject implements Action {
    readonly type = ProductActionTypes.SetOnlyProductsObject;
    constructor(){}
}

export class ClearProductsObjectCache implements Action {
    readonly type = ProductActionTypes.ClearProductsObjectCache;
    constructor(){}
}

export class GetProductProposalData implements Action{
    readonly type = ProductActionTypes.GetProductProposalData;
    constructor(public payload: {}){}
}

export class SetProductProposalData implements Action {
    readonly type = ProductActionTypes.SetProductProposalData;
    constructor(public payload: any){}
}

export class InsertImage implements Action {
    readonly type = ProductActionTypes.InsertImage;
    constructor(public payload: any){}
}

export class UpdateThumbnail implements Action {
    readonly type = ProductActionTypes.UpdateThumbnail;
    constructor(public payload: any){}
}

export class GetProductCalendar implements Action{
    readonly type = ProductActionTypes.GetProductCalendar;
    constructor(public payload: {}){}
}

export class SetProductCalendar implements Action {
    readonly type = ProductActionTypes.SetProductCalendar;
    constructor(public payload: {}){}
}

export class ResetCalendarMap implements Action {
    readonly type = ProductActionTypes.ResetCalendarMap;
    constructor(public payload: any){}
}

export class GetHieararchy implements Action {
    readonly type = ProductActionTypes.GetHieararchy;
    constructor(public payload: any){}
}

export class SetHieararchy implements Action {
    readonly type = ProductActionTypes.SetHieararchy;
    constructor(public payload: {}){}
}

export class ClearProductsHierarchyObject implements Action {
    readonly type = ProductActionTypes.ClearProductsHierarchyObject;
    constructor(){}
}

export class GetAssetHistory implements Action {
    readonly type = ProductActionTypes.GetAssetHistory;
    constructor(public payload: any){}
}

export class SetAssetHistory implements Action {
    readonly type = ProductActionTypes.SetAssetHistory;
    constructor(public payload: {}){}
}

export type ProductActions = GetProducts  | SetProducts | ResetProductList | DestroyDataObject | CacheProductsObject 
| SetOnlyProductsObject | ClearProductsObjectCache | GetProductProposalData | SetProductProposalData | InsertImage
| GetProductCalendar | SetProductCalendar | ResetCalendarMap | UpdateThumbnail | GetHieararchy | SetHieararchy | ClearProductsHierarchyObject | SetAssetHistory | GetAssetHistory;
