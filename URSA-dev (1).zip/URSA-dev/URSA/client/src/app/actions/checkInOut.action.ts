import {Action} from '@ngrx/store';

export enum CheckInOutActionTypes{
    SetCheckInOut = "[CheckInOut] Set Check In Out",
    GetCheckoutDateValidations = "[CheckInOut] Get Checkout Date Validations",
    SetCheckoutDateValidations = "[CheckInOut] Set Checkout Date Validations",
    CheckoutAssets = "[CheckInOut] Checkout Assets",
    SetCheckoutResults = "[CheckInOut] Set Checkout Results",
    CheckinAssets = "[CheckInOut] Checkin Assets",
    SetCheckinResults = "[CheckInOut] Set Checkin Results",
    CancelCheckout = "[CheckInOut] Cancel Checkout",
    CancelHardReservations = "[CheckInOut] Cancel Hard Reservations",
    SetCancelCheckoutResults = "[CheckInOut] Set Cancel Checkout Results",
    SetCancelHardReservationResults = "[CheckInOut] Set Cancel Hard Reservation Results",
    EditCheckout = "[CheckInOut] Edit Checkout",
    SetEditCheckoutResults = "[CheckInOut] Set Edit Checkout Results",
    ResetCheckInOut = "[CheckInOut] Reset CheckInOut",
    SetSorting = "[CheckInOut] Set Sorting",
    ReSetSorting = "[CheckInOut] ReSet Sorting",
    GetEditHardReserve = "[CheckInOut] Get Edit HardReserve",
    SetEditHardReserve = "[CheckInOut] Set Edit HardReserve"
}

export class SetCheckInOutReducer implements Action{
    readonly type = CheckInOutActionTypes.SetCheckInOut;
    constructor(public payload: any){}
}

export class GetCheckoutDateValidations implements Action{
    readonly type = CheckInOutActionTypes.GetCheckoutDateValidations;
    constructor(public payload: any){}
}

export class SetCheckoutDateValidations implements Action{
    readonly type = CheckInOutActionTypes.SetCheckoutDateValidations;
    constructor(public payload: any){}
}

export class CheckoutAssets implements Action{
    readonly type = CheckInOutActionTypes.CheckoutAssets;
    constructor(public payload: any){}
}

export class SetCheckoutResults implements Action{
    readonly type = CheckInOutActionTypes.SetCheckoutResults;
    constructor(public payload: any){}
}

export class CheckinAssets implements Action{
    readonly type = CheckInOutActionTypes.CheckinAssets;
    constructor(public payload: any){}
}

export class SetCheckinResults implements Action{
    readonly type = CheckInOutActionTypes.SetCheckinResults;
    constructor(public payload: any){}
}

export class CancelCheckout implements Action{
    readonly type = CheckInOutActionTypes.CancelCheckout;
    constructor(public payload: any){}
}

export class SetCancelCheckoutResults implements Action{
    readonly type = CheckInOutActionTypes.SetCancelCheckoutResults;
    constructor(public payload: any){}
}

export class CancelHardReservations implements Action{
    readonly type = CheckInOutActionTypes.CancelHardReservations;
    constructor(public payload: any){}
}

export class SetCancelHardReservationResults implements Action{
    readonly type = CheckInOutActionTypes.SetCancelHardReservationResults;
    constructor(public payload: any){}
}

export class EditCheckout implements Action{
    readonly type = CheckInOutActionTypes.EditCheckout;
    constructor(public payload: any){}
}

export class SetEditCheckoutResults implements Action{
    readonly type = CheckInOutActionTypes.SetEditCheckoutResults;
    constructor(public payload: any){}
}

export class ResetCheckInOut implements Action{
    readonly type = CheckInOutActionTypes.ResetCheckInOut;
    constructor(){}
}

export class SetSorting implements Action{
    readonly type = CheckInOutActionTypes.SetSorting;
    constructor(public payload: any){}
}

export class ReSetSorting implements Action{
    readonly type = CheckInOutActionTypes.ReSetSorting;
}

export class GetEditHardReserve implements Action{
    readonly type = CheckInOutActionTypes.GetEditHardReserve;
    constructor(public payload: any){}
    
}

export class SetEditHardReserve implements Action{
    readonly type = CheckInOutActionTypes.SetEditHardReserve;
    constructor(public payload: any){}
}

export type CheckInOutActions = SetCheckInOutReducer | GetCheckoutDateValidations | 
SetCheckoutDateValidations | CheckoutAssets | SetCheckoutResults | CheckinAssets |
SetCheckinResults | CancelCheckout | SetCancelCheckoutResults | CancelHardReservations |
SetCancelHardReservationResults | EditCheckout | SetEditCheckoutResults | ResetCheckInOut |
SetSorting | ReSetSorting | GetEditHardReserve | SetEditHardReserve;