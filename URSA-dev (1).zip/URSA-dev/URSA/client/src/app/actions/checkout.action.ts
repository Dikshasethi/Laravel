import {Action} from '@ngrx/store';

export enum CheckoutDataActionTypes{
    GetReadyToCheckoutData = "[CheckOutPage] Get CheckOut Page Data",
    SetReadyToCheckoutData = "[CheckOutPage] Set CheckOut Page Data",
    RemoveReadyToCheckoutData = "[CheckOutPage] Remove CheckOut Page Data",
    ChangeReadyToCheckoutData = "[CheckOutPage] Change CheckOut Page Data",
    CheckOutAsset = "[CheckOutPage] Check Out Asset ",
    SetCheckedOutData = "[CheckOutPage] Set checked out data ",
    CheckInAsset = "[CheckOutPage] Check In Asset ",
    SetCheckedInData = "[CheckOutPage] Set checked in data ",
    GetReservationTableData = "[CheckOutPage] Get ReCheckout Table Data ",
    SetReservationTableData="[CheckOutPage] Set ReCheckout Table Data",
    ValidateCheckoutAsset="[CheckOutPage] Validate Checkout Asset",
    SetValidatedCheckoutAsset="[CheckOutPage] Set Validated Checkout Asset",
    GetCheckInOutAssets="[CheckOutPage] Get Check In Out Data",
    SetCheckInOutAssets="[CheckOutPage] Set Check In Out Data",
    ReCheckoutAsset="[CheckOutPage] Re checkout asset",
    SetReCheckedoutAsset="[CheckOutPage] Set Rechecked out asset",
    GetProjectStatus= "[CheckOutPage] Get Project Status",
    SetProjectStatus= "[CheckOutPage] Set Project Status",
    CancelCheckedOutAsset = "[CheckOutPage] Cancel Checked Out Asset ",
    EditCheckoutAssets = "[CheckOutPage] Edit Checked Out Asset",
    SeEditCheckOutAssets = "[CheckOutPage] Set Edit Checked Out Asset",
    ClearCheckoutData = "[CheckOutPage] Clear Checked Out Asset",
    ClearCheckInOutAssets = "[CheckOutPage] Clear Check In Out Data"
}

export class GetReadyToCheckoutData implements Action{
    readonly type = CheckoutDataActionTypes.GetReadyToCheckoutData;
    constructor(public payload: {}){}
}

export class SetReadyToCheckoutData implements Action {
    readonly type = CheckoutDataActionTypes.SetReadyToCheckoutData;
    constructor(public payload: any){}
}

export class ChangeReadyToCheckoutData implements Action {
    readonly type = CheckoutDataActionTypes.ChangeReadyToCheckoutData;
    constructor(public payload: any){}
}

export class CheckOutAsset implements Action {
    readonly type = CheckoutDataActionTypes.CheckOutAsset;
    constructor(public payload: any){}
}

export class SetCheckedOutData implements Action {
    readonly type = CheckoutDataActionTypes.SetCheckedOutData;
    constructor(public payload: any){}
}

export class RemoveReadyToCheckoutData implements Action {
    readonly type = CheckoutDataActionTypes.RemoveReadyToCheckoutData;
    constructor(public payload: any){}
}

export class CheckInAsset implements Action {
    readonly type = CheckoutDataActionTypes.CheckInAsset;
    constructor(public payload: any){}
}

export class CancelCheckedOutAsset implements Action {
    readonly type = CheckoutDataActionTypes.CancelCheckedOutAsset;
    constructor(public payload: any){}
}

export class SetCheckedInData implements Action {
    readonly type = CheckoutDataActionTypes.SetCheckedInData;
    constructor(public payload: any){}
}

export class GetReservationTableData implements Action{
    readonly type = CheckoutDataActionTypes.GetReservationTableData;
    constructor(public payload: {}){}
}

export class SetReservationTableData implements Action{
    readonly type = CheckoutDataActionTypes.SetReservationTableData;
    constructor(public payload: {}){}
}

export class ValidateCheckoutAsset implements Action{
    readonly type = CheckoutDataActionTypes.ValidateCheckoutAsset;
    constructor(public payload: {}){}
}

export class SetValidatedCheckoutAsset implements Action{
    readonly type = CheckoutDataActionTypes.SetValidatedCheckoutAsset;
    constructor(public payload: {}){}
}

export class GetCheckInOutAssets implements Action{
    readonly type = CheckoutDataActionTypes.GetCheckInOutAssets;
    constructor(public payload: {}){}
}

export class SetCheckInOutAssets implements Action {
    readonly type = CheckoutDataActionTypes.SetCheckInOutAssets;
    constructor(public payload: any){}
}

export class ClearCheckInOutAssets implements Action {
    readonly type = CheckoutDataActionTypes.ClearCheckInOutAssets;
}
export class ReCheckoutAsset implements Action {
    readonly type = CheckoutDataActionTypes.ReCheckoutAsset;
    constructor(public payload: any){}
}

export class SetReCheckedoutAsset implements Action {
    readonly type = CheckoutDataActionTypes.SetReCheckedoutAsset;
    constructor(public payload: any){}
}

export class SetProjectStatus implements Action {
    readonly type = CheckoutDataActionTypes.SetProjectStatus;
    constructor(public payload: any){}
}

export class GetProjectStatus implements Action{
    readonly type = CheckoutDataActionTypes.GetProjectStatus;
    constructor(public payload: {}){}
}

export class EditCheckoutAsset implements Action{
    readonly type = CheckoutDataActionTypes.EditCheckoutAssets;
    constructor(public payload: any){}
    
}

export class SeEditCheckOutAssets implements Action{
    readonly type = CheckoutDataActionTypes.SeEditCheckOutAssets;
    constructor(public payload: any){}
}

export class ClearCheckoutData implements Action{
 readonly type = CheckoutDataActionTypes.ClearCheckoutData;
}

export type CheckoutDataTypes = GetReadyToCheckoutData | SetReadyToCheckoutData | ChangeReadyToCheckoutData | CheckOutAsset |SetValidatedCheckoutAsset
|SetCheckedOutData|RemoveReadyToCheckoutData|CheckInAsset|SetCheckedInData|GetReservationTableData|SetReservationTableData|ValidateCheckoutAsset|
GetCheckInOutAssets|SetCheckInOutAssets|ReCheckoutAsset|SetReCheckedoutAsset | SetProjectStatus | GetProjectStatus | CancelCheckedOutAsset | 
EditCheckoutAsset | SeEditCheckOutAssets | ClearCheckoutData | ClearCheckInOutAssets;