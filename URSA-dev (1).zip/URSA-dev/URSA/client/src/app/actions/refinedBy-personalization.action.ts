import {Action} from '@ngrx/store';

export enum PersonalizationActionTypes {
    GetPersonalizationRefinedByData = "[Personalization] Get Personalization Refined by Data",
    SetPersonalizationRefinedByData = "[Personalization] Set Personalization Refined by Data",
    SetError = "[Personalization] Set Error For Personalization Refined by Data",
    AddPersonalizationRefinedByData = "[Personalization] Add Personalization Refined by Data",
    SetAddedPersonalizationData= "[Personalization] Set Added Personalization Refined by Data",
    DeleteFromPersonalizationDataList= "[Personalization] Delete From Personalization Refined by Data List",
    SetDeletedPersonalizationData= "[Personalization] Set Deleted Personalization Refined by Data",
    ResetPersonalizationData= "[Personalization] Reset Personalization Refined by Data",
    UpdatePersonalizationRefinedByData= "[Personalization] Update Personalization Refined by Data",
    SetUpdatePersonalizationRefinedByData= "[Personalization] Set Update Personalization Refined by Data",
    TriggerSearchPersonalization= "[Personalization] Trigger Search Personalization Refined by Data",
    NameCheckPersonalization= "[Personalization] Name Check Personalization Refined by Data",
    SetNameCheckPersonalizationRefinedByData= "[Personalization] Set Name Check Personalization Refined by Data",
}

export class GetPersonalizationRefinedByData implements Action{    
    readonly type = PersonalizationActionTypes.GetPersonalizationRefinedByData;
    constructor(public payload: any){
    }
}

export class SetPersonalizationRefinedByData implements Action {
    readonly type = PersonalizationActionTypes.SetPersonalizationRefinedByData;
    constructor(public payload: any){}
}

export class AddPersonalizationRefinedByData implements Action{
    readonly type = PersonalizationActionTypes.AddPersonalizationRefinedByData;
    constructor(public payload: any){}
}

export class SetAddedPersonalizationData implements Action{
    readonly type = PersonalizationActionTypes.SetAddedPersonalizationData;
    constructor(public payload: any){}
}

export class DeleteFromPersonalizationDataList implements Action{
    readonly type = PersonalizationActionTypes.DeleteFromPersonalizationDataList;
    constructor(public payload: any){}
}

export class SetDeletedPersonalizationData implements Action {
    readonly type = PersonalizationActionTypes.SetDeletedPersonalizationData;
    constructor(public payload: any){}
}

export class UpdatePersonalizationRefinedByData implements Action{
    readonly type = PersonalizationActionTypes.UpdatePersonalizationRefinedByData;
    constructor(public payload: any){}
}

export class SetUpdatePersonalizationRefinedByData implements Action{
    readonly type = PersonalizationActionTypes.SetUpdatePersonalizationRefinedByData;
    constructor(public payload: any){}
}

export class SetError implements Action {
    readonly type = PersonalizationActionTypes.SetError;
    constructor(public payload: any) { }
}
export class ResetPersonalizationData implements Action{
    readonly type = PersonalizationActionTypes.ResetPersonalizationData;
    constructor(){}
}
export class TriggerSearchPersonalization implements Action{
    readonly type = PersonalizationActionTypes.TriggerSearchPersonalization;
    constructor(public payload: any){}
}
export class NameCheckPersonalization implements Action{
    readonly type = PersonalizationActionTypes.NameCheckPersonalization;
    constructor(public payload: any){}
}
export class SetNameCheckPersonalizationRefinedByData implements Action{
    readonly type = PersonalizationActionTypes.SetNameCheckPersonalizationRefinedByData;
    constructor(public payload: any){}
}


export type RefinedByPersonalizationActions = GetPersonalizationRefinedByData| SetNameCheckPersonalizationRefinedByData|NameCheckPersonalization| SetPersonalizationRefinedByData| DeleteFromPersonalizationDataList |SetDeletedPersonalizationData| AddPersonalizationRefinedByData| SetAddedPersonalizationData | ResetPersonalizationData| UpdatePersonalizationRefinedByData| SetUpdatePersonalizationRefinedByData| TriggerSearchPersonalization| SetError;