import {Action} from '@ngrx/store';

export enum UtilizationActionType {
    GetUtilization = "[Utilization] Get Utilization",
    SetUtilization = "[Utilization] Set Utilization",
    
}

export class GetUtilization implements Action {
    readonly type = UtilizationActionType.GetUtilization;
    constructor(public payload: {}){}
}

export class SetUtilization implements Action {
    readonly type = UtilizationActionType.SetUtilization;
    constructor(public payload: any){}
}


export type UtilizationType = GetUtilization | SetUtilization ;