import { Action } from '@ngrx/store';

export enum CheckoutDataActionTypes {
    GetCheckoutCheckInData = "[CheckedInAssets] Get CheckOutCheckIn Page Data",
    SetCheckoutCheckInData = "[CheckedInAssets] Set CheckOutCheckIn Page Data",
    ClearCheckedInList = "[CheckedInAssets] Clear checked in list"
}

export class GetCheckoutCheckInData implements Action {
    readonly type = CheckoutDataActionTypes.GetCheckoutCheckInData;
    constructor(public payload: {}) { }
}

export class SetCheckoutCheckInData implements Action {
    readonly type = CheckoutDataActionTypes.SetCheckoutCheckInData;
    constructor(public payload: any) { }
}

export class ClearCheckedInList implements Action {
    readonly type = CheckoutDataActionTypes.ClearCheckedInList;
    constructor() { }
}

export type CheckoutCheckinTypes = GetCheckoutCheckInData | SetCheckoutCheckInData | ClearCheckedInList;