import {Action} from '@ngrx/store';

export enum ServiceRequestDataActionTypes{
    GetRequestType = "[ServiceRequestData] Get Request Type Data",
    GetScopeType = "[ServiceRequestData] Get Scope Type Data",
    GetWorkType = "[ServiceRequestData] Get Work Type Data",
    GetServiceGroup = "[ServiceRequestData] Get Service Group Data",
    SetRequestType = "[ServiceRequestData] Set Request Type Data Data",
    SetScopeType = "[ServiceRequestData] Set Scope Type Data",
    SetWorkType = "[ServiceRequestData] Set Work Type Data",
    SetServiceGroup = "[ServiceRequestData] Set Service Group Data",
    SetError = "[ServiceRequestData] Set Error of Service Group Data",
    ResetScopeType =  "[ServiceRequestData] Resets Scope type Data",
    ResetWorkType =  "[ServiceRequestData] Resets Work type Data",
    ResetServiceGroup =  "[ServiceRequestData] Resets Service Group Data",
    GetTreeNode = "[ServiceRequestData] Get the tree Node Data",
    SetTreeNode = "[ServiceRequestData] Set the tree Node Data",
    ResetTreeNode = "[ServiceRequestData] ReSet the tree Node Data",
    GetServiceCenter = "[ServiceRequestData] Get the service center Data",
    SetServiceCenter = "[ServiceRequestData] Set the service center Data",
    ResetServiceCenter = "[ServiceRequestData] Reset the service center Data",
    GetServiceRequestList = "[GetServiceRequestList] Get Service Request List Data",
    SetServiceRequestList = "[SetServiceRequestList] Set Service Request List Data",
    ResetServiceRequestListData  = "[ResetServiceRequestList] Reset Service Request Data",
    SetSorting = "[ResetServiceRequestList] Set Sorting",
    ReSetSorting = "[ResetServiceRequestList] ReSet Sorting",
    GetServiceRequestData = "[ServiceRequestData] Get Service Request Data",
    SetServiceRequestData = "[ServiceRequestData] Set Service Request Data",
    SetAssetDataInServiceRequest = "[ServiceRequestData] Set Asset Data in Service Request",
    ResetServiceRequest = "[ServiceRequestData] Reset Service Request Data",
    DeleteSelectedAsset = "[ServiceRequestData] Delete Selected Service Request Data",
    SetAdditionalAssetinServiceRequest = "[ServiceRequestData] Sets Additional Assets in Service Request Data",
    CreateServiceRequest = "[ServiceRequestData] Create Assets in Service Request Data",
    DeleteServiceRequest = "[ServiceRequestData] Delete Assets in Service Request Data",
    EditServiceRequest = "[ServiceRequestData] Save Assets in Service Request Data",
    SetCreateServiceRequestData = "[ServiceRequestData] Set create Service Request Data",
    SetDeleteServiceRequestData = "[ServiceRequestData] Set delete Service Request Data",
    ResetServiceRequestError = "[ServiceRequestData] Resets the service request error "
}

export class GetRequestType implements Action{
    readonly type = ServiceRequestDataActionTypes.GetRequestType;
    constructor(){}
}

export class GetScopeType implements Action{
    readonly type = ServiceRequestDataActionTypes.GetScopeType;
    constructor(public payload: any){}
}

export class GetWorkType implements Action{
    readonly type = ServiceRequestDataActionTypes.GetWorkType;
    constructor(public payload: any){}
}

export class GetServiceGroup implements Action{
    readonly type = ServiceRequestDataActionTypes.GetServiceGroup;
    constructor(public payload: any){}
}

export class SetServiceGroup implements Action{
    readonly type = ServiceRequestDataActionTypes.SetServiceGroup;
    constructor(public payload: any){}
}

export class SetWorkType implements Action{
    readonly type = ServiceRequestDataActionTypes.SetWorkType;
    constructor(public payload: any){}
}

export class SetScopeType implements Action{
    readonly type = ServiceRequestDataActionTypes.SetScopeType;
    constructor(public payload: any){}
}

export class SetRequestType implements Action{
    readonly type = ServiceRequestDataActionTypes.SetRequestType;
    constructor(public payload: any){}
}

export class SetError implements Action{
    readonly type = ServiceRequestDataActionTypes.SetError;
    constructor(public payload: any){}
}

export class ResetScopeType implements Action{
    readonly type = ServiceRequestDataActionTypes.ResetScopeType;
    constructor(){}
}

export class ResetWorkType implements Action{
    readonly type = ServiceRequestDataActionTypes.ResetWorkType;
    constructor(){}
}

export class ResetServiceGroup implements Action{
    readonly type = ServiceRequestDataActionTypes.ResetServiceGroup;
    constructor(){}
}

export class GetTreeNode implements Action{
    readonly type = ServiceRequestDataActionTypes.GetTreeNode;
    constructor(public payload: any){}
}

export class SetTreeNode implements Action{
    readonly type = ServiceRequestDataActionTypes.SetTreeNode;
    constructor(public payload: any){}
}

export class ResetTreeNode implements Action{
    readonly type = ServiceRequestDataActionTypes.ResetTreeNode;
    constructor(){}
}

export class GetServiceCenter implements Action{
    readonly type = ServiceRequestDataActionTypes.GetServiceCenter;
    constructor(public payload: any){}
}

export class SetServiceCenter implements Action{
    readonly type = ServiceRequestDataActionTypes.SetServiceCenter;
    constructor(public payload: any){}
}

export class ResetServiceCenter implements Action{
    readonly type = ServiceRequestDataActionTypes.ResetServiceCenter;
    constructor(){}
}

export class GetServiceRequestList implements Action{
    readonly type = ServiceRequestDataActionTypes.GetServiceRequestList;
    constructor(public payload: any){}
}

export class SetServiceRequestList implements Action{
    readonly type = ServiceRequestDataActionTypes.SetServiceRequestList;
    constructor(public payload: any){}
}

export class ResetServiceRequestListData implements Action{
    readonly type = ServiceRequestDataActionTypes.ResetServiceRequestListData;
    constructor(){}
}

export class SetSorting implements Action{
    readonly type = ServiceRequestDataActionTypes.SetSorting;
    constructor(public payload: any){}
}

export class ReSetSorting implements Action{
    readonly type = ServiceRequestDataActionTypes.ReSetSorting;
}

export class GetServiceRequestData implements Action{
    readonly type = ServiceRequestDataActionTypes.GetServiceRequestData;
    constructor(public payload: any){}
}

export class SetServiceRequestData implements Action{
    readonly type = ServiceRequestDataActionTypes.SetServiceRequestData;
    constructor(public payload: any){}
}

export class SetAssetDataInServiceRequest implements Action{
    readonly type = ServiceRequestDataActionTypes.SetAssetDataInServiceRequest;
    constructor(public payload: any){}
}

export class ResetServiceRequest implements Action{
    readonly type = ServiceRequestDataActionTypes.ResetServiceRequest;
    constructor(){}
}

export class DeleteSelectedAsset implements Action{
    readonly type = ServiceRequestDataActionTypes.DeleteSelectedAsset;
    constructor(public payload: any){}
}

export class SetAdditionalAssetinServiceRequest implements Action{
    readonly type = ServiceRequestDataActionTypes.SetAdditionalAssetinServiceRequest;
    constructor(public payload: any){}
}

export class CreateServiceRequest  implements Action {
    readonly type = ServiceRequestDataActionTypes.CreateServiceRequest;
    constructor(public payload: any){}
}

export class EditServiceRequest  implements Action {
    readonly type = ServiceRequestDataActionTypes.EditServiceRequest;
    constructor(public payload: any){}
}

export class DeleteServiceRequest  implements Action {
    readonly type = ServiceRequestDataActionTypes.DeleteServiceRequest;
    constructor(public payload: any){}
}

export class SetCreateServiceRequestData  implements Action {
    readonly type = ServiceRequestDataActionTypes.SetCreateServiceRequestData;
    constructor(public payload: any){}
}

export class SetDeleteServiceRequestData  implements Action {
    readonly type = ServiceRequestDataActionTypes.SetDeleteServiceRequestData;
    constructor(public payload: any){}
}

export class ResetServiceRequestError implements Action{
    readonly type = ServiceRequestDataActionTypes.ResetServiceRequestError;
    constructor(){}
}

export type ServiceRequestDataTypes = GetRequestType | GetScopeType | GetWorkType | GetServiceGroup 
| SetRequestType | SetScopeType | SetWorkType | SetServiceGroup | SetError | ResetScopeType | ResetWorkType |
ResetServiceGroup | GetTreeNode | SetTreeNode | ResetTreeNode | GetServiceCenter | SetServiceCenter | ResetServiceCenter
| GetServiceRequestList | SetServiceRequestList | ResetServiceRequestListData | SetSorting | ReSetSorting | GetServiceRequestData
| SetServiceRequestData | SetAssetDataInServiceRequest | ResetServiceRequest | DeleteSelectedAsset | SetAdditionalAssetinServiceRequest
| CreateServiceRequest | SetCreateServiceRequestData | EditServiceRequest| DeleteServiceRequest | SetDeleteServiceRequestData |
ResetServiceRequestError;
