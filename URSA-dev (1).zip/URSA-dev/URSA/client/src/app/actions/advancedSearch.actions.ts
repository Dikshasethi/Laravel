import {Action} from '@ngrx/store';

export enum AdvancedSearchActionTypes{
    ManageAdvancedSearchDisplay = '[AdvancedSearch] Manage Display',
    HandleInput = "[AdvancedSearch] Handle Input",
    ResetSearch = "[AdvancedSearch] Reset Search",
    SetActiveSearch = "[AdvancedSearch] Set Active Search",
    HandlePillDeletion = "[AdvancedSearch] Handle Pill Deletion"
}

export class ManageAdvancedSearchDisplay implements Action{
    readonly type = AdvancedSearchActionTypes.ManageAdvancedSearchDisplay;
    constructor(public payload: string){}
}

export class HandleInput implements Action{
    readonly type = AdvancedSearchActionTypes.HandleInput;
    constructor(public payload: any){}
}

export class HandlePillDeletion implements Action{
    readonly type = AdvancedSearchActionTypes.HandlePillDeletion;
    constructor(public payload: any){}
}

export class ResetSearch implements Action{
    readonly type = AdvancedSearchActionTypes.ResetSearch;
    constructor(){}
}

export class SetActiveSearch implements Action{
    readonly type = AdvancedSearchActionTypes.SetActiveSearch;
    constructor(public payload: boolean){}
}

export type AdvancedSearchTypes = ManageAdvancedSearchDisplay | HandleInput | ResetSearch | SetActiveSearch | HandlePillDeletion;