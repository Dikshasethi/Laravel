import { Action } from '@ngrx/store';

export enum DashboardActionTypes {
    GetUtilizationChart = "[DashboardMetrics] Get Utilization Chart",
    SetUtilizationChart = "[DashboardMetrics] Set Utilization Chart",
    GetSoftReservationChart = "[DashboardMetrics] Get SoftReservation Chart",
    SetSoftReservationChart = "[DashboardMetrics] Set SoftReservation Chart",
    GetHardReservationChart = "[DashboardMetrics] Get HardReservation Chart",
    SetHardReservationChart = "[DashboardMetrics] Set HardReservation Chart",
    GetShippedChart = "[DashboardMetrics] Get Shipped Chart",
    SetShippedChart = "[DashboardMetrics] Set Shipped Chart",
    GetAssetCount = "[DashboardMetrics] Get AssetCount",
    SetAssetCount = "[DashboardMetrics] Set AssetCount",
    GetPastDueCheckOutCount = "[DashboardMetrics] Get PastDueCheckOutCount",
    SetPastDueCheckOutCount = "[DashboardMetrics] Set PastDueCheckOutCount",
    GetHardReservationCount = "[DashboardMetrics] Get HardreservationCount",
    SetHardReservationCount = "[DashboardMetrics] Set HardreservationCount",
    GetCheckoutCount = "[DashboardMetrics] Get CheckoutCount",
    SetCheckoutCount = "[DashboardMetrics] Set CheckoutCount",
    GetSoftReservationCount = "[DashboardMetrics] Get SoftReservationCount",
    SetSoftReservationCount = "[DashboardMetrics] Set SoftReservationCount",
    SetError = "[Dashboardmetrics] Set Error",
    ResetChartCounts = "[Dashboardmetrics] Reset counts",
    GetCheckoutmetrics = "[DashboardMetrics] Get Checkoutmetrics Chart",
    SetCheckoutmetrics = "[DashboardMetrics] Set Checkoutmetrics Chart",
    Getonhiremetrics= "[DashboardMetrics] Get onhiremetrics Chart",
    Setonhiremetrics= "[DashboardMetrics] Set onhiremetrics Chart",
    Getreceivecount= "[DashboardMetrics] Get receivecount Chart",
    Setreceivecount= "[DashboardMetrics] Set receivecount Chart",
}


export class GetUtilizationChart implements Action {
    readonly type = DashboardActionTypes.GetUtilizationChart;
    constructor(public payload: any) { }
}

export class SetUtilizationChart implements Action {
    readonly type = DashboardActionTypes.SetUtilizationChart;
    constructor(public payload: any) { }
}

export class GetSoftReservationChart implements Action {
    readonly type = DashboardActionTypes.GetSoftReservationChart;
    constructor(public payload: any) { }
}

export class SetSoftReservationChart implements Action {
    readonly type = DashboardActionTypes.SetSoftReservationChart;
    constructor(public payload: any) { }
}

export class GetHardReservationChart implements Action {
    readonly type = DashboardActionTypes.GetHardReservationChart;
    constructor(public payload: any) { }
}

export class SetHardReservationChart implements Action {
    readonly type = DashboardActionTypes.SetHardReservationChart;
    constructor(public payload: any) { }
}

export class GetShippedChart implements Action {
    readonly type = DashboardActionTypes.GetShippedChart;
    constructor(public payload: any) { }
}

export class SetShippedChart implements Action {
    readonly type = DashboardActionTypes.SetShippedChart;
    constructor(public payload: any) { }
}

export class GetAssetCount implements Action {
    readonly type = DashboardActionTypes.GetAssetCount;
    constructor(public payload: any) { }
}

export class SetAssetCount implements Action {
    readonly type = DashboardActionTypes.SetAssetCount;
    constructor(public payload: any) { }
}

export class GetPastDueCheckOutCount implements Action {
    readonly type = DashboardActionTypes.GetPastDueCheckOutCount;
    constructor(public payload: any) { }
}

export class SetPastDueCheckOutCount implements Action {
    readonly type = DashboardActionTypes.SetPastDueCheckOutCount;
    constructor(public payload: any) { }
}

export class GetHardReservationCount implements Action {
    readonly type = DashboardActionTypes.GetHardReservationCount;
    constructor(public payload: any) { }
}

export class SetHardReservationCount implements Action {
    readonly type = DashboardActionTypes.SetHardReservationCount;
    constructor(public payload: any) { }
}

export class GetCheckoutCount implements Action {
    readonly type = DashboardActionTypes.GetCheckoutCount;
    constructor(public payload: any) { }
}

export class SetCheckoutCount implements Action {
    readonly type = DashboardActionTypes.SetCheckoutCount;
    constructor(public payload: any) { }
}

export class GetSoftReservationCount implements Action {
    readonly type = DashboardActionTypes.GetSoftReservationCount;
    constructor(public payload: any) { }
}

export class SetSoftReservationCount implements Action {
    readonly type = DashboardActionTypes.SetSoftReservationCount;
    constructor(public payload: any) { }
}

export class SetError implements Action {
    readonly type = DashboardActionTypes.SetError;
    constructor(public payload: any) { }
}

export class ResetChartCounts implements Action {
    readonly type = DashboardActionTypes.ResetChartCounts;
    constructor(public payload: any) { }
}

export class GetCheckoutmetrics implements Action {
    readonly type = DashboardActionTypes.GetCheckoutmetrics;
    constructor(public payload: any) { }
}

export class SetCheckoutmetrics implements Action {
    readonly type = DashboardActionTypes.SetCheckoutmetrics;
    constructor(public payload: any) { }
}

export class Getonhiremetrics implements Action {
    readonly type = DashboardActionTypes.Getonhiremetrics;
    constructor(public payload: any) { }
}

export class Setonhiremetrics implements Action {
    readonly type = DashboardActionTypes.Setonhiremetrics;
    constructor(public payload: any) { }
}


export class Getreceivecount implements Action {
    readonly type = DashboardActionTypes.Getreceivecount;
    constructor(public payload: any) { }
}

export class Setreceivecount implements Action {
    readonly type = DashboardActionTypes.Setreceivecount;
    constructor(public payload: any) { }
}

export type DashboardTypes = GetUtilizationChart | SetUtilizationChart | GetSoftReservationChart
    | SetSoftReservationChart | GetHardReservationChart | SetHardReservationChart | GetShippedChart
    | SetShippedChart | GetAssetCount | SetAssetCount | GetPastDueCheckOutCount | SetPastDueCheckOutCount
    | GetHardReservationCount | SetHardReservationCount | GetCheckoutCount | SetCheckoutCount | GetSoftReservationCount
    | SetSoftReservationCount | SetError | ResetChartCounts | GetCheckoutmetrics | SetCheckoutmetrics | Setonhiremetrics 
    | Getonhiremetrics | Getreceivecount | Setreceivecount;