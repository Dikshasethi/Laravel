import {Action} from '@ngrx/store';

export enum ProposalDataActionTypes{
    GetProposalData = "[ProposalNewData] Get Proposal Data",
    SetProposalData = "[ProposalNewData] Set Proposal Data",
    SetProductProposalCartData = "[ProposalNewData] Set Product Proposal Cart Data",
    ResetProductProposalCartData = "[ProposalNewData] Reset Product Proposal Cart Data",
    DeleteProposalData = "[ProposalNewData] Delete Proposal Data",
    DeleteProductProposalCartData = "[ProposalNewData] Delete Product Proposal Cart Data",
    SetProposalMode = "[ProposalNewData] Set Proposal Mode",
    ReSetProposalMode = "[ProposalNewData] Reset Proposal Mode",
    SetError = "[ProposalNewData] Set Error of Proposal Page",
    SetAssetDataInProposalDeatil = "[ProposalNewData] Set Asset Detail in Proposal Page",
    SetProposalCartWithProposalMode = "[ProposalNewData] Set product proposal mode in Proposal cart",
    CreateProposal = "[ProposalNewData] Create proposal",
    SetCreatedProposalData = "[ProposalNewData] Set Create proposal",
    EditProposal = "[ProposalNewData] Edit proposal",
    UpdateProposalStatus = "[ProposalNewData] Update the status of proposal",
    ChangeProposalVersion = "[ProposalNewData] Change version of proposal",
    GetProposalVersions = "[ProposalNewData] Get versions of proposal",
    SetProposalVersions = "[ProposalNewData] Set versions of proposal",
    GetCrewRequirementType= "[ProposalNewData] Get the crew requirement details",
    GetCrewPositions="[ProposalNewData] Get the crew positions",
    GetJobTitles = "[ProposalNewData] Get the job title details",
    SetCrewRequirementType="[ProposalNewData] Set the Crew Requirement Types",
    SetCrewPositions= "[ProposalNewData] Set the Crew Positions",
    SetJobTitlesInProposalDetail="[ProposalNewData] Set the Job titles In proposal detail",
    RemoveJobTitlesInProposalDetail="[ProposalNewData] Remove the Job titles in proposal detail",
    CreateCrewDraft = "[ProposalNewData] Creates the crew draft",
    CancelProposal = "[ProposalNewData] Cancels the proposal",
    SetPermanentProjectId = "[ProposalNewData] Sets the permanent project id",
    SetProposalCartData = "[ProposalNewData] Sets the proposal cart data"
}

export class GetProposalData implements Action{
    readonly type = ProposalDataActionTypes.GetProposalData;
    constructor(public payload: {}){}
}

export class SetProposalData implements Action{
    readonly type = ProposalDataActionTypes.SetProposalData;
    constructor(public payload: any){}
}

export class SetProductProposalCartData implements Action{
    readonly type = ProposalDataActionTypes.SetProductProposalCartData;
    constructor(public payload: any){}
}

export class DeleteProposalData implements Action{
    readonly type = ProposalDataActionTypes.DeleteProposalData;
    constructor(public payload: any){}
}

export class DeleteProductProposalCartData implements Action{
    readonly type = ProposalDataActionTypes.DeleteProductProposalCartData;
    constructor(public payload: any){}
}

export class ResetProductProposalCartData implements Action{
    readonly type = ProposalDataActionTypes.ResetProductProposalCartData;
    constructor(){}
}

export class SetProposalMode implements Action {
    readonly type = ProposalDataActionTypes.SetProposalMode;
    constructor(public payload: any) { }
}

export class ReSetProposalMode implements Action {
    readonly type = ProposalDataActionTypes.ReSetProposalMode;
    constructor() { }
}

export class SetError implements Action {
    readonly type = ProposalDataActionTypes.SetError;
    constructor(public payload: any) { }
}

export class SetAssetDataInProposalDeatil implements Action {
    readonly type = ProposalDataActionTypes.SetAssetDataInProposalDeatil;
    constructor(public payload: any) { }
}

export class SetProposalCartWithProposalMode implements Action {
    readonly type = ProposalDataActionTypes.SetProposalCartWithProposalMode;
    constructor(public payload: any) { }
}

export class CreateProposal implements Action {
    readonly type = ProposalDataActionTypes.CreateProposal;
    constructor(public payload: any) { }
}

export class SetCreatedProposalData implements Action {
    readonly type = ProposalDataActionTypes.SetCreatedProposalData;
    constructor(public payload: any) { }
}

export class EditProposal implements Action {
    readonly type = ProposalDataActionTypes.EditProposal;
    constructor(public payload: any) { }
}

export class UpdateProposalStatus implements Action {
    readonly type = ProposalDataActionTypes.UpdateProposalStatus;
    constructor(public payload: any) { }
}

export class GetCrewRequirementType implements Action {
    readonly type = ProposalDataActionTypes.GetCrewRequirementType;
    constructor() { }
}

export class GetCrewPositions implements Action {
    readonly type = ProposalDataActionTypes.GetCrewPositions;
    constructor() { }
}

export class GetJobTitles implements Action {
    readonly type = ProposalDataActionTypes.GetJobTitles;
    constructor(public payload: any) { }
}

export class SetCrewRequirementType implements Action {
    readonly type = ProposalDataActionTypes.SetCrewRequirementType;
    constructor(public payload: any) { }
}

export class SetCrewPositions implements Action {
    readonly type = ProposalDataActionTypes.SetCrewPositions;
    constructor(public payload: any) { }
}

export class SetJobTitlesInProposalDetail implements Action {
    readonly type = ProposalDataActionTypes.SetJobTitlesInProposalDetail;
    constructor(public payload: any) { }
}

export class RemoveJobTitlesInProposalDetail implements Action {
    readonly type = ProposalDataActionTypes.RemoveJobTitlesInProposalDetail;
    constructor(public payload: any) { }
}

export class CreateCrewDraft implements Action {
    readonly type = ProposalDataActionTypes.CreateCrewDraft;
    constructor(public payload: any) { }
}

export class GetProposalVersions implements Action {
    readonly type = ProposalDataActionTypes.GetProposalVersions;
    constructor(public payload: any) { }
}

export class SetProposalVersions implements Action {
    readonly type = ProposalDataActionTypes.SetProposalVersions;
    constructor(public payload: any) { }
}

export class ChangeProposalVersion implements Action {
    readonly type = ProposalDataActionTypes.ChangeProposalVersion;
    constructor(public payload: any) { }
}


export class CancelProposal implements Action {
    readonly type = ProposalDataActionTypes.CancelProposal;
    constructor(public payload: any) { }
}

export class SetPermanentProjectId implements Action {
    readonly type = ProposalDataActionTypes.SetPermanentProjectId;
    constructor(public payload: any) { }
}

export class SetProposalCartData implements Action {
    readonly type = ProposalDataActionTypes.SetProposalCartData;
    constructor() { }
}

export type ProposalDataTypes = GetProposalData | SetProposalData | SetProductProposalCartData |
ResetProductProposalCartData | DeleteProposalData  | DeleteProductProposalCartData | 
SetError | SetProposalMode | ReSetProposalMode | SetAssetDataInProposalDeatil | 
SetProposalCartWithProposalMode | CreateProposal | SetCreatedProposalData | EditProposal |
UpdateProposalStatus | GetCrewRequirementType | GetCrewPositions | GetJobTitles | SetCrewRequirementType |
SetCrewPositions | SetJobTitlesInProposalDetail | RemoveJobTitlesInProposalDetail | CreateCrewDraft |
GetProposalVersions | SetProposalVersions | ChangeProposalVersion | CancelProposal | SetPermanentProjectId |
SetProposalCartData;