import {Action} from '@ngrx/store';

export enum CalloutActionTypes{
    GetCalloutList = "[CalloutList] Get Callout List",
    SetCalloutList = "[CalloutList] Set Callout List",
    GetCalloutDetails = "[CalloutList] Get Callout Details",
    SetCalloutDetails = "[CalloutList] Set Callout Details",
    ResetCalloutDetails = "[CalloutList] Reset Callout Details",
    DeleteCallout = "[CalloutList] Delete Callout",
    SetDeleteCalloutResponse = "[CalloutList] Set Delete Callout Response"
}

export class GetCalloutList implements Action{
    readonly type = CalloutActionTypes.GetCalloutList;
    constructor(public payload: any){}
}

export class SetCalloutList implements Action{
    readonly type = CalloutActionTypes.SetCalloutList;
    constructor(public payload: any){}
}

export class GetCalloutDetails implements Action{
    readonly type = CalloutActionTypes.GetCalloutDetails;
    constructor(public payload: any){}
}

export class SetCalloutDetails implements Action{
    readonly type = CalloutActionTypes.SetCalloutDetails;
    constructor(public payload: any){}
}

export class ResetCalloutDetails implements Action{
    readonly type = CalloutActionTypes.ResetCalloutDetails;
    constructor(){}
}

export class DeleteCallout implements Action{
    readonly type = CalloutActionTypes.DeleteCallout;
    constructor(public payload: any){}
}

export class SetDeleteCalloutResponse implements Action{
    readonly type = CalloutActionTypes.SetDeleteCalloutResponse;
    constructor(public payload: any){}
}

export type CalloutTypes = GetCalloutList | SetCalloutList |
GetCalloutDetails | SetCalloutDetails | ResetCalloutDetails | 
DeleteCallout | SetDeleteCalloutResponse;