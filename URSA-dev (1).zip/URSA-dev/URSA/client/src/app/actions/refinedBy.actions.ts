import {Action} from '@ngrx/store';

export enum RefinedByActionTypes{
    SetFilters = '[RefinedBy] Set Filters',
    ResetFilters = '[RefinedBy] Reset Filters',
    SetRefinedByField = "[RefinedBy] Set Refined By Field"
}

export class SetFilters implements Action{
    readonly type = RefinedByActionTypes.SetFilters;
    constructor(public payload: any){}
}

export class ResetFilters implements Action{
    readonly type = RefinedByActionTypes.ResetFilters;
    constructor(){}
}

export class SetRefinedByField implements Action{
    readonly type = RefinedByActionTypes.SetRefinedByField;
    constructor(public payload: any){}
}

export type RefinedByTypes = SetFilters | ResetFilters | SetRefinedByField;
