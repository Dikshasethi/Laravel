import { Action } from '@ngrx/store';

export enum DownloadActionTypes {
    GetDownloadData = "[Download] Get Download Data",
    SetDownloadData = "[Downlaod] Set Download Data",
    ClearDownloadData = "[Download] Clear Download Data"
}

export class GetDownloadData implements Action {
    readonly type = DownloadActionTypes.GetDownloadData;
    constructor(public payload: {}) { }
}

export class SetDownloadData implements Action {
    readonly type = DownloadActionTypes.SetDownloadData;
    constructor(public payload: {}) { }
}

export class ClearDownloadData implements Action {
    readonly type = DownloadActionTypes.ClearDownloadData;
}

export type DownloadTypes = GetDownloadData | SetDownloadData | ClearDownloadData;