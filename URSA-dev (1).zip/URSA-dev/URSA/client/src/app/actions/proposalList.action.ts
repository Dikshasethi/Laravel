import {Action} from '@ngrx/store';

export enum ProposalListDataActionTypes{
    GetProposalListData = "[ProposalList] Get Proposal List Data",
    SetProposalListData = "[ProposalList] Set Proposal List Data",
    ClearProposalListData = "[ProposalList] Clear Proposal List Data",
    SetError = "[ProposalList] Set Error of Proposal List Data",
}


export class GetProposalListData implements Action{
    readonly type = ProposalListDataActionTypes.GetProposalListData;
    constructor(public payload: any){
    }
}

export class SetProposalListData implements Action{
    readonly type = ProposalListDataActionTypes.SetProposalListData;
    constructor(public payload: any){}
}

export class SetError implements Action{
    readonly type = ProposalListDataActionTypes.SetError;
    constructor(public payload: any){}
}

export class ClearProposalListData implements Action{
    readonly type = ProposalListDataActionTypes.ClearProposalListData;
}

export type ProposalPageDataTypes = GetProposalListData | SetProposalListData | 
ClearProposalListData | SetError;