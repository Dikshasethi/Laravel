import {Action} from '@ngrx/store';

export enum AutocompleteActionTypes{
    GetAutocompleteList = "[Autocomplete] Get Search Box Autocomplete List",
    SetAutocompleteList = "[Autocomplete] Set Search Box Autocomplete List",
    GetCheckoutAutocomplete  = "[Autocomplete] Get Check Out Autocomplete List",
    SetCheckoutAutocomplete  = "[Autocomplete] Set Check Out Autocomplete List",
    GetProjectData  = "[Autocomplete] Get Re Check Out Project Autocomplete List",
    SetReCheckoutAutocomplete  = "[Autocomplete] Set Re Check Out Autocomplete List",
    GetCustodianAutocompleteList = "[Autocomplete] Custodian Autocomplete List",
    GetPcBusinessUnitAutocompleteList = "[Autocomplete] Get PC Business Unit Autocomplete List",
    DestroyAutocompleteList = "[Autocomplete] Destroy Autocomplete List",
    GetLocationAreasCheck  = "[Autocomplete] Get Check If Location Has One Or More Areas",
    SetLocationAreasCheck  = "[Autocomplete] Set Check If Location Has One Or More Areas",

    GetCountriesAutoComplete  = "[Autocomplete] Get Countries Autocomplete",
    SetCountriesAutoComplete  = "[Autocomplete] Set Countries Autocomplete",
    GetUOMAutoComplete =  "[Autocomplete] Get UOM Autocomplete",
    SetUOMAutoComplete = "[Autocomplete] Set UOM Autocomplete",
    GetPermissionAutoComplete = "[Autocomplete] Get Permission AutoComplete",
    SetPermissionAutoComplete = "[Autocomplete] Set Permission AutoComplete",
    ReSetPermissionAutoComplete = "[Autocomplete] ReSet Permission AutoComplete",
    GetRestrictionData = "[AutoComplete] Get Restriction Data",
    SetRestrictionData = "[AutoComplete] Set Restriciton Data",
    ReSetRestrictionData = "[AutoComplete] ReSet Restriciton Data",
    GetCrmData = "[AutoComplete] Get Crm Data",
    GetBillingGroupData = "[AutoComplete] Get Billing Group Data",
    GetBillingBusinessUnitData = "[AutoComplete] Get Billing Business unit Data",
    SetCrmData = "[AutoComplete] Set Crm Data",
    SetBillingGroupData = "[AutoComplete] Set Billing Group Data",
    SetBillingBusinessUnitData = "[AutoComplete] Set Billing Business Unit Data",
    GetCrewPositions = "[AutoComplete] Get Crew Positions Data",
    SetCrewPositions = "[AutoComplete] Set Crew Positions Data",
    GetServiceLineData = "[AutoComplete] Get Service Line Data", 
    SetServiceLineData = "[AutoComplete] Set Service Line Data", 
    GetScopeOfWorkData = "[AutoComplete] Get Scope Of Work Data",
    SetScopeOfWorkData = "[AutoComplete] Set Scope Of Work Data",
    GetResponsibilityCodeData = "[AutoComplete] Get responsibility code Data",
    SetResponsibilityCodeData = "[AutoComplete] Set responsibility code Data",
    GetBusinessUnitMasterData = "[AutoComplete] Get Business unit master Data",
    SetBusinessUnitMasterData = "[AutoComplete] Set Business unit master Data",
    GetCustomersData = "[AutoComplete] Get Customer Data",
    SetCustomersData = "[AutoComplete] Set Customer Data",
    SetAutoCompleteDisplayKey =  "[AutoComplete] Set Autocomplete Display key Data",

}
export class GetAutocompleteList implements Action {
    readonly type = AutocompleteActionTypes.GetAutocompleteList;
    constructor(public payload: any){}
}

export class SetAutocompleteList implements Action {
    readonly type = AutocompleteActionTypes.SetAutocompleteList;
    constructor(public payload: any){}
}

export class GetProjectData implements Action {
    readonly type = AutocompleteActionTypes.GetProjectData;
    constructor(public payload: any){}
}

export class SetReCheckoutAutocomplete implements Action {
    readonly type = AutocompleteActionTypes.SetReCheckoutAutocomplete;
    constructor(public payload: any){}
}

export class SetCheckoutAutocomplete implements Action {
    readonly type = AutocompleteActionTypes.SetCheckoutAutocomplete;
    constructor(public payload: any){}
}

export class GetCheckoutAutocomplete implements Action {
    readonly type = AutocompleteActionTypes.GetCheckoutAutocomplete;
    constructor(public payload: any){}
}

export class GetCustodianAutocompleteList implements Action {
    readonly type = AutocompleteActionTypes.GetCustodianAutocompleteList;
    constructor(public payload: any){}
}

export class GetPcBusinessUnitAutocompleteList implements Action {
    readonly type = AutocompleteActionTypes.GetPcBusinessUnitAutocompleteList;
    constructor(public payload: any){}
}

export class DestroyAutocompleteList implements Action {
    readonly type = AutocompleteActionTypes.DestroyAutocompleteList;
    constructor(){}
}
export class GetLocationAreasCheck implements Action {
    readonly type = AutocompleteActionTypes.GetLocationAreasCheck;
    constructor(public payload: any){}
}
export class SetLocationAreasCheck  implements Action {
    readonly type = AutocompleteActionTypes.SetLocationAreasCheck;
    constructor(public payload: any){}
}
export class GetCountriesAutoComplete implements Action {
    readonly type = AutocompleteActionTypes.GetCountriesAutoComplete;
    constructor(public payload: any){}
}
export class SetCountriesAutoComplete implements Action {
    readonly type = AutocompleteActionTypes.SetCountriesAutoComplete;
    constructor(public payload: any){}
}
export class GetUOMAutoComplete implements Action {
    readonly type = AutocompleteActionTypes.GetUOMAutoComplete;
    constructor(public payload: any){}
}
export class SetUOMAutoComplete implements Action {
    readonly type = AutocompleteActionTypes.SetUOMAutoComplete;
    constructor(public payload: any){}
}
export class GetPermissionAutoComplete implements Action {
    readonly type = AutocompleteActionTypes.GetPermissionAutoComplete;
    constructor(public payload: any) { }
}
export class SetPermissionAutoComplete implements Action {
    readonly type = AutocompleteActionTypes.SetPermissionAutoComplete;
    constructor(public payload: any) { }
}
export class ReSetPermissionAutoComplete implements Action {
    readonly type = AutocompleteActionTypes.ReSetPermissionAutoComplete;
}
export class GetRestrictionData implements Action {
    readonly type = AutocompleteActionTypes.GetRestrictionData;
    constructor(public payload: any) { }
}
export class SetRestrictionData implements Action {
    readonly type = AutocompleteActionTypes.SetRestrictionData;
    constructor(public payload: any) { }
}
export class ReSetRestrictionData implements Action {
    readonly type = AutocompleteActionTypes.ReSetRestrictionData;
}

export class GetCrmData implements Action {
    readonly type = AutocompleteActionTypes.GetCrmData;
    constructor(public payload: any) { }
}

export class SetCrmData implements Action {
    readonly type = AutocompleteActionTypes.SetCrmData;
    constructor(public payload: any) { }
}

export class GetBillingGroupData implements Action {
    readonly type = AutocompleteActionTypes.GetBillingGroupData;
    constructor(public payload: any) { }
}

export class SetBillingGroupData implements Action {
    readonly type = AutocompleteActionTypes.SetBillingGroupData;
    constructor(public payload: any) { }
}

export class GetBillingBusinessUnitData implements Action {
    readonly type = AutocompleteActionTypes.GetBillingBusinessUnitData;
    constructor(public payload: any) { }
}

export class SetBillingBusinessUnitData implements Action {
    readonly type = AutocompleteActionTypes.SetBillingBusinessUnitData;
    constructor(public payload: any) { }
}

export class GetBusinessUnitMasterData implements Action {
    readonly type = AutocompleteActionTypes.GetBusinessUnitMasterData;
    constructor(public payload: any) { }
}

export class SetBusinessUnitMasterData implements Action {
    readonly type = AutocompleteActionTypes.SetBusinessUnitMasterData;
    constructor(public payload: any) { }
}

export class GetCrewPositions implements Action {
    readonly type = AutocompleteActionTypes.GetCrewPositions;
    constructor(public payload: any) { }
}

export class SetCrewPositions implements Action {
    readonly type = AutocompleteActionTypes.SetCrewPositions;
    constructor(public payload: any) { }
}

export class GetServiceLineData implements Action {
    readonly type = AutocompleteActionTypes.GetServiceLineData;
    constructor(public payload: any) { }
}

export class SetServiceLineData implements Action {
    readonly type = AutocompleteActionTypes.SetServiceLineData;
    constructor(public payload: any) { }
}

export class GetScopeOfWorkData implements Action {
    readonly type = AutocompleteActionTypes.GetScopeOfWorkData;
    constructor(public payload: any) { }
}

export class SetScopeOfWorkData implements Action {
    readonly type = AutocompleteActionTypes.SetScopeOfWorkData;
    constructor(public payload: any) { }
}

export class GetResponsibilityCodeData implements Action {
    readonly type = AutocompleteActionTypes.GetResponsibilityCodeData;
    constructor(public payload: any) { }
}

export class SetResponsibilityCodeData implements Action {
    readonly type = AutocompleteActionTypes.SetResponsibilityCodeData;
    constructor(public payload: any) { }
}

export class GetCustomersData implements Action {
    readonly type = AutocompleteActionTypes.GetCustomersData;
    constructor(public payload: any) { }
}

export class SetCustomersData implements Action {
    readonly type = AutocompleteActionTypes.SetCustomersData;
    constructor(public payload: any) { }
}

export class SetAutoCompleteDisplayKey implements Action {
    readonly type = AutocompleteActionTypes.SetAutoCompleteDisplayKey;
    constructor(public payload: any) { }
}

export type AutocompleteTypes = GetAutocompleteList | SetAutocompleteList | DestroyAutocompleteList |GetCheckoutAutocomplete| SetCheckoutAutocomplete|
GetProjectData|SetReCheckoutAutocomplete|GetCustodianAutocompleteList|GetPcBusinessUnitAutocompleteList | GetLocationAreasCheck | SetLocationAreasCheck|
GetCountriesAutoComplete | SetCountriesAutoComplete | GetUOMAutoComplete | SetUOMAutoComplete | GetPermissionAutoComplete
| SetPermissionAutoComplete | ReSetPermissionAutoComplete |GetRestrictionData | SetRestrictionData | ReSetRestrictionData 
| GetBillingGroupData | GetCrmData | GetBillingBusinessUnitData | SetCrmData | SetBillingGroupData |  SetBillingBusinessUnitData |
GetCrewPositions | SetCrewPositions | GetServiceLineData | SetServiceLineData | GetScopeOfWorkData | SetScopeOfWorkData | 
GetResponsibilityCodeData | SetResponsibilityCodeData | GetBusinessUnitMasterData | SetBusinessUnitMasterData | GetCustomersData | SetCustomersData |
SetAutoCompleteDisplayKey;