import { Action } from '@ngrx/store';

export enum ReceivingActionTypes {
    CreateReceivingData = "[Receiving] Create Receiving Data",
    GetReceivingData = "[Receiving] Get Receiving Data",
    SetReecivingData = "[Receiving] Set Receiving Data",
    ResetReceivingList = "[Receiving] Reset Receiving List",
    UpdateReceivingData = "[Receiving] Update Receiving Data",
    Received = "[Receiving] Received Data",
    SetReceivingMode = "[Receiving] Set Receiving Mode",
    ResetReceivingMode = "[Receiving] Reset Receiving Mode",
    SetReceivingRecord = "[Receiving] Set Receiving Record",
    ResetReceivingRecord = "[Receiving] Reset Receiving Record",
    GetReceivingList = "[Receiving] Get Receiving List",
    SetReceivingList = "[Receiving] Set Receiving List"
}

export class CreateReceivingData implements Action {
    readonly type = ReceivingActionTypes.CreateReceivingData;
    constructor(public payload: any) { }
}

export class GetReceivingData implements Action {
    readonly type = ReceivingActionTypes.GetReceivingData;
    constructor(public payload: any) { }
}

export class SetReecivingData implements Action {
    readonly type = ReceivingActionTypes.SetReecivingData;
    constructor(public payload: any) { }
}

export class ResetReceivingList implements Action {
    readonly type = ReceivingActionTypes.ResetReceivingList;
    constructor() { }
}

export class UpdateReceivingData implements Action {
    readonly type = ReceivingActionTypes.UpdateReceivingData;
    constructor(public payload: any) { }
}

export class Received implements Action {
    readonly type = ReceivingActionTypes.Received;
    constructor(public payload: any) { }
}

export class SetReceivingRecord implements Action {
    readonly type = ReceivingActionTypes.SetReceivingRecord;
    constructor(public payload: any) { }
}

export class ResetReceivingRecord implements Action {
    readonly type = ReceivingActionTypes.ResetReceivingRecord;
}

export class SetReceivingMode implements Action {
    readonly type = ReceivingActionTypes.SetReceivingMode;
    constructor(public payload: any) { }
}

export class ResetReceivingMode implements Action {
    readonly type = ReceivingActionTypes.ResetReceivingMode;
}

export class GetReceivingList implements Action{
    readonly type = ReceivingActionTypes.GetReceivingList;
    constructor(public payload: any){}
}

export class SetReceivingList implements Action{
    readonly type = ReceivingActionTypes.SetReceivingList;
    constructor(public payload: any){}
}
export type ReceivingTypes = CreateReceivingData | ResetReceivingMode | GetReceivingData | SetReecivingData |
UpdateReceivingData | Received | SetReceivingRecord | ResetReceivingRecord | SetReceivingMode | ResetReceivingMode |
GetReceivingList | SetReceivingList | ResetReceivingList;

