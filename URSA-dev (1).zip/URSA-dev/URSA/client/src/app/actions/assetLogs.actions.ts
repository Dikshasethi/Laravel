import {Action} from '@ngrx/store';

export enum AssetLogActionTypes{
    GetAssetLogs = "[AssetLogs] Get AssetLog List",
    SetAssetLogs = "[AssetLogs] Set AssetLog List",
    ResetLogReducer = "[AssetLogs] Reset AssetLog Reducer",
    GetAssetIdBusinessUnit = "[AssetLogs] Get Assetid and Businessunit",
    SetAssetIdBusinessUnit = "[AssetLogs] Set Assetid and Businessunit"
}

export class GetAssetLogs implements Action{
    readonly type = AssetLogActionTypes.GetAssetLogs;
    constructor(public payload: any){}
}

export class SetAssetLogs implements Action{
    readonly type = AssetLogActionTypes.SetAssetLogs;
    constructor(public payload: any){}
}

export class SetAssetIdBusinessUnit implements Action{
    readonly type = AssetLogActionTypes.SetAssetIdBusinessUnit;
    constructor(public payload: any){}
}

export class ResetLogReducer implements Action{
    readonly type = AssetLogActionTypes.ResetLogReducer;
    constructor(){}
}

export type AssetLogTypes = GetAssetLogs | SetAssetLogs | ResetLogReducer | SetAssetIdBusinessUnit;