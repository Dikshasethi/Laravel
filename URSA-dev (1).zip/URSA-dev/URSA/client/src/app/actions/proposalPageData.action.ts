import {Action} from '@ngrx/store';

export enum ProposalPageDataActionTypes{
    GetProposalPageData = "[ProposalPage] Get Proposal Page Data",
    SetProposalPageData = "[ProposalPage] Set Proposal Page Data",
    SetHardReserveMode = "[ProposalPage] Set Hard Reserve Mode",
    ResetHardReserveMode = "[ProposalPage] Reset Hard Reserve Mode",
    SetHardReserveCart = "[ProposalPage] Set Hard Reserve Cart",
    ResetCart = "[ProposalPage] Reset Hard Reserve Cart",
    CreateReservation = "[ProposalPage] Create HardReservation",
    HardReservationResponse = "[ProposalPage] Hard Reservation Response",
    ResetProposalPageData = "[ProposalPage] Reset Proposal Page Data",
    CancelReservation = "[ProposalPage] Cancel Hard Reservation",
    GetProjectAutoComplete = "[ProposalPage] Get Project Autocomplete",
    SetProjectAutoComplete = "[ProposalPage] Set project Autocomplete",
    ValidateHardReserveAssetDate = "[ProposalPage] Validate Hard Reserve Asset Date",
    SetValidateHardReserveAssetDate = "[ProposalPage] Set Validated Hard Reserve Asset Date",
}

export class GetProposalPageData implements Action{
    readonly type = ProposalPageDataActionTypes.GetProposalPageData;
    constructor(public payload: {}){}
}

export class SetProposalPageData implements Action{
    readonly type = ProposalPageDataActionTypes.SetProposalPageData;
    constructor(public payload: any){}
}

export class SetHardReserveMode implements Action{
    readonly type = ProposalPageDataActionTypes.SetHardReserveMode;
    constructor(public payload: any){}
}

export class ResetHardReserveMode implements Action{
    readonly type = ProposalPageDataActionTypes.ResetHardReserveMode;
    constructor(public payload: any){}
}

export class CreateReservation implements Action{
    readonly type = ProposalPageDataActionTypes.CreateReservation;
    constructor(public payload: any){}
}

export class CancelReservation implements Action{
    readonly type = ProposalPageDataActionTypes.CancelReservation;
    constructor(public payload: any){}
}

export class HardReservationResponse implements Action{
    readonly type = ProposalPageDataActionTypes.HardReservationResponse;
    constructor(public payload: any){}
}

export class SetHardReserveCart implements Action{
    readonly type = ProposalPageDataActionTypes.SetHardReserveCart;
    constructor(public payload: any){}
}

export class ResetCart implements Action{
    readonly type = ProposalPageDataActionTypes.ResetCart;
    constructor(){}
}

export class ResetProposalPageData implements Action{
    readonly type = ProposalPageDataActionTypes.ResetProposalPageData;
    constructor(){}
}

export class GetProjectAutoComplete implements Action{
    readonly type = ProposalPageDataActionTypes.GetProjectAutoComplete;
    constructor(public payload: any){}
}

export class SetProjectAutoComplete implements Action{
    readonly type = ProposalPageDataActionTypes.SetProjectAutoComplete;
    constructor(public payload: any){}
}

export class ValidateHardReserveAssetDate implements Action{
    readonly type = ProposalPageDataActionTypes.ValidateHardReserveAssetDate;
    constructor(public payload: any){}
}

export class SetValidateHardReserveAssetDate implements Action{
    readonly type = ProposalPageDataActionTypes.SetValidateHardReserveAssetDate;
    constructor(public payload: any){}
}



export type ProposalPageDataTypes = GetProposalPageData | SetProposalPageData | 
SetHardReserveMode | SetHardReserveCart | ResetProposalPageData |
ResetCart | ResetHardReserveMode | CreateReservation | HardReservationResponse
| CancelReservation | GetProjectAutoComplete | SetProjectAutoComplete| ValidateHardReserveAssetDate|
SetValidateHardReserveAssetDate;