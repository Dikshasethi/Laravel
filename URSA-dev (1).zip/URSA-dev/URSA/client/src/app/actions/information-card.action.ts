import { Action } from '@ngrx/store';

export enum InformationCardActionTypes {
    GetEmoDetails = "[EmoDetail] Get EmoDetail Data",
    SetEmoDetails = "[EmoDetail] Set EmoDetail Data",
    ReSetEmoDetails = "[EmoDetail] ReSet EmoDetail Data",
    GetReceivingDetails = "[ReceivingDetail] Get ReceivingDetail Data",
    SetReceivingDetails = "[ReceivingDetail] Set ReceivingDetail Data",
    ReSetReceivingDetails = "[ReceivingDetail] ReSet ReceivingDetail Data",
    GetAssetTransactionLogs = "[AssetTransactionLogs] Get Asset Transaction Logs Data",
    SetAssetTransactionLogs = "[AssetTransactionLogs] Set Asset Transaction Logs Data",
    ReSetAssetTransactionLogs = "[AssetTransactionLogs] ReSet Asset Transaction Logs Data"

}

export class GetEmoDetails implements Action {
    readonly type = InformationCardActionTypes.GetEmoDetails;
    constructor(public payload: {}) { }
}

export class SetEmoDetails implements Action {
    readonly type = InformationCardActionTypes.SetEmoDetails;
    constructor(public payload: any) { }
}

export class ReSetEmoDetails implements Action {
    readonly type = InformationCardActionTypes.ReSetEmoDetails;
}

export class GetReceivingDetails implements Action {
    readonly type = InformationCardActionTypes.GetReceivingDetails;
    constructor(public payload: {}) { }
}

export class SetReceivingDetails implements Action {
    readonly type = InformationCardActionTypes.SetReceivingDetails;
    constructor(public payload: any) { }
}

export class ReSetReceivingDetails implements Action {
    readonly type = InformationCardActionTypes.ReSetReceivingDetails;
}

export class GetAssetTransactionLogs implements Action {
    readonly type = InformationCardActionTypes.GetAssetTransactionLogs;
    constructor(public payload: {}) { }
}

export class SetAssetTransactionLogs implements Action {
    readonly type = InformationCardActionTypes.SetAssetTransactionLogs;
    constructor(public payload: any) { }
}

export class ReSetAssetTransactionLogs implements Action {
    readonly type = InformationCardActionTypes.ReSetAssetTransactionLogs;
}

export type InformationCardActions = GetEmoDetails | SetEmoDetails | ReSetEmoDetails |
    GetReceivingDetails | SetReceivingDetails | ReSetReceivingDetails | GetAssetTransactionLogs |
    SetAssetTransactionLogs | ReSetAssetTransactionLogs;