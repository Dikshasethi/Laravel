import {Action} from '@ngrx/store';

export enum CartActionTypes {
    AddToCart = "[Cart] Add to cart",
    SetAddedCartData = "[Cart] Set Added Cart Data",
    GetCartData = "[Cart] Get cart Data",
    SetCartData = "[Cart] Set cart Data",
    DeleteFromCart = "[Cart] Delete from cart",
    SetDeletedCartData = "[Cart] Set Deleted Cart Data",
    GetCalenderForCart = "[Cart] Get Data For Cart",
    SetCalenderForCart = "[Cart] Set Data For Cart",
    SetError = "[Cart] Set Error For Cart",
}

export class AddToCart implements Action {
    readonly type = CartActionTypes.AddToCart;
    constructor(public payload: any){}
}

export class GetCartData implements Action{
    readonly type = CartActionTypes.GetCartData;
    constructor(public payload: {}){}
}

export class SetCartData implements Action {
    readonly type = CartActionTypes.SetCartData;
    constructor(public payload: any){}
}

export class SetAddedCartData implements Action {
    readonly type = CartActionTypes.SetAddedCartData;
    constructor(public payload: any){}
}

export class DeleteFromCart implements Action {
    readonly type = CartActionTypes.DeleteFromCart;
    constructor(public payload: any){}
}

export class SetDeletedCartData implements Action {
    readonly type = CartActionTypes.SetDeletedCartData;
    constructor(public payload: any){}
}

export class GetCalenderForCart implements Action {
    readonly type = CartActionTypes.GetCalenderForCart;
    constructor(public payload: any){}
}

export class SetCalenderForCart implements Action {
    readonly type = CartActionTypes.SetCalenderForCart;
    constructor(public payload: any){}
}

export class SetError implements Action {
    readonly type = CartActionTypes.SetError;
    constructor(public payload: any) { }
}

export type CartActions = AddToCart| SetAddedCartData| GetCartData| SetCartData| DeleteFromCart| SetDeletedCartData
| GetCalenderForCart | SetCalenderForCart | SetError;