export  interface WatchList {
    assetid: string,
    businessunit: string
}