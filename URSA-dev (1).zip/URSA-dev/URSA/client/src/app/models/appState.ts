export interface AppState{
    readonly Product: {
        productFetchIsLoading : boolean,
        calendarDataIsLoading : boolean,
        productsObject : {},
        productHierarchy : {},
        productList : any,
        productsObjectCache : {},
        calendarMap : {},
        assetHistoryDetails : {
            assetdetails:any,
            statustext:any,
            statusbackgroundcolor:any,
            pastduecheckout:any,
            assetworkorderdetails:any,
            licensedetails:any,
            activeCertificate:any
        }
    },   
    readonly Autocomplete: {
        globalSuggestionList: any,
        categoryStringSuggestionList:any,
        manufacturerStringSuggestionList:any,
        modelStringSuggestionList:any,
        locationStringSuggestionList:any,
        subtype2StringSuggestionList:any,
        descriptionStringSuggestionList:any,
        checkoutAutocomplete:any,
        projectAutocomplete:any,
        custodianAutocomplete:any,
        areaCountForCurrentLocation:any,
        isLoading:any,
        cachedArea:any,
        autocompleteLastRequestIdentifierKey:string,
        proposalAutoComplete: {
            suggestionList: any,
            isFetchingAutocompleteList: boolean,
            isResponsibilityCode: boolean
        },
        permissionValidation: {
            permissionValidationFetchisLoading:boolean,
            permissionValidationResult: any
        },
        restrictionData: {
            restrictionFetchisLoading: boolean,
            restrictionResult: any
        }
    },   
    readonly ProposalData: {
        proposalData:{},
        isFetchingProposalData:boolean
    },
    readonly RefinedBy : {
        detailsRefinedBy : {
            lastFilterSectionClicked : any,
            listStateTracker : {},
            clickTracker : {}
        },
        summaryRefinedBy : {
            lastFilterSectionClicked : any,
            listStateTracker : {},
            clickTracker : {}
        }
    },
    readonly Search : {
        searchKeyword : string,
        startDate : any,
        endDate : any,
        searchCount : Number,
        localStorageKeyword : string
    },
    readonly AdvancedSearch : {
        display : string,
        activeSearch : any,
        categoryString : string,
        manufacturerString : string,
        modelString : string,
        locationString : string,
        subtype2String : string,
        descriptionString : string
    },
    readonly ProductSummary : {
        productSummaryFetchIsLoading : boolean;
        productSummaryList : any,
        productSummaryObject : {},
        searchCriteria : {},
        activeStatus: string,
        activeIndex: any,
        productSummaryObjectCache : {},
        scrollTop : number
    },
    readonly ProposalPageData : {
        proposalData:{
            proposalPageInfoData : {},
            hardReservedAssets : any,
            checkedOutAssets : any,
            checkedInAssets : any,
            proposalDataLoading : boolean,
            proposalDataError : boolean
        },
        isFetchingProposalData:boolean,
        hardReserveMode : boolean,
        cartIndex : any,
        proposalNumber : string,
        category : string,
        subtype2 : string,
        startDate : string,
        endDate : string,
        projectNumber : string,
        hrIsLoading : boolean,
        hrResponseObj : any,
        maxHrCount : number,
        pdid : string,
        pdidIndex : number,
        businessUnit : string,
        customerName : string,
        proposalDescription : string,
        projectsAutocompleteList : any,
        pcbusinessunit : string,
        projectid: string,
        projectmanagername:string,
        custodian: string,
        getProjectsAutocompleteLoading : boolean,
        getProjectsAutocompleteError : boolean,
        crmnumber:string,
        validatedHardReservedData:any,
        productProposalCartIndex: any
    },
    readonly ProposalNewData : {
        proposalNewData:{
            proposalData : {},
            hardReservedAssets : any,
            checkedOutAssets : any,
            checkedInAssets : any,
            proposalDataLoading : boolean,
            proposalDataError : boolean
        },
        createdProposalData:{ 
            addProposalData: any, 
            addProposalLoading: boolean
        },
        proposalVersion: {
            proposalVersionsData : any,
            proposalVersionLoading: boolean
        },
        crewRequirementType: {
            crewRequirementTypes: {},
            crewRequirementTypesLoading: boolean,
        },
        crewPostition: {
            crewPostitions: any,
            crewpositionsLoading: boolean
        },
        crewJobTitle: {
            crewjobtitlesLoading: boolean
        },
        proposalModeObj: {
            isProposalPageType : string,
            isProposalMode: boolean,
            proposalid: string,
            indexToAdd: any,
            detailTobeDeletedFromCart: any
        },
        errorState: {
            error: boolean,
            error_message: string | null
        }
        productProposalCartData: any
    },
    readonly User : {
        userViewPreference : string,
        blockSearch : boolean,
        previousView : string
    },
    readonly ImageUpload : {
        detailsView : {
            activeList : any,
            imageInList : any,
            thumbnailMap : any,
            fileData : {},
            errorList : any,
            loadingList : any,
            deleteUpdate : any

        },
        summaryView : {
            activeList : any,
            fileData : {},
            errorList : any,
            loadingList : any
        }
    },
    readonly UserDetail : {
        details : {},
        isloggedOut : boolean,
        isTimeout : boolean,
        isfetch: boolean,
        isLoginError : boolean      
    },
    readonly CheckOutPageData : {
        checkoutFetchIsLoading:boolean,
        readyToCheckOutData: {
            hardReservedAssets : any,
            hardReservedAssetsTotalCount : number,
            readyToCheckoutDataLoading : boolean,
            readyToCheckoutDataError : boolean
        },
        checkInOutData: { 
            checkInOutRecords : any,
            checkInOutTotalCount : number,
            checkInOutIsLoading : boolean,
            checkInOutError : boolean
        },
        checkedoutData:any,
        checkedinData:any,
        reservationTableData:any,
        validatedCheckoutData:any,
        recheckedoutData:any,
        editCheckoutData:any
        projectStatus:any
    },
    readonly ProposalList : {
        proposalListData : any,
        proposalListCount : Number,
        proposalListLoading : boolean,
        total_proposals: number,
        errorState: {
            error: boolean,
            error_message: string | null;
        }
    },
    readonly Cart : {
        cartData: {
            cartData: any,
            iscartItemsInDB:boolean,
            cartFetchIsLoading: boolean
        };
        deletedCartData: {
            deletedCartData: any,
            deletedCartFetchLoading: boolean
        };
        addedCartData: {
            addedCartData: any,
            addedCartFetchLoading: boolean
        }
        calendarDataIsLoading:boolean,
        calenderDataMap:any,
        errorState: {
            error: boolean,
            error_message: string | null;
        }
    },
    readonly Callout : {
        calloutList : any,
        calloutListIsLoading : boolean,
        calloutListError : boolean,
        calloutDetails : any;
        calloutDetailsIsLoading : boolean,
        calloutDetailsError : boolean,
        calloutCount:number,
        deleteCalloutLoading : boolean,
        deleteCalloutError : boolean,
        deleteCalloutSuccess : boolean,
        deleteCalloutErrorMessage : any

    },
    readonly CheckInOut : {
        checkedin : {
            rows : {},
            splitView : boolean,
            clientPanel : {},
            allRecordSelected : boolean
        },
        checkout : {
            rows : {},
            splitView : boolean,
            clientPanel : {},
            allRecordSelected : boolean,
            isLoading : boolean,
            hasError : boolean,
            submitResults : any
        },
        checkin : {
            rows : {},
            splitView : boolean,
            clientPanel : {},
            allRecordSelected : boolean,
            isLoading : boolean,
            hasError : boolean,
            submitResults : any
        },
        projectStatusMap : any,
        dateValidationResults : any,
        dateValidationLoading : boolean,
        dateValidationError : boolean,
        sort:any
    }
    
    readonly CheckoutCheckIn : {
        chekOutCheckIndata:any,
        checkOutdataIsLoading : boolean
    }
    
    readonly UserManagement : {
        searchedUserResults : any,
        tableData : any,
        appRoles : any,
        addedUser : any,
        userManagementLoading : boolean,
        userManagementLoading_userFind : boolean,
        userManagementError : boolean
    }

    readonly Utilization : {
        utilizationPercentage: [],
        utilizationloading : boolean
    }

    readonly Emo : {
        emoList : any,
        emoListIsLoading : boolean,
        emoListError : boolean,
        emoCount:number,
        emoData : any,
        emoFetchisLoading: boolean,
        addedEmo :any,
        emoRecordInfo:any
        emoPath : string,
        emoMode : boolean,
        loading:boolean,
        onScrollLoading: boolean
    }
    
    readonly Receiving : {
        receivingData: any,
        addedReceivingData: any,
        receivingRecordInfo: any,
        receivingPath: string,
        receivingMode: boolean,
        receivingList: [],
        receivingCount: number,
        receivingListIsLoading: boolean,
        receivingListError: boolean,
        onScrollLoading: boolean
    }

    readonly AssetLog : {
        assetLogList : [],
        isLoading : boolean,
        hasError : boolean,
        totalCount : number,
        filterObj : {}
    }

    readonly Notification : {
        notificationLoading : boolean,
        notificationError : boolean,
        usersNotifications : [],
        updateNotificationLoading : boolean,
        updateNotificationError : boolean,
        updateNotificationResponse : any
    }

    readonly RoleMatrix: {
        permissionData: {
            permissionResult: any,
        },
        roleData: {
            roleResult: any,
        },
        permissionDataById: {
            permissionByIdResult: any,
        },
        roleDataById: {
            roleByIdResult: any,
        },
        userList: {
            userListResult: any,
            userListCount: number,
            userListFetchisLoading: boolean
        },
        userRoleById: {
            userroleByIdResult: any,
        },
        userInfo: {
            userInfoList: any,
        },
        restrictionData: {
            restrictionResult: any,
        },
        userListFilter:any,
        userValidation: boolean,
        errorState: {
            error: boolean,
            error_message: string | null;
        },
        loading:boolean
    }
    readonly Download:{
        downloadData:any,
        isLoading:boolean
    }
    readonly InformationCard: {
        emodetails: {
            emodetailsData:any,
            totalCount:number
        },
        receivingdetails: {
            receivingdetailsData:any,
            totalCount:number
        }
        assettransactionlogsdetail: {
            assettransactionlogsData: any,
            totalCount: number
        }
    }
    readonly WatchList : {
        watchListData:{
            watchListData: any,
            watchListLoading : boolean,
            watchListError: boolean,
            totalCount: number
        },
        addedWatchListData:{ 
            addedWatchlistData: any, 
            addedWatchListLoading: boolean
        }
        deletedWatchListData: {
            deletedWatchListData: any, 
            deletedWatchListLoading: boolean,
        },
        errorState: {
            error: boolean,
            error_message: string | null;
        },
        onScrollLoading: boolean
    }
    readonly Personalization : {
        personalizationRefinedByData:{
            personalizationRefinedByData: any,
            personalizationRefinedByLoading : boolean,
            personalizationRefinedByError: boolean,
            totalCount: number
        },
        addedPersonalizationRefinedByData:{ 
            addedPersonalizationRefinedByData: {}, 
            addedPersonalizationRefinedByDataLoading: false
        },
        deletedPersonalizationRefinedByData: {
            deletedPersonalizationRefinedByData: [], 
            deletedPersonalizationRefinedByLoading: false
        },
        updatePersonalizationRefinedByData:{
            updatePersonalizationRefinedByData:[],
            updatePersonalizationRefinedByDataLoading:false,
        },
        nameCheckPersonalizationRefinedBy:{},
        nameCheckPersonalizationRefinedByLoading:false,
        errorState: {
            error: boolean,
            error_message: string | null;
        }
    }
    readonly ServiceRequest : {
        serviceRequestData: {
            serviceRequestData: any,
            serviceRequestDataLoading : boolean,
        },
        requestType: {
            requestTypeData: [],
            requestTypeDataLoading: boolean,
        },
        scopeType: {
            scopeTypeData: [],
            scopeTypeDataLoading: boolean
        },
        workType: {
            workTypeData: [],
            workTypeDataLoading: boolean
        },
        serviceGroup: {
            serviceGroupData: [],
            serviceGroupDataLoading: boolean
        },
        treeNode: {
            treeNodeData: [],
            treeNodeDataLoading: boolean
        },
        serviceCenter: {
            serviceCenterData: [],
            serviceCenterDataLoading: boolean
        },
        serviceRequestListData:{
            serviceRequestListData: any,
            serviceRequestListLoading : boolean,
            serviceRequestListError: boolean,
            totalCount: number
        },
        createdServiceRequestData:{ 
            addServiceRequestData: any, 
            addServiceRequestLoading: boolean
        },
        deletedServiceRequestData: {
            deleteServiceRequestData: any, 
            deleteServiceRequestLoading: boolean
        },
        errorState: {
            errorLoading: boolean,
            error: any
        },
        onScrollLoading: boolean,
        sort:any
    }
    readonly TableColumnPersonalization : {
        personalizationTableColumnData:{
            personalizationTableColumnData: any,
            personalizationTableColumnLoading : boolean,
            personalizationTableColumnError: boolean,
            totalCount: number
        },
        addedPersonalizationTableColumnData:{ 
            addedPersonalizationTableColumnData: {}, 
            addedPersonalizationTableColumnLoading: false
        },
        deletedPersonalizationTableColumnData: {
            deletedPersonalizationTableColumnData: [], 
            deletedPersonalizationTableColumnLoading: false
        },
        updatePersonalizationTableColumnData:{
            updatePersonalizationTableColumnData: {},
            updatePersonalizationTableColumnDataLoading:false,
        },
        errorState: {
            error: boolean,
            error_message: string | null;
        }
    }
    readonly Dashboard: {
        utilizationChart: {
            utilizationChartData: any[],
            utilizationChartLoading: boolean
        },
        checkoututilizationChart: {
            checkoututilizationChartData: any[],
            checkoututilizationChartLoading: boolean
        },
        onhireutilizationChart: {
            onhireutilizationChartData: any[],
            onhireutilizationChartLoading: boolean
        },
        receivecountChart: {
            receivecountChartData: any[],
            receivecountChartLoading: boolean
        },
        softReservationChart: {
            softReservationChartData: any[],
            softReservationChartLoading: boolean
        },
        hardReservationChart: {
            hardReservationChartData: any[],
            hardReservationChartLoading: boolean
        },
        shippedChart: {
            shippedChartData: any[],
            shippedChartLoading: boolean
        },
        assetCount: {
            assetCountData: number,
            assetCountLoading: boolean
        },
        pastDueCount: {
            pastDueCountData: number,
            pastDueCountLoading: boolean
        },
        hardReservationCount: {
            hardReservationCountData: number,
            hardReservationCountLoading: boolean
        },
        softReservationCount: {
            softReservationCountData: number,
            softReservationCountLoading: boolean
        },
        checkoutCount: {
            checkoutCountData: number,
            checkoutCountLoading: boolean
        },
        errorState: {
            utilization: {
                error: boolean,
                error_message: string | null;
            },
            checkoututilization: {
                error: boolean,
                error_message: string | null;
            },
            onhire: {
                error: boolean,
                error_message: string | null;
            },
            softReservation: {
                error: boolean,
                error_message: string | null;
            },
            hardReservation: {
                error: boolean,
                error_message: string | null;
            },
            shipped: {
                error: boolean,
                error_message: string | null;
            },
            asset: {
                error: boolean,
                error_message: string | null;
            },
            pastDue: {
                error: boolean,
                error_message: string | null;
            },
            hardReservationCount: {
                error: boolean,
                error_message: string | null;
            },
            checkout: {
                error: boolean,
                error_message: string | null;
            },
            softReservationCount: {
                error: boolean,
                error_message: string | null;
            },
            receivecount: {
                error: boolean,
                error_message:string | null;
            }
        }
    }
}
