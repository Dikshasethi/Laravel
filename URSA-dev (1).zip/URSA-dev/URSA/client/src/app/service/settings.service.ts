import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class SettingsService {

  constructor(private http:HttpClient) { }
  getLanguage(){
    navigator.geolocation.getCurrentPosition(this.success, this.error, this.options);
    // return code;
  }
  // navigator.geolocation.getCurrentPosition(success, error, options);
  success(pos) {
    var crd = pos.coords;
    // this.getCountry.subscribe(data => {console.log(data)});
    // return this.http.get(`http://api.geonames.org/countryCodeJSON?lat=49.03&lng=10.2&username=swastika`)
    // .map(res => {
    //   console.log(res)
    // })

    return this.http.get(`http://api.geonames.org/countryCodeJSON?lat=49.03&lng=10.2&username=swastika`)
                        // ...and calling .json() on the response to return data
                         .map((res:Response) =>  
                         res.json()
                         )
                         //...errors if any
                         .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
      
    }

    getCountry() {
      return this.http.get(`http://api.geonames.org/countryCodeJSON?lat=49.03&lng=10.2&username=swastika`);
    }
    // this.http.get(`http://api.geonames.org/countryCodeJSON?lat=49.03&lng=10.2&username=swastika`)
    // .toPromise()
    // .then(res => {
    //   console.log(res)
    //   return res;    
    // })
    // .catch(error => {
    //     console.log('fetch error', error);
        
    // })

    // console.log('Your current position is:');
    // console.log(`Latitude : ${crd.latitude}`);
    // console.log(`Longitude: ${crd.longitude}`);
    // console.log(`More or less ${crd.accuracy} meters.`);
  // }

  error(err) {
    console.warn(`ERROR(${err.code}): ${err.message}`);
  }

  options = {
    enableHighAccuracy: true,
    timeout: 5000,
    maximumAge: 0
  };
}
