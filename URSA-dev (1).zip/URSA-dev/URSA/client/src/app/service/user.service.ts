import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';


@Injectable()
export class UserService {

  private userName;
  private userToken;
  constructor(private http: HttpClient) {this.userName = "";}

  validateUser(): Promise<boolean> {
    return new Promise((resolve, reject) => {
      this.http.get("/api/user/validateSession").toPromise()
        .then((res) => {
          
          if (res['flag'] == true){
            this.userName=res['username']
            resolve(true);
          } 
          else resolve(false);
        })
        .catch((err) => {
          reject(false);
        });

    })
  }
  getUsername(){
    return this.userName;
  }
  checkIsLoggedIn(){
    return this.http.get("/api/user/validateSession")
    .map(
    res => {
    if (res['flag'] == true){
    return true;
    }
    else{
    return false;
    }
    
    })
    }
  }

  