import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'getKeysValues'
})
export class GetKeysValuesPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    let keyvaluesArray = [];
     Object.keys(value).map(key => {
       keyvaluesArray.push({
        keys: key,
        values: value[key]
      });
    });
    return keyvaluesArray;
  }
}
