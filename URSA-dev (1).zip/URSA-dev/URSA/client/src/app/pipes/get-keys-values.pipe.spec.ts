import { GetKeysValuesPipe } from './get-keys-values.pipe';

describe('GetKeysValuesPipe', () => {
  it('create an instance', () => {
    const pipe = new GetKeysValuesPipe();
    expect(pipe).toBeTruthy();
  });
});
