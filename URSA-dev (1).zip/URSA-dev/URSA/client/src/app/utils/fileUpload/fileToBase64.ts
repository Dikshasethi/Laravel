export default function (file){
    try{
      let base64 = new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject({error : true, errorPayload : error});
      });

      return base64;
    }catch(e){
      return {error : true, errorPayload : e}
    }
  }