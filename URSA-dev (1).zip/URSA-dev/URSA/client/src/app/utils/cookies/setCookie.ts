export default function(cookieName, value, remove=false){
    try{
        if(cookieName){
            let accumulator={};
            let cookies = document.cookie;
            console.log('cookies', cookies)
            let splitCookies = cookies.split(';');
            for (let i = 0; i < splitCookies.length; i++){
                let cookieBlock = splitCookies[i];
                let subSplit = cookieBlock.split('=');
                if(subSplit.length > 0){
                    accumulator[subSplit[0]] = subSplit[1];
                }
            }

            if(remove){
                delete accumulator[cookieName];
            }else{
                accumulator[cookieName] = value;
            }

            let newCookie = '';
            for (let key in accumulator){
                let val = accumulator[key];
                newCookie += `${key}=${val};`
            }
            // console.log('accum', accumulator, newCookie, cookieName)
            // document.cookie = newCookie;
        }
    }catch(e){
        console.log('set cookie failed');
        return false;
    }
}