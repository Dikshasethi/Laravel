export default {
    currentLocationFilterList : 'pslocationtbldescr',
    category : 'psamsubtypedescr',
    manufacturer : 'manufacturer',
    model : 'model',
    subtype : 'assetsubtype2',
    detailDescription : 'descrlong'
}