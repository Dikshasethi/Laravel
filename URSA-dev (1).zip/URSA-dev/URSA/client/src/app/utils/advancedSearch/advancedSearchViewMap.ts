export const reducerMap = {
    Category : 'categoryString',
    Manufacturer : 'manufacturerString',
    Model : 'modelString',
    Location : 'locationString',
    "Sub Type 2" : 'subtype2String',
    Description : 'descriptionString'
}

export const searchMap = {
    Category : 'category',
    Manufacturer : 'manufacturer',
    Model : 'model',
    Location : 'currentLocationFilterList',
    "Sub Type 2" : 'subtype',
    Description : 'detailDescription'
}