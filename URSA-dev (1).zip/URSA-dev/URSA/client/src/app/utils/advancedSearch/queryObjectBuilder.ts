import map from './advancedSearchMap';
export const advancedSearchObjectBuilder = (searchObj) => {
    let accumulator = {};
    if(searchObj){
        for (let k in searchObj){
            let exactCount = 0;
            let newList = [];
            let key = map[k];
            accumulator[key] = {};
            let fieldList = searchObj[k];
            for (let i = 0; i < fieldList.length; i++){
                let searchWord = fieldList[i] && fieldList[i];
                if(searchWord || typeof searchWord === 'number'){
                    let length = searchWord && searchWord.length;
                    if(
                        (searchWord[0] === '"' || searchWord[0] === "'") &&
                        (searchWord[length - 1] === '"' || searchWord[length - 1] === "'")
                    ){
                        exactCount++;
                    }
                    newList.push(searchWord);
                }
            }
            if(newList && newList.length > 0){
                accumulator[key]['value'] = newList;
                accumulator[key]['type'] = exactCount > 0 ? 'exact_match' : 'partial_match';
            }
        }
        return accumulator;
    }else{
        return accumulator;
    }
}