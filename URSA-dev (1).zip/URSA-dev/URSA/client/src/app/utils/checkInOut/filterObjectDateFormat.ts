import * as moment from 'moment';
import reformatDate from '../date/reformatDate';

export default function (filter={}, format=''){
    let formattedFilters = {};
    try{
        for (let key in filter){
            let value = filter[key];
            if(
                value ||
                typeof value === 'number'
            ){
                if(
                    [
                        'startdate',
                        'enddate',
                        'checkoutdate',
                        'expectedcheckindate',
                        'actualcheckindate',
                        'begindate',
                        'emodate',
                        'shipmentmustarriveby',
                        'createdAt',
                        'updatedAt',
                        'shipdate',
                        'createddate',
                        'updateddate',
                        'receivingdate',
                        'activitydate',
                        'newcheckindate'

                    ].includes(key)
                ){
                    let locale = window.navigator.language;
                    moment.locale(locale);
                    let localFormat = moment().localeData()['_longDateFormat']['L'];
                    formattedFilters[key] = moment(value,localFormat).isValid() && (value.length > 8) ? 
                    reformatDate(value, format || 'YYYY-MM-DD') : value;
                }else{
                    formattedFilters[key] = value;
                }
            }
        }
        return formattedFilters;
    }catch(e){
        console.log('/utils/checkInOut/filterObjectDateFormat catch block error', e);
        return formattedFilters;
    }
}