export default [
    {
        label : 'Cancel Hard Reserve',
        activeClass : 'btn cancel-hard-r-btn' ,
        useIn : ['checkout'],
        type : 'cancelHardReserve',
        // iconClass : 'fa fa-times-circle'
    },
    {
        label : 'Edit Hard Reserve',
        activeClass : 'btn edit-hard-r-btn' ,
        useIn : ['checkout'],
        type : 'editHardReserve',
    },
    {
        label : 'Checkout',
        activeClass : 'btn check-out-btn',
        useIn : ['checkout'],
        type : 'checkout'
    },
    {
        label : 'Add To EMO',
        activeClass : 'btn add-to-emo-btn',
        useIn : ['checkin','emoMode'],
        // iconClass : 'fa fa-plus-circle',
        type : 'emo'
    },
    {
        label : 'Add To Receiving',
        activeClass : 'btn add-hard-r-btn',
        useIn : ['checkin','receivingMode'],
        iconClass : 'fa fa-plus-circle',
        type : 'receiving'
    },
    {
        label : 'Cancel Checkout',
        activeClass : 'btn cancel-hard-r-btn',
        useIn : ['checkin'],
        type : 'cancelCheckout',
        // iconClass : 'fa fa-times-circle'
    },
    {
        label : 'Edit Checkout',
        activeClass : 'btn edit-hard-r-btn',
        useIn : ['checkin'],
        iconClass : 'fa fa-pencil',
        type : 'editCheckout'
    },
    {
        label : 'Create SR',
        activeClass : 'btn create-sr-btn',
        useIn : ['checkin','checkout', 'checkedin'],
        type : 'createServiceRequest',
         iconClass : 'fa fa-pencil-square-o'
    },
    {
        label : 'Re-Checkout',
        activeClass : 'btn reset-btn',
        useIn : ['checkin'],
        type : 'reCheckout',
        // iconClass : 'fa fa-refresh'
    },
    {
        label : 'Checkin',
        activeClass : 'btn check-out-btn',
        useIn : ['checkin'],
        type : 'checkin'
    }
]