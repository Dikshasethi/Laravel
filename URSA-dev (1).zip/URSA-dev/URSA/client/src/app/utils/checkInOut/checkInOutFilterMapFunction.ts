import checkInOutFilterMap from './checkInOutFilterMap';

export default (filters={}) => {
    let mappedObject = {};
    try{
        for (let key in filters){
            let value = filters[key];
            let field = checkInOutFilterMap[key];
            if(
                value ||
                typeof value === 'number'
            ){
                mappedObject[field] = value;
            }
        }

        return mappedObject;
    }catch(e){
        console.log('/utils/checkInOut/checkInOutFilterMapFunction catch block error', e);
        return mappedObject;
    }
}