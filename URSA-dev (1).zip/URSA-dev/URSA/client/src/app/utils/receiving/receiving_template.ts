import {
    receivePermission, cancelReceivePermission, checkinPermission
} from '../../utils/config/config';

const form_template = [
    {
        "type": "text",
        "row_width": "form-group col-md-12",
        "labelClass": "label",
        "label": "Notes:",
        "dataKey": "shipmentcondition",
        "inputClass": "input_default",
        "required": false
    },
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-4",
        "label": "Project No/Activity :",
        "dataKey": "projectnumber",
        "inputClass": "input_default",
        "required": true
    },
    {
        "type": "autocomplete",
        "labelClass": "label",
        "row_width": "form-group col-md-4",
        "label": "Receiving Location :",
        "dataKey": "receivinglocation",
        "displayText": "receivinglocationdescription",
        "inputClass": "input_default",
        "required": true
    }, {
        "type": "autocomplete",
        "labelClass": "label",
        "row_width": "form-group col-md-4",
        "label": "Receiving Area :",
        "dataKey": "receivingarea",
        "displayText": "receivingareadescription",
        "inputClass": "input_default",
        "required": true
    }
]

const action_buttons = [
    {
        label: "Save",
        type: 'saveReceiving',
        activeClass: 'btn save-btn-1 cust-flt-right ml-2',
    },
    {
        label: "Checkin",
        type: 'checkin',
        activeClass: 'btn checkin-btn cust-flt-right ml-2',
        permissionBasedDisplay : true,
        permission : checkinPermission
    },    
    {
        label: "Receive",
        type: 'received',
        activeClass: 'btn receive-btn cust-flt-right ml-2 cust-button',
        permissionBasedDisplay : true,
        permission : receivePermission
    },
    {
        label: "Cancel Receive",
        type: 'cancelreceive',
        activeClass: 'btn calcelreceive-btn cust-flt-right ml-2 cust-button',
        permissionBasedDisplay : true,
        permission : cancelReceivePermission
    },
    {
        label: "Print",
        type: 'printReceiving',
        activeClass: 'btn print-btn cust-flt-right ml-2 cust-button',
    },
    {
        label: "Close",
        type: 'close',
        activeClass: 'btn close-btn cust-flt-right  ml-2 cust-button',
    }
]
export { form_template, action_buttons }