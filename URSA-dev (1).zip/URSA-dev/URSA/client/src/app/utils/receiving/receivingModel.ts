class ReceivingModel {
    shipmentcondition: String = '';
    projectnumber: String = '';
    receivinglocation: String = '';
    receivinglocationdescription: String = '';
    receivingarea: String = '';
    receivingareadescription: String = '';
    receivingdetails: ReceivingDetailsModel[] = []
}

class ReceivingDetailsModel {
    itemno: string = '';
    itemtype: string = '';
    businessunit: string = '';
    peoplesoftcheckoutid: string = '';
    serialid: string = '';
    tagnumber: string = '';
    partno: string = '';
    quantity: number = 0;
    uom: string = '';
    description: string = '';
    observation: string = '';
    assetid: string = '';
    destinationlocation: string = '';
    destinationarea: string = '';
    checkoutdate: string = '';
    expectedcheckindate: string = '';
    proposalnumber: string = '';
    projectnumber: string = '';
    pdid: string = '';
    calloutid: string = '';
    pcbusinessunit: string = '';
    customerreferencenumber: string = '';
    crmnumber: string = '';
    subtype2: string = '';
}
export { ReceivingModel, ReceivingDetailsModel };
