const receivingFilter = {
    asset: "Asset",
    container: "Container",
    part: "Part"
}

export { receivingFilter }