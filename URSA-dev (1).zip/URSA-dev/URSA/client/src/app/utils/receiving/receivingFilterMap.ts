export default {
    receivingid : 'receivingid',
    receivingdate : 'receivingdate',
    projectnumber : 'projectnumber',
    receivinglocation : 'receivinglocation',
    receivingarea: 'receivingarea',
    received: 'received',
    createdby : 'createdby',
    createdAt : 'createdAt',
    modifiedby : 'modifiedby',
    updatedAt : 'updatedAt',
    createddate : 'createddate',
    updateddate : 'updateddate',
    assetid : 'assetid',
    businessunit : 'businessunit'
}
