import * as moment from 'moment';

export default function(date, fallbackFormat){
    let locale = window.navigator.language;
    if(locale){
        moment.locale(locale);
        return moment(date).format('L');
    }else{
        if(fallbackFormat){
            return moment(date).format(fallbackFormat);
        }
        return date;
    }
}