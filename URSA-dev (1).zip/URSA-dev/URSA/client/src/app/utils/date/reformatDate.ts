import * as moment from 'moment';

export default function(date, format){
    let locale = window.navigator.language;
    moment.locale(locale);
    let localFormat = moment().localeData()['_longDateFormat']['L']
    return moment(date, localFormat).format(format);
}