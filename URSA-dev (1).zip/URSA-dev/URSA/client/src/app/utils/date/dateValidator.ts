import * as moment from 'moment';

export default function dateValidation(date) {
    if(
        typeof date !== 'string' ||
        !date
    ){
        return false;
    }

    if(
        date.trim().toLowerCase().includes('invalid date')
    ){
        return false;
    }

    let day = Number(new Date(date).getDate())
    let month = Number(new Date(date).getMonth() + 1);
    let year = Number(new Date(date).getFullYear());
    let totalDaysInMonth = Number(new Date(year, month, 0).getDate());
    let minYear = 1900;
    let maxYear = 9999;

    if (moment(date).isValid()) {
        if(!year || !month || !day){
            return false;
        }
        else if (year < minYear || year > maxYear) {
            return false;
        }
        else if (month < 1 || month > 12) {
            return false;
        }
        else if (day < 1 || day > totalDaysInMonth) {
            return false;
        }
    }
    else {
        return false;
    }

    return true;
}