import reformatDate from '../../utils/date/reformatDate';
import * as moment from 'moment';

export default function(dateString: string){
    if(dateString) {
        return moment(reformatDate(dateString,'YYYY-MM-DD')).isValid();
    }
    return false;
}
