import * as moment from 'moment';

export default function( ){
    let locale = window.navigator.language;
    let dateformat  = '';
    if(locale){
        moment.locale(locale);
        let localFormat = moment().localeData()['_longDateFormat']['L']
        dateformat = localFormat;
    }
    return dateformat;
}