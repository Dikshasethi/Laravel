export default [
    {"label":"Checkout", "value": "checkout"},
    {"label":"Checkin", "value": "checkin"},
    {"label":"Update Checkout", "value": "updatecheckout"},
    {"label":"Cancel Checkout", "value": "cancelcheckout"},
    {"label":"Hard Reserve", "value": "hardreserve"},
    {"label":"Edit Hard Reserve", "value": "edithardreserve"},
    {"label":"Cancel Hard Rreserve", "value": "cancelhardreserve"},
    {"label":"Added To Emo", "value": "addedtoemo"},
    {"label":"Added To Receiving", "value": "addedtoreceiving"},
    {"label":"Emo Shipped", "value": "emoshipped"},
    {"label":"Receiving Report Received", "value": "receivingreportreceived"}
]