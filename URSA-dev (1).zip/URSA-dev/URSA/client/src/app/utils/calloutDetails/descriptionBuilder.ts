export default [
    {
        label : 'Callout ID',
        dataKey : 'calloutid',
        labelClassName : 'text-secondary',
        bodyClassName : ''
    },
    {
        label : 'Project No#',
        dataKey : 'projectnumber',
        labelClassName : 'text-secondary',
        bodyClassName : ''
    },
    {
        label : 'Project Start Date',
        dataKey : 'projectstartdate',
        labelClassName : 'text-secondary',
        bodyClassName : '',
        transformBody : true,
        transformType : 'date',
        dateFormat : 'DD-MMM-YYYY'
    },
    {
        label : 'Project End Date',
        dataKey : 'projectenddate',
        labelClassName : 'text-secondary',
        bodyClassName : '',
        transformBody : true,
        transformType : 'date',
        dateFormat : 'DD-MMM-YYYY'
    },
    {
        label : 'Customer Name',
        dataKey : 'customername',
        labelClassName : 'text-secondary',
        bodyClassName : ''
    },
    {
        label : 'Created By',
        dataKey : 'createdby',
        labelClassName : 'text-secondary',
        bodyClassName : ''
    },
    {
        label : 'Created Date',
        dataKey : 'createdAt',
        labelClassName : 'text-secondary',
        bodyClassName : '',
        transformBody : true,
        transformType : 'date',
        dateFormat : 'DD-MMM-YYYY'
    },
]