export default {
    projectnumber : "projectnumber",
    calloutid : "calloutid",
    createdAt : "createdAt",
    projectstartdate : "projectstartdate",
    projectenddate : "projectenddate",
    customername : "customername",
    createdby : "createdby",
}
