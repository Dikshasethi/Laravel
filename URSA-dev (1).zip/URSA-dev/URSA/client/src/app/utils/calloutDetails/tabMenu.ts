export default [
    {
        label : 'Hard Reserved',
        listName : 'sortedHardReservedAssets',
        tableInFocus : 'checkout'
    },
    {
        label : 'Checked Out',
        listName : 'sortedCheckedOutAssets',
        tableInFocus : 'checkin'
    },
    {
        label : 'Checked In',
        listName : 'sortedCheckedInAssets',
        tableInFocus : 'checkedin'
    }
]