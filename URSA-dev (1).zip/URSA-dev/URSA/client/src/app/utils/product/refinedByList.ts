export const productRefinedByList = [
    {label : 'Business Unit', value : 'buList'},
    {label : 'Category', value : 'category'},
    {label : 'Subtype 2', value : 'subtype'},
    {label : 'Manufacturer', value : 'manufacturer'},
    {label : 'Model', value : 'model'},
    {label : 'Asset Base', value : 'assetbase'},
    {label : 'Asset Owner', value : 'assetlocation'},
    {label : 'Current Location', value : 'currentLocationFilterList'},
    {label : 'Asset Disposed', value : 'isdisposed'},
    {label : 'State', value : 'stateList'},
    {label : 'Service Line', value : 'serviceline'},
    {label : 'Status', value : 'statusList'},
    {label : 'Utilization', value :'utilization',type:"slider"},
    {label : 'Days Since Last Checked in', value :'dayssincelastcheckedin',type:"slider"}
]

export const productRefinedByStateMapper = {
    category : 'filterCategories',
    manufacturer : 'filterManufacturers',
    model : 'filterModel',
    subtype : 'filterSubtype',
    currentLocationFilterList : 'filterLocations',
    statusList : 'filterstatus'
}

export const hardReserveModeRefinedByList = [
    {label : 'Asset Base', value : 'assetbase'},
    {label : 'Asset Owner', value : 'assetlocation'},
    {label : 'Manufacturer', value : 'manufacturer'},
    {label : 'Model', value : 'model'},
    {label : 'Current Location', value : 'currentLocationFilterList'},
    {label : 'State', value : 'stateList'},
]
