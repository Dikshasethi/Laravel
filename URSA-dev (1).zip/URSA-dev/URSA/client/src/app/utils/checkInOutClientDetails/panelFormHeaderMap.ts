export default {
    cancelHardReserve : {
        headerText : 'Cancel Hard Reservation(s)',
        submitButtonText : 'Submit'
    },
    checkout : {
        headerText : 'Checkout Asset(s)',
        submitButtonText : 'Submit'
    },
    checkin : {
        headerText : 'Checkin Asset(s)',
        submitButtonText : 'Submit'
    },
    editCheckout : {
        headerText : 'Edit Checkout Record(s)',
        submitButtonText : 'Submit'
    },
    cancelCheckout : {
        headerText : 'Cancel Checkout(s)',
        submitButtonText : 'Submit'
    },
    reCheckout : {
        headerText : 'Recheckout Asset(s)',
        submitButtonText : 'Submit'
    }
}