export default {
    areaText : 'NA'
}
