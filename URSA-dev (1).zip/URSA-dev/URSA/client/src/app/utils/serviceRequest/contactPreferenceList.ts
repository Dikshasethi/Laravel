export default [
    {"name":"Phone", "value": "phone"},
    {"name":"Email", "value": "email"},
]