export default [
    {
        label : 'Notes',
        listName : '',
        tableInFocus : 'notes',
        stateName : 'notes',
        checkStatus: ''
    }
]
