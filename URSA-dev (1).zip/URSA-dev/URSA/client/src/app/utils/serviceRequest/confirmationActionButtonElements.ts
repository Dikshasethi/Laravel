export default [
    {
        label : 'Cancel',
        activeClass : 'btn cancel-btn' ,
        type : 'cancelconfirmationmodal',
    },
    {
        label : 'Confirm',
        activeClass : 'btn save-btn' ,
        type : 'confirmconfirmationmodal',
    }
]