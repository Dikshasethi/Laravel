import { ServiceRequestAssetsModel } from '../serviceRequest/serviceRequestModel'

class SelectedAssetsdetailsModel implements ServiceRequestAssetsModel {
    assetid: string = '';
    businessunit: string = '';
    startdate: string = '';
    enddate: string = '';
    projectnumber: string = '';
    projectmanagername: string = '';
    serialid: string = '';
    tagnumber: string = '';
    assetdescription: string = '';
}
export { SelectedAssetsdetailsModel };