const request_detail_form_template = [
    {
        "type": "select",
        "row_width": "form-group col-md-3",
        "labelClass": "label",
        "label": "Request type",
        "dataKey": "requesttype",
        "inputClass": "input_default width-100",
        "required": true,
        "resetSelectedField": ["scopetype", "worktype", "servicegroup"]
    },
    {
        "type": "select",
        "labelClass": "label",
        "row_width": "form-group col-md-3",
        "label": "Scope Type",
        "dataKey": "scopetype",
        "inputClass": "input_default width-100",
        "required": true,
        "resetSelectedField": ["worktype", "servicegroup"]
    },
    {
        "type": "select",
        "labelClass": "label",
        "row_width": "form-group col-md-3",
        "label": "Work Type",
        "dataKey": "worktype",
        "inputClass": "input_default width-100",
        "required": true,
        "resetSelectedField": ["servicegroup"]
    },
    {
        "type": "select",
        "labelClass": "label",
        "row_width": "form-group col-md-3",
        "label": "Service Group",
        "dataKey": "servicegroup",
        "inputClass": "input_default width-100",
        "required": true
    },
   
];


export { request_detail_form_template }