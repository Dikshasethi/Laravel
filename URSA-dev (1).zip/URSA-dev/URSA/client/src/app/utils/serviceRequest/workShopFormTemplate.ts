const work_shop_form_template = [
    {
        "type": "text",
        "row_width": "form-group col-md-2",
        "labelClass": "label",
        "label": "Subject",
        "dataKey": "subject",
        "inputClass": "input_default width-100",
        "required": true
    },
    {
        "type": "textarea",
        "labelClass": "label",
        "row_width": "form-group col-md-10",
        "label": "Description",
        "dataKey": "description",
        "inputClass": "input_default width-100",
    },
    {
        "type": "autocomplete",
        "labelClass": "label",
        "row_width": "form-group col-md-3",
        "label": "Project",
        "dataKey": "projectnumber",
        "inputClass": "input_default width-100",
        "required": true
    },
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-3",
        "label": "Activity ID",
        "dataKey": "activityid",
        "inputClass": "input_default width-100",
    },
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-3",
        "label": "Project Manager",
        "dataKey": "projectmanagername",
        "inputClass": "input_default width-100",
    },
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-3",
        "label": "Client",
        "dataKey": "customername",
        "inputClass": "input_default width-100",
    },
    {
        "type": "select",
        "labelClass": "label",
        "row_width": "form-group col-md-3",
        "label": "Service Center",
        "dataKey": "servicecenter",
        "inputClass": "input_default width-100",
        "required": true,
    },
    {
        "type": "textarea",
        "labelClass": "label",
        "row_width": "form-group col-md-6",
        "label": "Special Instruction",
        "dataKey": "specialinstruction",
        "inputClass": "input_default width-100",
    }
];


export { work_shop_form_template }