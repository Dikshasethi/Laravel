interface ServiceRequestModel {
    requesttype? : string,
    sourcetype? : string,
    scopetype? : string,
    worktype? : string,
    servicegroup? : string,
    requestedbyname? : string,
    requestedbyid? : string,
    requestedforname? : string,
    requestedforid? : string,
    contactpreference? : string,
    contactemail? : string,
    contactphonenumber? : string,
    servicerequestnote? : string,
    subject? : string,
    description? : string,
    projectnumber? : string,
    activityid? : string,
    projectmanagername? : string,
    customername? : string,
    customerid? : string,
    servicecenter? : string,
    originmodule? : string,
    specialinstruction? : string,
    relatedrequest?: string,
    businessunit? : string,
    createdAt? : string,
    notes? : string,
    peoplesoftservicerequestid? : string,
    assets? : ServiceRequestAssetsModel[]
}

interface ServiceRequestAssetsModel {
    assetid? : string,
    businessunit? : string,
    startdate? : string,
    enddate? : string,
    projectnumber?: string,
    projectmanagername?: string,
    serialid?: string,
    tagnumber?: string,
    assetdescription?: string,
}


export { ServiceRequestModel, ServiceRequestAssetsModel };
