export default {
    requesttype : 'requesttype',
    sourcetype : 'sourcetype',
    worktype : 'worktype',
    servicegroup : 'servicegroup',
    projectnumber : 'projectnumber',
    subject: 'subject',
    activityid : 'activityid',
    projectmanagername : 'projectmanagername',
    customername : 'customername',
    servicecenter : 'servicecenter',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
}
