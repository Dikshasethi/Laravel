export default [
    {
        label : 'Create SR',
        activeClass : 'btn mr-2 create-sr-btn' ,
        type : 'create',
        checkDisplayOnPage : true,
        iconClass : 'fa fa-check-square-o',
        permissionBasedDisplay : true,
    },
    {
        label: "Delete",
        activeClass : 'btn mr-2 cancel-sr-btn',
        iconClass : "fa fa-close",
        type: 'delete',
        permissionBasedDisplay : true,
    },
    {
        label : 'Save',
        activeClass : 'btn mr-2 save-sr-btn' ,
        type : 'save',
        iconClass : 'fa fa-floppy-o',
        permissionBasedDisplay : true,
    }
]