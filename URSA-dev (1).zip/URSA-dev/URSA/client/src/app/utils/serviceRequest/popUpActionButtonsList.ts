export default [
    {
        label : 'Cancel',
        activeClass : 'btn cancel-pop-btn' ,
        type : 'cancelModal',
        iconClass : 'fa fa-close'
    },
    {
        label : 'Save',
        activeClass : 'btn save-popup-btn' ,
        type : 'saveModal',
        iconClass : 'fa fa-floppy-o',
    }
]