const contact_detail_form_template = [
    {
        "type": "autocomplete",
        "row_width": "form-group col-md-2",
        "labelClass": "label",
        "label": "Requested By",
        "dataKey": "requestedbyname",
        "inputClass": "input_default width-100",
        "required": true
    },
    {
        "type": "autocomplete",
        "labelClass": "label",
        "row_width": "form-group col-md-2",
        "label": "Requested for",
        "dataKey": "requestedforname",
        "inputClass": "input_default width-100",
        "required": true,
    },
    {
        "type": "select",
        "labelClass": "label",
        "row_width": "form-group col-md-2",
        "label": "Contact Preference",
        "dataKey": "contactpreference",
        "inputClass": "input_default width-100",
        "required": true,
    },
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-2",
        "label": "Email",
        "dataKey": "contactemail",
        "inputClass": "input_default width-100",
        "required": true,
    },
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-2",
        "label": "Phone",
        "dataKey": "contactphonenumber",
        "inputClass": "input_default width-100",
        "required": true,
    }
];


export { contact_detail_form_template }