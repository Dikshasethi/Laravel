export default [
    'model','manufacturer','psamsubtypedescr',
    'assetid','serialid','descrlong','bu',
    'tagnumber','assetbase','assetlocation'
]