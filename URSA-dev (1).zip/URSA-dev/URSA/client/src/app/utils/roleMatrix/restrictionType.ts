export default [
    {
        key: 'Business Unit',
        value: 'businessUnit'
    }
]