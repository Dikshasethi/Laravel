import {
    shipEMOPermission, cancelEMOShipPermission, 
} from '../../utils/config/config';

const form_template = [
    {
        "type": "text",
        "row_width": "form-group col-md-12",
        "labelClass": "label",
        "label": "Notes :",
        "dataKey": "specialinstructions",
        "inputClass": "input_default",
    },
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-4",
        "label": "Project No./Sales Order No. :",
        "dataKey": "projectsalesno",
        "inputClass": "input_default"
    },
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-4",
        "label": "Customer PO No. :",
        "dataKey": "customerponumber",
        "inputClass": "input_default"
    },
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-4",
        "label": "Oceaneering PO No. :",
        "dataKey": "oceaneeringponumber",
        "inputClass": "input_default",
    }

]

const address_template = [
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-4",
        "label": "Shipping Instructions :",
        "dataKey": "shippinginstructions",
        "inputClass": "form-control input_default",
        "required" : false
    },
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-4",
        "label": "Shipping via :",
        "dataKey": "shippingvia",
        "inputClass": "form-control input_default",
        "required" : false
    },
    {
        "type": "date",
        "labelClass": "label",
        "row_width": "form-group col-md-4",
        "label": "Must Arrive By :",
        "dataKey": "shipmentmustarriveby",
        "inputClass": "form-control input_default",
        "required" : false
    },
    {
        "type": "autocomplete",
        "labelClass": "label",
        "row_width": "form-group col-md-6",
        "label": "Destination Location :",
        "dataKey": "destinationlocation",
        "displayText":"destinationlocationdescription",
        "inputClass": "input_default",
        "required" : true
    }, {
        "type": "autocomplete",
        "labelClass": "label",
        "row_width": "form-group col-md-6",
        "label": "Destination Area :",
        "dataKey": "destinationarea",
        "displayText":"destinationareadescription",
        "inputClass": "input_default",
        "required" : true
    },
    {
        "type": "textarea",
        "row_width": "form-group col-md-4",
        "labelClass": "label",
        "label": "Ship from :",
        "dataKey": "shippingfrom",
        "inputClass": "form-control input_bold",
        "required" : true
    },
    {
        "type": "textarea",
        "row_width": "form-group col-md-4",
        "labelClass": "label",
        "label": "Ship to :",
        "dataKey": "shippingto",
        "inputClass": "form-control input_bold",
        "required" : true
    }
]


const action_buttons = [
    {
        label: "Save",
        type: 'saveemo',
        activeClass: 'btn save-btn-1 cust-flt-right my-2',
    },
    {
        label: "Ship",
        type: 'shipemo',
        activeClass: 'btn ship-btn cust-flt-right m-2',
        permissionBasedDisplay : true,
        permission : shipEMOPermission
    },
    {
        label: "Cancel Ship",
        type: 'cancelship',
        activeClass: 'btn cancelship-btn cust-flt-right m-2',
        permissionBasedDisplay : true,
        permission : cancelEMOShipPermission
    },
    {
        label: "Print",
        type: 'printemo',
        activeClass: 'btn print-btn cust-flt-right  m-2 cust-button',
    },
    {
        label: "Close",
        type: 'cancelemo',
        activeClass: 'btn close-btn cust-flt-right m-2 cust-button',
    }
]
export { form_template, address_template, action_buttons }