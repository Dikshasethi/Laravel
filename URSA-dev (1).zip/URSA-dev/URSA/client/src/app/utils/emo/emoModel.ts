class EmoModel {
    projectsalesno: String = '';
    customerponumber: String = '';
    shippinginstructions: String = '';
    specialinstructions: string = '';
    oceaneeringponumber: string = '';
    shippingvia: String = '';
    shipmentmustarriveby: String = '';
    destinationlocation: String = '';
    destinationlocationdescription: String = '';
    destinationarea: String = '';
    destinationareadescription: String = '';
    projectarea: String = '';
    shippingfrom: String = '';
    shippingto: String = '';
    emodetails: EmodetailsModel[] = []
}

class EmodetailsModel {
    itemno: string = '';
    itemtype: string = '';
    businessunit: string = '';
    peoplesoftcheckoutid: string = '';
    serialid: string = '';
    tagnumber: string = '';
    partno: string = '';
    quantity: number = 0;
    uom: string = '';
    description: string = '';
    unitvalue: string = '';
    currency: string = '';
    dimensions: string = '';
    weight: number = 0;
    weightuom: string = '';
    projectnumber: string = '';
    assetid: string = '';
    activity: string = '';
    htscode: string = '';
    eccn: string = '';
    origincountry: string = '';
    extendedvalue: string = ''
}
export { EmoModel, EmodetailsModel };
