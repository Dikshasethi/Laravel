export default {
    emoid : 'emoid',
    emodate : 'emodate',
    projectsalesno : 'projectsalesno',
    customerponumber : 'customerponumber',
    shipmentmustarriveby : 'shipmentmustarriveby',
    createdby : 'createdby',
    shipdate : 'shipdate',
    destinationlocation : 'destinationlocation',
    destinationarea : 'destinationarea',
    shipped: 'shipped',
    createdAt : 'createdAt',
    modifiedby : 'modifiedby',
    updatedAt : 'updatedAt',
    createddate : 'createddate',
    updateddate : 'updateddate',
    assetid : "assetid",
    businessunit : "businessunit"
}
