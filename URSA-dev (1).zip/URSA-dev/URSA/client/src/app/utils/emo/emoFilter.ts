const emoFilter = {
    asset: "Asset",
    container: "Container",
    part: "Part"
}

export { emoFilter }