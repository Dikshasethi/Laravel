const emoDetails = [
    {
        "type": "text",
        "labelClass": "label",
        "label": "Item No.",
        "dataKey": "itemno",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : true
    },
    {
        "type": "dropdown",
        "labelClass": "label",
        "label": "Type",
        "dataKey": "itemtype",
        "class": "form-group col-md-4",
        "editable": false,
        "viewMode": true,
        "uniqueValue" : false,
        "options": [
            {
                "key": "Container",
                "value": "container",
                "requiredField": ["quantity", "description"],
                'disabledField': ["itemno", "partno", "businessunit", "serialid", "tagnumber", "assetid", "peoplesoftcheckoutid", "unitvalue", "currency", "projectnumber", "activity", "htscode", "eccn", "origincountry", "extendedvalue"]
            },
            {
                "key": "Part",
                "value": "part",
                "requiredField": ["partno", "quantity", "unitvalue", "currency"],
                'disabledField': ["itemno", "businessunit", "assetid", "serialid", "tagnumber", "peoplesoftcheckoutid", "projectnumber","assetid", "activity"]
            },
            {
                "key": "Asset",
                "value": "asset",
                'disabledField': ["itemno", "businessunit", "assetid", "serialid", "tagnumber","description", "partno", "peoplesoftcheckoutid", "quantity", "projectnumber"]
            }
        ]
    },
    {
        "type": "text",
        "labelClass": "label",
        "label": "Business Unit",
        "dataKey": "businessunit",
        "class": "form-group col-md-4",
        "editable": false,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "text",
        "labelClass": "label",
        "label": "Checkout ID",
        "dataKey": "peoplesoftcheckoutid",
        "class": "form-group col-md-4",
        "editable": false,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "text",
        "labelClass": "label",
        "label": "Serial Number",
        "dataKey": "serialid",
        "class": "form-group col-md-4",
        "editable": false,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "text",
        "labelClass": "label",
        "label": "Tag Number",
        "dataKey": "tagnumber",
        "class": "form-group col-md-4",
        "editable": false,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "text",
        "labelClass": "label",
        "label": "Part No.",
        "dataKey": "partno",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : true,
    },
    {
        "type": "number",
        "labelClass": "label",
        "label": "Quantity",
        "dataKey": "quantity",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "autocomplete",
        "labelClass": "label",
        "label": "Unit Of Measurement ",
        "dataKey": "uom",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue": false
    },
    {
        "type": "text",
        "labelClass": "label",
        "label": "Description",
        "dataKey": "description",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "text",
        "labelClass": "label",
        "label": "Unit Value",
        "dataKey": "unitvalue",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "dropdown",
        "labelClass": "label",
        "label": "Currency",
        "dataKey": "currency",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
        "options": [
            {
                "key": "Dollar",
                "value": "Dollar",
            },
            {
                "key": "Rupee",
                "value": "Rupee",
            },
            {
                "key": "Euro",
                "value": "Euro"
            }
        ]
    },
    {
        "type": "text",
        "labelClass": "label",
        "label": "Dimension(L*W*H)",
        "dataKey": "dimensions",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "dropdown",
        "labelClass": "label",
        "label": "UOM(of Dimension)",
        "dataKey": "uomdimensions",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
        "options": [
            {
                "key": "MM",
                "value": "MM",
            },
            {
                "key": "CM",
                "value": "CM",
            },
            {
                "key": "METRE",
                "value": "METRE"
            },
            {
                "key": "INCH",
                "value": "INCH"
            },
            {
                "key": "FOOT",
                "value": "FOOT"
            }
        ]
    },
    {
        "type": "number",
        "labelClass": "label",
        "label": "Weight",
        "dataKey": "weight",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "dropdown",
        "labelClass": "label",
        "label": "Weight UOM",
        "dataKey": "weightuom",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
        "options": [
            {
                "key": "Kilogram",
                "value": "Kilogram",
            },
            {
                "key": "Pound",
                "value": "Pound",
            },
            {
                "key": "Gram",
                "value": "Gram"
            }
        ]
    }, {
        "type": "autocomplete",
        "labelClass": "label",
        "label": "Project Number",
        "dataKey": "projectnumber",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "text",
        "labelClass": "label",
        "label": "Asset ID",
        "dataKey": "assetid",
        "class": "form-group col-md-4",
        "editable": false,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "text",
        "labelClass": "label",
        "label": "Activity",
        "dataKey": "activity",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
    },

    {
        "type": "text",
        "labelClass": "label",
        "label": "HTS Code",
        "dataKey": "htscode",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
    }, {
        "type": "text",
        "labelClass": "label",
        "label": "ECCN",
        "dataKey": "eccn",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
    },
    {
        "type": "autocomplete",
        "labelClass": "label",
        "label": "Country of Origin",
        "dataKey": "origincountry",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
        "options": [
            {
                "key": "INDIA",
                "value": "INDIA",
            },
            {
                "key": "USA",
                "value": "USA",
            },
            {
                "key": "U.K",
                "value": "U.K"
            }
        ]
    },
    {
        "type": "text",
        "labelClass": "label",
        "label": "Extended Value",
        "dataKey": "extendedvalue",
        "class": "form-group col-md-4",
        "editable": true,
        "viewMode": true,
        "uniqueValue" : false,
    }
]

export { emoDetails }