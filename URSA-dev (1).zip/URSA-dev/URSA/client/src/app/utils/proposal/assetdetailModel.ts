import {  ProposaldetailsModel } from '../../utils/proposal/proposalModel';

class AssetModel implements ProposaldetailsModel {
   public itemtype: string;
   public projectid: string;
   public oiamsubtype2: string;
   public businessunit: string;
   public productcategory: string;
   public assetid: string;
   public begindate: string;
   public enddate: string;
   public chargerate: number;
   public chargeunit: number;
   public chargeunittype?: string;
   public quantity: number;

    constructor(begindate: string = '', enddate: string= '',
        itemtype: string = '', quantity: number = 0,
        chargerate: number=0, chargeunit: number = 0,
        chargeunittype: string = 'day', productcategory: string = '',
        oiamsubtype2 : string = '',businessunit : string = '', 
        assetid : string = '',projectid: string = ''
        ) {
        this.itemtype= itemtype;
        this.quantity= quantity;
        this.begindate= begindate;
        this.enddate= enddate;
        this.chargerate= chargerate;
        this.chargeunit= chargeunit;
        this.chargeunittype= chargeunittype;
        this.productcategory= productcategory;
        this.projectid= projectid;
        this.oiamsubtype2= oiamsubtype2;
        this.businessunit= businessunit;
        this.assetid= assetid;
    }
}

export { AssetModel };