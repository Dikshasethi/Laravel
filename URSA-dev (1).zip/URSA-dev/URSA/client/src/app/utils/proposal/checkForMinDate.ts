import * as moment from 'moment';

export default function (datakey: string , begindate) {
    if (datakey === 'enddate' && begindate) {
        return moment(begindate).format('YYYY-MM-DD');
    }
      return;
}