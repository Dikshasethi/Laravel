export default [
    {"name":"Contractor", "value": "C"},
    {"name":"Regular", "value": "R"},
    {"name":"Temporary", "value": "T"},
]