interface ProposalModel {
    proposalid?: string;
    businessunit?: string;
    businessunitname?: string;
    group?: string;
    customerid?: string;
    customername?: string;
    crmcustomername? : string;
    crmprobability? : string;
    crmstatus? : string;
    crmcustomerid? : string;
    begindate?: string;
    enddate?: string;
    oicrmbidnumber?: string;
    proposaltitle?: string;
    responsibilitycode?: string;
    responsibilityname?: string;
    cancelled? : boolean;
    cancelledby? : string;
    cancelledbyid? : string;
    canceldate? : string;
    regionname?: string;
    regioncode?: string;
    proposalplannerid?: string;
    proposalplannername?: string;
    serviceline?: string,
    servicelinename?: string,
    scopeofwork?: [],
    subscopeofwork?: [],
    submitstatus?: string;
    activeversion?: boolean;
    comments?: string;
    crewrequirementid?: string;
    crewrequirementtype? : string;
    crewassignmenttype? : string;
    crewrequirementprojectnumber? : string;
    version? : number;
    fromps?: boolean; 
    projectcreated?: boolean;
    createdprojectid? : string;
    finalprojectset?: boolean;
    projectid? : string;
    proposaldetails?: ProposaldetailsModel[] ;
}

interface ProposaldetailsModel {
    _id?: string;
    itemtype?: string;
    pdid?: string;
    assetid?: string;
    businessunit?: string;
    productcategory?: string;
    oiamsubtype2: string;
    quantity?: number;
    projectid?: string;
    begindate?: string;
    enddate?: string;
    chargerate?: number;
    chargeunit?: number;
    chargeunittype?: string;
    crewpositionid? : string;
    crewjobtitles? : [];
    crewtype? : string;
    crewrequiredbydate? : string;
    crewpositionname?: string;
    softreservecount?: number;
}

interface ProposalCrewModel {
    itemtype?: string;
    quantity?: number;
    begindate?: string;
    enddate?: string;
    chargerate?: number;
    chargeunit?: number;
    chargeunittype?: string;
    crewpositionid? : string;
    crewjobtitles ? : [];
    crewtype? : string;
    crewrequiredbydate? : string;
    crewpositionname? : string;
    
}

export { ProposalModel, ProposaldetailsModel, ProposalCrewModel};
