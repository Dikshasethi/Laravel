export default [
    {"name":"Year", "value": "year"},
    {"name":"Month", "value": "month"},
    {"name":"Week", "value": "week"},
    {"name":"Day", "value": "day"},
    {"name":"Hour", "value": "hour"},
]