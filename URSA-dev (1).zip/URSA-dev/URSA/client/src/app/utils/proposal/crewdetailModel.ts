import {  ProposalCrewModel } from '../../utils/proposal/proposalModel';

class CrewModel implements ProposalCrewModel {
   public itemtype?: string;
   public quantity?: number;
   public begindate?: string;
   public enddate?: string;
   public chargerate?: number;
   public chargeunit?: number;
   public chargeunittype?: string;
   public crewpositionid? : string;
   public crewjobtitles ? : [];
   public crewtype? : string;
   public crewrequiredbydate? : string;
   public crewpositionname: string;
   public newDetail? : boolean;

    constructor(begindate: string = '', enddate: string= '',
        itemtype: string = 'crew', quantity: number = 0, 
        chargerate: number=0, chargeunit: number = 0,
        chargeunittype: string = 'day', crewpositionid: string = '',
        crewjobtitles  : [] = [], crewtype : string = '',
        crewrequiredbydate : string = '',newDetail: boolean = true,
        crewpositionname : string = ''
        ) {
        this.itemtype= itemtype;
        this.quantity= quantity;
        this.begindate= begindate;
        this.enddate= enddate;
        this.chargerate= chargerate;
        this.chargeunit= chargeunit;
        this.chargeunittype= chargeunittype;
        this.crewpositionid= crewpositionid;
        this.crewjobtitles = crewjobtitles;
        this.crewtype= crewtype;
        this.crewrequiredbydate= crewrequiredbydate;
        this.crewpositionname = crewpositionname;
        this.newDetail = newDetail;
    }
}

export { CrewModel };