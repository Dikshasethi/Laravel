export default [
    {
        label : 'Assets',
        listName : '',
        tableInFocus : 'proposal',
        stateName : 'proposalDetails',
        checkStatus: ''
    },
    {
        label : 'Crew',
        listName : '',
        tableInFocus : 'crew',
        stateName : 'proposalCrewDetails',
        checkStatus: ''
    },
    {
        label : 'Hard Reserved',
        listName : 'sortedHardReservedAssets',
        tableInFocus : 'checkout',
        stateName : 'hardReservedAssets',
        checkStatus: 'Committed'
    },
    {
        label : 'Checked Out',
        listName : 'sortedCheckedOutAssets',
        tableInFocus : 'checkin',
        stateName : 'checkedOutAssets',
        checkStatus: 'Committed'
    },
    {
        label : 'Checked In',
        listName : 'sortedCheckedInAssets',
        tableInFocus : 'checkedin',
        stateName : 'checkedInAssets',
        checkStatus: 'Committed'
    }
]
