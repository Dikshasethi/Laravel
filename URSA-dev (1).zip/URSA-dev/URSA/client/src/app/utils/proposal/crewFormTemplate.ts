const crew_form_template = [
    {
        "type": "select",
        "row_width": "form-group col-md-2",
        "labelClass": "label",
        "label": "Crew Requirement Type",
        "dataKey": "crewrequirementtype",
        "inputClass": "input_default width-100",
        "required": true

    },
    {
        "type": "select",
        "labelClass": "label",
        "row_width": "form-group col-md-2",
        "label": "Type of Assignment",
        "dataKey": "crewassignmenttype",
        "inputClass": "input_default width-100",
        "required": true
    },
    {
        "type": "text",
        "labelClass": "label",
        "row_width": "form-group col-md-2",
        "label": "Crew Requirement Number",
        "dataKey": "crewrequirementid",
        "inputClass": "input_default width-100",
        "required": true
    }
];


export { crew_form_template }