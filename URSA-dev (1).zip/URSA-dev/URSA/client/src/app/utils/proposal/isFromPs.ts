export default function (proposalObjet={}) {
   if(!proposalObjet['fromps']) {
        return false;
   }
   if(typeof proposalObjet['fromps'] === 'boolean'
    && proposalObjet['fromps'] === true
   ){
        return true;
   }
   if(typeof proposalObjet['fromps'] === 'string'
    && proposalObjet['fromps'].toLowerCase() === 'true'
   ){
        return true;
   }
       return false;
}