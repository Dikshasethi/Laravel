export default [
    {"name":"Asset", "value": "asset"},
    {"name":"Material", "value": "materials"},
]