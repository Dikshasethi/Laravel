export default [
    {"name":"Onshore", "value": "Onshore"},
    {"name":"Offshore", "value": "Offshore"},
]