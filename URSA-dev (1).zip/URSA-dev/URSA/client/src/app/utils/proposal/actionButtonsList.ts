import {
    createProposalPermission, editProposalPermission, commitProposalPermission,
    deleteProposalPermission
} from '../../utils/config/config';
export default [
    {
        label : 'Save Proposal',
        activeClass : 'btn mr-2 create-prop-btn' ,
        type : 'createProposal',
        checkDisplayOnPage : true,
        iconClass : 'fa fa-check-square-o',
        permissionBasedDisplay : true,
        permission : createProposalPermission
    },
    {
        label : 'Save',
        activeClass : 'btn mr-2 save-fooer-btn' ,
        type : 'save',
        checkDisplayOnPage : true,
        iconClass : 'fa fa-floppy-o',
        permissionBasedDisplay : true,
        permission : editProposalPermission
    },
    {
        label : 'Make Active Version',
        activeClass : 'btn mr-2 active-version-btn',
        type : 'activeversion',
        checkDisplayOnPage: true,
        iconClass : 'fa fa-external-link',
    },
    {
        label : 'Return to draft',
        activeClass : 'btn mr-2 active-version-btn',
        type : 'returntodraft',
        checkDisplayOnPage: true,
        iconClass : 'fa fa-undo',
    },
    {
        label: "Overwrite temp. projectid",
        activeClass : 'btn mr-2 active-version-btn',
        iconClass : "fa fa-pencil-square-o",
        type: 'overwritetempprojectid',
        permissionBasedDisplay : true,
        permission : commitProposalPermission
    },
    {
        label: "Cancel Proposal",
        activeClass : 'btn mr-2 prop-close-btn',
        iconClass : "fa fa-close",
        type: 'cancelproposal',
        permissionBasedDisplay : true,
        permission : deleteProposalPermission
    },
    {
        label : 'Mark as Ready',
        activeClass : 'btn mr-2 commit-prposal-btn',
        iconClass : 'fa fa-check-square-o',
        type : 'readyproposal',
        permissionBasedDisplay : true,
        permission : commitProposalPermission
    },
    {
        label : 'Commit Proposal',
        activeClass : 'btn mr-2 commit-prposal-btn',
        iconClass : 'fa fa-check-square-o',
        type : 'commitproposal',
        permissionBasedDisplay : true,
        permission : commitProposalPermission
    },
    {
        label : 'Decommit Proposal',
        activeClass : 'btn mr-2 decommit-proposal-btn',
        type : 'decommitproposal',
        iconClass : 'fa fa-check-square-o',
        permissionBasedDisplay : true,
        permission : commitProposalPermission
    }
]