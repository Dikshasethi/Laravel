export default [
    {
        label : 'Destination Location',
        changeDateRangeButton : false,
        autocomplete : true,
        required : true,
        type : 'text',
        dataKey : 'location',
        viewText : 'locationdescription',
        autoCompleteDisplayKey : 'locationText',
        useIn : ['checkout', 'checkin']
    },
    {
        label : 'Destination Area',
        changeDateRangeButton : false,
        autocomplete : true,
        required : true,
        type : 'text',
        dataKey : 'area',
        viewText : 'areadescription',
        autoCompleteDisplayKey : 'areaText',
        useIn : ['checkout', 'checkin']
    },
    {
        label : 'Custodian',
        changeDateRangeButton : false,
        autocomplete : true,
        required : true,
        type : 'text',
        dataKey : 'custodian',
        viewText : 'custodianname',
        autoCompleteDisplayKey : 'empName',
        useIn : ['checkout', 'checkin']
    },
    {
        label : 'Expected Check In Date',
        changeDateRangeButton : false,
        autocomplete : false,
        type : 'date',
        dataKey : 'checkindate',
        useIn : ['checkin'],
        viewText : 'checkindate',
        hasMax : false,
        maxInFormMap : false,
        maxFormMap : 'checkindate',
        maxDate : new Date().getTime()
    }
]