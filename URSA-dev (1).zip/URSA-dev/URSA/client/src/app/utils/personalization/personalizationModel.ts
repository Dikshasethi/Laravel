class PersonalizationModel {
    appId: String = '';
    name: String = '';
    userId: String = '';
    personalizationType: String = '';
    isDefault: boolean = false;
    data: Object = {};
}

export { PersonalizationModel };
