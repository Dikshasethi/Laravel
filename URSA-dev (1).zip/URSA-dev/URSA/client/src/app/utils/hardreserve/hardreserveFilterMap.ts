export default {
    projectId : "projectnumber",
    projectmanagername : "projectmanagername",
    serialnumber : "serialid",
    tagnumber : "tagnumber",
    assetDesc : "assetdescription",
    startdate : "startdate",
    enddate :"enddate",
    sourcelocation : "sourcelocation",
    sourcearea : "sourcearea",
    proposalnumber : "proposalnumber",
    calloutid : "calloutid",
    category : "assetCategory",
    subtype2 : "subtype2",
    businessunit : "businessunit",
    crmnumber : "crmnumber",
    assetid : "assetid",
    createdby : "createdby"
}