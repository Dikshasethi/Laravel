export const summaryRefinedBy = 'summaryRefinedBy';
export const detailsRefinedBy = 'detailsRefinedBy';
export const assetRefinedByMap = {
    buList : 'Business Unit',
    category : 'Category',
    subtype : 'Subtype 2',
    manufacturer : 'Manufacturer',
    model : 'Model',
    parentunitnumber : 'Parent Unit Number',
    currentLocationFilterList : 'Current Location',
    stateList : 'State',
    statusList : 'Status',
    assetList:'Asset Disposed'
}