import { ExportToCsv } from 'export-to-csv';
let options = {
  fieldSeparator: ',',
  filename: '',
  quoteStrings: '"',
  decimalSeparator: '.',
  showLabels: true,
  showTitle: true,
  useTextFile: false,
  title: '',
  useBom: true,
  useKeysAsHeaders: true,
};

const downlaodcsv = (filename, record) => {
  options = {
    ...options,
    filename
  }
  const csvExporter = new ExportToCsv(options);
  csvExporter.generateCsv(record);
}

export default downlaodcsv;
