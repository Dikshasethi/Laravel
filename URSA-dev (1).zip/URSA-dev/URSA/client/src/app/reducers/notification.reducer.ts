import * as NotificationActions from '../actions/notifications.actions';

const initialState = {
    notificationLoading : false,
    notificationError : false,
    usersNotifications : [],
    updateNotificationLoading : false,
    updateNotificationError : false,
    updateNotificationResponse : {}
}

export default function(state = initialState, action: NotificationActions.NotificationTypes){
    switch(action.type){
        case NotificationActions.NotificationActionTypes.GetUsersNotifications:
            return {
                ...state,
                notificationLoading : true,
                notificationError : false
            }
        case NotificationActions.NotificationActionTypes.SetUsersNotifications:
            return {
                ...state,
                notificationLoading : false,
                notificationError : action.payload['hasError'] || 
                action.payload['error'] ? true : false,
                usersNotifications : action.payload['hasError'] || 
                action.payload['error'] ? state.usersNotifications : 
                action.payload
            }
        case NotificationActions.NotificationActionTypes.UpdateNotification:
            return {
                ...state,
                updateNotificationLoading : true,
                updateNotificationError : false
            }
        case NotificationActions.NotificationActionTypes.SetUpdateNotificationResponse:
            return {
                ...state,
                updateNotificationLoading : false,
                updateNotificationError : action.payload['hasError'] || 
                action.payload['error'] ? true : false,
                updateNotificationResponse : action.payload['hasError'] || 
                action.payload['error'] ? {success : false} : {
                    ...action.payload,
                    success : true
                }
            }
        case NotificationActions.NotificationActionTypes.SetRealTimeNotification:
            return {
                ...state,
                usersNotifications : [
                    action.payload,
                    ...state.usersNotifications
                ]
            }
        case NotificationActions.NotificationActionTypes.SetNotificationReducer:
            return {
                ...state,
                ...action.payload
            }
        default:
            return state;
    }
}