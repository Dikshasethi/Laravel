import * as CheckInOutActions from '../actions/checkInOut.action';
const initialState = {
    checkedin : {
        rows : {},
        splitView : false,
        clientPanel : {},
        allRecordSelected : false
    },
    checkout : {
        rows : {},
        splitView : false,
        clientPanel : {},
        allRecordSelected : false,
        isLoading : false,
        hasError : false,
        submitResults : {}
    },
    checkin : {
        rows : {},
        splitView : false,
        clientPanel : {},
        allRecordSelected : false,
        isLoading : false,
        hasError : false,
        submitResults : {}
    },
    projectStatusMap : {},
    dateValidationResults : [],
    dateValidationLoading : false,
    dateValidationError : false,
    sort: {
        checkout: {},
        checkin: {},
        checkedin: {},
        proposal: {
            "createdAt" : -1
        },
        emo: {},
        receiving: {},
        assetlogs: {},
        cart: {},
        watchlist: {},
        workorderhistory: {},
        certificatehistory:{}
    }
}

export default function(state = initialState, action: CheckInOutActions.CheckInOutActions){
    switch(action.type){
        case CheckInOutActions.CheckInOutActionTypes.SetCheckInOut:
            return {
                ...state,
                [action.payload.field] : action.payload.value
            }
        case CheckInOutActions.CheckInOutActionTypes.GetCheckoutDateValidations:
            return {
                ...state,
                dateValidationLoading : true,
                dateValidationError : false,
                dateValidationResults : []
            }
        case CheckInOutActions.CheckInOutActionTypes.SetCheckoutDateValidations:
            return {
                ...state,
                dateValidationLoading : false,
                dateValidationError : action.payload['hasError'] || 
                action.payload['error'] ? true : false,
                dateValidationResults : action.payload['hasError'] || 
                action.payload['error'] ? [] : action.payload
            }
        case CheckInOutActions.CheckInOutActionTypes.CheckoutAssets:
            return {
                ...state,
                checkout : {
                    ...state['checkout'],
                    isLoading : true,
                    hasError : false,
                    submitResults : {}
                }
            };
        case CheckInOutActions.CheckInOutActionTypes.SetCheckoutResults:
            return {
                ...state,
                checkout : {
                    ...state['checkout'],
                    isLoading : false,
                    hasError : action.payload['hasError'] || 
                    action.payload['error'] ? true : false,
                    submitResults : action.payload['hasError'] || 
                    action.payload['error'] ? {} : action.payload 
                }
            }; 
        case CheckInOutActions.CheckInOutActionTypes.EditCheckout:
            return {
                ...state,
                checkin : {
                    ...state['checkin'],
                    isLoading : true,
                    hasError : false,
                    submitResults : {}
                }
            };
        case CheckInOutActions.CheckInOutActionTypes.SetEditCheckoutResults:
            return {
                ...state,
                checkin : {
                    ...state['checkin'],
                    isLoading : false,
                    hasError : action.payload['hasError'] || 
                    action.payload['error'] ? true : false,
                    submitResults : action.payload['hasError'] || 
                    action.payload['error'] ? {} : action.payload 
                }
            }; 
        case CheckInOutActions.CheckInOutActionTypes.CancelHardReservations:
            return {
                ...state,
                checkout : {
                    ...state['checkout'],
                    isLoading : true,
                    hasError : false,
                    submitResults : {}
                }
            };
        case CheckInOutActions.CheckInOutActionTypes.SetCancelHardReservationResults:
            return {
                ...state,
                checkout : {
                    ...state['checkout'],
                    isLoading : false,
                    hasError : action.payload['hasError'] || 
                    action.payload['error'] ? true : false,
                    submitResults : action.payload['hasError'] || 
                    action.payload['error'] ? {} : action.payload 
                }
            }; 
        case CheckInOutActions.CheckInOutActionTypes.GetEditHardReserve:
            return {
                ...state,
                checkout : {
                    ...state['checkout'],
                    isLoading : true,
                    hasError : false,
                    submitResults : {}
                }
            }
        case CheckInOutActions.CheckInOutActionTypes.SetEditHardReserve:
            return {
                ...state,
                checkout: {
                    ...state['checkout'],
                    isLoading: false,
                    hasError: action.payload['hasError'] ||
                        action.payload['error'] ? true : false,
                    submitResults: action.payload['hasError'] ||
                        action.payload['error'] ? {} : action.payload
                }
            }
        
        case CheckInOutActions.CheckInOutActionTypes.CheckinAssets:
            return {
                ...state,
                checkin : {
                    ...state['checkin'],
                    isLoading : true,
                    hasError : false,
                    submitResults : {}
                }
            };
        case CheckInOutActions.CheckInOutActionTypes.SetCheckinResults:
            return {
                ...state,
                checkin : {
                    ...state['checkin'],
                    isLoading : false,
                    hasError : action.payload['hasError'] || 
                    action.payload['error'] ? true : false,
                    submitResults : action.payload['hasError'] || 
                    action.payload['error'] ? {} : action.payload 
                }
            }; 
        case CheckInOutActions.CheckInOutActionTypes.CancelCheckout:
            return {
                ...state,
                checkin : {
                    ...state['checkin'],
                    isLoading : true,
                    hasError : false,
                    submitResults : {}
                }
            };
        case CheckInOutActions.CheckInOutActionTypes.SetCancelCheckoutResults:
            return {
                ...state,
                checkin : {
                    ...state['checkin'],
                    isLoading : false,
                    hasError : action.payload['hasError'] || 
                    action.payload['error'] ? true : false,
                    submitResults : action.payload['hasError'] || 
                    action.payload['error'] ? {} : action.payload 
                }
            }; 
        case CheckInOutActions.CheckInOutActionTypes.ResetCheckInOut:
            return initialState; 
        case CheckInOutActions.CheckInOutActionTypes.SetSorting:
            const { componentType, dataKey } = action.payload;
            if (state['sort'][componentType][dataKey] === -1) {
                delete state['sort'][componentType][dataKey];
                return {
                    ...state
                }
            } else if (state['sort'][componentType][dataKey] === 1) {
                return {
                    ...state,
                    sort: {
                        ...state.sort,
                        [componentType]: {
                            ...state.sort[componentType],
                            [dataKey]: -1
                        }
                    }
                }
            } else {
                return {
                    ...state,
                    sort: {
                        ...state.sort,
                        [componentType]: {
                            ...state.sort[componentType],
                            [dataKey]: 1
                        }
                    }
                }
            }
        case CheckInOutActions.CheckInOutActionTypes.ReSetSorting:
            return {
                ...state,
                sort: {
                    checkout: {},
                    checkin: {},
                    checkedin: {},
                    proposal:{},
                    emo:{},
                    receiving:{},
                    assetlogs:{},
                    cart:{},
                    watchlist: {},
                    workorderhistory:{},
                    certificatehistory:{}
                }
            }
        default:
            return state;
    }
}