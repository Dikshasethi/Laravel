import * as ReceivingActions from '../actions/receiving.actons';

const initialState = {
    receivingData: {},
    addedReceivingData: {},
    receivingRecordInfo: {},
    receivingPath: '',
    receivingMode: false,
    receivingList: [],
    receivingCount: 0,
    receivingListIsLoading: false,
    receivingListError: false,
    onScrollLoading: false

}

export default function (state = initialState, action: ReceivingActions.ReceivingTypes) {
    switch (action.type) {
        case ReceivingActions.ReceivingActionTypes.CreateReceivingData:
            return {
                ...state,
                payload: action.payload,
                receivingData: {
                    receivingFetchisLoading: true
                }
            }
        case ReceivingActions.ReceivingActionTypes.SetReecivingData:
            return {
                ...state,
                receivingData: {
                    receivingData: action.payload,
                    receivingFetchisLoading: false
                },
            }
        case ReceivingActions.ReceivingActionTypes.GetReceivingData:
            return {
                ...state,
                payload: action.payload,
                receivingData: {
                    receivingFetchisLoading: true
                }
            }
        case ReceivingActions.ReceivingActionTypes.UpdateReceivingData:
            return {
                ...state,
                payload: action.payload,
                receivingData: {
                    receivingFetchisLoading: true
                }
            }
        case ReceivingActions.ReceivingActionTypes.Received:
            return {
                ...state,
                payload: action.payload,
                receivingData: {
                    receivingFetchisLoading: true
                }
            }
        case ReceivingActions.ReceivingActionTypes.SetReceivingMode:
            let addedReceivingData = state.addedReceivingData && state.addedReceivingData['addedReceivingData'] ? state.addedReceivingData['addedReceivingData'] : [];
            if (action.payload.isReceivingDataMerged) {
                addedReceivingData = [...addedReceivingData, ...action.payload.receivingRecord]
            } else {
                addedReceivingData = [...action.payload.receivingRecord]
            }
            return {
                ...state,
                addedReceivingData: {
                    addedReceivingData: addedReceivingData,
                    receivingHeaderRecord: action.payload.isReceivingDataMerged ? state.addedReceivingData['receivingHeaderRecord'] : action.payload.receivingHeaderRecord,
                    receivingMode: action.payload.receivingMode,
                    receivingPath: action.payload.receivingPath,
                    previousUrl: action.payload.previousUrl
                },
            }
        case ReceivingActions.ReceivingActionTypes.SetReceivingRecord:
            return {
                ...state,
                receivingRecordInfo: {
                    receivingRecordInfo: action.payload
                }
            }
        case ReceivingActions.ReceivingActionTypes.ResetReceivingRecord:
            return {
                ...state,
                receivingRecordInfo: {}
            }

        case ReceivingActions.ReceivingActionTypes.GetReceivingList:
            return {
                ...state,
                receivingListIsLoading: true,
                receivingListError: false,
                onScrollLoading: action.payload.skip ? true : false
            }
        case ReceivingActions.ReceivingActionTypes.SetReceivingList:
            let records = action.payload.results || [];
            return {
                ...state,
                receivingListIsLoading: false,
                receivingListError: action.payload.hasError ? true : false,
                receivingList: action.payload.hasError ? [] : [...state.receivingList, ...records],
                receivingCount: action.payload.total_count,
            }
        case ReceivingActions.ReceivingActionTypes.ResetReceivingList:
            return {
                ...state,
                receivingListIsLoading: false,
                receivingListError: false,
                receivingList: [],
                receivingCount: 0,
            }
        case ReceivingActions.ReceivingActionTypes.ResetReceivingMode:
            return initialState;
        default:
            return state;
    }
}