import * as RefinedByActions from '../actions/refinedBy.actions';
const initialState = {
    summaryRefinedBy : {
        lastFilterSectionClicked : [],
        listStateTracker : {},
        clickTracker : {}
    },
    detailsRefinedBy : {
        lastFilterSectionClicked : [],
        listStateTracker : {},
        clickTracker : {}
    }
}

export default function(state = initialState, action: RefinedByActions.RefinedByTypes) {
    switch(action.type){
        case RefinedByActions.RefinedByActionTypes.SetFilters:
            let payload = action.payload;
            return {
                ...state, [payload.key] : payload.value
            }
        case RefinedByActions.RefinedByActionTypes.ResetFilters:
            if(sessionStorage.getItem('defaultRefiendByPersonalization')){
                sessionStorage.removeItem('defaultRefiendByPersonalization') 
            }
            return {
                ...state,
                summaryRefinedBy : {
                    lastFilterSectionClicked : [],
                    listStateTracker : {},
                    clickTracker : {}
                },
                detailsRefinedBy : {
                    lastFilterSectionClicked : [],
                    listStateTracker : {},
                    clickTracker : {}
                }
            }
        case RefinedByActions.RefinedByActionTypes.SetRefinedByField:
            let update = {...action.payload};
            let {
                refinedByNgrxKey='',
                field='', value
            } = update;
            return {
                ...state,
                [refinedByNgrxKey] : {
                    ...state[refinedByNgrxKey],
                    [field] : value
                }
            }
        default:
            return state;
    }
}