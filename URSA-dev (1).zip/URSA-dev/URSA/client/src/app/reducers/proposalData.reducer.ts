import * as ProposalDataActions from '../actions/proposalData.action'
import * as _ from 'lodash';
import update from 'immutability-helper';

const initialState = {
    proposalNewData : {
        proposalData : {},
        hardReservedAssets : [],
        checkedOutAssets : [],
        checkedInAssets : [],
        proposalDataLoading : false,
        proposalDataError : false
    },
    createdProposalData:{ 
        addProposalData: {}, 
        addProposalLoading: false
    },
    proposalModeObj: {
        isProposalPageType : '',
        isProposalMode: false,
        proposalid: '',
        indexToAdd: -1,
        detailTobeDeletedFromCart: {}
    },
    proposalVersion: {
      proposalVersionsData : {},
      proposalVersionLoading: false
    },
    crewRequirementType: {
        crewRequirementTypes: {},
        crewRequirementTypesLoading: false,
    },
    crewPostition: {
        crewPostitions: {},
        crewpositionsLoading: false
    },
    crewJobTitle: {
        crewjobtitlesLoading: false
    },
    productProposalCartData: [],
    errorState: {
        error: false,
        error_message: null
    }
}

export default function(state = initialState, action: ProposalDataActions.ProposalDataTypes) {
    switch(action.type){
        case ProposalDataActions.ProposalDataActionTypes.GetProposalData:
            return {
                ...state, 
                payload : action.payload, 
                proposalNewData : {
                    ...state.proposalNewData,
                    proposalDataLoading : true,
                    proposalDataError : false
                },
                createdProposalData:{ 
                    addProposalData: {}, 
                    addProposalLoading: false
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case ProposalDataActions.ProposalDataActionTypes.SetProposalData:
            return {
                ...state, 
                proposalNewData : {
                    proposalData : action.payload.proposal || {},
                    hardReservedAssets : action.payload.hardReservedAssets || [],
                    checkedOutAssets : action.payload.checkedOutAssets || [],
                    checkedInAssets : action.payload.checkedInAssets || [],
                    proposalDataLoading : false,
                    proposalDataError : action.payload.error || action.payload.hasError ? 
                    true : false
                },
                createdProposalData:{ 
                    addProposalData: {}, 
                    addProposalLoading: false
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }
    
        case ProposalDataActions.ProposalDataActionTypes.DeleteProposalData:
            const propdetailCopy = state.proposalNewData.proposalData['proposaldetails'] || []
            const index = action.payload.index;
            if(propdetailCopy.length > 0 && index > -1) { 
                const filteredAssets =  propdetailCopy.filter((detailObj) => {
                    return   detailObj.itemtype !== 'crew';
                 });
                 const filteredCrew =  propdetailCopy.filter((detailObj) => {
                    return   detailObj.itemtype === 'crew';
                 });
                 let newFilteredAssetArray = filteredAssets;
                 let newFilteredCrewArray  = filteredCrew;

                 if(action.payload.hasOwnProperty('isDeleteCrew') && action.payload.isDeleteCrew) {
                    newFilteredCrewArray= update(filteredCrew, { $splice: [[action.payload.index, 1]] } )
                 }else{
                    newFilteredAssetArray = update(filteredAssets, { $splice: [[action.payload.index, 1]] } )
                 }
                 
                const newFilteredArray = [
                    ...newFilteredAssetArray,
                    ...newFilteredCrewArray
                ]
                return {
                    ...state, 
                    proposalNewData: {
                        proposalData: {
                            ...state.proposalNewData.proposalData,
                            proposaldetails: newFilteredArray
                        },
                        hardReservedAssets : [...state.proposalNewData.hardReservedAssets],
                        checkedOutAssets : [...state.proposalNewData.checkedOutAssets],
                        checkedInAssets : [...state.proposalNewData.checkedInAssets],
                        proposalDataLoading : false,
                        proposalDataError : false
                    },
                    createdProposalData:{ 
                         addProposalData: {}, 
                        addProposalLoading: false
                    },
                    errorState: {
                        error: false,
                        error_message: null
                    }
                } 
            }
            return {
                ...state
            } 

        case ProposalDataActions.ProposalDataActionTypes.SetProposalMode:
            return {
                    ...state,
                    proposalModeObj: {
                        isProposalPageType : action.payload.isProposalPageType,
                        isProposalMode: true,
                        proposalid: action.payload.proposalid,
                        indexToAdd: action.payload.indexToAdd,
                        detailTobeDeletedFromCart: action.payload.detailTobeDeletedFromCart
                    },
                    createdProposalData:{ 
                         addProposalData: {}, 
                        addProposalLoading: false
                    },
                    errorState: {
                        error: false,
                        error_message: null
                    }
            }

        case ProposalDataActions.ProposalDataActionTypes.ReSetProposalMode:
            return {
                    ...state,
                    proposalModeObj: {
                        isProposalPageType: '',
                        isProposalMode: false,
                        proposalid: '',
                        detailTobeDeletedFromCart: {},
                        indexToAdd: -1

                    },
                    createdProposalData:{ 
                         addProposalData: {}, 
                        addProposalLoading: false
                    },
                    errorState: {
                        error: false,
                        error_message: null
                    }
            }
            
        case ProposalDataActions.ProposalDataActionTypes.SetProductProposalCartData:
            let cartData = JSON.parse(JSON.stringify(state['productProposalCartData']));
            let cartIndex = cartData.findIndex(cartValue => {
                if(cartValue.view === 'productSummaryList'){
                    return cartValue.productcategory === action.payload.productcategory && 
                    cartValue.businessunit === action.payload.businessunit &&
                    cartValue.oiamsubtype2 === action.payload.oiamsubtype2;
                }else if(cartValue.view === 'productList'){ 
                    return cartValue.assetid === action.payload.assetid && 
                    cartValue.businessunit === action.payload.businessunit &&
                    cartValue.oiamsubtype2 === action.payload.oiamsubtype2;  
                }
            });
            if(cartIndex > -1) {
                let removedItem = cartData.splice(cartIndex, 1);
            }else {
                cartData = [...state['productProposalCartData'], action.payload]
            }

            return {
                ...state,
                productProposalCartData : cartData
            }

        case ProposalDataActions.ProposalDataActionTypes.DeleteProductProposalCartData:
            const propcartCopy =  state['productProposalCartData'];
            const propCartIndex = propcartCopy.findIndex(cartDetail => {
                return cartDetail.assetid === action.payload.assetid && 
                cartDetail.businessunit === action.payload.businessunit &&
                cartDetail.oiamsubtype2 === action.payload.oiamsubtype2 &&
                cartDetail.productcategory === action.payload.productcategory &&
                cartDetail.view === action.payload.view
            });
            const newFilteredArray = (propCartIndex > -1) ?
            update(propcartCopy, { $splice: [[propCartIndex, 1]] } ) :
            [...propcartCopy];

            return {
                ...state, 
                productProposalCartData : newFilteredArray
            }
            
        case ProposalDataActions.ProposalDataActionTypes.SetAssetDataInProposalDeatil:
           let assetDetailCopy = state.proposalNewData.proposalData['proposaldetails'] || [];
           let assetDetails = [];
           let crewDetails = [];
           let assetDetailsToAdd = action.payload.detailToBeAdded;
           const indexToBeSliced = action.payload.indexToBeSliced
           if(assetDetailsToAdd.length > 0) {
            const filteredAssets =  assetDetailCopy.filter((detailObj) => {
                return   detailObj.itemtype !== 'crew';
             });
             const filteredCrew =  assetDetailCopy.filter((detailObj) => {
                return   detailObj.itemtype === 'crew';
             });
                assetDetails = filteredAssets;
                crewDetails = filteredCrew;
                if(indexToBeSliced > -1) {
                      // to clone values from row selected to data to be appended...
                    const rowToBesliced = filteredAssets[indexToBeSliced];
                    const newAssetDetailsToAdd  =  assetDetailsToAdd.map((detailObject) => {
                        return {
                            ...detailObject,
                            begindate: rowToBesliced.begindate || '',
                            enddate: rowToBesliced.enddate || '',
                            chargerate: rowToBesliced.chargerate || 0,
                            chargeunit: rowToBesliced.chargeunit || 0,
                            chargeunittype: rowToBesliced.chargeunittype || 'day',
                            coQty: rowToBesliced.coQty || 0,
                            hrQty: rowToBesliced.hrQty || 0,
                            projectid: rowToBesliced.projectid || '',
                            quantity: (detailObject.assetid) ? 1 : rowToBesliced.quantity || 0,
                        }
                    });
                   
                    assetDetails   =  update(filteredAssets, { $splice: [[indexToBeSliced, 1, ...newAssetDetailsToAdd]] } );
                    assetDetails =  _.uniqBy(assetDetails, obj => {
                            return [obj.assetid, obj.businessunit, obj.oiamsubtype2, obj.productcategory, obj.view].join()
                    });
                }else{
                    if(action.payload.hasOwnProperty('isAddCrew') && action.payload.isAddCrew) {
                        crewDetails = [...filteredCrew, ...assetDetailsToAdd]
                    }else{
                        assetDetails = [...filteredAssets, ...assetDetailsToAdd]
                    }
                }

                const newAddedProposalDetails = [
                    ...assetDetails,
                    ...crewDetails
                ]
     
                return {
                    ...state, 
                    proposalNewData: {
                        proposalData: {
                            ...state.proposalNewData.proposalData,
                            proposaldetails: newAddedProposalDetails
                        },
                        hardReservedAssets : [...state.proposalNewData.hardReservedAssets],
                        checkedOutAssets : [...state.proposalNewData.checkedOutAssets],
                        checkedInAssets : [...state.proposalNewData.checkedInAssets],
                        proposalDataLoading : false,
                        proposalDataError : false
                    },
                    createdProposalData:{ 
                         addProposalData: {}, 
                        addProposalLoading: false
                    },
                    errorState: {
                        error: false,
                        error_message: null
                    }
                }
            }else{
               return {
                   ...state
               }
           }

           case ProposalDataActions.ProposalDataActionTypes.SetProposalCartData:
            let proposalDetailsCopy = state.proposalNewData.proposalData['proposaldetails'] || [];
            const newProposalCartData = []
            if(proposalDetailsCopy && proposalDetailsCopy.length > 0) {
                for (let detailObj of  proposalDetailsCopy) {
                    if(detailObj.itemtype === 'asset'){
                        let obj = {};
                        if(detailObj.assetid){
                             obj = {
                                ...detailObj,
                                view:   'productList', //keyword view to diiferentiate from which view
                                proposalMode:  false 
                            }
   
                        }else {
                            obj = {
                               ...detailObj,
                               view:   'productSummaryList', //keyword view to diiferentiate from which view
                               proposalMode:  false 
                           }
                        }
                        newProposalCartData.push(obj);
                    }

                }
            }
            const newPropCartData = newProposalCartData.length > 0 ? newProposalCartData: state.productProposalCartData
            return {
                ...state,
                productProposalCartData: newPropCartData
            }            

           case ProposalDataActions.ProposalDataActionTypes.SetProposalCartWithProposalMode:
            return {
                ...state,
                productProposalCartData : action.payload.cartData
            }

        case ProposalDataActions.ProposalDataActionTypes.SetError: {
            return {
                ...state,
                proposalNewData:{
                    proposalData: {...state.proposalNewData.proposalData},
                    hardReservedAssets : [...state.proposalNewData.hardReservedAssets],
                    checkedOutAssets : [...state.proposalNewData.checkedOutAssets],
                    checkedInAssets : [...state.proposalNewData.checkedInAssets],
                    proposalDataLoading : false,
                    proposalDataError : false
                },
                createdProposalData:{ 
                    addProposalData: {}, 
                    addProposalLoading: false
                },
                proposalModeObj: {
                    isProposalPageType: '',
                    isProposalMode: false,
                    proposalid: ''
                },
                proposalVersion: {
                    proposalVersionsData : {...state.proposalVersion.proposalVersionsData},
                    proposalVersionLoading: false
                },
                crewRequirementType: {
                    crewRequirementTypes: {...state.crewRequirementType.crewRequirementTypes},
                    crewRequirementTypesLoading: false
                },
                crewPostition: {
                    crewPostitions: {...state.crewPostition.crewPostitions},
                    crewpositionsLoading: false
                },
                crewJobTitle: {
                    crewjobtitlesLoading: false
                },
                errorState: {
                    error: true,
                    error_message: action.payload
                }
            }
        }

        case ProposalDataActions.ProposalDataActionTypes.CreateProposal:
            return {
               ...state,
                createdProposalData:{ 
                    addProposalData: {}, 
                    addProposalLoading: true,
                }
            }

        case ProposalDataActions.ProposalDataActionTypes.EditProposal:
            return {
                ...state,
                createdProposalData:{ 
                    addProposalData: {}, 
                    addProposalLoading: true,
                }
            }

        case ProposalDataActions.ProposalDataActionTypes.UpdateProposalStatus:
            return {
                ...state,
                createdProposalData:{ 
                    addProposalData: {}, 
                    addProposalLoading: true,
                }
        }

        case ProposalDataActions.ProposalDataActionTypes.ChangeProposalVersion:
            return {
                ...state,
                createdProposalData:{ 
                    addProposalData: {}, 
                    addProposalLoading: true,
                }
            }

        case ProposalDataActions.ProposalDataActionTypes.SetCreatedProposalData:
            return {
               ...state,
                createdProposalData:{ 
                    addProposalData: action.payload, 
                    addProposalLoading: false
                },
                errorState: {
                    error: false,
                    error_message: null
                }
        }

        case ProposalDataActions.ProposalDataActionTypes.GetProposalVersions:
            return {
                ...state,
                proposalVersion: {
                    proposalVersionsData : {},
                    proposalVersionLoading: true
                },
                createdProposalData:{ 
                    addProposalData: {}, 
                    addProposalLoading: false
                }
        }

        case ProposalDataActions.ProposalDataActionTypes.SetProposalVersions:
            return {
                ...state,
                proposalVersion: {
                    proposalVersionsData : action.payload,
                    proposalVersionLoading: false
                }
        }

        case ProposalDataActions.ProposalDataActionTypes.GetCrewRequirementType:
            return {
                ...state,
                crewRequirementType: {
                    crewRequirementTypes: {},
                    crewRequirementTypesLoading: true,
                }
            }

            case ProposalDataActions.ProposalDataActionTypes.SetCrewRequirementType:
                return {
                    ...state,
                    crewRequirementType: {
                        crewRequirementTypes: action.payload,
                        crewRequirementTypesLoading: false,
                    }
                }
            
            case ProposalDataActions.ProposalDataActionTypes.GetCrewPositions:
                return {
                    ...state,
                    crewPostition: {
                        crewPostitions: [],
                        crewpositionsLoading: true
                    }
                }
        
            case ProposalDataActions.ProposalDataActionTypes.SetCrewPositions:
                return {
                    ...state,
                    crewPostition: {
                        crewPostitions: action.payload,
                        crewpositionsLoading: false
                    }
                }

            case ProposalDataActions.ProposalDataActionTypes.GetJobTitles:
                return {
                    ...state,
                    crewJobTitle: {
                        crewJobTitles: [],
                        crewjobtitlesLoading: true
                    }
                }
        
            case ProposalDataActions.ProposalDataActionTypes.SetJobTitlesInProposalDetail:
                let poposalDetailCopy = state.proposalNewData.proposalData['proposaldetails'] || [];
                const filteredAssets =  poposalDetailCopy.filter((detailObj) => {
                    return   detailObj.itemtype !== 'crew';
                 });
                 const filteredCrew =  poposalDetailCopy.filter((detailObj) => {
                    return   detailObj.itemtype === 'crew';
                 });

                const crewjobTitles = action.payload.result.data;
                filteredCrew[action.payload.crewJobtitleAppendIndex]['crewjobtitles'] = crewjobTitles;

                const newAddedProposalDetails = [
                    ...filteredAssets,
                    ...filteredCrew
                ]
                return {
                    ...state,
                    proposalNewData: {
                        proposalData: {
                            ...state.proposalNewData.proposalData,
                            proposaldetails: newAddedProposalDetails
                        },
                        hardReservedAssets : [...state.proposalNewData.hardReservedAssets],
                        checkedOutAssets : [...state.proposalNewData.checkedOutAssets],
                        checkedInAssets : [...state.proposalNewData.checkedInAssets],
                        proposalDataLoading : false,
                        proposalDataError : false
                    },
                    crewJobTitle: {
                        crewjobtitlesLoading: false,
                    }
                }

            case ProposalDataActions.ProposalDataActionTypes.RemoveJobTitlesInProposalDetail:
                let poposalDetailCopyData = state.proposalNewData.proposalData['proposaldetails'] || [];
                const filteredAssetsData =  poposalDetailCopyData.filter((detailObj) => {
                    return   detailObj.itemtype !== 'crew';
                 });
                 const filteredCrewData =  poposalDetailCopyData.filter((detailObj) => {
                    return   detailObj.itemtype === 'crew';
                 });

                const filteredcrewjobtitleidsarray = filteredCrewData[action.payload.index]['crewjobtitles'].filter((jobTitleObj) => {
                    return  jobTitleObj.jobCode !== action.payload.jobtitleaction.jobCode
                 })

                filteredCrewData[action.payload.index]['crewjobtitles'] = filteredcrewjobtitleidsarray;
                
                const newAddedJobTitleProposalDetails = [
                    ...filteredAssetsData,
                    ...filteredCrewData
                ]

                return {
                    ...state,
                    proposalNewData: {
                        proposalData: {
                            ...state.proposalNewData.proposalData,
                            proposaldetails: newAddedJobTitleProposalDetails
                        },
                        hardReservedAssets : [...state.proposalNewData.hardReservedAssets],
                        checkedOutAssets : [...state.proposalNewData.checkedOutAssets],
                        checkedInAssets : [...state.proposalNewData.checkedInAssets],
                        proposalDataLoading : false,
                        proposalDataError : false
                    },
                    crewJobTitle: {
                        crewjobtitlesLoading: false,
                    }
                }

        case ProposalDataActions.ProposalDataActionTypes.CreateCrewDraft:
            return {
                ...state,
                createdProposalData:{ 
                    addProposalData: {}, 
                    addProposalLoading: true,
                }
            }

        case ProposalDataActions.ProposalDataActionTypes.CancelProposal:
            return {
                ...state,
                createdProposalData:{ 
                    addProposalData: {}, 
                    addProposalLoading: true,
                }
            }

        case ProposalDataActions.ProposalDataActionTypes.SetPermanentProjectId:
        return {
            ...state,
            createdProposalData:{ 
                addProposalData: {}, 
                addProposalLoading: true,
            }
        }

        case ProposalDataActions.ProposalDataActionTypes.ResetProductProposalCartData:
            return initialState;
        default:
            return state;
    }
}