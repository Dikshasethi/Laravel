import * as UserActions from '../actions/user.actions';

let storedView = localStorage.getItem('userViewPreference');
const initialState = {
    userViewPreference : storedView && ['mixed', 'summary', 'details', 'hierarchy','utilization', 'forecast'].includes(storedView) ? storedView : 'details',
    blockSearch : false,
    previousView : ''
}

export default function (state = initialState, action: UserActions.UserTypes){
    switch(action.type){
        case UserActions.UserActionTypes.SetViewPreference:
            localStorage.setItem('userViewPreference', action.payload);
            return {
                ...state, 
                userViewPreference : action.payload, 
                blockSearch : false,
                previousView : state.userViewPreference
            }
        case UserActions.UserActionTypes.BlockSearchChangeView:
            localStorage.setItem('userViewPreference', action.payload);
            return {...state, blockSearch : true, userViewPreference : action.payload}
        case UserActions.UserActionTypes.RemoveBlockSearch:
            return {
                ...state,
                blockSearch : false
            }
        default:
            return state;
    }
}