import * as PersonalizationDataActions from '../actions/refinedBy-personalization.action';
const initialState = {
    personalizationRefinedByData:{
        personalizationRefinedByData: [],
        personalizationRefinedByLoading : false,
        personalizationRefinedByError: false,
        totalCount: 0
    },
    addedPersonalizationRefinedByData:{ 
        addedPersonalizationRefinedByData: {}, 
        addedPersonalizationRefinedByDataLoading: false
    },
    deletedPersonalizationRefinedByData: {
        deletedPersonalizationRefinedByData: [], 
        deletedPersonalizationRefinedByLoading: false
    },
    updatePersonalizationRefinedByData: {
        updatePersonalizationRefinedByData:[],
        updatePersonalizationRefinedByDataLoading:false,
    },
    nameCheckPersonalizationRefinedBy:{},
    errorState: {
        error: false,
        error_message: null
    }
}

export default function(state = initialState, action: PersonalizationDataActions.RefinedByPersonalizationActions) {

    switch(action.type){
        
        case PersonalizationDataActions.PersonalizationActionTypes.GetPersonalizationRefinedByData:
            return {
                ...state,
                personalizationRefinedByData:{
                personalizationRefinedByData: [...state.personalizationRefinedByData.personalizationRefinedByData],
                    personalizationRefinedByLoading: true,
                    personalizationRefinedByError: false,
                    totalCount: state.personalizationRefinedByData.totalCount
                },
                errorState: {
                    error: false,
                    error_message: null
                }
                
            }
        case PersonalizationDataActions.PersonalizationActionTypes.SetPersonalizationRefinedByData:
            return {
                ...state,
               personalizationRefinedByData:{
                    personalizationRefinedByData: action.payload.hasError ? [] : [...state.personalizationRefinedByData.personalizationRefinedByData, ...action.payload['results']],
                    personalizationRefinedByLoading : false,
                    personalizationRefinedByError: action.payload.hasError ? true : false,
                    totalCount : action.payload.hasError ? state.personalizationRefinedByData.totalCount : 
                    action.payload['total_count']
                },
                addedPersonalizationRefinedByData:{ 
                    addedPersonalizationRefinedByData: {}, 
                    addedPersonalizationRefinedByDataLoading: false
                },
                deletedPersonalizationRefinedByData: {
                    deletedPersonalizationRefinedByData: [], 
                    deletedPersonalizationRefinedByLoading: false
                },
                updatePersonalizationRefinedByData:{
                    updatePersonalizationRefinedByData:[],
                    updatePersonalizationRefinedByDataLoading:false   
                },
                nameCheckPersonalizationRefinedBy:{},
                errorState: {
                    error: false,
                    error_message: null
                }
            }

        case PersonalizationDataActions.PersonalizationActionTypes.DeleteFromPersonalizationDataList:
            return {
                ...state,
                payload : action.payload, 
                personalizationRefinedByData:{
                    ...state.personalizationRefinedByData,
                    personalizationRefinedByLoading: true,
                },
                deletedPersonalizationRefinedByData: {
                     deletedPersonalizationRefinedByData: [], 
                     deletedPersonalizationRefinedByLoading: true
                 },
                errorState: {
                    error: false,
                    error_message: null
                }     
         }

         case PersonalizationDataActions.PersonalizationActionTypes.SetDeletedPersonalizationData:
            return {
                ...state,
                personalizationRefinedByData:{
                   personalizationRefinedByData: [],
                    personalizationRefinedByLoading: false,
                    personalizationRefinedByError: false,
                },
                deletedPersonalizationRefinedByData: {
                    deletedPersonalizationRefinedByData: action.payload, 
                    deletedPersonalizationRefinedByLoading: false
                },
                errorState: {
                    error: false,
                    error_message: null
                }     
         }

         case PersonalizationDataActions.PersonalizationActionTypes.AddPersonalizationRefinedByData:
            return {
                ...state,
                payload : action.payload, 
                personalizationRefinedByData:{
                    ...state.personalizationRefinedByData,
                    personalizationRefinedByLoading: true,
                },
                addedPersonalizationRefinedByData:{ 
                    addedPersonalizationRefinedByData: {}, 
                    addedPersonalizationRefinedByDataLoading: true
                },
                deletedPersonalizationRefinedByData: {
                     deletedPersonalizationRefinedByData: [], 
                     deletedPersonalizationRefinedByLoading: false
                 },
                nameCheckPersonalizationRefinedBy:{},  
                nameCheckPersonalizationRefinedByLoading:false,
                errorState: {
                    error: false,
                    error_message: null
                }     
         }
         case PersonalizationDataActions.PersonalizationActionTypes.SetAddedPersonalizationData:
            return {
                ...state,
                personalizationRefinedByData:{
                   personalizationRefinedByData: [],
                    personalizationRefinedByLoading: false,
                    personalizationRefinedByError: false,
                },
                addedPersonalizationRefinedByData:{ 
                    addedPersonalizationRefinedByData: action.payload, 
                    addedPersonalizationRefinedByDataLoading: false
                },
                deletedPersonalizationRefinedByData: {
                    deletedPersonalizationRefinedByData: [], 
                    deletedPersonalizationRefinedByLoading: false
                },
                nameCheckPersonalizationRefinedBy:{},  
                nameCheckPersonalizationRefinedByLoading:false,
                errorState: {
                    error: false,
                    error_message: null
                } 
                    
         }

         case PersonalizationDataActions.PersonalizationActionTypes.UpdatePersonalizationRefinedByData:
            return {
                ...state,
                payload: action.payload,
                personalizationRefinedByData:{
                    ...state.personalizationRefinedByData,
                     personalizationRefinedByLoading: false,
                 },
                updatePersonalizationRefinedByData:{
                    updatePersonalizationRefinedByData:{},
                    updatePersonalizationRefinedByDataLoading:true   
                }  
         }

         case PersonalizationDataActions.PersonalizationActionTypes.SetUpdatePersonalizationRefinedByData:
            return {
                ...state,
                personalizationRefinedByData:{
                    personalizationRefinedByData: [],
                     personalizationRefinedByLoading: false,
                     personalizationRefinedByError: false,
                 },
                updatePersonalizationRefinedByData:{
                    updatePersonalizationRefinedByData:action.payload,
                    updatePersonalizationRefinedByDataLoading:false   
                }  
         }
         case PersonalizationDataActions.PersonalizationActionTypes.NameCheckPersonalization:
            return {
                ...state,
                nameCheckPersonalizationRefinedBy:{},  
                nameCheckPersonalizationRefinedByLoading:true
         }

         case PersonalizationDataActions.PersonalizationActionTypes.SetNameCheckPersonalizationRefinedByData:
            return {
                ...state,
                nameCheckPersonalizationRefinedBy:action.payload,  
                nameCheckPersonalizationRefinedByLoading:false
         }

         case PersonalizationDataActions.PersonalizationActionTypes.ResetPersonalizationData:
            return initialState;

    
        case PersonalizationDataActions.PersonalizationActionTypes.SetError: {
            return {
                ...state,
                personalizationRefinedByData:{
                personalizationRefinedByData: [...state.personalizationRefinedByData.personalizationRefinedByData],
                    personalizationRefinedByLoading: false,
                    personalizationRefinedByError: true,
                    totalCount: state.personalizationRefinedByData.totalCount
                },
                addedPersonalizationRefinedByData:{ 
                    addedPersonalizationRefinedByData: {}, 
                    addedPersonalizationRefinedByDataLoading: false
                },
                deletedPersonalizationRefinedByData: {
                    deletedPersonalizationRefinedByData: [], 
                    deletedPersonalizationRefinedByLoading: false
                },
                updatePersonalizationRefinedByData:{
                    updatePersonalizationRefinedByData:[],
                    updatePersonalizationRefinedByDataLoading:false   
                },
                nameCheckPersonalizationRefinedBy:{},
                errorState: {
                    error: true,
                    error_message: action.payload
                }
            }

        }    
        default:
            return state;
    }
}