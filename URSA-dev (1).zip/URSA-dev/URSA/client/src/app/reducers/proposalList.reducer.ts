import * as ProposalListDataActions from '../actions/proposalList.action'

const initialState = {
    proposalListData : [],
    proposalListCount : 0,
    proposalListLoading : false,
    total_proposals : 0,
    errorState: {
        error: false,
        error_message: null
    }
}

export default function(state = initialState, action: ProposalListDataActions.ProposalPageDataTypes) {
    switch(action.type) {
        case ProposalListDataActions.ProposalListDataActionTypes.GetProposalListData:
            let _proposalListData = [];
            return {...state, 
                proposalListLoading : true, 
                proposalListData : [...state.proposalListData],
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case ProposalListDataActions.ProposalListDataActionTypes.SetProposalListData: 
                return {
                    ...state,
                    proposalListData: [...state.proposalListData, ...action.payload.results],
                    proposalListCount :  action.payload.total_count || 0,
                    total_proposals : action.payload.total_count || 0,
                    proposalListLoading : false,
                    errorState: {
                        error: false,
                        error_message: null
                    }
                }
        case ProposalListDataActions.ProposalListDataActionTypes.ClearProposalListData: {
            return initialState;
        }
        case ProposalListDataActions.ProposalListDataActionTypes.SetError: {
            return {
                ...state,
                proposalListData:  [...state.proposalListData],
                proposalListCount :  state.proposalListCount,
                total_proposals : state.total_proposals,
                proposalListLoading : false,
                errorState: {
                    error: true,
                    error_message: action.payload
                }
            }
        }
        default:
            return state;
    }
}