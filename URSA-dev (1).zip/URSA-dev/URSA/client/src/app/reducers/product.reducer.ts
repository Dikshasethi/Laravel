import * as ProductActions from '../actions/product.actions';

const initialState = {
    productFetchIsLoading : false,
    calendarDataIsLoading : false,
    productsObject : {},
    productHierarchy : {},
    productList : [],
    productsObjectCache : {},
    calendarMap : {},
    assetHistoryDetails : {}
}

export default function(state = initialState, action: ProductActions.ProductActions){
    switch(action.type){
        case ProductActions.ProductActionTypes.GetProducts:
            return {...state, productFetchIsLoading : true}
        case ProductActions.ProductActionTypes.SetProducts:
             return {
                ...state, 
                productsObject : action.payload,
                productList : [...state.productList, ...action.payload.productList || []],
                productFetchIsLoading : false
            }
        case ProductActions.ProductActionTypes.ResetProductList:

            return {...state, productList : action.payload}
                
        case ProductActions.ProductActionTypes.ResetCalendarMap:
            return {...state, calendarMap : []}

        case ProductActions.ProductActionTypes.DestroyDataObject:

            return {
                ...state,
                productsObject : {},
                productList : [],
                productHierarchy : {},
                productFetchIsLoading : false
            }
        case ProductActions.ProductActionTypes.CacheProductsObject:

            return {
                ...state,
                productsObjectCache : state.productsObject
            }
        case ProductActions.ProductActionTypes.SetOnlyProductsObject:

            return {
                ...state,
                productsObject : state.productsObjectCache
            }
        case ProductActions.ProductActionTypes.ClearProductsObjectCache: 

            return {
                ...state,
                productsObjectCache : {}
            }

        case ProductActions.ProductActionTypes.ClearProductsHierarchyObject:

            return {
                ...state, 
                productHierarchy : {}
            }

        case ProductActions.ProductActionTypes.GetProductProposalData:

            state.productsObject['hasProposalError']= false;            
            return {...state, payload : action.payload, productFetchIsLoading : true}    
        case ProductActions.ProductActionTypes.SetProductProposalData:

            let proposalData = [];
            if(action.payload.isAuthenticate && action.payload.isAuthenticate=="not authenticated"){
                state.productsObject['isAuthenticate']= "not authenticated";
            }
            else if(action.payload.hasError){
                state.productList[state['payload']['index']].animationState = 'in';
                state.productList[state['payload']['index']].showIcon = true  ;
                state.productsObject['hasProposalError']= true;
            }
            else{
                if(action.payload.totalCount> 0){
                    proposalData = action.payload.proposalList
                }
                state.productList[action.payload.index]['proposalList'] = proposalData;
                state.productList[action.payload.index].animationState = 'in';
                state.productList[action.payload.index].showIcon = true  ;
                state.productsObject['hasProposalError']= false;
            }            
            
            return {
                ...state, 
                productsObject : state.productsObject,
                productList : [...state.productList || []],
                productFetchIsLoading : false
            }  
        case ProductActions.ProductActionTypes.InsertImage:
            const {newImageList, updatedAssetImageDetails} = action.payload.imageObject;
            if(!action.payload.error){
                state.productsObject['productList'] = state['productList']
                state.productsObject['productList'][action.payload.index]['imageList'] = newImageList;
                state.productsObject['productList'][action.payload.index]['assetimagedetails'] = updatedAssetImageDetails;
                return {
                    ...state, 
                    productsObject : state.productsObject,
                    productList : state.productsObject['productList'],
                }  
        }
        case ProductActions.ProductActionTypes.UpdateThumbnail:
            if(!action.payload.error &&
                action.payload.response && 
                action.payload.response.updatedAssetImageDetails
                ){
                state.productsObject['productList'] = state['productList']
                state.productsObject['productList'][action.payload.index]['assetimagedetails'] = action.payload.response.updatedAssetImageDetails;
                return {
                    ...state, 
                    productsObject : state.productsObject,
                    productList : state.productsObject['productList'],
                }  
        }

        case ProductActions.ProductActionTypes.GetProductCalendar:
            return { ...state, calendarDataIsLoading : true }  
            

        case ProductActions.ProductActionTypes.SetProductCalendar:
            let _calendarMap = state.calendarMap
            _calendarMap[action.payload['timeseries']['index']] = action.payload['timeseries'].calendarData;
                return {...state, calendarDataIsLoading : false}  
        
        case ProductActions.ProductActionTypes.GetHieararchy:
            return {...state, productFetchIsLoading : true}

            
        case ProductActions.ProductActionTypes.SetHieararchy:
             return {
                ...state, 
                productHierarchy : action.payload,
                productFetchIsLoading : false
            }     
        case ProductActions.ProductActionTypes.GetAssetHistory:
             return {...state, productFetchIsLoading : true}
    
                
        case ProductActions.ProductActionTypes.SetAssetHistory:
             return {
                ...state, 
                assetHistoryDetails : action.payload,
                productFetchIsLoading : false
            }                        

        default:
            if(state.productsObject['hasProposalError']){
                state.productsObject['hasProposalError']= false;
            }
            return state;
    }
}