import * as AdvancedSearchActions from '../actions/advancedSearch.actions';

const initialState = {
    activeSearch : false,
    display : 'none',
    categoryString : '',
    manufacturerString : '',
    modelString : '',
    locationString : '',
    subtype2String : '',
    descriptionString : ''
}

export default function(state = initialState, action: AdvancedSearchActions.AdvancedSearchTypes) {
    switch(action.type){
        case AdvancedSearchActions.AdvancedSearchActionTypes.ManageAdvancedSearchDisplay:
            return {
                ...state,
                display : action.payload
            }
        case AdvancedSearchActions.AdvancedSearchActionTypes.HandleInput:
            const {field, value} = action.payload;
            return {
                ...state,
                [field] : value,
                activeSearch : false
            }
        case AdvancedSearchActions.AdvancedSearchActionTypes.HandlePillDeletion:
            return {
                ...state,
                [action.payload['field']] : action.payload.value
            }
        case AdvancedSearchActions.AdvancedSearchActionTypes.ResetSearch:
            return {
                ...state,
                categoryString : '',
                manufacturerString : '',
                modelString : '',
                locationString : '',
                subtype2String : '',
                descriptionString : '',
                activeSearch : false
            }
        case AdvancedSearchActions.AdvancedSearchActionTypes.SetActiveSearch:
            return {...state, activeSearch : action.payload}
        default:
            return state;
    }
}