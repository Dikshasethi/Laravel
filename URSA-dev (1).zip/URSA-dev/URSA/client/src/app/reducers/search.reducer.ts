import * as SearchActions from '../actions/search.actions';
import * as moment from 'moment';

let searchKeyword = sessionStorage.getItem('searchKeyword');
const initialState = {
    searchKeyword : searchKeyword ? searchKeyword : '',
    startDate : moment().format('YYYY-MM-DD'),
    endDate : moment().add(6, 'months').format('YYYY-MM-DD'),
    searchCount : 0,
    localStorageKeyword : searchKeyword ? searchKeyword : '',
}

export default function(state = initialState, action: SearchActions.SearchTypes) {
    switch(action.type){
        case SearchActions.SearchActionTypes.SetSearchKeyword:
            return {...state, searchKeyword : action.payload}
        case SearchActions.SearchActionTypes.SetSearchKeywordLocalStorage:
            sessionStorage.setItem('searchKeyword', action.payload);
            return {...state,localStorageKeyword:action.payload}
        case SearchActions.SearchActionTypes.SetDateRange:
            const {startDate, endDate} = action.payload;
            return {
                ...state,
                startDate : startDate || state.startDate,
                endDate : endDate || state.endDate
            }
        case SearchActions.SearchActionTypes.ResetDateRange:
            return {
                ...state,
                startDate : moment().format('YYYY-MM-DD'),
                endDate : moment().add(6, 'months').format('YYYY-MM-DD')
            }
        case SearchActions.SearchActionTypes.RegisterSearchCount:
            return {...state, searchCount : state.searchCount + 1}
        default:
            return state;
    }
}