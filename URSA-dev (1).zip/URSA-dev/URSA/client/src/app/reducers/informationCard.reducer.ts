import * as InformationCardActions from '../actions/information-card.action';

const initialState = {
    emodetails: {
        emodetailsData: [],
        totalCount: 0
    },
    receivingdetails: {
        receivingdetailsData: [],
        totalCount: 0
    },
    assettransactionlogsdetail: {
        assettransactionlogsData: [],
        totalCount: 0
    }
}

export default function (state = initialState, action: InformationCardActions.InformationCardActions) {
    switch (action.type) {
        case InformationCardActions.InformationCardActionTypes.GetEmoDetails:
            return {
                ...state
            }

        case InformationCardActions.InformationCardActionTypes.SetEmoDetails:
            let emoRecords = action.payload.results || [];
            return {
                ...state,
                emodetails: {
                    ...state.emodetails,
                    emodetailsData: [...state.emodetails.emodetailsData, ...emoRecords],
                    totalCount: action.payload.total_count
                }
            }

        case InformationCardActions.InformationCardActionTypes.ReSetEmoDetails:
            return {
                ...state,
                emodetails: initialState.emodetails
            }

        case InformationCardActions.InformationCardActionTypes.GetReceivingDetails:
            return {
                ...state
            }

        case InformationCardActions.InformationCardActionTypes.SetReceivingDetails:
            let receivingrecords = action.payload.results || [];
            return {
                ...state,
                receivingdetails: {
                    ...state.receivingdetails,
                    receivingdetailsData: [...state.receivingdetails.receivingdetailsData, ...receivingrecords],
                    totalCount: action.payload.total_count
                }
            }
        case InformationCardActions.InformationCardActionTypes.ReSetReceivingDetails:
            return {
                ...state,
                receivingdetails: initialState.receivingdetails
            }
        case InformationCardActions.InformationCardActionTypes.GetAssetTransactionLogs:
            return {
                ...state
            }

        case InformationCardActions.InformationCardActionTypes.SetAssetTransactionLogs:
            let assetrecords = action.payload.results || [];
            return {
                ...state,
                assettransactionlogsdetail: {
                    ...state.assettransactionlogsdetail,
                    assettransactionlogsData: [...state.assettransactionlogsdetail.assettransactionlogsData, ...assetrecords],
                    totalCount: action.payload.total_count
                }
            }
        case InformationCardActions.InformationCardActionTypes.ReSetAssetTransactionLogs:
            return {
                ...state,
                assettransactionlogsdetail: initialState.assettransactionlogsdetail
            }

        default:
            return state;
    }
}