import * as CheckedInAssetsAction from '../actions/checked-in-assets.action';

const initialState = {
    checkedInAssets : [],
    checkedInAssetsCount : 0,
    checkedInAssetsTotalCount :0,
    isLoading : false
}

export default function (state = initialState, action: CheckedInAssetsAction.CheckoutCheckinTypes) {
    switch (action.type) {
        case CheckedInAssetsAction.CheckoutDataActionTypes.SetCheckoutCheckInData:
            let checkedInRecords = [...state.checkedInAssets, ...action.payload.results]
            return {
                ...state,
                checkedInAssets: checkedInRecords,
                checkedInAssetsCount : checkedInRecords.length,
                checkedInAssetsTotalCount :action.payload.total_count,
                isLoading : false,
            }
        case CheckedInAssetsAction.CheckoutDataActionTypes.GetCheckoutCheckInData:
            return {
                ...state,
                payload: action.payload,
                isLoading : true,
            }
        case CheckedInAssetsAction.CheckoutDataActionTypes.ClearCheckedInList:
            return {
                ...state,
                checkedInAssets : [],
                checkedInAssetsCount : 0,
                checkedInAssetsTotalCount : 0
            }
        default:
            return state;
    }
}