import * as DashboardActions from '../actions/dashbord.action'
const initialState = {
    utilizationChart: {
        utilizationChartData: [],
        utilizationChartLoading: false
    },
    checkoututilizationChart: {
        checkoututilizationChartData: [],
        checkoututilizationChartLoading: false
    },
    onhireutilizationChart: {
        onhireutilizationChartData: [],
        onhireutilizationChartLoading: false
    },
    receivecountChart: {
        receivecountChartData: [],
        receivecountChartLoading: false
    },
    softReservationChart: {
        softReservationChartData: [],
        softReservationChartLoading: false
    },
    hardReservationChart: {
        hardReservationChartData: [],
        hardReservationChartLoading: false
    },
    shippedChart: {
        shippedChartData: [],
        shippedChartLoading: false
    },
    assetCount: {
        assetCountData: 0,
        assetCountLoading: false
    },
    pastDueCount: {
        pastDueCountData: 0,
        pastDueCountLoading: false
    },
    hardReservationCount: {
        hardReservationCountData: 0,
        hardReservationCountLoading: false
    },
    softReservationCount: {
        softReservationCountData: 0,
        softReservationCountLoading: false
    },
    checkoutCount: {
        checkoutCountData: 0,
        checkoutCountLoading: false
    },
    errorState: {
        utilization: {
            error: false,
            error_message: null
        },
        checkoututilization: {
            error: false,
            error_message:null
        },
        onhire: {
            error: false,
            error_message:null
        },
        softReservation: {
            error: false,
            error_message: null
        },
        hardReservation: {
            error: false,
            error_message: null
        },
        shipped: {
            error: false,
            error_message: null
        },
        asset: {
            error: false,
            error_message: null
        },
        pastDue: {
            error: false,
            error_message: null
        },
        hardReservationCount: {
            error: false,
            error_message: null
        },
        checkout: {
            error: false,
            error_message: null
        },
        softReservationCount: {
            error: false,
            error_message: null
        },
        receivecount: {
            error: false,
            error_message:null
        },
    }

}

export default function (state = initialState, action: DashboardActions.DashboardTypes) {
    switch (action.type) {
        case DashboardActions.DashboardActionTypes.GetUtilizationChart:
            return {
                ...state,
                utilizationChart: {
                    ...state.utilizationChart,
                    utilizationChartLoading: true
                },
                errorState: {
                    ...state.errorState,
                    utilization: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.SetUtilizationChart:
            let utilizationData = action.payload.results || [];
            return {
                ...state,
                utilizationChart: {
                    utilizationChartData: utilizationData,
                    utilizationChartLoading: false
                },
                errorState: {
                    ...state.errorState,
                    utilization: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.GetCheckoutmetrics:
            return {
                ...state,
                checkoututilizationChart: {
                    ...state.checkoututilizationChart,
                    checkoututilizationChartLoading: true
                },
                errorState: {
                    ...state.errorState,
                    checkoututilization: {
                        error: false,
                        error_message: null
                    }
                }
            }
        
        case DashboardActions.DashboardActionTypes.SetCheckoutmetrics:
            let CheckoutmetricsData = action.payload.results || [];
            return {
                ...state,
                checkoututilizationChart: {
                    checkoututilizationChartData: CheckoutmetricsData,
                    checkoututilizationChartLoading: false
                },
                errorState: {
                    ...state.errorState,
                    checkoututilization: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.Getonhiremetrics:
            return {
                ...state,
                onhireutilizationChart: {
                    ...state.onhireutilizationChart,
                    onhireutilizationChartLoading: true
                },
                errorState: {
                    ...state.errorState,
                    onhire: {
                        error: false,
                        error_message: null
                    }
                }
            }
        
        case DashboardActions.DashboardActionTypes.Setonhiremetrics:
            let onhiremetricsData = action.payload.results || [];
            return {
                ...state,
                onhireutilizationChart: {
                    onhireutilizationChartData: onhiremetricsData,
                    onhireutilizationChartLoading: false
                },
                errorState: {
                    ...state.errorState,
                    onhire: {
                        error: false,
                        error_message: null
                    }
                }
            }


        case DashboardActions.DashboardActionTypes.Getreceivecount:
                return {
                    ...state,
                    receivecountChart: {
                        ...state.receivecountChart,
                        receivecountChartLoading: true
                    },
                    errorState: {
                        ...state.errorState,
                        receivecount: {
                            error: false,
                            error_message: null
                        }
                    }
                }
    
        case DashboardActions.DashboardActionTypes.Setreceivecount:
                let receivecountData = action.payload.results || [];
                return {
                    ...state,
                    receivecountChart: {
                        receivecountChartData: receivecountData,
                        receivecountChartLoading: false
                    },
                    errorState: {
                        ...state.errorState,
                        receivecount: {
                            error: false,
                            error_message: null
                        }
                    }
                }

        case DashboardActions.DashboardActionTypes.GetSoftReservationChart:
            return {
                ...state,
                softReservationChart: {
                    ...state.softReservationChart,
                    softReservationChartLoading: true
                },
                errorState: {
                    ...state.errorState,
                    softReservation: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.SetSoftReservationChart:
            let softReservationData = action.payload.results || [];
            return {
                ...state,
                softReservationChart: {
                    softReservationChartData: softReservationData,
                    softReservationChartLoading: false
                },
                errorState: {
                    ...state.errorState,
                    softReservation: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.GetHardReservationChart:
            return {
                ...state,
                hardReservationChart: {
                    ...state.hardReservationChart,
                    hardReservationChartLoading: true
                },
                errorState: {
                    ...state.errorState,
                    hardReservation: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.SetHardReservationChart:
            let hardReservationData = action.payload.results || [];
            return {
                ...state,
                hardReservationChart: {
                    hardReservationChartData: hardReservationData,
                    hardReservationChartLoading: false
                },
                metricsloading: false,
                errorState: {
                    ...state.errorState,
                    hardReservation: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.GetShippedChart:
            return {
                ...state,
                shippedChart: {
                    ...state.shippedChart,
                    shippedChartLoading: true
                },
                errorState: {
                    ...state.errorState,
                    shipped: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.SetShippedChart:
            let shippedData = action.payload.shipCountList || [];
            return {
                ...state,
                shippedChart: {
                    shippedChartData: shippedData,
                    shippedChartLoading: false
                },
                errorState: {
                    ...state.errorState,
                    shipped: {
                        error: false,
                        error_message: null
                    }
                }
            }
        case DashboardActions.DashboardActionTypes.GetAssetCount:
            return {
                ...state,
                assetCount: {
                    ...state.assetCount,
                    assetCountLoading: true
                },
                errorState: {
                    ...state.errorState,
                    asset: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.SetAssetCount:
            return {
                ...state,
                assetCount: {
                    assetCountData: action.payload.assetCount || 0,
                    assetCountLoading: false
                },
                errorState: {
                    ...state.errorState,
                    asset: {
                        error: false,
                        error_message: null
                    }
                }
            }
        case DashboardActions.DashboardActionTypes.GetPastDueCheckOutCount:
            return {
                ...state,
                pastDueCount: {
                    ...state.pastDueCount,
                    pastDueCountLoading: true
                },
                errorState: {
                    ...state.errorState,
                    pastDue: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.SetPastDueCheckOutCount:
            return {
                ...state,
                pastDueCount: {
                    pastDueCountData: action.payload.pastDueCount || 0,
                    pastDueCountLoading: false
                },
                errorState: {
                    ...state.errorState,
                    pastDue: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.GetHardReservationCount:
            return {
                ...state,
                hardReservationCount: {
                    ...state.hardReservationCount,
                    hardReservationCountLoading: true
                },
                errorState: {
                    ...state.errorState,
                    hardReservationCount: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.SetHardReservationCount:
            return {
                ...state,
                hardReservationCount: {
                    hardReservationCountData: action.payload.hardReserveCount || 0,
                    hardReservationCountLoading: true
                },
                errorState: {
                    ...state.errorState,
                    hardReservationCount: {
                        error: false,
                        error_message: null
                    }
                }
            }
        case DashboardActions.DashboardActionTypes.GetCheckoutCount:
            return {
                ...state,
                checkoutCount: {
                    ...state.checkoutCount,
                    checkoutCountLoading: true
                },
                errorState: {
                    ...state.errorState,
                    checkoutCount: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.SetCheckoutCount:
            return {
                ...state,
                checkoutCount: {
                    checkoutCountData: action.payload.checkinOutCount || 0,
                    checkoutCountLoading: true
                },
                errorState: {
                    ...state.errorState,
                    checkoutCount: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.GetSoftReservationCount:
            return {
                ...state,
                softReservationCount: {
                    ...state.softReservationCount,
                    softReservationCountLoading: true
                },
                errorState: {
                    ...state.errorState,
                    softReservationCount: {
                        error: false,
                        error_message: null
                    }
                }
            }

        case DashboardActions.DashboardActionTypes.SetSoftReservationCount:
            return {
                ...state,
                softReservationCount: {
                    softReservationCountData: action.payload.softreservecount || 0,
                    checkoutCountLoading: true
                },
                errorState: {
                    ...state.errorState,
                    softReservationCount: {
                        error: false,
                        error_message: null
                    }
                }
            }
        case DashboardActions.DashboardActionTypes.SetError: {
            const { error, apiName } = action.payload;
            return {
                ...state,
                utilizationChart: {
                    ...state.utilizationChart,
                    utilizationChartLoading: false
                },
                checkoututilizationChart: {
                    ...state.checkoututilizationChart,
                    checkoututilizationChartLoading: false
                },
                onhireutilizationChart: {
                    ...state.onhireutilizationChart,
                    onhireutilizationChartLoading: false
                },
                receivecountChart: {
                    ...state.receivecountChart,
                    receivecountChartLoading: false
                },
                softReservationChart: {
                    ...state.softReservationChart,
                    softReservationChartLoading: false
                },
                hardReservationChart: {
                    ...state.hardReservationChart,
                    hardReservationChartLoading: false
                },
                shippedChart: {
                    ...state.shippedChart,
                    shippedChartLoading: false
                },
                assetCount: {
                    ...state.assetCount,
                    assetCountLoading: false
                },
                pastDueCount: {
                    ...state.pastDueCount,
                    pastDueCountLoading: false
                },
                errorState: {
                    ...state.errorState,
                    [apiName]: {
                        error: true,
                        error_message: error
                    }
                }
            }

        }
        case DashboardActions.DashboardActionTypes.ResetChartCounts:
            return {
                ...state,
                assetCount: {
                    ...state.assetCount,
                    assetCountData: 0,
                },
                pastDueCount: {
                    ...state.pastDueCount,
                    pastDueCountData: 0
                },
                hardReservationCount: {
                    ...state.hardReservationCount,
                    hardReservationCountData: 0,
                },
                softReservationCount: {
                    ...state.softReservationCount,
                    softReservationCountData: 0,
                },
                checkoutCount: {
                    ...state.checkoutCount,
                    checkoutCountData: 0,
                },
                errorState: {
                    utilization: {
                        error: false,
                        error_message: null
                    },
                    checkoututilization: {
                        error: false,
                        error_message:null
                    },
                    onhire: {
                        error: false,
                        error_message:null
                    },
                    receivecount: {
                        error: false,
                        error_message:null
                    },
                    softReservation: {
                        error: false,
                        error_message: null
                    },
                    hardReservation: {
                        error: false,
                        error_message: null
                    },
                    shipped: {
                        error: false,
                        error_message: null
                    },
                    asset: {
                        error: false,
                        error_message: null
                    },
                    pastDue: {
                        error: false,
                        error_message: null
                    },
                    hardReservationCount: {
                        error: false,
                        error_message: null
                    },
                    checkout: {
                        error: false,
                        error_message: null
                    },
                    softReservationCount: {
                        error: false,
                        error_message: null
                    }
                }
            }
        default:
            return state;
    }
}