import * as AutocompleteActions from '../actions/autocomplete.actions'

const initialState = {
    globalSuggestionList: [],
    categoryStringSuggestionList:[],
    manufacturerStringSuggestionList:[],
    modelStringSuggestionList:[],
    locationStringSuggestionList:[],
    subtype2StringSuggestionList:[],
    descriptionStringSuggestionList:[],
    checkoutAutocomplete:[],
    projectAutocomplete:[],
    custodianAutocomplete:[],
    areaCountForCurrentLocation:0,
    isLoading:false,
    cachedArea:[],
    autocompleteLastRequestIdentifierKey:'',
    proposalAutoComplete: {
        suggestionList: [],
        isFetchingAutocompleteList: false,
        isResponsibilityCode: false
    },
    permissionValidation: {
        permissionValidationFetchisLoading: false,
        permissionValidationResult: []
    },
    restrictionData: {
        restrictionFetchisLoading: false,
        restrictionResult: []
    }
}

export default function(state = initialState, action: AutocompleteActions.AutocompleteTypes) {
    switch(action.type){
        case AutocompleteActions.AutocompleteActionTypes.GetAutocompleteList:
            return {...state, letters : action.payload}
        case AutocompleteActions.AutocompleteActionTypes.SetAutocompleteList:
            let obj = action.payload;
            return {
                ...state, 
                [state['letters'].suggestionField] : obj.suggestionList,              
            }

        case AutocompleteActions.AutocompleteActionTypes.GetCheckoutAutocomplete:
            return {...state, letters : action.payload, isFetchingAutocompleteList:true}

        case AutocompleteActions.AutocompleteActionTypes.SetCheckoutAutocomplete:
            let suggestionCheckOutData =  action.payload
            if(state.autocompleteLastRequestIdentifierKey) {
                suggestionCheckOutData = ['proposalplannername','requestedbyname','requestedforname'].includes(state.autocompleteLastRequestIdentifierKey) ?
                 action.payload : []
            }
            return {...state, 
                        checkoutAutocomplete : {
                            suggestionList:suggestionCheckOutData, 
                            isFetchingAutocompleteList:false,
                            field:state['letters'].field
                        }
                    }    

        case AutocompleteActions.AutocompleteActionTypes.GetProjectData:
            return {...state, letters : action.payload} 

        case AutocompleteActions.AutocompleteActionTypes.SetReCheckoutAutocomplete:
            let suggestionData =  action.payload
            if(state.autocompleteLastRequestIdentifierKey) {
                suggestionData = ['crewrequirementprojectnumber','newProjectId','projectid','projectnumber'].includes(state.autocompleteLastRequestIdentifierKey) ?
                 action.payload : []
            }
            let suggestionListRecheckoutData = (state.projectAutocomplete['suggestionList']) ? 
            [...state.projectAutocomplete['suggestionList'], ...suggestionData] : suggestionData
            return {...state, 
                projectAutocomplete : {
                            suggestionList:suggestionListRecheckoutData, 
                            isFetchingAutocompleteList:false,
                            field:(state["letters"]["filter"]) ? Object.keys(state["letters"].filter)[0] : ''
                        }
                    }   
                    
        case AutocompleteActions.AutocompleteActionTypes.GetCustodianAutocompleteList:
            return {...state, letters : action.payload}    
            
        case AutocompleteActions.AutocompleteActionTypes.GetPcBusinessUnitAutocompleteList:
            return {...state, letters : action.payload}     
                
        case AutocompleteActions.AutocompleteActionTypes.GetLocationAreasCheck:
            return {...state, isLoading : true}

        case AutocompleteActions.AutocompleteActionTypes.SetLocationAreasCheck:
            let { total_count, results } = action.payload.results
            let zeroResultsList = [{
                LOCATION : 'NA',
                SETID : 'NA',
                DESCR : 'NA' 
            }];
 
            return {
                ...state, 
                areaCountForCurrentLocation : total_count, 
                cachedArea : total_count > 0 ? results : zeroResultsList,
                isLoading : false             
            }
        
        case AutocompleteActions.AutocompleteActionTypes.DestroyAutocompleteList:
            return {
                ...state, 
                globalSuggestionList: [],
                categoryStringSuggestionList:[],
                manufacturerStringSuggestionList:[],
                modelStringSuggestionList:[],
                locationStringSuggestionList:[],
                subtype2StringSuggestionList:[],
                descriptionStringSuggestionList:[],
                checkoutAutocomplete:[],
                projectAutocomplete:[],
                custodianAutocomplete:[],
                cachedArea:[],
                autocompleteLastRequestIdentifierKey:'',
                proposalAutoComplete: {
                    suggestionList: [],
                    isFetchingAutocompleteList: false,
                    isResponsibilityCode: false
                },
                areaCountForCurrentLocation:0
            }

        case AutocompleteActions.AutocompleteActionTypes.GetCountriesAutoComplete:
            return {...state, letters : action.payload, isFetchingAutocompleteList:true}

        case AutocompleteActions.AutocompleteActionTypes.SetCountriesAutoComplete:
            return {
                ...state, 
                checkoutAutocomplete : {
                    suggestionList:action.payload.data.results, 
                    isFetchingAutocompleteList:false,
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.GetUOMAutoComplete:
            return { ...state, letters: action.payload, isFetchingAutocompleteList: true }

        case AutocompleteActions.AutocompleteActionTypes.SetUOMAutoComplete:
            return {
                ...state,
                checkoutAutocomplete: {
                    suggestionList: action.payload.data.results,
                    isFetchingAutocompleteList: false,
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.GetPermissionAutoComplete:
            return {
                ...state,
                permissionValidation: {
                    permissionValidationFetchisLoading: true,
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.SetPermissionAutoComplete:
            return {
                ...state,
                permissionValidation: {
                    permissionValidationFetchisLoading: false,
                    permissionValidationResult: action.payload
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.ReSetPermissionAutoComplete:
            return {
                ...state,
                permissionValidation: {
                    permissionValidationFetchisLoading: false,
                    permissionValidationResult: []
                }
            }   
        case AutocompleteActions.AutocompleteActionTypes.GetRestrictionData:
            return {
                ...state,
                restrictionData: {
                    restrictionFetchisLoading: true
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.SetRestrictionData:
            return {
                ...state,
                restrictionData: {
                    restrictionFetchisLoading: false,
                    restrictionResult: action.payload
                }
            } 
        case AutocompleteActions.AutocompleteActionTypes.ReSetRestrictionData:
            return {
                ...state,
                restrictionData: {
                    restrictionFetchisLoading: false,
                    restrictionResult: []
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.GetCrmData:
            return { ...state, 
                letters: action.payload, 
                proposalAutoComplete: {
                    suggestionList: [...state.proposalAutoComplete.suggestionList],
                    isFetchingAutocompleteList: true,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.SetCrmData:
            let crmList = ['oicrmbidnumber'].includes(state.autocompleteLastRequestIdentifierKey) ? action.payload : []
            return {
                ...state,
                proposalAutoComplete: {
                    suggestionList: action.payload.hasError ? [] : [...state.proposalAutoComplete.suggestionList, ...crmList],
                    isFetchingAutocompleteList: false,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.GetBillingGroupData:
            return { ...state, 
                letters: action.payload, 
                proposalAutoComplete: {
                    suggestionList:  [...state.proposalAutoComplete.suggestionList],
                    isFetchingAutocompleteList: true,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.SetBillingGroupData:
            let groupData =  ['group'].includes(state.autocompleteLastRequestIdentifierKey) ? action.payload : []
            return {
                ...state,
                proposalAutoComplete: {
                    suggestionList: action.payload.hasError ? [] : [...state.proposalAutoComplete.suggestionList, ...groupData],
                    isFetchingAutocompleteList: false,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.GetBillingBusinessUnitData:
            return { ...state, 
                letters: action.payload, 
                proposalAutoComplete: {
                    suggestionList: [],
                    isFetchingAutocompleteList: true,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.SetBillingBusinessUnitData:
            return {
                ...state,
                proposalAutoComplete: {
                    suggestionList: action.payload.hasError ? [] : action.payload,
                    isFetchingAutocompleteList: false,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.GetBusinessUnitMasterData:
            return { ...state, 
                letters: action.payload, 
                proposalAutoComplete: {
                    suggestionList: [...state.proposalAutoComplete.suggestionList],
                    isFetchingAutocompleteList: true,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.SetBusinessUnitMasterData:
            let billingBusinessMasterData = ['businessunit'].includes(state.autocompleteLastRequestIdentifierKey) ? action.payload.data : []
           
            return {
                ...state,
                proposalAutoComplete: {
                    suggestionList: action.payload.hasError ? [] : [...state.proposalAutoComplete.suggestionList, ...billingBusinessMasterData],
                    isFetchingAutocompleteList: false,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.GetCrewPositions:
            return { ...state, 
                letters: action.payload, 
                proposalAutoComplete: {
                    suggestionList: [...state.proposalAutoComplete.suggestionList],
                    isFetchingAutocompleteList: true,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.SetCrewPositions:
            let crewPositionData = ['crewpositionname'].includes(state.autocompleteLastRequestIdentifierKey) ? action.payload.data : []
            return {
                ...state,
                proposalAutoComplete: {
                    suggestionList: action.payload.hasError ? [] : [...state.proposalAutoComplete.suggestionList, ...crewPositionData],
                    isFetchingAutocompleteList: false,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.GetServiceLineData:
            return { ...state, 
                letters: action.payload, 
                proposalAutoComplete: {
                    suggestionList: [...state.proposalAutoComplete.suggestionList],
                    isFetchingAutocompleteList: true,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.SetServiceLineData:
            let serviceLineData =  ['servicelinename'].includes(state.autocompleteLastRequestIdentifierKey) ? action.payload.data : []
            return {
                ...state,
                proposalAutoComplete: {
                    suggestionList: action.payload.hasError ? [] : [...state.proposalAutoComplete.suggestionList, ...serviceLineData],
                    isFetchingAutocompleteList: false,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.GetScopeOfWorkData:
            return { ...state, 
                letters: action.payload, 
                proposalAutoComplete: {
                    suggestionList: [...state.proposalAutoComplete.suggestionList],
                    isFetchingAutocompleteList: true,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.SetScopeOfWorkData:
            let scopeOfWorkData = ['scopeofwork'].includes(state.autocompleteLastRequestIdentifierKey) ? action.payload.data : []
            return {
                ...state,
                proposalAutoComplete: {
                    suggestionList: action.payload.hasError ? [] : [...state.proposalAutoComplete.suggestionList, ...scopeOfWorkData],
                    isFetchingAutocompleteList: false,
                    isResponsibilityCode: false
                }
            }
        
        case AutocompleteActions.AutocompleteActionTypes.GetResponsibilityCodeData:
            return { ...state, 
                letters: action.payload, 
                proposalAutoComplete: {
                    suggestionList: [...state.proposalAutoComplete.suggestionList],
                    isFetchingAutocompleteList: true,
                    isResponsibilityCode: false
                }
            }

        case AutocompleteActions.AutocompleteActionTypes.SetResponsibilityCodeData:
            let responsibilityData = ['responsibilityname'].includes(state.autocompleteLastRequestIdentifierKey) ? action.payload.data : []
            return {
                ...state,
                proposalAutoComplete: {
                    suggestionList: action.payload.hasError ? [] : [...state.proposalAutoComplete.suggestionList, ...responsibilityData],
                    isFetchingAutocompleteList: false,
                    isResponsibilityCode: true
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.GetCustomersData:
            return { ...state, 
                letters: action.payload, 
                proposalAutoComplete: {
                    suggestionList: [...state.proposalAutoComplete.suggestionList],
                    isFetchingAutocompleteList: true,
                    isResponsibilityCode: false
                }
            }

        case AutocompleteActions.AutocompleteActionTypes.SetCustomersData:
            let customerNameData =  ['customername'].includes(state.autocompleteLastRequestIdentifierKey) ? action.payload.data : []
            
            return {
                ...state,
                proposalAutoComplete: {
                    suggestionList: action.payload.hasError ? [] : [...state.proposalAutoComplete.suggestionList, ...customerNameData],
                    isFetchingAutocompleteList: false,
                    isResponsibilityCode: false
                }
            }
        case AutocompleteActions.AutocompleteActionTypes.SetAutoCompleteDisplayKey:
            return {
                ...state,
                autocompleteLastRequestIdentifierKey: action.payload.identifierKey
            }
        default:
            return state;
    }
}