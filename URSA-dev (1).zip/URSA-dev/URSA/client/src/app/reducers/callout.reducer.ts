import * as CalloutActions from '../actions/callout.action';

const initialState = {
    calloutList : [],
    calloutCount : 0,
    calloutListIsLoading : false,
    calloutListError : false,
    calloutDetails : {},
    calloutDetailsIsLoading : false,
    calloutDetailsError : false,
    deleteCalloutLoading : false,
    deleteCalloutError : false,
    deleteCalloutSuccess : false
    
}

export default function(state = initialState, action: CalloutActions.CalloutTypes){
    switch(action.type){
        case CalloutActions.CalloutActionTypes.GetCalloutList:
            return {
                ...state,
                calloutListIsLoading : true,
                calloutListError : false
            }
        case CalloutActions.CalloutActionTypes.SetCalloutList:
            return {
                ...state,
                calloutListIsLoading : false,
                calloutListError : action.payload.hasError ? true : false,
                calloutList : action.payload.hasError ? [] : [...state.calloutList,...action.payload.callouts],
                calloutCount : action.payload.total_count,
            }
        case CalloutActions.CalloutActionTypes.GetCalloutDetails:
            return {
                ...state,
                calloutDetailsIsLoading : true,
                calloutDetailsError : false
            }
        case CalloutActions.CalloutActionTypes.SetCalloutDetails:
            return {
                ...state,
                calloutDetailsIsLoading : false,
                calloutDetailsError : action.payload.hasError ? true : false,
                calloutDetails : action.payload.hasError ? {} : action.payload
            }
        case CalloutActions.CalloutActionTypes.ResetCalloutDetails:
            return initialState;
        case CalloutActions.CalloutActionTypes.DeleteCallout:
            return {
                ...state,
                deleteCalloutError : false,
                deleteCalloutLoading : false
            }
        case CalloutActions.CalloutActionTypes.SetDeleteCalloutResponse:
            return {
                ...state,
                deleteCalloutLoading : false,
                deleteCalloutError : action.payload.hasError || action.payload.error ? 
                true : false,
                deleteCalloutSuccess : action.payload.success ? true : false,
                deleteCalloutErrorMessage : action.payload.error && action.payload.error.message ? 
                action.payload.error.message : ''
            }
        default:
            return state;
    }
}