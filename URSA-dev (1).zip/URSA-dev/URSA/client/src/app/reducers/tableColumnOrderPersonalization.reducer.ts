import * as PersonalizationDataActions from '../actions/tableColumnOrderPersonalization.action';
const initialState = {
    personalizationTableColumnData:{
        personalizationTableColumnData: [],
        personalizationTableColumnLoading : false,
        personalizationTableColumnError: false,
        totalCount: 0
    },
    addedPersonalizationTableColumnData:{ 
        addedPersonalizationTableColumnData: {}, 
        addedPersonalizationTableColumnLoading: false
    },
    deletedPersonalizationTableColumnData: {
        deletedPersonalizationTableColumnData: [], 
        deletedPersonalizationTableColumnLoading: false
    },
    updatePersonalizationTableColumnData:{
        updatePersonalizationTableColumnData: {},
        updatePersonalizationTableColumnDataLoading:false,
    },
    errorState: {
        error: false,
        error_message: null
    }
}

export default function(state = initialState, action: PersonalizationDataActions.TableColumnPersonalizationActions) {

    switch(action.type){
        
        case PersonalizationDataActions.PersonalizationActionTypes.GetPersonalizationTableColumnData:
            return {
                ...state,
                personalizationTableColumnData:{
                    personalizationTableColumnData: [...state.personalizationTableColumnData.personalizationTableColumnData],
                    personalizationTableColumnLoading: true,
                    personalizationTableColumnError: false,
                    totalCount: state.personalizationTableColumnData.totalCount
                },
                errorState: {
                    error: false,
                    error_message: null
                }
                
            }
        case PersonalizationDataActions.PersonalizationActionTypes.SetPersonalizationTableColumnData:
            return {
                ...state,
                personalizationTableColumnData:{
                    personalizationTableColumnData: action.payload.hasError ? [] : [...state.personalizationTableColumnData.personalizationTableColumnData, ...action.payload['results']],
                    personalizationTableColumnLoading : false,
                    personalizationTableColumnError: action.payload.hasError ? true : false,
                    totalCount : action.payload.hasError ? state.personalizationTableColumnData.totalCount : 
                    action.payload['total_count']
                },
                addedPersonalizationTableColumnData:{ 
                    addedPersonalizationTableColumnData: {}, 
                    addedPersonalizationTableColumnLoading: false
                },
                deletedPersonalizationTableColumnData: {
                    deletedPersonalizationTableColumnData: [], 
                    deletedPersonalizationTableColumnLoading: false
                },
                updatePersonalizationTableColumnData:{
                    updatePersonalizationTableColumnData:[],
                    updatePersonalizationTableColumnDataLoading:false,
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }
         case PersonalizationDataActions.PersonalizationActionTypes.AddPersonalizationTableColumnData:
            return {
                ...state,
                payload : action.payload, 
                personalizationTableColumnData:{
                    ...state.personalizationTableColumnData,
                    personalizationTableColumnLoading: false,
                },
                addedPersonalizationTableColumnData:{ 
                    addedPersonalizationTableColumnData: {}, 
                    addedPersonalizationTableColumnLoading: true
                },
                updatePersonalizationTableColumnData:{
                    updatePersonalizationTableColumnData: {},
                    updatePersonalizationTableColumnDataLoading:false,
                },
                errorState: {
                    error: false,
                    error_message: null
                }     
         }
         case PersonalizationDataActions.PersonalizationActionTypes.SetAddedPersonalizationTableColumnData:
            return {
                ...state,
                personalizationTableColumnData:{
                    personalizationTableColumnData: [],
                    personalizationTableColumnLoading: false,
                    personalizationTableColumnError: false,
                },
                addedPersonalizationTableColumnData:{ 
                    addedPersonalizationTableColumnData: action.payload, 
                    addedPersonalizationTableColumnLoading: false
                },
                updatePersonalizationTableColumnData:{
                    updatePersonalizationTableColumnData:[],
                    updatePersonalizationTableColumnDataLoading:false,
                },
                errorState: {
                    error: false,
                    error_message: null
                }       
         }

         case PersonalizationDataActions.PersonalizationActionTypes.UpdatePersonalizationTableColumnData:
            return {
                ...state,
                payload: action.payload,
                personalizationTableColumnData:{
                    ...state.personalizationTableColumnData,
                    personalizationTableColumnLoading: false,
                 },
                 updatePersonalizationTableColumnData:{
                    updatePersonalizationTableColumnData:[],
                    updatePersonalizationTableColumnDataLoading:true,
                },
         }

         case PersonalizationDataActions.PersonalizationActionTypes.SetUpdatePersonalizationTableColumnData:
            return {
                ...state,
                personalizationTableColumnData:{
                    personalizationTableColumnData: [],
                    personalizationTableColumnLoading: false,
                    personalizationTableColumnError: false,
                 },
                 updatePersonalizationTableColumnData:{
                    updatePersonalizationTableColumnData:action.payload,
                    updatePersonalizationTableColumnDataLoading:false,
                },
         }

        case PersonalizationDataActions.PersonalizationActionTypes.ResetPersonalizationTableColumnData:
            return initialState;
        
            
        case PersonalizationDataActions.PersonalizationActionTypes.DeleteTableColumnPersonalizationData:
            return {
                ...state,
                payload : action.payload, 
                personalizationTableColumnData:{
                    ...state.personalizationTableColumnData,
                    personalizationTableColumnLoading: false,
                 },
                 deletedPersonalizationTableColumnData: {
                    deletedPersonalizationTableColumnData: [], 
                    deletedPersonalizationTableColumnLoading: true
                },
                errorState: {
                    error: false,
                    error_message: null
                }     
         }

         case PersonalizationDataActions.PersonalizationActionTypes.SetDeletedTableColumnPersonalizationData:
            return {
                ...state,
                personalizationTableColumnData:{
                    personalizationTableColumnData: [],
                    personalizationTableColumnLoading: false,
                    personalizationTableColumnError: false,
                 },
                deletedPersonalizationTableColumnData: {
                    deletedPersonalizationTableColumnData: action.payload, 
                    deletedPersonalizationTableColumnLoading: false
                },
                errorState: {
                    error: false,
                    error_message: null
                }     
         }
        case PersonalizationDataActions.PersonalizationActionTypes.SetError: {
            return {
                ...state,
                personalizationTableColumnData:{
                    personalizationTableColumnData: [...state.personalizationTableColumnData.personalizationTableColumnData],
                    personalizationTableColumnLoading: false,
                    personalizationTableColumnError: true,
                    totalCount: state.personalizationTableColumnData.totalCount
                },
                addedPersonalizationTableColumnData:{ 
                    addedPersonalizationTableColumnData: {}, 
                    addedPersonalizationTableColumnLoading: false
                },
                updatePersonalizationTableColumnData:{
                    updatePersonalizationTableColumnData:[],
                    updatePersonalizationTableColumnDataLoading:false,
                },
                errorState: {
                    error: true,
                    error_message: action.payload
                }
            }

        }    
        default:
            return state;
    }
}