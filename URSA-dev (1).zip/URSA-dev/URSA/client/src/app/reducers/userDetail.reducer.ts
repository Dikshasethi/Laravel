import * as UserDetailActions from '../actions/userDetail.actions';

const initialState = {
    details : {},
    isloggedOut : false,
    isTimeout: false,
    isfetch: false,
    isLoginError : false
}

export default function (state = initialState, action: UserDetailActions.UserDetailActions){
    switch(action.type){
        case UserDetailActions.UserDetailActionTypes.LoginUser:
            return {...state, LoginDetail : action.payload, isfetch : true, isLoginError : false}
        case UserDetailActions.UserDetailActionTypes.SetUserDetail:
            return {
                ...state, 
                details : action.payload, 
                isfetch : false, 
                isLoginError : action.payload.hasError || action.payload.error ? true : false,
                isTimeout : (
                    action.payload.hasError || action.payload.error
                ) || !action.payload.authTokenExpiryTime ? state.isTimeout : false
            }
        case UserDetailActions.UserDetailActionTypes.GetUserDetail:
            return {...state, isfetch : true}
        case UserDetailActions.UserDetailActionTypes.LogoutUser:
            return {...state, isTimeout: false, details : {}}
        case UserDetailActions.UserDetailActionTypes.LogoutViewChange:
            return {...state, isloggedOut : action.payload}
        case UserDetailActions.UserDetailActionTypes.ClearUserDetail:
             return {...state, details : {}, isloggedOut : false}        
        case UserDetailActions.UserDetailActionTypes.UserTimedOut:{
            return {...state, isTimeout : true}
        } 
        case UserDetailActions.UserDetailActionTypes.RefreshUserSessionGet: 
            return {...state}
        case UserDetailActions.UserDetailActionTypes.RefreshUserSessionSet: 
        let newSessionUser = state.details;
            newSessionUser['authToken'] = action.payload.authToken; 
            newSessionUser['authTokenDuration'] = action.payload.authTokenDuration; 
            newSessionUser['authTokenExpiryTime'] = action.payload.authTokenExpiryTime; 
            newSessionUser['authDuration'] = action.payload.authDuration; 
            return {...state, details: newSessionUser, isTimeout : false}

        case UserDetailActions.UserDetailActionTypes.NewSessionDurationGet: 
            return {...state}

        case UserDetailActions.UserDetailActionTypes.NewSessionDurationSet: 
            let _newSessionUser = state.details;
            let newDuration =  _newSessionUser['authDuration'] != action.payload._authDuration ? true : false;
            _newSessionUser['authToken'] = action.payload._authToken; 
            _newSessionUser['authTokenDuration'] = action.payload._authTokenDuration; 
            _newSessionUser['authTokenExpiryTime'] = action.payload._authTokenExpiryTime; 
            _newSessionUser['authDuration'] = action.payload._authDuration; 
            _newSessionUser['access_token'] = action.payload._access_token; 
            _newSessionUser['expiryTime'] = action.payload._expiryTime; 
            return {...state, details: newDuration ? _newSessionUser : state.details, isTimeout : false}

        case UserDetailActions.UserDetailActionTypes.RefreshElasticSearchTokenGet: 
            return {...state}

        case UserDetailActions.UserDetailActionTypes.RefreshElasticSearchTokenSet: 
            let updatedSession = state.details;
            let { access_token='', expiryTime='', esError=false, hasError=false } = action.payload

            if(!esError && !hasError){
                updatedSession['access_token'] = access_token; 
                updatedSession['expiryTime'] = expiryTime; 
                updatedSession['esError'] = false
            }

            return {...state, details : updatedSession }
        case UserDetailActions.UserDetailActionTypes.SetUserDetailReducer:
            return {
                ...state,
                ...action.payload
            }
        default:
            return state;
    }
}