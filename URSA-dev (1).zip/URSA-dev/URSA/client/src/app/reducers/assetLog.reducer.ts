import * as AssetLogActions from '../actions/assetLogs.actions';

const initialState = {
    assetLogList : [],
    totalCount : 0,
    isLoading : false,
    hasError : false,
    filterObj : {}
}

export default function(state = initialState, action: AssetLogActions.AssetLogTypes){
    switch(action.type){
        case AssetLogActions.AssetLogActionTypes.GetAssetLogs:
            return {
                ...state,
                isLoading : true,
                hasError : false
            }
        case AssetLogActions.AssetLogActionTypes.SetAssetLogs:
            return {
                ...state,
                isLoading : false,
                hasError : action.payload['hasError'] ? true : false,
                assetLogList : action.payload['hasError'] ? state.assetLogList : 
                [...state.assetLogList, ...action.payload['results']],
                totalCount : action.payload['hasError'] ? state.totalCount : 
                action.payload['total_count']
            }

        case AssetLogActions.AssetLogActionTypes.SetAssetIdBusinessUnit:
            return{
                ...state,
                filterObj:{
                    assetid : action.payload['assetid'],
                    businessunit : action.payload['businessunit'],
                }
            }
                    
            
        case AssetLogActions.AssetLogActionTypes.ResetLogReducer:
            return initialState;
        default:
            return state;
    }
}