import * as ProposalPageDataActions from '../actions/proposalPageData.action'
import * as _ from 'lodash';

const initialState = {
    proposalData : {
        proposalPageInfoData : {},
        hardReservedAssets : [],
        checkedOutAssets : [],
        checkedInAssets : [],
        proposalDataLoading : false,
        proposalDataError : false
    },
    isFetchingProposalData : false,
    hrIsLoading : false,
    hardReserveMode : false,
    cartIndex : [],
    proposalNumber : '',
    category : '',
    subtype2 : '',
    startDate : '',
    endDate : '',
    projectNumber : '',
    pdid : '',
    hrResponseObj : {},
    maxHrCount : 0,
    pdidIndex : 0,
    businessUnit : '',
    customerName : '',
    proposalDescription : '',
    pcbusinessunit : '',
    projectid: '',
    custodian: '',
    projectsAutocompleteList : [],
    getProjectsAutocompleteLoading : false,
    getProjectsAutocompleteError : false,
    crmnumber:'',
    validatedHardReservedData:[]
}

export default function(state = initialState, action: ProposalPageDataActions.ProposalPageDataTypes) {
    switch(action.type){
        case ProposalPageDataActions.ProposalPageDataActionTypes.GetProposalPageData:
            return {
                ...state, 
                payload : action.payload, 
                proposalData : {
                    ...state.proposalData,
                    proposalDataLoading : true,
                    proposalDataError : false
                }
            }
        case ProposalPageDataActions.ProposalPageDataActionTypes.SetProposalPageData:
            return {
                ...state, 
                proposalData : {
                    proposalPageInfoData : action.payload.proposalPageInfoData || {},
                    hardReservedAssets : action.payload.hardReservedAssets || [],
                    checkedOutAssets : action.payload.checkedOutAssets || [],
                    checkedInAssets : action.payload.checkedInAssets || [],
                    proposalDataLoading : false,
                    proposalDataError : action.payload.error || action.payload.hasError ? 
                    true : false
                }
            }
        case ProposalPageDataActions.ProposalPageDataActionTypes.SetHardReserveMode:
            return {
                ...state,
                hardReserveMode : true,
                proposalNumber : action.payload['proposalNumber'],
                projectNumber : action.payload['projectNumber'],
                category : action.payload['category'],
                subtype2 : action.payload['subtype2'],
                startDate : action.payload['startDate'],
                endDate : action.payload['endDate'],
                maxHrCount : action.payload['maxHrCount'],
                pdid : action.payload['pdid'],
                pdidIndex : action.payload['pdidIndex'],
                businessUnit : action.payload['businessUnit'],
                customerName : action.payload['customerName'],
                proposalDescription : action.payload['proposalDescription'],
                pcbusinessunit : action.payload['pcbusinessunit'],
                projectid : action.payload['projectid'],
                crmnumber:action.payload['crmnumber'],
                hrResponseObj : {}
            }
        case ProposalPageDataActions.ProposalPageDataActionTypes.ResetHardReserveMode:
            return {
                ...state,
                hardReserveMode : false,
                proposalNumber : '',
                projectNumber : '',
                category : '',
                subtype2 : '',
                startDate : '',
                endDate : '',
                maxHrCount : 0,
                pdid : '',
                pdidIndex : 0,
                businessUnit : '',
                customerName : '',
                proposalDescription : '',
                pcbusinessunit : '',
                projectid : '',
                hrResponseObj : {}
            }
        case ProposalPageDataActions.ProposalPageDataActionTypes.SetHardReserveCart:
            return {
                ...state,
                cartIndex : state['cartIndex'].includes(action.payload) ?
                state['cartIndex'].filter(item => {
                    return item !== action.payload
                })
                : 
                [...state['cartIndex'], action.payload]
            }
        case ProposalPageDataActions.ProposalPageDataActionTypes.ResetCart:
            return {
                ...state,
                cartIndex : []
            }
        case ProposalPageDataActions.ProposalPageDataActionTypes.CreateReservation:
            return {
                ...state,
                hrIsLoading : true,
                hrResponseObj : {}
            }
        case ProposalPageDataActions.ProposalPageDataActionTypes.HardReservationResponse:
            return {
                ...state,
                hrIsLoading : false,
                hrResponseObj : action.payload
            }
        case ProposalPageDataActions.ProposalPageDataActionTypes.ResetProposalPageData:
            return initialState;
        case ProposalPageDataActions.ProposalPageDataActionTypes.CancelReservation:
            return{
                ...state,
                hrIsLoading : true,
                hrResponseObj : {}
            }
        case ProposalPageDataActions.ProposalPageDataActionTypes.GetProjectAutoComplete:
            return {
                ...state,
                getProjectsAutocompleteLoading : true,
                getProjectsAutocompleteError : false
            }
        case ProposalPageDataActions.ProposalPageDataActionTypes.SetProjectAutoComplete:
            return {
                ...state,
                getProjectsAutocompleteLoading : false,
                getProjectsAutocompleteError : action.payload['error'] || action.payload['hasError'] ? true : false,
                projectsAutocompleteList : action.payload['error'] || action.payload['hasError'] ? [] : action.payload['results']
            }

        case ProposalPageDataActions.ProposalPageDataActionTypes.ValidateHardReserveAssetDate:
            return {...state, payload : action.payload, isFetchingProposalData : false}  
            
        case ProposalPageDataActions.ProposalPageDataActionTypes.SetValidateHardReserveAssetDate:
            return {
                ...state, 
                validatedHardReservedData :{
                    validatedHardReservedData:action.payload,
                    isFetchingProposalData:false
                }           
            }
        default:
            return state;
    }
}