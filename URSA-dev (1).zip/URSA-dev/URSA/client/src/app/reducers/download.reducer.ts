import * as DownloadActions from '../actions/download.action'
const initialState = {
    downloadData: [],
    isLoading: false
}

export default function (state = initialState, action: DownloadActions.DownloadTypes) {
    switch (action.type) {
        case DownloadActions.DownloadActionTypes.GetDownloadData:
            return {
                ...state,
                isLoading: true
            }
        case DownloadActions.DownloadActionTypes.SetDownloadData:
            return {
                ...state,
                downloadData: action.payload,
                isLoading: false
            }
        case DownloadActions.DownloadActionTypes.ClearDownloadData:
            return {
                ...state,
                downloadData: {}
            }
        default:
            return state;
    }
}