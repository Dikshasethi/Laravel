import * as CheckoutDataActions from '../actions/checkout.action'
const initialState = {
    readyToCheckOutData : {
        hardReservedAssets : [],
        hardReservedAssetsTotalCount : 0,
        readyToCheckoutDataLoading : false,
        readyToCheckoutDataError : false
    },
    checkInOutData : {
        checkInOutRecords : [],
        checkInOutTotalCount : 0,
        checkInOutIsLoading : false,
        checkInOutError : false
    },
    readyToCheckOutCount:0,
    checkOutTotalCount:0,
    checkoutFetchIsLoading :false,
    checkedoutData:[],
    checkedinData:[],
    reservationTableData:[],
    validatedCheckoutData:[],
    checkInOutCount:0,
    checkInOutTotalCount:0,
    recheckedoutData:[],
    projectStatus:[],
    editCheckoutData:[]
}

export default function(state = initialState, action: CheckoutDataActions.CheckoutDataTypes) {
    switch(action.type){
        case CheckoutDataActions.CheckoutDataActionTypes.GetReadyToCheckoutData:
            return {
                ...state, 
                payload : action.payload, 
                readyToCheckOutData : {
                    ...state.readyToCheckOutData,
                    readyToCheckoutDataLoading : true,
                    readyToCheckoutDataError : false
                }
            }
        
        case CheckoutDataActions.CheckoutDataActionTypes.SetReadyToCheckoutData:
                let checkOutData = state.readyToCheckOutData && 
                Array.isArray(state.readyToCheckOutData['hardReservedAssets']) ? 
                state.readyToCheckOutData['hardReservedAssets'] : [];
                return {
                    ...state, 
                    readyToCheckOutData : {
                        hardReservedAssets: !action.payload.hasError && 
                        !action.payload.error ? 
                        [...checkOutData, ...action.payload.results] : checkOutData,
                        hardReservedAssetsTotalCount : action.payload.total_count || 0,
                        readyToCheckoutDataLoading : false,
                        readyToCheckoutDataError : action.payload.hasError || action.payload.error ? true : false
                    },
                    // checkoutFetchIsLoading :false           
                }
        case CheckoutDataActions.CheckoutDataActionTypes.ClearCheckoutData:
            return {
                ...state,
                readyToCheckOutData : {
                    hardReservedAssets : [],
                    hardReservedAssetsTotalCount : 0,
                    readyToCheckoutDataLoading : false,
                    readyToCheckoutDataError : false
                }
            }

        case CheckoutDataActions.CheckoutDataActionTypes.GetCheckInOutAssets:
            return {
                ...state, 
                payload : action.payload, 
                checkInOutData : {
                    ...state.checkInOutData,
                    checkInOutIsLoading : true,
                    checkInOutError : false
                }
            }    

        case CheckoutDataActions.CheckoutDataActionTypes.SetCheckInOutAssets:
            let checkInOutData = state.checkInOutData && 
            state.checkInOutData['checkInOutRecords'] && 
            Array.isArray(state.checkInOutData['checkInOutRecords']) ? 
            state.checkInOutData['checkInOutRecords'] : [];
            return {
                ...state, 
                checkInOutData : {
                    checkInOutRecords : !action.payload.hasError && 
                    !action.payload.error ? 
                    [...checkInOutData,...action.payload.results] : checkInOutData,
                    checkInOutTotalCount : action.payload.total_count || 0,
                    checkInOutIsLoading : false,
                    checkInOutError : action.payload.hasError || action.payload.error ? true : false
                },
            } 
       case CheckoutDataActions.CheckoutDataActionTypes.ClearCheckInOutAssets:
           return {
               ...state,
               checkInOutData : {
                   checkInOutRecords : [],
                   checkInOutTotalCount : 0,
                   checkInOutIsLoading : false,
                   checkInOutError : false
               }
           }

        case CheckoutDataActions.CheckoutDataActionTypes.ChangeReadyToCheckoutData:
            return {...state, payload : action.payload, checkoutFetchIsLoading :true}    

        case CheckoutDataActions.CheckoutDataActionTypes.CheckOutAsset:
            return {
                ...state,
                payload : action.payload,
                checkedoutData :{
                    checkoutFetchIsLoading:true
                },
                checkoutFetchIsLoading :true}

        case CheckoutDataActions.CheckoutDataActionTypes.SetCheckedOutData:
            return {
                ...state, 
                checkedoutData :{
                    checkedoutData:action.payload,
                    checkoutFetchIsLoading:false
                } ,
                checkoutFetchIsLoading :false           
            }
        case CheckoutDataActions.CheckoutDataActionTypes.RemoveReadyToCheckoutData:
            return {...state, payload : action.payload, checkoutFetchIsLoading :true}

        case CheckoutDataActions.CheckoutDataActionTypes.CheckInAsset:
            return {...state, payload : action.payload, checkoutFetchIsLoading :true}
            
        case CheckoutDataActions.CheckoutDataActionTypes.CancelCheckedOutAsset:
            return {...state, payload : action.payload, checkoutFetchIsLoading :true}    
            
        case CheckoutDataActions.CheckoutDataActionTypes.SetCheckedInData:
            return {
                ...state, 
                checkedinData :{
                    checkedinData:action.payload,
                    checkoutFetchIsLoading:false
                } ,
                checkoutFetchIsLoading :false           
            }

        case CheckoutDataActions.CheckoutDataActionTypes.GetReservationTableData:
            return {...state, payload : action.payload, checkoutFetchIsLoading :true}


        case CheckoutDataActions.CheckoutDataActionTypes.SetReservationTableData:
            return {
                ...state, 
                reservationTableData :{
                    reservationTableData:action.payload,
                    checkoutFetchIsLoading:false
                } ,
                checkoutFetchIsLoading :false           
            }  
            
        case CheckoutDataActions.CheckoutDataActionTypes.ValidateCheckoutAsset:
            return {...state, payload : action.payload, checkoutFetchIsLoading :true}   

        case CheckoutDataActions.CheckoutDataActionTypes.SetValidatedCheckoutAsset:
            return {
                ...state, 
                validatedCheckoutData :{
                    validatedCheckoutData:action.payload,
                    checkoutFetchIsLoading:false
                } ,
                checkoutFetchIsLoading :false           
            } 
        case CheckoutDataActions.CheckoutDataActionTypes.ReCheckoutAsset:
            return {
                ...state,
                payload : action.payload,
                recheckedoutData : {
                    checkoutFetchIsLoading:true
            }
        }
        case CheckoutDataActions.CheckoutDataActionTypes.SetReCheckedoutAsset:
            return {
                ...state, 
                recheckedoutData : {
                    recheckedoutData:action.payload,
                    checkoutFetchIsLoading:false
            },
        }

        case CheckoutDataActions.CheckoutDataActionTypes.GetProjectStatus:
            return {...state, payload : action.payload, checkoutFetchIsLoading :true}
        
        case CheckoutDataActions.CheckoutDataActionTypes.SetProjectStatus:
            return {
                ...state, 
                projectStatus : {
                    projectStatus:action.payload,
                    checkoutFetchIsLoading:false
            },
        }
       case CheckoutDataActions.CheckoutDataActionTypes.EditCheckoutAssets:
       return {...state, payload : action.payload, editCheckoutFetchIsLoading :true}  

       case CheckoutDataActions.CheckoutDataActionTypes.SeEditCheckOutAssets:
            return {...state, 
                editCheckoutData : {
                    editCheckoutData :action.payload,
                    editCheckoutFetchIsLoading:false
                }, 
            }  

        default:
            return state;
    }
}