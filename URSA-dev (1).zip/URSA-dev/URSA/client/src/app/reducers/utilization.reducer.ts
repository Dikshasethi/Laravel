import * as utilizationAction from '../actions/utilization.actions';

const initialState = {
    utilizationPercentage  : [], 
    utilizationloading : false
}

export default function (state = initialState, action: utilizationAction.UtilizationType) {
    switch (action.type) {
        case utilizationAction.UtilizationActionType.GetUtilization:
            return {
                ...state,
                payload: action.payload,
                utilizationloading : true,
            }
        case utilizationAction.UtilizationActionType.SetUtilization:
            return {
                ...state,
                utilizationPercentage : action.payload['productList'],
                utilizationloading : false,
            }
 
        default:
            return state;
    }

    
}