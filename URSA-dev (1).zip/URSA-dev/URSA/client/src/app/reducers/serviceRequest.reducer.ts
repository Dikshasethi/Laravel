import * as ServiceRequestDataActions from '../actions/serviceRequest.actions'
import * as _ from 'lodash';
import update from 'immutability-helper';

const initialState = {
    serviceRequestData: {
        serviceRequestData: [],
        serviceRequestDataLoading : false,
    },
    requestType: {
        requestTypeData: [],
        requestTypeDataLoading: false,
    },
    scopeType: {
        scopeTypeData: [],
        scopeTypeDataLoading: false
    },
    workType: {
        workTypeData: [],
        workTypeDataLoading: false
    },
    serviceGroup: {
        serviceGroupData: [],
        serviceGroupDataLoading: false
    },
    treeNode: {
        treeNodeData: [],
        treeNodeDataLoading: false
    },
    serviceCenter: {
        serviceCenterData: [],
        serviceCenterDataLoading: false
    },
    serviceRequestListData: {
        serviceRequestListData: [],
        serviceRequestListLoading : false,
        serviceRequestListError: false,
        totalCount: 0
    },
    createdServiceRequestData: { 
        addServiceRequestData: {}, 
        addServiceRequestLoading: false
    },
    deletedServiceRequestData: {
        deleteServiceRequestData: {}, 
        deleteServiceRequestLoading: false
    },
    errorState: {
        errorLoading: false,
        error: {}
    },
    onScrollLoading : false,
    sort: {}
}

export default function(state = initialState, action: ServiceRequestDataActions.ServiceRequestDataTypes) {
    switch(action.type){
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.GetRequestType:
            return {
               ...state,
               requestType: {
                    requestTypeData: [],
                    requestTypeDataLoading: true,
                },
               createdServiceRequestData:{ 
                    addServiceRequestData: {}, 
                    addServiceRequestLoading: false
                },
                deletedServiceRequestData: {
                    deleteServiceRequestData: {}, 
                    deleteServiceRequestLoading: false
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetRequestType:
        return {
            ...state,
            requestType: {
                requestTypeData: [...action.payload],
                requestTypeDataLoading: false,
            },
            errorState: {
                errorLoading: false,
                error: {}
            }
        }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.GetScopeType:
            return {
                ...state,
                scopeType: {
                    scopeTypeData: [],
                    scopeTypeDataLoading: true
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
        }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetScopeType:
            return {
                ...state,
                scopeType: {
                    scopeTypeData: [...action.payload],
                    scopeTypeDataLoading: false
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
        }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.GetWorkType:
            return {
                ...state,
                workType: {
                    workTypeData: [],
                    workTypeDataLoading: true
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
        }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetWorkType:
            return {
                ...state,
                workType: {
                    workTypeData: [...action.payload],
                    workTypeDataLoading: false
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
        }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.GetServiceGroup:
            return {
                ...state,
                serviceGroup: {
                    serviceGroupData: [],
                    serviceGroupDataLoading: true
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
        }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetServiceGroup:
            return {
                ...state,
                serviceGroup: {
                    serviceGroupData:[...action.payload],
                    serviceGroupDataLoading: false
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
        }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.ResetServiceGroup:
            return {
                ...state,
                serviceGroup: {
                    serviceGroupData: [],
                    serviceGroupDataLoading: false
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
        }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.ResetWorkType:
            return {
                ...state,
                workType: {
                    workTypeData: [],
                    workTypeDataLoading: false
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
        }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.ResetScopeType:
            return {
                ...state,
                scopeType: {
                    scopeTypeData: [],
                    scopeTypeDataLoading: false
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
        }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.GetServiceRequestList:
            return {
                ...state,
                serviceRequestListData:{
                    serviceRequestListData: [...state.serviceRequestListData.serviceRequestListData],
                    serviceRequestListLoading : true,
                    serviceRequestError: false,
                },
                onScrollLoading : action.payload.skip ? true : false
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetServiceRequestList:
            return {
                ...state,
                serviceRequestListData:{
                    serviceRequestListData: action.payload.hasError ? [] : [...state.serviceRequestListData.serviceRequestListData, ...action.payload['results']],
                    serviceRequestListLoading : false,
                    serviceRequestListError: action.payload.hasError ? true : false,
                    totalCount : action.payload.hasError ? state.serviceRequestListData.totalCount : 
                    action.payload['total_count']
                },
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.ResetServiceRequestListData:
            return initialState;  

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetSorting:
                return {
                    ...state,
                    sort: {
                        ...state.sort,
                        ...action.payload
                    }
                }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.ReSetSorting:
            return {
                ...state,
                sort: {}
            }    
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetError:
            return {
                ...state,
                requestType: {
                    requestTypeData: [...state.requestType.requestTypeData],
                    requestTypeDataLoading: false,
                },
                scopeType: {
                    scopeTypeData: [...state.scopeType.scopeTypeData],
                    scopeTypeDataLoading: false
                },
                workType: {
                    workTypeData: [...state.workType.workTypeData],
                    workTypeDataLoading: false
                },
                serviceGroup: {
                    serviceGroupData: [...state.serviceGroup.serviceGroupData],
                    serviceGroupDataLoading: false
                },
                treeNode: {
                    treeNodeData: [...state.treeNode.treeNodeData],
                    treeNodeDataLoading: false
                },
                serviceCenter: {
                    serviceCenterData: [...state.serviceCenter.serviceCenterData],
                    serviceCenterDataLoading: false
                },
                createdServiceRequestData:{
                    addServiceRequestData: {}, 
                    addServiceRequestLoading: false
                },
                deletedServiceRequestData: {
                    deleteServiceRequestData: {}, 
                    deleteServiceRequestLoading: false
                },
                serviceRequestListData:{
                    serviceRequestListData: [...state.serviceRequestListData.serviceRequestListData],
                    serviceRequestListLoading : false,
                    serviceRequestListError: true,
                },
                errorState: {
                    errorLoading: true,
                    error: action.payload
                }
        }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.GetTreeNode:
            return {
               ...state,
               treeNode: {
                treeNodeData: [],
                treeNodeDataLoading: true
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }
        
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetTreeNode:
            return {
                ...state,
                treeNode: {
                    treeNodeData:  [...action.payload],
                    treeNodeDataLoading: false,
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.ResetTreeNode:
            return {
                ...state,
                treeNode: {
                    treeNodeData:  [],
                    treeNodeDataLoading: false,
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.GetServiceCenter:
            return {
                ...state,
                serviceCenter: {
                    serviceCenterData: [],
                    serviceCenterDataLoading: true
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }
        
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetServiceCenter:
            return {
                ...state,
                serviceCenter: {
                    serviceCenterData: [...action.payload],
                    serviceCenterDataLoading: false
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }

        case ServiceRequestDataActions.ServiceRequestDataActionTypes.ResetServiceCenter:
            return {
                ...state,
                serviceCenter: {
                    serviceCenterData: [],
                    serviceCenterDataLoading: false
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.GetServiceRequestData:
            return {
                ...state, 
                serviceRequestData: {
                    serviceRequestData: [],
                    serviceRequestDataLoading : true,
                },
                createdServiceRequestData:{ 
                    addServiceRequestData: {}, 
                    addServiceRequestLoading: false
                },
                deletedServiceRequestData: {
                    deleteServiceRequestData: {}, 
                    deleteServiceRequestLoading: false
                },
                errorState: {
                    error: {},
                    errorLoading: false
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetServiceRequestData:
            return {
                ...state, 
                serviceRequestData: {
                    serviceRequestData: action.payload['serviceRequest'],
                    serviceRequestDataLoading : false,
                },
                errorState: {
                    error: {},
                    errorLoading: false
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetAssetDataInServiceRequest:
            const serviceRequestOject = {
                ...state.serviceRequestData.serviceRequestData,
                assets: action.payload.selectedAssetsObject,
                originmodule: action.payload.originmodule,
                projectnumber: action.payload.projectnumber,
                projectmanagername: action.payload.projectmanagername,
                customername: action.payload.customername,
            }
            return {
                ...state, 
                serviceRequestData: {
                    serviceRequestData: serviceRequestOject,
                    serviceRequestDataLoading : false,
                },
                errorState: {
                    error: {},
                    errorLoading: false
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetAdditionalAssetinServiceRequest:
            let assetDetails = state.serviceRequestData.serviceRequestData['assets'] || [];
            let newAssetDetails = [...assetDetails, ...action.payload.reqObj] 
            const serviceRequestOjectNew = {
                ...state.serviceRequestData.serviceRequestData,
                assets: newAssetDetails,
            }
            return {
                ...state, 
                serviceRequestData: {
                    serviceRequestData: serviceRequestOjectNew,
                    serviceRequestDataLoading : false,
                },
                errorState: {
                    error: {},
                    errorLoading: false
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.DeleteSelectedAsset:
            let selectedAssetDeatils = state.serviceRequestData.serviceRequestData['assets'] || [];
            selectedAssetDeatils = update(selectedAssetDeatils, { $splice: [[action.payload.indexToDelete, 1]] } );
            const deletedServiceRequestOject = {
                ...state.serviceRequestData.serviceRequestData,
                assets: selectedAssetDeatils
            }
            return {
                ...state, 
                serviceRequestData: {
                    serviceRequestData: deletedServiceRequestOject,
                    serviceRequestDataLoading : false,
                },
                errorState: {
                    error: {},
                    errorLoading: false
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.CreateServiceRequest:
            return {
                ...state,
                createdServiceRequestData:{
                    addServiceRequestData: {}, 
                    addServiceRequestLoading: true
                },
                errorState: {
                 errorLoading: false,
                 error: {}
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.EditServiceRequest:
            return {
                ...state,
                createdServiceRequestData:{
                    addServiceRequestData: {}, 
                    addServiceRequestLoading: true
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.DeleteServiceRequest:
            return {
                ...state,
                deletedServiceRequestData: {
                    deleteServiceRequestData: {}, 
                    deleteServiceRequestLoading: true
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetCreateServiceRequestData:
            return {
                ...state,
                createdServiceRequestData: {
                    addServiceRequestData: action.payload,
                    addServiceRequestLoading: false
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.SetDeleteServiceRequestData:
            return {
                ...state,
                deletedServiceRequestData: {
                    deleteServiceRequestData: action.payload, 
                    deleteServiceRequestLoading: false
                },
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.ResetServiceRequestError:
            return {
                ...state,
                errorState: {
                    errorLoading: false,
                    error: {}
                }
            }
        case ServiceRequestDataActions.ServiceRequestDataActionTypes.ResetServiceRequest:
            return initialState;
        default:
            return state;
    }
}