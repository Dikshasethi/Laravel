import * as RoleMatrixActions from '../actions/roleMatrix.action';

const initialState = {
    permissionData: {
        permissionResult: [],
    },
    roleData: {
        roleResult: [],
    },
    permissionDataById: {
        permissionByIdResult: {},
    },
    roleDataById: {
        roleByIdResult: {},
    },
    userList: {
        userListResult: [],
        userListCount: 0,
        userListFetchisLoading: false
    },
    userInfo: {
        userInfoList: [],
    },
    userRoleById: {
        userroleByIdResult: {},
    },
    restrictionData: {
        restrictionResult: [],
    },
    userListFilter: {},
    userValidation : true,
    errorState: {
        error: false,
        error_message: null
    },
    loading:false
}

export default function (state = initialState, action: RoleMatrixActions.RoleMatrixTypes) {
    switch (action.type) {
        case RoleMatrixActions.RoleMatrixActionTypes.SetRole:
            return {
                ...state,
                roleData: {
                    roleResult: action.payload
                },
                loading:false,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.GetRole:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                },

            }
        case RoleMatrixActions.RoleMatrixActionTypes.CreatePermission:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.EditPermission:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.SetPermission:
            return {
                ...state,
                permissionData: {
                    permissionResult: action.payload
                },
                loading:false,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.GetPermission:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.DeletePermission:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.GetPermissionByID:
            return {
                ...state,
                permissionDataById: {
                    permissionByIdFetchisLoading: true
                },
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.SetPermissionByID:
            return {
                ...state,
                permissionDataById: {
                    permissionByIdResult: action.payload,
                },
                loading:false,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.CreateRole:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.EditRole:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.GetRoleByID:
            return {
                ...state,
                roleDataById: {
                    rolenByIdFetchisLoading: true
                },
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.SetRoleByID:
            return {
                ...state,
                roleDataById: {
                    roleByIdResult: action.payload,
                },
                loading:false,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.DeleteRole:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.GetUserList:
            return {
                ...state,
                loading:true,
                userList: {
                    ...state.userList,
                    userListFetchisLoading: true,
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.SetUserList:
            const { userList: { userListResult = [] } } = state;
            return {
                ...state,
                userList: {
                    userListResult: action.payload.hasError ? userListResult : [...userListResult, ...action.payload.results],
                    userListCount: action.payload.total_count,
                    userListFetchisLoading: false
                },
                loading:false,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.ReSetUserList:
            return {
                ...state,
                userList: {
                    userListResult: [],
                    userListFetchisLoading: false
                },
                loading:false,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.GetUserInfo:
            return {
                ...state,
                userInfo: {
                    userInfoListFetchisLoading: true,
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.SetUserInfo:
            return {
                ...state,
                userInfo: {
                    userInfoList: action.payload,
                    userInfoListFetchisLoading: false,
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.CreateUser:
            return {
                ...state,
                userList: {
                    userListFetchisLoading: true,
                },
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.CloneUserRole:
            return {
                ...state,
                userList: {
                    userListFetchisLoading: true,
                },
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.GetUserRoleByID:
            return {
                ...state,
                userRoleById: {
                    userroleByIdFetchisLoading: true,
                },
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.SetUserRoleByID:
            return {
                ...state,
                userRoleById: {
                    userroleByIdResult: action.payload,
                },
                loading:false,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.GetRestrictions:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.SetRestrictions:
            return {
                ...state,
                restrictionData: {
                    restrictionResult: action.payload,
                },
                loading:false,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.CreateRestriction:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.EditRestriction:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.DeleteRestriction:
            return {
                ...state,
                loading:true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        case RoleMatrixActions.RoleMatrixActionTypes.SetUserListFilters: {
            const { filter = {} } = { ...action.payload };
            return {
                ...state,
                userListFilter: filter,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        }
        case RoleMatrixActions.RoleMatrixActionTypes.ReSetUserListFilters: {
            return {
                ...state,
                userListFilter: {},
                errorState: {
                    error: false,
                    error_message: null
                }
            }

        }
        case RoleMatrixActions.RoleMatrixActionTypes.GetUserRolesValidation: {
            return {
                ...state,
                loading: true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        }
        case RoleMatrixActions.RoleMatrixActionTypes.SetUserRolesValidation: {
            return {
                ...state,
                loading: false,
                userValidation: action.payload['total_count'] ? false : true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        }
        case RoleMatrixActions.RoleMatrixActionTypes.setError: {
            return {
                ...state,
                loading:false,
                userList: {
                ...state.userList,
                    userListFetchisLoading: false
                },
                errorState: {
                    error: true,
                    error_message: action.payload
                }
            }

        }
        default:
            return state;
    }
}