import * as ImageUploadActions from '../actions/imageUpload.actions';

const initialState = {
    detailsView : {
        activeList : [],
        imageInList : [],
        fileData : {},
        errorList : [],
        loadingList : [],
        thumbnailList : {},
        thumbnailMap : {},
        deleteUpdate : {}
        
    },
    summaryView : {
        activeList : [],
        fileData : {},
        errorList : [],
        loadingList : []
    }
}

export default function(state = initialState, action: ImageUploadActions.ImageUploadActions){
    switch(action.type){
        case ImageUploadActions.ImageUploadActionTypes.SetImageActiveList:
        return {
            ...state, [action.payload.view] : {
            ...state[action.payload.view],
            activeList : [...state[action.payload.view]['activeList'], action.payload.index]
        }};
        case ImageUploadActions.ImageUploadActionTypes.GetImageFile:

        if(state[action.payload.view].imageInList && state[action.payload.view].imageInList.includes(action.payload.index)){
            return { //IF THE INDEX HAS DATA
                ...state, 
                [action.payload.view] : {
                ...state[action.payload.view],
                fileData : 
                {
                    ...state[action.payload.view]['fileData'],
                    [action.payload.index] : [...state[action.payload.view]['fileData'][action.payload.index], action.payload.imageFile]
                    
                },
                errorList : state[action.payload.view]['errorList'].filter(i => i !== action.payload.index)
            }}
        }
        else{ //IF THE INDEX IS NULL
            return{
                ...state, 
                [action.payload.view] : {
                ...state[action.payload.view],
                fileData : 
                {
                    ...state[action.payload.view]['fileData'],
                    [action.payload.index] :  ["init", action.payload.imageFile]
                },
                errorList : state[action.payload.view]['errorList'].filter(i => i !== action.payload.index),
                imageInList : [...state[action.payload.view]['imageInList'], action.payload.index]
            }
        }};
    
        case ImageUploadActions.ImageUploadActionTypes.CancelImageUpload:
        let carryOver = state[action.payload.view]['fileData'][action.payload.index];
        if (carryOver){
            let counter = 0;
            for (let i = 1; i < carryOver.length; i++){
                if(carryOver[i]['name'] == action.payload.imgName){
                    carryOver.splice(i, 1)
                }
            }
        }

        let tempActiveList : any;
        if (carryOver.length <= 1){
            tempActiveList = state[action.payload.view]['activeList'].filter(index => {
                return index !== action.payload.index;
            })
        }
        else{
            tempActiveList = state[action.payload.view]['activeList'];
        }

        return {
            ...state,
            [action.payload.view] : {
                ...state[action.payload.view],
                activeList : tempActiveList,
                fileData : {
                    ...state[action.payload.view]['fileData'],
                    [action.payload.index] : carryOver
                },
                errorList : state[action.payload.view]['errorList'].filter(i => i !== action.payload.index)
            }
        }
        case ImageUploadActions.ImageUploadActionTypes.SetImageUploadErrorList:
            return {
                ...state,
                [action.payload.view] : {
                    ...state[action.payload.view],
                    errorList : [...state[action.payload.view]['errorList'], action.payload.index],
                    loadingList : state[action.payload.view]['loadingList'].filter(i => i !== action.payload.index),
                    activeList : state[action.payload.view]['activeList']
                }
            }
        case ImageUploadActions.ImageUploadActionTypes.SubmitFileToApi:
            return {
                ...state,
                [action.payload.view] : {
                    ...state[action.payload.view],
                    loadingList : [...state[action.payload.view]['loadingList'], action.payload.index]
                }
            }
        case ImageUploadActions.ImageUploadActionTypes.RemoveUploadError:
            return {
                ...state,
                [action.payload.view] : {
                    ...state[action.payload.view],
                    errorList : state[action.payload.view]['errorList'].filter(i => i !== action.payload.index)
                }
            }
        case ImageUploadActions.ImageUploadActionTypes.RemoveUploadFromLoadingList:
            return {
                ...state,
                [action.payload.view] : {
                    ...state[action.payload.view],
                    loadingList : state[action.payload.view]['loadingList'].filter(i => i !== action.payload.index)
                }
            }
        case ImageUploadActions.ImageUploadActionTypes.SetImageUploadResponse:
                return {
                ...state,
                [action.payload.view] : {
                    ...state[action.payload.view],
                    errorList : action.payload.response.error ? 
                        [...state[action.payload.view]['errorList'], action.payload.index] :
                        state[action.payload.view]['errorList'].filter(i => i !== action.payload.index),
                    loadingList : state[action.payload.view]['loadingList'].filter(i => i !== action.payload.index),
                    activeList : action.payload.response.error ?
                        state[action.payload.view]['activeList'] :
                        state[action.payload.view]['activeList'].filter(index => index !== action.payload.index),
                    fileData : action.payload.response.error ? 
                    state[action.payload.view]['fileData']
                    :
                    {
                        ...state[action.payload.view]['fileData'],
                        [action.payload.index] : {}
                    },
                    imageInList : action.payload.response.error ?
                        state[action.payload.view]['imageInList'] :
                        state[action.payload.view]['imageInList'].filter(index => index !== action.payload.index),
                    
                    thumbnailMap : action.payload.response.error || !action.payload.response.updatedAssetImageDetails.thumbnailindex ? 
                                   
                                   state[action.payload.view]['thumbnailList'] 
                                   : 
                                   {
                                       ...[action.payload.view]['thumbnailList'],
                                       [action.payload.index] : action.payload.response.updatedAssetImageDetails.thumbnailindex 
                                   }
                }
            }
        case ImageUploadActions.ImageUploadActionTypes.ResetImageReducer:
            return {
                ...state,
                detailsView : {
                    activeList : [],
                    imageInList : [],
                    fileData : {},
                    errorList : [],
                    loadingList : [],
                    thumbnailList : {},
                    thumbnailMap : {},
                    deleteUpdate : {}

                },
                summaryView : {
                    activeList : [],
                    fileData : {},
                    errorList : [],
                    loadingList : []
                }
            }
        case ImageUploadActions.ImageUploadActionTypes.CallChangeThumbnail:
                return {
                    ...state,
                    [action.payload.view] : {
                        ...state[action.payload.view],
                        loadingList : [...state[action.payload.view]['loadingList'], action.payload.index]
                    }
                }

        case ImageUploadActions.ImageUploadActionTypes.ReturnChangeThumbnail :
                    return { 
                        ...state, 
                        [action.payload.view] : {
                        ...state[action.payload.view],
                        fileData : 
                        {
                            ...state[action.payload.view]['thumbnailList'],
                            [action.payload.index] :  true
                            
                        },
                        errorList : state[action.payload.view]['errorList'].filter(i => i !== action.payload.index),
                        loadingList : state[action.payload.view]['loadingList'].filter(i => i !== action.payload.index),
                        
                        thumbnailMap : 
                            action.payload.response.error || 
                            (
                                action.payload.response ||
                                action.payload.response.updatedAssetImageDetails ||
                                action.payload.response.updatedAssetImageDetails.thumbnailurl != 'none'
                            ) ? 
                            {
                                ...[action.payload.view]['thumbnailList'],
                                [action.payload.index] : action.payload.response.updatedAssetImageDetails.thumbnailurl
                            } :
                            state[action.payload.view]['thumbnailList'] 

                    }

                }


        case ImageUploadActions.ImageUploadActionTypes.SendRemoveImage:
                return {
                    ...state,
                    [action.payload.view] : {
                        ...state[action.payload.view],
                        loadingList : [...state[action.payload.view]['loadingList'], action.payload.index]
                    }
                }
                case ImageUploadActions.ImageUploadActionTypes.ResponceRemoveImage:        
                        return { 
                            ...state, 
                            [action.payload.view] : {
                            ...state[action.payload.view],

                            errorList : state[action.payload.view]['errorList'].filter(i => i !== action.payload.index),
                            loadingList : state[action.payload.view]['loadingList'].filter(i => i !== action.payload.index),
                            
                            thumbnailMap : action.payload.response.error || !action.payload.response.thumbnailUrl ? 
                            {
                                ...[action.payload.view]['thumbnailList'],
                                [action.payload.index] : ""
                            }
                            : 
                            {
                                ...[action.payload.view]['thumbnailList'],
                                [action.payload.index] : action.payload.response.thumbnailUrl 
                            },

                            deleteUpdate : action.payload.response.error ?
                            {
                                ...[action.payload.view]['deleteUpdate'],
                            }
                            :
                            {
                                ...[action.payload.view]['deleteUpdate'],
                                [action.payload.index] : action.payload.deleteRefrence
                            }
    
                        }
    
                    }


        default: 
        return state;
    }

    
}