import * as EmoActions from '../actions/emo.actions';

const initialState = {
    emoList : [],
    emoCount : 0,
    emoListIsLoading : false,
    emoListError : false,
    emoData: {},
    addedEmo: {},
    emoRecordInfo: {},
    emoPath: '',
    emoMode: false,
    loading: true,
    successEmo:{},
    onScrollLoading : false
    
}

export default function(state = initialState, action: EmoActions.EmoTypes){
    switch(action.type){
        case EmoActions.EmoActionTypes.GetEmoList:
            return {
                ...state,
                emoListIsLoading : true,
                emoListError : false,
                onScrollLoading : action.payload.skip ? true : false
            }
        case EmoActions.EmoActionTypes.SetEmoList:
            let records = action.payload.results || [];
            return {
                ...state,
                emoListIsLoading : false,
                emoListError : action.payload.hasError ? true : false,
                emoList : action.payload.hasError ? [] : [...state.emoList, ...records],
                emoCount : action.payload.total_count,
            }
        case EmoActions.EmoActionTypes.ResetEmoDetails:
            return initialState;  
        case EmoActions.EmoActionTypes.ClearEmoList:
            return {
                ...state,
                emoList : [],
                emoCount : 0,
                emoListError : false,
                emoListIsLoading : false
            };   
        case EmoActions.EmoActionTypes.GenerateEmoData:
            return {
                ...state,
                payload: action.payload,
                emoData: {
                    emoFetchisLoading: true
                }
            }
        case EmoActions.EmoActionTypes.SetEmoData:
            return {
                ...state,
                emoData: {
                    emoData: action.payload,
                    emoFetchisLoading: false
                },
            }
        case EmoActions.EmoActionTypes.GetEmoData:
            return {
                ...state,
                payload: action.payload,
                emoData: {
                    emoFetchisLoading: true
                }
            }
        
        case EmoActions.EmoActionTypes.ShipEmo:
            return {
                ...state,
                payload: action.payload,
                emoData: {
                    emoFetchisLoading: true
                }
            }
        case EmoActions.EmoActionTypes.updateEmo:
            return {
                ...state,
                payload: action.payload,
                emoData: {
                    emoFetchisLoading: true
                }
            }
        
        case EmoActions.EmoActionTypes.setEmoMode:
            let addedEmo = state.addedEmo && state.addedEmo['addedEmo'] ? state.addedEmo['addedEmo'] : [];
            if (action.payload.isEmoDataMerged) {
                addedEmo = [...addedEmo, ...action.payload.emoRecord]
            } else {
                addedEmo = [ ...action.payload.emoRecord]
            }
            return {
                ...state,
                addedEmo: {
                    addedEmo: addedEmo,
                    emoHeaderRecord: action.payload.isEmoDataMerged ? state.addedEmo['emoHeaderRecord'] : action.payload.emoHeaderRecord,
                    emoMode: action.payload.emoMode,
                    emoPath: action.payload.emoPath,
                    previousUrl :action.payload.previousUrl
                },
            }
        case EmoActions.EmoActionTypes.setEmoRecord:
            return {
                ...state,
                emoRecordInfo: {
                    emoRecordInfo: action.payload,
                    loading: false
                }
            }
        case EmoActions.EmoActionTypes.resetEmoRecord:
            return {
                ...state,
                emoRecordInfo: {},
                loading: true
            }
        case EmoActions.EmoActionTypes.resetEmoMode:
            return initialState;
        default:
            return state;
    }
}