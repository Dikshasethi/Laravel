import * as ProductSummaryActions from '../actions/productSummary.actions';

const initialState = {
    productSummaryFetchIsLoading : false,
    productSummaryList : [],
    productSummaryObject : {},
    searchCriteria : {},
    activeStatus : '',
    activeIndex : null,
    productSummaryObjectCache : {},
    scrollTop : 0
}

export default function(state = initialState, action: ProductSummaryActions.ProductSummaryActions){
    switch(action.type){
        case ProductSummaryActions.ProductSummaryActionTypes.GetProductSummary:
            return {...state, productSummaryFetchIsLoading : true}
        case ProductSummaryActions.ProductSummaryActionTypes.SetSummaryScrollTop:
            return {...state, scrollTop : action.payload}
        case ProductSummaryActions.ProductSummaryActionTypes.SetProductSummary:
            let obj = action.payload;
            return {
                ...state, 
                productSummaryList : obj['productList'] || [],
                productSummaryFetchIsLoading : false,
                productSummaryObject : obj
            }
        case ProductSummaryActions.ProductSummaryActionTypes.DestroyProductSummary:
            return {
                ...state,
                productSummaryList : [],
                productSummaryObject : {},
                searchCriteria : {},
                productSummaryFetchIsLoading : false,
                activeStatus : '',
                activeIndex : null
            }
        case ProductSummaryActions.ProductSummaryActionTypes.SetSearchCriteria:
            return {
                ...state,
                searchCriteria : action.payload
            }
        case ProductSummaryActions.ProductSummaryActionTypes.SetSummaryStatusAndIndex:
            return {
                ...state,
                activeStatus : action.payload['status'],
                activeIndex : action.payload['index']
            }
        case ProductSummaryActions.ProductSummaryActionTypes.CacheProductSummaryObject:
            return {
                ...state,
                productSummaryObjectCache : state.productSummaryObject
            }
        case ProductSummaryActions.ProductSummaryActionTypes.SetOnlyProductSummaryObject:
            return {
                ...state,
                productSummaryObject : state.productSummaryObjectCache
            }
        case ProductSummaryActions.ProductSummaryActionTypes.ClearProductSummaryCache:
            return {
                ...state,
                productSummaryObjectCache : {}
            }

        case ProductSummaryActions.ProductSummaryActionTypes.GetSummaryProposalData:  
            state.productSummaryObject['hasProposalError']= false;            
            return {...state, payload : action.payload, productSummaryFetchIsLoading : true}    
        case ProductSummaryActions.ProductSummaryActionTypes.SetSummaryProposalData:
            let proposalData = [];
            if(action.payload.isAuthenticate && action.payload.isAuthenticate=="not authenticated"){
                state.productSummaryObject['isAuthenticate']= "not authenticated";
            }
            else if(action.payload.hasError)
                state.productSummaryObject['hasProposalError']= true;
            else{
                if(action.payload.totalCount> 0)
                    proposalData = action.payload.proposalList
                state.productSummaryObject['productList'][action.payload.index]['proposalList'] = proposalData;
                state.productSummaryObject['productList'][action.payload.index].animationState = 'in';
                state.productSummaryObject['productList'][action.payload.index].showIcon = true  ;
            }
           
            return {
                ...state, 
                productSummaryObject : state.productSummaryObject,
                productSummaryList : [...state.productSummaryList || []],
                productSummaryFetchIsLoading : false
            }        
        default:
            if(state.productSummaryObject['hasProposalError']){
                state.productSummaryObject['hasProposalError']= false;
            }             
            return state;
    }
}