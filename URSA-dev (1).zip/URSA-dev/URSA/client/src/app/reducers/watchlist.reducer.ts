import * as WatchListDataActions from '../actions/watchlist.action'
const initialState = {
    watchListData:{
        watchListData: [],
        watchListLoading : false,
        watchListError: false,
        totalCount: 0
    },
    addedWatchListData:{ 
        addedWatchlistData: {}, 
        addedWatchListLoading: false
    },
    deletedWatchListData: {
        deletedWatchListData: [], 
        deletedWatchListLoading: false
    },
    errorState: {
        error: false,
        error_message: null
    },
    onScrollLoading : false
}

export default function(state = initialState, action: WatchListDataActions.WatchListActions) {
    switch(action.type){
        case WatchListDataActions.WatchListActionTypes.GetWatchListData:
            return {
                ...state,
                watchListData:{
                    watchListData: [...state.watchListData.watchListData],
                    watchListLoading : true,
                    watchListError: false,
                },
                addedWatchListData:{ 
                    addedWatchlistData: {}, 
                    addedWatchListLoading: false
                },
                deletedWatchListData: {
                    deletedWatchListData: [],
                    deletedWatchListLoading: false
                },errorState: {
                    error: false,
                    error_message: null
                },
                onScrollLoading : action.payload.skip ? true : false
            }
        case WatchListDataActions.WatchListActionTypes.ResetWatchListData:
                return initialState;   

        case WatchListDataActions.WatchListActionTypes.SetWatchListData:
            return {
                ...state,
                watchListData:{
                    watchListData: action.payload.hasError ? [] : [...state.watchListData.watchListData, ...action.payload['results']],
                    watchListLoading : false,
                    watchListError: action.payload.hasError ? true : false,
                    totalCount : action.payload.hasError ? state.watchListData.totalCount : 
                    action.payload['total_count']
                },
                addedWatchListData:{ 
                    addedWatchlistData: {}, 
                    addedWatchListLoading: false
                },
                deletedWatchListData: {
                    deletedWatchListData: [],
                    deletedWatchListLoading: false
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }
        
        case WatchListDataActions.WatchListActionTypes.DeleteFromWatchList:
            return {
                    ...state, 
                    payload : action.payload,
                    watchListData:{
                        watchListData: [...state.watchListData.watchListData],
                        watchListLoading : false,
                        watchListError: action.payload.hasError ? true : false,
                        totalCount: state.watchListData.totalCount,
                    },
                    addedWatchListData:{ 
                        addedWatchlistData: {}, 
                        addedWatchListLoading: false
                    }, 
                    deletedWatchListData : {
                        deletedWatchListData: [],
                        deletedWatchListLoading : true
                    },
                    errorState: {
                        error: false,
                        error_message: null
                    }
            }
    
    
        case WatchListDataActions.WatchListActionTypes.SetDeletedWatchListData:
            return {
                    ...state,
                    watchListData:{
                        watchListData: [],
                        watchListLoading : false,
                        watchListError: false,
                    },
                    addedWatchListData:{ 
                        addedWatchlistData: {}, 
                        addedWatchListLoading: false
                    }, 
                    deletedWatchListData: {
                        deletedWatchListData: action.payload,
                        deletedWatchListLoading: false
                    },
                    errorState: {
                        error: false,
                        error_message: null
                    }
            }

            case WatchListDataActions.WatchListActionTypes.AddToWatchList:
                return {
                        ...state, 
                        payload : action.payload,
                        watchListData:{
                            watchListData: [...state.watchListData.watchListData],
                            watchListLoading : false,
                            watchListError: action.payload.hasError ? true : false,
                            totalCount: state.watchListData.totalCount,
                        },
                        addedWatchListData:{ 
                            addedWatchlistData: {}, 
                            addedWatchListLoading: true
                        }, 
                        deletedWatchListData : {
                            deletedWatchListData: [],
                            deletedWatchListLoading : false
                        },
                        errorState: {
                            error: false,
                            error_message: null
                        }
                }

                case WatchListDataActions.WatchListActionTypes.EditInWatchList:
                    return {
                            ...state, 
                            payload : action.payload,
                            watchListData:{
                                watchListData: [...state.watchListData.watchListData],
                                watchListLoading : false,
                                watchListError: action.payload.hasError ? true : false,
                                totalCount: state.watchListData.totalCount,
                            },
                            addedWatchListData:{ 
                                addedWatchlistData: {}, 
                                addedWatchListLoading: true
                            }, 
                            deletedWatchListData : {
                                deletedWatchListData: [],
                                deletedWatchListLoading : false
                            },
                            errorState: {
                                error: false,
                                error_message: null
                            }
                    }
        
        
            case WatchListDataActions.WatchListActionTypes.SetAddedWatchListData:
                return {
                        ...state,
                        watchListData:{
                            watchListData: [],
                            watchListLoading : false,
                            watchListError: false,
                        },
                        addedWatchListData:{ 
                            addedWatchlistData: action.payload, 
                            addedWatchListLoading: false
                        }, 
                        deletedWatchListData: {
                            deletedWatchListData: action.payload,
                            deletedWatchListLoading: false
                        },
                        errorState: {
                            error: false,
                            error_message: null
                        }
                } 

            case WatchListDataActions.WatchListActionTypes.SetError: {
                return {
                    ...state,
                    watchListData:{
                        watchListData: [...state.watchListData.watchListData],
                        watchListLoading : false,
                        watchListError: true,
                    },
                    addedWatchListData:{ 
                        addedWatchlistData: {}, 
                        addedWatchListLoading: false
                    }, 
                    deletedWatchListData: {
                        deletedWatchListData: [],
                        deletedWatchListLoading: false
                    },
                    errorState: {
                        error: true,
                        error_message: action.payload
                    }
                }
    
            }    

        default:
            return state;
    }
}