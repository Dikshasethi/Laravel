import * as CartDataActions from '../actions/cart.action'
const initialState = {
    cartData: { 
        cartData: [], 
        iscartItemsInDB:false,
        cartFetchIsLoading: false
    },
    addedCartData:{ 
        addedCartData: {}, 
        addedCartFetchLoading: false
    },
    deletedCartData: {
         deletedCartData: {}, 
         deletedCartFetchLoading: false
    },
    calenderDataMap: {},
    calendarDataIsLoading: false,
    errorState: {
        error: false,
        error_message: null
    },
}

export default function(state = initialState, action: CartDataActions.CartActions) {
    switch(action.type){
        case CartDataActions.CartActionTypes.AddToCart:
            return {
                ...state, 
                payload : action.payload, 
                addedCartFetchLoading: true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }

        case CartDataActions.CartActionTypes.GetCartData:
            return {
                ...state, 
                payload : action.payload, 
                checkoutFetchIsLoading : true,
                cartData : {
                    ...state.cartData,
                    cartFetchIsLoading : true
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }

        case CartDataActions.CartActionTypes.SetCartData:
            return {
                ...state, 
                addedCartData: {
                    addedCartData: {},
                    addedCartFetchLoading: false
                },
                deletedCartData: {
                    deletedCartData: {},
                    deletedCartFetchLoading: false
                },
                cartData : {
                    cartData : action.payload,
                    iscartItemsInDB: action.payload.length ? false : true,
                    cartFetchIsLoading : false
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }   
            
        case CartDataActions.CartActionTypes.SetAddedCartData:
            return {
                ...state, 
                cartData :{
                    cartData:[],
                    iscartItemsInDB: false, 
                },
                deletedCartData: {
                    deletedCartData : {},
                    deletedCartFetchLoading : false
                },
                addedCartData : {
                    addedCartData:action.payload,
                    addedCartFetchLoading:false
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }       

        case CartDataActions.CartActionTypes.DeleteFromCart:
            return {
                ...state, 
                payload : action.payload, 
                deletedCartFetchLoading :true,
                cartData : {
                    ...state.cartData,
                    cartFetchIsLoading : true
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }


        case CartDataActions.CartActionTypes.SetDeletedCartData:
            return {
                ...state,
                cartData: {
                    cartData: [],
                    iscartItemsInDB: false
                },
                addedCartData: {
                    addedCartData: {},
                    addedCartFetchLoading: false
                },
                deletedCartData: {
                    deletedCartData: action.payload,
                    deletedCartFetchLoading: false
                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }    
            
        case CartDataActions.CartActionTypes.GetCalenderForCart:
            return{
                ...state,
                calendarDataIsLoading : true,
                errorState: {
                    error: false,
                    error_message: null
                }
            }    

        case CartDataActions.CartActionTypes.SetCalenderForCart:
            return{
                ...state,
                calendarDataIsLoading: false,
                cartData : {
                    ...state.cartData,
                    cartFetchIsLoading : false
                },
                calenderDataMap: {
                    ...state.calenderDataMap,
                    [action.payload['index']] : action.payload.data

                },
                errorState: {
                    error: false,
                    error_message: null
                }
            }    
        
            case CartDataActions.CartActionTypes.SetError: {
                return {
                    ...state,
                    cartData: {
                    ...state.cartData,
                        cartFetchIsLoading : false
                    },
                    errorState: {
                        error: true,
                        error_message: action.payload
                    }
                }
    
            }    

        default:
            return state;
    }
}