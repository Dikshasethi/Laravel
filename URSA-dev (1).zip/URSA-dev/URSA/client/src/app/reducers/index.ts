import Product from './product.reducer';
import RefinedBy from './refinedBy.reducer';
import Search from './search.reducer';
import AdvancedSearch from './advancedSearch.reducer';
import ProductSummary from './productSummary.reducer';
import User from './user.reducer';
import Autocomplete from './autocomplete.reducer';
import ProposalPageData from './proposalPageData.reducer';
import ImageUpload from './imageUpload.reducer';
import UserDetail from './userDetail.reducer';
import CheckOutPageData from './checkout.reducer';
import ProposalList from './proposalList.reducer';
import Cart from './cart.reducer';
import Callout from './callout.reducer';
import CheckInOut from './checkInOut.reducer';
import CheckinAssets from './checked-in-assets.reducer';
import Utilization from './utilization.reducer';
import Emo from './emo.reducer';
import Receiving from './receiving.reducer';
import AssetLog from './assetLog.reducer';
import Notification from './notification.reducer';
import RoleMatrix from './roleMatrix.reducer';
import Download from './download.reducer';
import InformationCard from './informationCard.reducer';
import WatchList from './watchlist.reducer';
import Dashboard from './dashboard.reducer';
import ProposalNewData from './proposalData.reducer'
import Personalization from './refinedBypersonalization.reducer'
import TableColumnPersonalization from './tableColumnOrderPersonalization.reducer'
import ServiceRequest from './serviceRequest.reducer';

export const reducers = {
    Product,
    RefinedBy,
    Search,
    AdvancedSearch,
    ProductSummary,
    User,
    Autocomplete,
    ProposalPageData,
    ImageUpload,
    UserDetail,
    CheckOutPageData,
    ProposalList,
    Cart,
    Callout,
    CheckInOut,
    CheckinAssets,
    Utilization,
    Emo,
    Receiving,
    AssetLog,
    Notification,
    RoleMatrix,
    Download,
    InformationCard,
    WatchList,
    Dashboard,
    ProposalNewData,
    Personalization,
    ServiceRequest,
    TableColumnPersonalization
}