import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AutoCompleteComponent } from './components/custom-components/auto-complete/auto-complete.component';
import { DragulaModule, DragulaService } from 'ng2-dragula';
import { PrintReportComponent } from './components/print-report/print-report.component';
import { CheckInOutClientPanelModalComponent } from './components/check-in-out-client-panel-modal/check-in-out-client-panel-modal.component';
import { CheckInOutClientPanelComponent } from './components/check-in-out-client-panel/check-in-out-client-panel.component';
import { ReceivingPrintReportComponent } from './components/receiving-print-report/receiving-print-report.component';
import { CheckInOutComponent } from './components/check-in-out/check-in-out.component';
import { EditCheckoutModalComponent } from './components/edit-checkout-modal/edit-checkout-modal.component';
import { ReservationModalComponent } from './components/reservation-modal/reservation-modal.component';
import { HardReserveDetailsPanelComponent } from './components/hard-reserve-details-panel/hard-reserve-details-panel.component';
import { DetailsPanelComponent } from './components/details-panel/details-panel.component';
import { NgPipesModule } from 'ngx-pipes';
import { RouterModule } from '@angular/router';
import { DateRangeComponent } from './components/custom-components/date-range/date-range.component';
import { Daterangepicker } from 'ng2-daterangepicker';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { Ng5SliderModule } from 'ng5-slider';
import { CalendarComponentComponent } from './components/calendar-component/calendar-component.component';
import { SearchFieldComponent } from './components/search-field/search-field.component';
import { AdvancedSearchComponent } from './components/advanced-search/advanced-search.component';
import { EmoListComponent } from './components/emo-list/emo-list.component';
import { ReceivingListComponent } from './components/receiving-list/receiving-list.component';

import { RefinedByComponent } from './components/custom-components/refined-by/refined-by.component';

import { MultiSelectAutoComplete } from './components/custom-components/multi-select-autocomplete/multi-select-auto-complete.component';
import { WatchListModalComponent } from './components/watch-list-modal/watch-list-modal.component';
import {EditHardReserveModalComponent} from './components/edit-hardreserve-modal/edit-hardreserve-modal.component'

import { RefinedByPersonalizationModalComponent } from './components/custom-components/refinedBy-personalization/refinedBy-personalization-modal.component';
import { TableColumnOrderPersonalizationModalComponent } from './components/custom-components/tableColumnOrder-personalization/tableColumnOrder-personalization-modal.component';
import { AssetsServiceRequestListComponent } from './components/assets-service-request-list/assets-service-request-list.component';
import { FlashErrorComponent } from './components/flash-error/flash-error.component';
import { ConfirmationModalComponent } from './components/custom-components/confirmation-modal/confirmation-modal.component';
import { GetKeysValuesPipe } from './pipes/get-keys-values.pipe'

@NgModule({
    declarations: [
        AutoCompleteComponent, PrintReportComponent, ReceivingPrintReportComponent,
        EditCheckoutModalComponent, ReservationModalComponent, HardReserveDetailsPanelComponent,
        DetailsPanelComponent, DateRangeComponent, CalendarComponentComponent,
        CheckInOutClientPanelModalComponent, CheckInOutClientPanelComponent, CheckInOutComponent,
        SearchFieldComponent, AdvancedSearchComponent, EmoListComponent, ReceivingListComponent,
        RefinedByComponent,EditHardReserveModalComponent,
        MultiSelectAutoComplete, WatchListModalComponent,
        RefinedByPersonalizationModalComponent,TableColumnOrderPersonalizationModalComponent,AssetsServiceRequestListComponent,
        FlashErrorComponent, ConfirmationModalComponent, GetKeysValuesPipe

    ],
    imports: [CommonModule, Daterangepicker, Ng5SliderModule, FormsModule, DragulaModule,
        NgPipesModule, RouterModule, ReactiveFormsModule, InfiniteScrollModule],
    providers: [DragulaService],
    exports: [FormsModule, AutoCompleteComponent, PrintReportComponent, CheckInOutClientPanelComponent,
        ReceivingPrintReportComponent, CheckInOutComponent, EditCheckoutModalComponent,
        DetailsPanelComponent, RouterModule, CalendarComponentComponent,
        CheckInOutClientPanelModalComponent, Daterangepicker,
        ReservationModalComponent, DateRangeComponent,EditHardReserveModalComponent,
        HardReserveDetailsPanelComponent, NgPipesModule, Ng5SliderModule,
        ReactiveFormsModule, InfiniteScrollModule, DragulaModule, SearchFieldComponent,
        AdvancedSearchComponent, EmoListComponent, ReceivingListComponent,RefinedByComponent,
        AdvancedSearchComponent, EmoListComponent, ReceivingListComponent,
        MultiSelectAutoComplete, WatchListModalComponent,RefinedByPersonalizationModalComponent,TableColumnOrderPersonalizationModalComponent,
        AssetsServiceRequestListComponent, FlashErrorComponent, ConfirmationModalComponent, GetKeysValuesPipe
    ]
})
export class SharedModule { }