import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as CheckoutActions from '../actions/checkout.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class CheckoutEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    //fetch ready to check out data
    @Effect() readyToCheckoutPage$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutActions.CheckoutDataActionTypes.GetReadyToCheckoutData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/hardreserve/gethrassets`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                return new CheckoutActions.SetReadyToCheckoutData(res);               
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new CheckoutActions.SetReadyToCheckoutData({
                        isAuthenticate: 'not authenticated',
                        hasError : true
                    });
                }
                else{
                    return new CheckoutActions.SetReadyToCheckoutData({hasError : true});
                }
            })
        })
    )

    //fetch ready to check in data
    @Effect() readyToCheckinPage$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutActions.CheckoutDataActionTypes.GetCheckInOutAssets)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/getcheckedinoutassets`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                return new CheckoutActions.SetCheckInOutAssets(res);               
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new CheckoutActions.SetCheckInOutAssets({
                        isAuthenticate: 'not authenticated',
                        hasError : true
                    });
                }
                else{
                    return new CheckoutActions.SetCheckInOutAssets({hasError : true});
                }
            })
        })
    )

    //edit ready to check out data
    @Effect() changeReadyToCheckoutPage$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutActions.CheckoutDataActionTypes.ChangeReadyToCheckoutData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/hardreserve/edithardreserve`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                res["isChanged"] = true;
                return new CheckoutActions.SetReadyToCheckoutData(res);               
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new CheckoutActions.SetReadyToCheckoutData({isAuthenticate: 'not authenticated' });
                }
                else{
                    return new CheckoutActions.SetReadyToCheckoutData({hasError : true});
                }
            })
        })
    )

    //remove ready to check out data
    @Effect() removeReadyToCheckoutPageData$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutActions.CheckoutDataActionTypes.RemoveReadyToCheckoutData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/hardreserve/remove`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(res.numberOfErrors > 0){
                    return new CheckoutActions.SetReadyToCheckoutData({hasError : true});
                }else{
                    return new CheckoutActions.SetReadyToCheckoutData({cancelReservation : "successful"});  
                }
                             
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new CheckoutActions.SetReadyToCheckoutData({isAuthenticate: 'not authenticated' });
                }
                else{
                    return new CheckoutActions.SetReadyToCheckoutData({hasError : true});
                }
            })
        })
    )

    //check out asset
    @Effect() checkoutAsset$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutActions.CheckoutDataActionTypes.CheckOutAsset)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/checkout`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                return new CheckoutActions.SetCheckedOutData(res);               
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new CheckoutActions.SetCheckedOutData({isAuthenticate: 'not authenticated' });
                }
                else{
                    return new CheckoutActions.SetCheckedOutData({hasError : true});
                }
            })
        })
    )

    //check in asset
    @Effect() checkinAsset$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutActions.CheckoutDataActionTypes.CheckInAsset)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/checkin`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                res["isCheckedIn"] = true;
                return new CheckoutActions.SetCheckedInData(res);               
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new CheckoutActions.SetCheckedInData({isAuthenticate: 'not authenticated' });
                }
                else{
                    return new CheckoutActions.SetCheckedInData({hasError : true});
                }
            })
        })
    )

    //cancel checkout
    @Effect() cancelCheckout$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutActions.CheckoutDataActionTypes.CancelCheckedOutAsset)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/cancelcheckout`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                res["isCheckedIn"] = true;
                return new CheckoutActions.SetCheckedInData(res);               
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new CheckoutActions.SetCheckedInData({isAuthenticate: 'not authenticated' });
                }
                else{
                    return new CheckoutActions.SetCheckedInData({hasError : true});
                }
            })
        })
    )

    //Recheckout table data
    @Effect() rechekoutTableData$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutActions.CheckoutDataActionTypes.GetReservationTableData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/getreservationtable`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                return new CheckoutActions.SetReservationTableData(res);               
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new CheckoutActions.SetReservationTableData({isAuthenticate: 'not authenticated' });
                }
                else{
                    return new CheckoutActions.SetReservationTableData({hasError : true});
                }
            })
        })
    )

    //validate recheckout
    @Effect() validateCheckoutAsset$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutActions.CheckoutDataActionTypes.ValidateCheckoutAsset)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/assetdatevalidation`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                return new CheckoutActions.SetValidatedCheckoutAsset(res);               
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new CheckoutActions.SetValidatedCheckoutAsset({isAuthenticate: 'not authenticated' });
                }
                else{
                    return new CheckoutActions.SetValidatedCheckoutAsset({hasError : true});
                }
            })
        })
    )

    //Re-checkout Asset
    @Effect() recheckoutAsset$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutActions.CheckoutDataActionTypes.ReCheckoutAsset)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/recheckout`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                return new CheckoutActions.SetReCheckedoutAsset(res);   
                            
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new CheckoutActions.SetReCheckedoutAsset({isAuthenticate: 'not authenticated' });
                }
                else{
                    return new CheckoutActions.SetReCheckedoutAsset({hasError : true});
                }
            })
        })
    )

    //Get Project Status
    @Effect() getProjectStatus$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutActions.CheckoutDataActionTypes.GetProjectStatus)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`api/masterdata/getprojectmaster`, action.payload, httpOptions)
           .toPromise()
           .then(res => {
                return new CheckoutActions.SetProjectStatus(res);                      
           })
           .catch(error => {
               console.log('fetch error', error);
               if (error.error.isAuth || error.status==401) {
                   return new CheckoutActions.SetProjectStatus({ isAuthenticate: 'not authenticated' });
               }
               else{
                   return error;
               }
           })
        })
    )

    @Effect() editCheckoutStatus$: Observable<Action> = this.actions$
    .ofType<any>(CheckoutActions.CheckoutDataActionTypes.EditCheckoutAssets)
    .pipe(
    switchMap(action => {
        this.cookieService.put('last_action_timestamp', moment().unix().toString());
        return this.http.post<any>(`api/checkinout/updateCheckout`, action.payload, httpOptions)
       .toPromise()
       .then(res => {  
        return new CheckoutActions.SeEditCheckOutAssets(res);               
    })
    .catch(error => {
        console.log('fetch error', error);
        if (error.error.isAuth || error.status==401) {
            return new CheckoutActions.SeEditCheckOutAssets({isAuthenticate: 'not authenticated' });
        }
        else{
            return new CheckoutActions.SeEditCheckOutAssets({hasError : true});
        }
    })
    })
)
    

   

}