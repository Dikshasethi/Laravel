import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap, mergeMap, catchError} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as AutocompleteActions from '../actions/autocomplete.actions';
import * as CheckoutActions from '../actions/checkout.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';


const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class AutocompleteEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    //search autocomplete
    @Effect() autocomplete$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetAutocompleteList)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/product/getAutocompleteList`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(res.error || res['success'] !== 'true'){
                    return new AutocompleteActions.SetAutocompleteList({hasError : true});
                }else{
                    return new AutocompleteActions.SetAutocompleteList(res);
                }                
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new AutocompleteActions.SetAutocompleteList({ isAuthenticate: 'not authenticated' });
                }
                else{
                    return error;
                }
            })
        })
    )


    //checkout autocomplete
    @Effect() checkoutAutocomplete$: Observable<Action> = this.actions$ 
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetCheckoutAutocomplete)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/masterdata/getlocationarea`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                return new AutocompleteActions.SetCheckoutAutocomplete(res); 
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new AutocompleteActions.SetCheckoutAutocomplete({ isAuthenticate: 'not authenticated' });
                }
                else{
                    return error;
                }
            })
        })
    )

       //checkout autocomplete
       @Effect() recheckoutAutocomplete$: Observable<Action> = this.actions$
       .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetProjectData)
       .pipe(
       switchMap(action => {
           this.cookieService.put('last_action_timestamp', moment().unix().toString());
           return this.http.post<any>(`api/masterdata/getprojectmaster`, action.payload, httpOptions)
           .toPromise()
           .then(res => {
                return new AutocompleteActions.SetReCheckoutAutocomplete(res);                      
           })
           .catch(error => {
               this.cookieService.put('last_action_timestamp', moment().unix().toString());
               console.log('fetch error', error);
               if (error.error.isAuth || error.status==401) {
                   return new AutocompleteActions.SetReCheckoutAutocomplete({ isAuthenticate: 'not authenticated' });
               }
               else{
                   return error;
               }
           })
       })
   )

   //custodian autocomplete
   @Effect() custodianAutocomplete$: Observable<Action> = this.actions$
   .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetCustodianAutocompleteList)
   .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/getCustodian`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                    return new AutocompleteActions.SetCheckoutAutocomplete(res);    
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new AutocompleteActions.SetCheckoutAutocomplete({ isAuthenticate: 'not authenticated' });
                }
                else{
                    return error;
                }
            })
        })
    )

    //pc businessunit autocomplete
   @Effect() pcBusinessUnitAutocomplete$: Observable<Action> = this.actions$
   .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetPcBusinessUnitAutocompleteList)
   .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/masterdata/getpcbusinessunit`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                    return new AutocompleteActions.SetReCheckoutAutocomplete(res);    
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new AutocompleteActions.SetReCheckoutAutocomplete({ isAuthenticate: 'not authenticated' });
                }
                else{
                    return error;
                }
            })
        })
    )

    @Effect() GetLocationAreasCheck$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetLocationAreasCheck)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/getareaforlocation`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetLocationAreasCheck({haseError : true});    

                    }else{
                        return new AutocompleteActions.SetLocationAreasCheck({
                            results : res
                        });    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    console.log('fetch error', error);
                    return new AutocompleteActions.SetLocationAreasCheck({ haseError: true });
                })
            })
        )


        @Effect() GetCountries$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetCountriesAutoComplete)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/getcountrieslist`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetCountriesAutoComplete({hasError : true});    

                    }else{
                        return new AutocompleteActions.SetCountriesAutoComplete({
                            data : res
                        });    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    console.log('fetch error', error);
                    return new AutocompleteActions.SetCountriesAutoComplete({ haseError: true });
                })
            })
        )

        @Effect() GetUOM$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetUOMAutoComplete)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`api/masterdata/getuomlist`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetUOMAutoComplete({hasError : true});    

                    }else{
                        return new AutocompleteActions.SetUOMAutoComplete({
                            data : res
                        });    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    console.log('fetch error', error);
                    return new AutocompleteActions.SetUOMAutoComplete({ haseError: true });
                })
            })
        )

        @Effect() getPermissionAutoComplete$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetPermissionAutoComplete)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/permissions/getpermissions`, action.payload)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new AutocompleteActions.SetPermissionAutoComplete({ hasError: true });
                        } else {
                            return new AutocompleteActions.SetPermissionAutoComplete(res.results);
                        }

                    })
                    .catch(error => {
                        this.cookieService.put('last_action_timestamp', moment().unix().toString());
                        return new AutocompleteActions.SetPermissionAutoComplete({ hasError: true });
                    })
            })
        )

        @Effect() getRestricitonData$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetRestrictionData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/getrestrictiondata`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetRestrictionData({hasError : true});    

                    }else{
                        return new AutocompleteActions.SetRestrictionData(res);    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    return new AutocompleteActions.SetRestrictionData({ haseError: true });
                })
            })
        )
        
        @Effect() getCrmData$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetCrmData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/getcrmdata`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetCrmData({hasError : true});    

                    }else{
                        return new AutocompleteActions.SetCrmData(res);    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    return new AutocompleteActions.SetCrmData({ haseError: true });
                })
            })
        )
        
        @Effect() getBillingGroup$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetBillingGroupData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/getbillinggroup`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetBillingGroupData({hasError : true});
                    }else{
                        return new AutocompleteActions.SetBillingGroupData(res);    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    return new AutocompleteActions.SetBillingGroupData({ haseError: true });
                })
            })
        )
        
        @Effect() getBillingBusinessUnit$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetBillingBusinessUnitData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/getbillingbusinessunit`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetBillingBusinessUnitData({hasError : true});    

                    }else{
                        return new AutocompleteActions.SetBillingBusinessUnitData(res);    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    return new AutocompleteActions.SetBillingBusinessUnitData({ haseError: true });
                })
            })
        )

        @Effect() getBusinessUnitMaster$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetBusinessUnitMasterData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/businessunitmaster`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetBusinessUnitMasterData({hasError : true});    

                    }else{
                        return new AutocompleteActions.SetBusinessUnitMasterData(res);    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    return new AutocompleteActions.SetBusinessUnitMasterData({ haseError: true });
                })
            })
        )

        @Effect() getCrewPositions$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetCrewPositions)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/proposal/crew/getcrewpositions`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetCrewPositions({hasError : true});
                    }else{
                        return new AutocompleteActions.SetCrewPositions(res);    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    return new AutocompleteActions.SetCrewPositions({ haseError: true });
                })
            })
        )

        @Effect() getServiceLineData$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetServiceLineData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/getserviceline`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetServiceLineData({hasError : true});
                    }else{
                        return new AutocompleteActions.SetServiceLineData(res);    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    return new AutocompleteActions.SetServiceLineData({ haseError: true });
                })
            })
        )

        @Effect() getScopeOfWorkData$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetScopeOfWorkData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/getscopeofwork`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetScopeOfWorkData({hasError : true});
                    }else{
                        return new AutocompleteActions.SetScopeOfWorkData(res);    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    return new AutocompleteActions.SetScopeOfWorkData({ haseError: true });
                })
            })
        )

        @Effect() getResponsibilityCodeData$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetResponsibilityCodeData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/getresponsibilitycodes`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetResponsibilityCodeData({hasError : true});
                    }else{
                        return new AutocompleteActions.SetResponsibilityCodeData(res);    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    return new AutocompleteActions.SetResponsibilityCodeData({ haseError: true });
                })
            })
        )

        @Effect() getCustomersData$: Observable<Action> = this.actions$
        .ofType<any>(AutocompleteActions.AutocompleteActionTypes.GetCustomersData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/getCustomers`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if(res.error){
                        return new AutocompleteActions.SetCustomersData({hasError : true});
                    }else{
                        return new AutocompleteActions.SetCustomersData(res);    
                    }
                })
                .catch(error => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    return new AutocompleteActions.SetCustomersData({ haseError: true });
                })
            })
        )
}