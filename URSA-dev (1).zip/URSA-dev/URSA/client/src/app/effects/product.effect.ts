import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, pipe } from 'rxjs';
import {switchMap, mergeMap, catchError, concatMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as ProductActions from '../actions/product.actions';
import * as ProductSummaryActions from '../actions/productSummary.actions';
import * as ImageUploadActions from '../actions/imageUpload.actions';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

@Injectable()
export class ProductEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    //details
    @Effect() products$: Observable<Action> = this.actions$
        .ofType<any>(ProductActions.ProductActionTypes.GetProducts)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/product/getSearchMoreProducts`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(res.error || res['success'] !== true){
                    return new ProductActions.SetProducts({hasError : true});
                }else if(res.totalCount === 0){
                    return new ProductActions.SetProducts({hasError : false , noDataFound:true, suggestionList:res.suggestions});
                }else{
                    return new ProductActions.SetProducts(res);
                }                
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new ProductActions.SetProducts({ isAuthenticate: 'not authenticated' });
                }
                else{
                    console.log('fetch error', error);
                    return new ProductActions.SetProducts({hasError : true});
                }
            })
        })
    )

    // Proposal data for product page
    @Effect() proposalDetail$: Observable<Action> = this.actions$
        .ofType<any>(ProductActions.ProductActionTypes.GetProductProposalData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/product/getProposalData`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(res.error || res['success'] !== true){
                    return new ProductActions.SetProductProposalData({hasError : true});
                }else{
                    return new ProductActions.SetProductProposalData(res);
                }                
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new ProductActions.SetProductProposalData({ isAuthenticate: 'not authenticated' });
                }
                else{
                    console.log('fetch error', error);
                    return new ProductActions.SetProductProposalData({hasError : true});
                }
            })
        })
    )

    //summary
    @Effect() productSummary$: Observable<Action> = this.actions$
        .ofType<any>(ProductSummaryActions.ProductSummaryActionTypes.GetProductSummary)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/product/getSearchMoreProducts`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(res.error){
                    return new ProductSummaryActions.SetProductSummary({hasError : true});
                }else if(res.totalCount === 0){
                    return new ProductSummaryActions.SetProductSummary({hasError : false, noDataFound:true,suggestionList:res.suggestions});
                }else{
                    return new ProductSummaryActions.SetProductSummary(res);
                }                
            })
            .catch(error => {
                console.log('summary fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new ProductSummaryActions.SetProductSummary({ isAuthenticate: 'not authenticated' });
                }
                else{
                    console.log('fetch error', error);
                    return new ProductSummaryActions.SetProductSummary({hasError : true});
                }
            })
        })
    )

    //proposal data for summary page
    @Effect() proposal$: Observable<Action> = this.actions$
        .ofType<any>(ProductSummaryActions.ProductSummaryActionTypes.GetSummaryProposalData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/product/getProposalData`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(res.error || res['success'] !== true){
                    return new ProductSummaryActions.SetSummaryProposalData({hasError : true});
                }else{
                    return new ProductSummaryActions.SetSummaryProposalData(res);
                }                
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new ProductSummaryActions.SetSummaryProposalData({ isAuthenticate: 'not authenticated' });
                }
                else{
                    console.log('fetch error', error);
                    return new ProductSummaryActions.SetSummaryProposalData({hasError : true});
                }
            })
        })
    )

    //mageUpload effect
    @Effect() imageUpload$: Observable<Action> = this.actions$
        .ofType<any>(ImageUploadActions.ImageUploadActionTypes.SubmitFileToApi)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>('/api/fileupload/imageUpload', action.payload.file, httpOptions)
                .pipe(
                    mergeMap((res) => {
                        return [
                            new ProductActions.InsertImage({
                                index : action.payload.index,
                                imageObject : res
                            }),
                            new ImageUploadActions.SetImageUploadResponse({
                                view : action.payload.view,
                                index : action.payload.index,
                                response : res
                            })
                        ]                        
                    }),
                    catchError((err) => {
                        console.log('image upload catch block error', err)
                        return [
                            new ImageUploadActions.SetImageUploadErrorList({
                                view : action.payload.view,
                                index : action.payload.index
                            })
                        ]
                    })
                )
            })
        )


        @Effect() setThumbnail$: Observable<Action> = this.actions$
        .ofType<any>(ImageUploadActions.ImageUploadActionTypes.CallChangeThumbnail)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>('/api/fileupload/setthumbnail', action.payload.file, httpOptions)
                .pipe(
                    mergeMap((res) => {
                        return [
                            new ImageUploadActions.ReturnChangeThumbnail ({
                                view : action.payload.view,
                                index : action.payload.index,
                                response : res
                            }),
                            new ProductActions.UpdateThumbnail ({
                                view : action.payload.view,
                                index : action.payload.index,
                                response : res
                            })
                        ]                        
                    }),
                    catchError((err) => {
                        console.log('image upload catch block error', err)
                        return [
                            new ImageUploadActions.SetImageUploadErrorList({
                                view : action.payload.view,
                                index : action.payload.index
                            })
                        ]
                    })
                )
            })
        )

        @Effect() sendRemoveImage$: Observable<Action> = this.actions$
        .ofType<any>(ImageUploadActions.ImageUploadActionTypes.SendRemoveImage)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>('/api/fileupload/imagedelete', action.payload.data, httpOptions)
                .pipe(
                    mergeMap((res) => {
                        return [
                            new ImageUploadActions.ResponceRemoveImage ({
                                view : action.payload.view,
                                index : action.payload.index,
                                response : res.thumbnailUrl,
                                deleteRefrence : action.payload.data.imageUrl
                            })
                        ]                        
                    }),
                    catchError((err) => {
                        console.log('image upload catch block error', err)
                        return [
                            new ImageUploadActions.SetImageUploadErrorList({
                                view : action.payload.view,
                                index : action.payload.index
                            })
                        ]
                    })
                )
            })
        )

        @Effect() getProductCalendarData$: Observable<Action> = this.actions$
        .ofType<any>(ProductActions.ProductActionTypes.GetProductCalendar)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>('/api/product/getproductcalendardata', action.payload, httpOptions)
                .pipe(
                    mergeMap((res) => {
                        return [
                            new ProductActions.SetProductCalendar ({
                                timeseries : res,
                                status : true
                            })
                        ]                        
                    }),
                    catchError((err) => {
                        console.log('image upload catch block error', err)
                        return [
                            new ProductActions.SetProductCalendar({
                                timeseries : err,
                                status : false
                            })
                        ]
                    })
                )
            })
        )

            //Hierarchy Data For Hierarchy View
        @Effect() hierarchy$: Observable<Action> = this.actions$
        .ofType<any>(ProductActions.ProductActionTypes.GetHieararchy)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/product/getassethierarchy`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        return new ProductActions.SetHieararchy(res);
                    }
                    )
                    .catch(error => {
                        console.log('fetch error', error);
                        if (error.error.isAuth || error.status == 401) {
                            return new ProductActions.GetHieararchy({ isAuthenticate: 'not authenticated' });
                        }
                        else {
                            console.log('fetch error', error);
                            return new ProductActions.SetHieararchy({ hasError: true });
                        }
                    })
            })
        )

            //Asset History Details
            @Effect() assethistory$: Observable<Action> = this.actions$
            .ofType<any>(ProductActions.ProductActionTypes.GetAssetHistory)
            .pipe(
                switchMap(action => {
                    this.cookieService.put('last_action_timestamp', moment().unix().toString());
                    return this.http.get<any>(`/api/product/getassetdetails/${action.payload.businessunit}/${action.payload.assetid}`, action.payload)
                        .toPromise()
                        .then(res => {
                            return new ProductActions.SetAssetHistory(res);
                        }
                        )
                        .catch(error => {
                            return new ProductActions.SetAssetHistory({ hasError: true });
                        })
                })
            )        
        
}   