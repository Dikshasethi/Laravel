import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as CalloutActions from '../actions/callout.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

@Injectable()
export class CalloutEffects{
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    @Effect() calloutlist$: Observable<Action> = this.actions$
        .ofType<any>(CalloutActions.CalloutActionTypes.GetCalloutList)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/masterdata/getcalloutlist`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(res.error){
                    console.log('Callout list error', res)
                    return new CalloutActions.SetCalloutList({hasError : true});
                }else{
                    return new CalloutActions.SetCalloutList(res);
                }  
               
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CalloutActions.SetCalloutList({hasError : true});
            })
        })
    )

    @Effect() calloutDetails$: Observable<Action> = this.actions$
        .ofType<any>(CalloutActions.CalloutActionTypes.GetCalloutDetails)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/callout/getcalloutdetails`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(res.error){
                    console.log('Callout details error', res)
                    return new CalloutActions.SetCalloutDetails({hasError : true});
                }else{
                    return new CalloutActions.SetCalloutDetails(res);
                }  
               
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CalloutActions.SetCalloutDetails({hasError : true});
            })
        })
    )

    @Effect() deleteCallout$: Observable<Action> = this.actions$
        .ofType<any>(CalloutActions.CalloutActionTypes.DeleteCallout)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/masterdata/deletecallout`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(res.error){
                    console.log('Callout list error', res)
                    return new CalloutActions.SetDeleteCalloutResponse({
                        hasError : true,
                        error : res.error
                    });
                }else{
                    return new CalloutActions.SetDeleteCalloutResponse(res);
                }  
               
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CalloutActions.SetDeleteCalloutResponse({
                    hasError : true,
                    error : {
                        message : 'Callout deletion failed. System error.'
                    }
                });
            })
        })
    )
}