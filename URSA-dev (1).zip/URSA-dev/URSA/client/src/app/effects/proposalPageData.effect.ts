import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as ProposalPageDataActions from '../actions/proposalPageData.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class ProposalPageDataEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    //details
    @Effect() proposalPage$: Observable<Action> = this.actions$
        .ofType<any>(ProposalPageDataActions.ProposalPageDataActionTypes.GetProposalPageData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/proposal/getProposalData`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    console.log('summary result error', res)
                    return new ProposalPageDataActions.SetProposalPageData({hasError : true});
                }else{
                    return new ProposalPageDataActions.SetProposalPageData(res);
                }  
               
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalPageDataActions.SetProposalPageData({hasError : true});
            })
        })
    )

    @Effect() hrCreate$: Observable<Action> = this.actions$
        .ofType<any>(ProposalPageDataActions.ProposalPageDataActionTypes.CreateReservation)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/hardreserve/create`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                let value = localStorage.getItem('refreshOnHardReserveChange')==='Hard refresh' ? 'Hard refreshed' : 'Hard refresh'
                window.localStorage.setItem('refreshOnHardReserveChange', value)
                return new ProposalPageDataActions.HardReservationResponse(res);                
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401 ) {
                    return new ProposalPageDataActions.HardReservationResponse({ isAuthenticate: 'not authenticated' });
                }
                else{
                    return new ProposalPageDataActions.HardReservationResponse({error : 'true'});
                }
            })
        })
    )

    @Effect() hrCancel$: Observable<Action> = this.actions$
        .ofType<any>(ProposalPageDataActions.ProposalPageDataActionTypes.CancelReservation)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/hardreserve/remove`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                return new ProposalPageDataActions.HardReservationResponse(res); 
               
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new ProposalPageDataActions.HardReservationResponse({ isAuthenticate: 'not authenticated' });
                }
                else{
                    return new ProposalPageDataActions.HardReservationResponse({error : 'true'});
                }
            })
        })
    )
    // project autocomple
    @Effect() getProjectAutocomplete$: Observable<Action> = this.actions$ 
        .ofType<any>(ProposalPageDataActions.ProposalPageDataActionTypes.GetProjectAutoComplete)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/masterdata/getprojects`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                return new ProposalPageDataActions.SetProjectAutoComplete(res); 
               
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new ProposalPageDataActions.SetProjectAutoComplete({ 
                        isAuthenticate: 'not authenticated',
                        error : true
                    });
                }
                else{
                    return new ProposalPageDataActions.SetProjectAutoComplete({error : true});
                }
            })
        })
    )

    @Effect() validateAssetDate$: Observable<Action> = this.actions$ 
        .ofType<any>(ProposalPageDataActions.ProposalPageDataActionTypes.ValidateHardReserveAssetDate)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/hardreserve/assetdatevalidation`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                return new ProposalPageDataActions.SetValidateHardReserveAssetDate(res); 
               
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new ProposalPageDataActions.SetValidateHardReserveAssetDate({ 
                        isAuthenticate: 'not authenticated',
                        error : true
                    });
                }
                else{
                    return new ProposalPageDataActions.SetValidateHardReserveAssetDate({error : true});
                }
            })
        })
    )

}