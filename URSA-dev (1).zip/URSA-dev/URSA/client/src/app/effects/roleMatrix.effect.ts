import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as RoleMatrixActions from '../actions/roleMatrix.action';
import { environment } from '../../environments/environment';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

const applicatonIdObj = {
    "appid": environment.appID,
    "appname": environment.appName,
}

@Injectable()
export class RoleMatrixEffects {
    skip: number = 0;
    limit: number = 20;
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ) { }

    @Effect() createPermissions$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.CreatePermission)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`api/permissions/createpermission`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.GetPermission(applicatonIdObj);
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() edditPermission$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.EditPermission)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`api/permissions/editpermission`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.GetPermission(applicatonIdObj);
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() getRoles$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.GetRole)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/roles/getroles`, action.payload)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res['error'] });
                        } else {
                            return new RoleMatrixActions.SetRole(res.results);
                        }

                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() getPermissions$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.GetPermission)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/permissions/getpermissions`, action.payload)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res['error'] });
                        } else {
                            return new RoleMatrixActions.SetPermission(res.results);
                        }

                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() getPermissionsByID$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.GetPermissionByID)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.get<any>(`/api/permissions/getpermission/${action.payload.permissionId}`)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res['error'] });
                        } else {
                            return new RoleMatrixActions.SetPermissionByID(res);
                        }

                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() deletePermission$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.DeletePermission)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.delete<any>(`/api/permissions/deletepermission/${action.payload.permissionId}`, action.payload)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res['error'] });
                        } else {
                            return new RoleMatrixActions.GetPermission(applicatonIdObj);
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() createRoles$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.CreateRole)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`api/roles/createrole`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.GetRole(applicatonIdObj);
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() edditRole$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.EditRole)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`api/roles/editrole`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.GetRole(applicatonIdObj);
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() getRoleByID$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.GetRoleByID)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.get<any>(`/api/roles/getrole/${action.payload.roleId}`)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res['error'] });
                        } else {
                            return new RoleMatrixActions.SetRoleByID(res);
                        }

                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )


    @Effect() deleteRole$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.DeleteRole)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.delete<any>(`/api/roles/deleterole/${action.payload.roleId}`, action.payload)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res['error'] });
                        } else {
                            return new RoleMatrixActions.GetRole(applicatonIdObj);
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() getUserList$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.GetUserList)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/userrole/getusersroles`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.SetUserList(res);
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() getUserInfo$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.GetUserInfo)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/userrole/searchemployee`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.SetUserInfo(res);
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() creteUser$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.CreateUser)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/userrole/updaterole`, action.payload.userRolePayload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.GetUserList({
                                'appid': applicatonIdObj.appid,
                                'filter': action.payload.filter,
                                'skip': this.skip,
                                'limit': this.limit
                            });
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() CloneUserRole$: Observable<Action> = this.actions$
    .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.CloneUserRole)
    .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/userrole/cloneroles`, action.payload.userRolePayload, httpOptions)
                .toPromise()
                .then(res => {
                    if (res['error']) {
                        return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                    } else {
                        return new RoleMatrixActions.GetUserList({
                            'appid': applicatonIdObj.appid,
                            'filter': action.payload.filter,
                            'skip': this.skip,
                            'limit': this.limit
                        });
                    }
                })
                .catch(error => {
                    return new RoleMatrixActions.setError({ hasError: true });
                })
        })
    )
        
    @Effect() getUserRoleByID$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.GetUserRoleByID)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/userrole/getuserrole`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.SetUserRoleByID({ 'appid': applicatonIdObj.appid });
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() getrestrictions$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.GetRestrictions)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/restrictions/getrestrictions`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.SetRestrictions(res.results);
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() createRestriction$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.CreateRestriction)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/restrictions/createrestriction`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.SetRestrictions(res);
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() editRestriction$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.EditRestriction)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/restrictions/editRestriction`, action.payload.restrictionObj, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.GetRestrictions({
                                "filter": {
                                    "appid": applicatonIdObj.appid,
                                    "permissionid": action.payload.permissionid,
                                    "restricteduserid": action.payload.restricteduserid
                                }
                            });
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() deleteUserRestriction$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.DeleteRestriction)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.delete<any>(`/api/restrictions/deleterestriction/${action.payload.restictionid}`, action.payload)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res['error'] });
                        } else {
                            return new RoleMatrixActions.GetRestrictions({
                                "filter": {
                                    "appid": applicatonIdObj.appid,
                                    "permissionid": action.payload.permissionid,
                                    "restricteduserid": action.payload.restricteduserid
                                }
                            });
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )

    @Effect() getUserRolesValidation$: Observable<Action> = this.actions$
        .ofType<any>(RoleMatrixActions.RoleMatrixActionTypes.GetUserRolesValidation)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/userrole/getusersroles`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new RoleMatrixActions.setError({ hasError: true, error: res.error });
                        } else {
                            return new RoleMatrixActions.SetUserRolesValidation(res);
                        }
                    })
                    .catch(error => {
                        return new RoleMatrixActions.setError({ hasError: true });
                    })
            })
        )
}

