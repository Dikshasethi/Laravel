import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as CheckoutCheckinActions from '../actions/checked-in-assets.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';


const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class CheckoutCheckinEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ) { }

    @Effect() checkoutCheckinPage$: Observable<Action> = this.actions$
        .ofType<any>(CheckoutCheckinActions.CheckoutDataActionTypes.GetCheckoutCheckInData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/checkinout/getcheckedinoutassets`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        return new CheckoutCheckinActions.SetCheckoutCheckInData(res);
                    })
                    .catch(error => {
                        if (error.error.isAuth || error.status == 401) {
                            return new CheckoutCheckinActions.SetCheckoutCheckInData({ isAuthenticate: 'not authenticated' });
                        }
                        else {
                            return new CheckoutCheckinActions.SetCheckoutCheckInData({ hasError: true });
                        }
                    })
            })
        )
}