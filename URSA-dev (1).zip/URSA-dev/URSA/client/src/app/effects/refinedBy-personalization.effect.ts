import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect} from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as RefinedByPersonalizationActions from '../actions/refinedBy-personalization.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';


const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class RefinedByPersonalizationEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

       //get Personalization data
       @Effect() getPersonalizationRefinedByData$: Observable<Action> = this.actions$
       .ofType<any>(RefinedByPersonalizationActions.PersonalizationActionTypes.GetPersonalizationRefinedByData)
       .pipe(
       switchMap(action => {
           this.cookieService.put('last_action_timestamp', moment().unix().toString());
           return this.http.post<any>(`/api/personalization/getpersonalizations`, action.payload, httpOptions)
           .toPromise()
           .then(res => { 

               if(res.error){
                   return new RefinedByPersonalizationActions.SetError({ hasError: true, error: res.error });
               }else{
                   return new RefinedByPersonalizationActions.SetPersonalizationRefinedByData(res);  
               }             
           })
           .catch(error => {
               return new RefinedByPersonalizationActions.SetError({ hasError: true});
           })
          })
        )

    //Add Personalization Data in List
        @Effect() savePersonalizationRefinedByData$: Observable<Action> = this.actions$
        .ofType<any>(RefinedByPersonalizationActions.PersonalizationActionTypes.AddPersonalizationRefinedByData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/personalization/create`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(res.error){
                    return new RefinedByPersonalizationActions.SetError({ hasError: true, error: res });
                }else{
                    return new RefinedByPersonalizationActions.SetAddedPersonalizationData(res);    
                }
            })
            .catch(error => {
                return new RefinedByPersonalizationActions.SetError({ hasError: true});
            })
        })
      )



    //Delete from Personalization Data List
    @Effect() deletePersonalizationRefinedByData$: Observable<Action> = this.actions$
    .ofType<any>(RefinedByPersonalizationActions.PersonalizationActionTypes.DeleteFromPersonalizationDataList)
    .pipe(
    switchMap(action => {
        this.cookieService.put('last_action_timestamp', moment().unix().toString());
        return this.http.post<any>(`/api/personalization/delete`, action.payload, httpOptions)
        .toPromise()
        .then(res => {  
            if(res.error){
                return new RefinedByPersonalizationActions.SetError({ hasError: true, error: res });
            }else{
                return new RefinedByPersonalizationActions.SetDeletedPersonalizationData(res);    
            }
        })
        .catch(error => {
            return new RefinedByPersonalizationActions.SetError({ hasError: true});
        })
    })
  )

    //Update Personalization Data 
    @Effect() updatePersonalizationRefinedByData$: Observable<Action> = this.actions$
    .ofType<any>(RefinedByPersonalizationActions.PersonalizationActionTypes.UpdatePersonalizationRefinedByData)
    .pipe(
    switchMap(action => {
        this.cookieService.put('last_action_timestamp', moment().unix().toString());
        return this.http.post<any>(`/api/personalization/edit`, action.payload, httpOptions)
        .toPromise()
        .then(res => {  
            if(res.error){
                return new RefinedByPersonalizationActions.SetError({ hasError: true, error: res });
            }else{
                return new RefinedByPersonalizationActions.SetUpdatePersonalizationRefinedByData(res);    
            }
        })
        .catch(error => {
            return new RefinedByPersonalizationActions.SetError({ hasError: true});
        })
    })
    )


    //Name check Personalization Data 
    @Effect() nameCheckPersonalizationRefinedByData$: Observable<Action> = this.actions$
    .ofType<any>(RefinedByPersonalizationActions.PersonalizationActionTypes.NameCheckPersonalization)
    .pipe(
    switchMap(action => {
        this.cookieService.put('last_action_timestamp', moment().unix().toString());
        return this.http.post<any>(`/api/personalization/namecheck`, action.payload, httpOptions)
        .toPromise()
        .then(res => {
            if(res.error){
                return new RefinedByPersonalizationActions.SetError({ hasError: true, error: res });
            }else{
                return new RefinedByPersonalizationActions.SetNameCheckPersonalizationRefinedByData(res);    
            }
        })
        .catch(error => {
            return new RefinedByPersonalizationActions.SetError({ hasError: true});
        })
    })
    )


   

    
}