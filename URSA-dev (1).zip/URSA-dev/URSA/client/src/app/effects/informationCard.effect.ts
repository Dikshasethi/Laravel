import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as informationAcitons from '../actions/information-card.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

@Injectable()
export class InformationCardEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ) { }

    @Effect() getReceivingDetails$: Observable<Action> = this.actions$
        .ofType<any>(informationAcitons.InformationCardActionTypes.GetReceivingDetails)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/receiving/getreceivingdetails`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new informationAcitons.SetReceivingDetails({ hasError: true });
                        } else {
                            return new informationAcitons.SetReceivingDetails(res);
                        }

                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new informationAcitons.SetReceivingDetails({ hasError: true });
                    })
            })
        )

    @Effect() getEmoDetails$: Observable<Action> = this.actions$
        .ofType<any>(informationAcitons.InformationCardActionTypes.GetEmoDetails)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/emo/getemodetails`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new informationAcitons.SetEmoDetails({ hasError: true });
                        } else {
                            return new informationAcitons.SetEmoDetails(res);
                        }

                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new informationAcitons.SetEmoDetails({ hasError: true });
                    })
            })
        )

        @Effect() getAssetTransactionLogs$: Observable<Action> = this.actions$
        .ofType<any>(informationAcitons.InformationCardActionTypes.GetAssetTransactionLogs)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/masterdata/getassetlogs`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new informationAcitons.SetAssetTransactionLogs({ hasError: true });
                        } else {
                            return new informationAcitons.SetAssetTransactionLogs(res);
                        }

                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new informationAcitons.SetAssetTransactionLogs({ hasError: true });
                    })
            })
        )
}