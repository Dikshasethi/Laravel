import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as AssetLogActions from '../actions/assetLogs.actions';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

@Injectable()
export class AssetLogEffects{
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    @Effect() calloutlist$: Observable<Action> = this.actions$
        .ofType<any>(AssetLogActions.AssetLogActionTypes.GetAssetLogs)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/masterdata/getassetlogs`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(res.error){
                    return new AssetLogActions.SetAssetLogs({
                        ...res,
                        hasError : true
                    });
                }else{
                    return new AssetLogActions.SetAssetLogs(res);
                }  
               
            })
            .catch(error => {
                console.log('fetch error', error);
                return new AssetLogActions.SetAssetLogs({hasError : true});
            })
        })
    )
}