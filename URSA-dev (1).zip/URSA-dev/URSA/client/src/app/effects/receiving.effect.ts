import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as ReceivingActions from '../actions/receiving.actons';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

@Injectable()
export class ReceivingEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ) { }

    @Effect() createReceiving$: Observable<Action> = this.actions$
        .ofType<any>(ReceivingActions.ReceivingActionTypes.CreateReceivingData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/receiving/create`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new ReceivingActions.SetReecivingData({ hasError: true, error: res.error });
                        } else {
                            res['save'] = true;
                            return new ReceivingActions.SetReecivingData(res);
                        }

                    })
                    .catch(error => {
                        return new ReceivingActions.SetReecivingData({ hasError: true });
                    })
            })
        )



    @Effect() getReceivingData$: Observable<Action> = this.actions$
        .ofType<any>(ReceivingActions.ReceivingActionTypes.GetReceivingData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.get<any>(`/api/receiving/get/${action.payload.filter.receivingid}`, action.payload)
                    .toPromise()
                    .then(res => {
                        if (res['error']) {
                            return new ReceivingActions.SetReecivingData({ hasError: true });
                        } else {
                            return new ReceivingActions.SetReecivingData(res);
                        }

                    })
                    .catch(error => {
                        return new ReceivingActions.SetReecivingData({ hasError: true });
                    })
            })
        )

    @Effect() updateReceivingData$: Observable<Action> = this.actions$
        .ofType<any>(ReceivingActions.ReceivingActionTypes.UpdateReceivingData)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/receiving/edit`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new ReceivingActions.SetReecivingData({ hasError: true, error: res.error });
                        } else {
                            res['save'] = true;
                            return new ReceivingActions.SetReecivingData(res);
                        }

                    })
                    .catch(error => {
                        return new ReceivingActions.SetReecivingData({ hasError: true });
                    })
            })
        )
    @Effect() receivedData$: Observable<Action> = this.actions$
        .ofType<any>(ReceivingActions.ReceivingActionTypes.Received)
        .pipe(
            switchMap(action => {
                const {cancelreceive} = action.payload;
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/receiving/received`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new ReceivingActions.SetReecivingData({ hasError: true, error: res.error });
                        } else {
                            res['receive'] = !cancelreceive;
                            res['refresh'] = true;
                            return new ReceivingActions.SetReecivingData(res);
                        }

                    })
                    .catch(error => {
                        return new ReceivingActions.SetReecivingData({ hasError: true });
                    })
            })
        )

    @Effect() receivingList$: Observable<Action> = this.actions$
        .ofType<any>(ReceivingActions.ReceivingActionTypes.GetReceivingList)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/receiving/get`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new ReceivingActions.SetReceivingList({ hasError: true });
                        } else {
                            return new ReceivingActions.SetReceivingList(res);
                        }

                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new ReceivingActions.SetReceivingList({ hasError: true });
                    })
            })
        )

}