import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, pipe } from 'rxjs';
import { switchMap, mergeMap, catchError, merge, mergeAll, switchMapTo } from 'rxjs/operators'
import { Action } from '@ngrx/store';
import { CookieService } from "angular2-cookie/core";
import * as UserDetailActions from '../actions/userDetail.actions';
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

@Injectable()
export class UserDetailEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ) { }

    //details
    @Effect() userDetail$: Observable<Action> = this.actions$
        .ofType<any>(UserDetailActions.UserDetailActionTypes.LoginUser)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/user/login`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error || res.hasError) {
                            return new UserDetailActions.SetUserDetail({ hasError: true });
                        }else {
                            return new UserDetailActions.SetUserDetail(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        if (error) {
                            return new UserDetailActions.SetUserDetail({ hasError: true });
                        }
                    })
            })
        )

    //FetchUser
    @Effect() fetchUser$: Observable<Action> = this.actions$
        .ofType<any>(UserDetailActions.UserDetailActionTypes.GetUserDetail)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.get<any>(`/api/user/getloggedinuser`)
                    .toPromise()
                    .then(res => {
                        if (res.error || res.hasError) {

                            return new UserDetailActions.SetUserDetail({ hasError: true });
                        }else{
                            this.cookieService.put('es_access_token', res.access_token);
                            this.cookieService.put('es_token_expiry_time', `${res.expiryTime}`);
                            this.cookieService.put('authToken', `${res.authToken}`);
                            this.cookieService.put('authTokenExpiryTime', `${res.authTokenExpiryTime}`)
                            this.cookieService.put('schedulinkToken', `${res.schedulink_token}`);
                            this.cookieService.put('schedulinkTokenExpiryTime', `${res.schedulink_tokenExpiryTime}`);
                            this.cookieService.put('adeptia_token', `${res.adeptia_token}`);
                            this.cookieService.put('adeptia_tokenExpiryTime', `${res.adeptia_tokenExpiryTime}`);
                            return new UserDetailActions.SetUserDetail(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        if (error) {
                            return new UserDetailActions.SetUserDetail({ hasError: true });
                        }
                    })
            })
        )


    //Logout
    @Effect() logout$: Observable<Action> = this.actions$
        .ofType<any>(UserDetailActions.UserDetailActionTypes.LogoutUser)
        .pipe(
            switchMap(action => {
                this.cookieService.remove('last_action_timestamp');
                return this.http.post<any>(`/api/user/logout`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        return new UserDetailActions.LogoutViewChange(true);
                    })
                    .catch(error => {
                        return new UserDetailActions.LogoutViewChange(true);
                    })
            })
        )

    //Refresh Session
    @Effect() refreshSession$: Observable<Action> = this.actions$
        .ofType<any>(UserDetailActions.UserDetailActionTypes.RefreshUserSessionGet)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/user/refreshSession`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error || res.hasError) {
                            return new UserDetailActions.RefreshUserSessionSet({ hasError: true });
                        }else{
                            return new UserDetailActions.RefreshUserSessionSet(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        if (error) {
                            return new UserDetailActions.RefreshUserSessionSet({ hasError: true });
                        }
                    })
            })
        )

    //Refresh Session
    @Effect() getSessionRefresh$: Observable<Action> = this.actions$
    .ofType<any>(UserDetailActions.UserDetailActionTypes.NewSessionDurationGet)
    .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/user/getupdatedsession`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if (res.error || res.hasError) {
                        return new UserDetailActions.NewSessionDurationSet({ hasError: true });
                    }else{
                        return new UserDetailActions.NewSessionDurationSet(res);
                    }
                })
                .catch(error => {
                    console.log('fetch error', error);
                    if (error) {
                        return new UserDetailActions.NewSessionDurationSet({ hasError: true });
                    }
                })
        })
    )

    //Refresh Elasti
    @Effect() getElasticSearchTokenRefresh$: Observable<Action> = this.actions$
    .ofType<any>(UserDetailActions.UserDetailActionTypes.RefreshElasticSearchTokenGet)
    .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/user/refreshelasticsearchtoken`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if (res.error || res.hasError) {
                        return new UserDetailActions.RefreshElasticSearchTokenSet({ hasError: true });
                    }else{
                        return new UserDetailActions.RefreshElasticSearchTokenSet(res);
                    }
                })
                .catch(error => {
                    console.log('fetch error', error);
                    if (error) {
                        return new UserDetailActions.RefreshElasticSearchTokenSet({ hasError: true });
                    }
                })
        })
    )
}
