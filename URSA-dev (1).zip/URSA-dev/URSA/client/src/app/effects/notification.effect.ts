import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as NotificationActions from '../actions/notifications.actions';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

@Injectable()
export class NotificationEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    @Effect() getUsersNotifications$: Observable<Action> = this.actions$
    .ofType<any>(NotificationActions.NotificationActionTypes.GetUsersNotifications)
    .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/notification/getusersclientnotifications`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(
                    res['error'] ||
                    res['hasError']
                ){
                    return new NotificationActions.SetUsersNotifications({hasError : true});
                }
                return new NotificationActions.SetUsersNotifications(res);               
            })
            .catch(error => {
                console.log('fetch error', error);
                return new NotificationActions.SetUsersNotifications({hasError : true});
            })
        })
    )

    @Effect() updateNotification$: Observable<Action> = this.actions$
    .ofType<any>(NotificationActions.NotificationActionTypes.UpdateNotification)
    .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/notification/updateusernotification`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(
                    res['error'] ||
                    res['hasError']
                ){
                    return new NotificationActions.SetUpdateNotificationResponse({hasError : true});
                }
                return new NotificationActions.SetUpdateNotificationResponse(res);               
            })
            .catch(error => {
                console.log('fetch error', error);
                return new NotificationActions.SetUpdateNotificationResponse({hasError : true});
            })
        })
    )
}