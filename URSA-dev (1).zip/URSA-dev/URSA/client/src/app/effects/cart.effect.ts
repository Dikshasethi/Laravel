import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap, mergeMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as CartActions from '../actions/cart.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';


const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class CartEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    //add to cart
    @Effect() addToCart$: Observable<Action> = this.actions$
        .ofType<any>(CartActions.CartActionTypes.AddToCart)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/cart/addtocart`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(res.error){
                    return new CartActions.SetError({ hasError: true, error: res.error });
                }else{
                    return new CartActions.SetAddedCartData({success : true});    
                }
                        
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CartActions.SetError({ hasError: true});
            })
        })
    )

    //get cart data
    @Effect() getCartData$: Observable<Action> = this.actions$
        .ofType<any>(CartActions.CartActionTypes.GetCartData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/cart/getcart`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(res.error){
                    return new CartActions.SetError({ hasError: true, error: res.error });
                }else{
                    return new CartActions.SetCartData(res);  
                }             
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CartActions.SetError({ hasError: true});
            })
        })
    )

    //delete from cart
    @Effect() deleteFromCart$: Observable<Action> = this.actions$
        .ofType<any>(CartActions.CartActionTypes.DeleteFromCart)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/cart/deletefromcart`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(res.error){
                    return new CartActions.SetError({ hasError: true, error: res.error });
                }else{
                    return new CartActions.SetDeletedCartData(res);      
                }
                        
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CartActions.SetError({ hasError: true});
            })
        })
    )

    @Effect() getCalenderForCart$: Observable<Action> = this.actions$
        .ofType<any>(CartActions.CartActionTypes.GetCalenderForCart)
        .pipe(
            mergeMap(action => {
            return this.http.post<any>('/api/product/getproductcalendardata', action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(res.error){
                    return new CartActions.SetCalenderForCart({
                        index : action.payload['_index'],
                        data : {
                            timeseries: [],
                            stateData: [],
                            reservationData:[],
                            index:action.payload['_index']
                        }
                    });
                }else{
                    return new CartActions.SetCalenderForCart({
                        index : res['index'],
                        data: {
                            ...res.calendarData,
                            index:res['index']
                        }

                    });      
                }
                        
            })
            .catch(err => {
                return new CartActions.SetCalenderForCart({
                    index : action.payload['_index'],
                    data : {
                        timeseries: [],
                        stateData: [],
                        reservationData:[],
                        index:action.payload['_index']
                    }
                })
            })
        })
    )
}