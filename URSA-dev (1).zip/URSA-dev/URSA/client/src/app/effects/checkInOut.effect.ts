import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as CheckInOutActions from '../actions/checkInOut.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';


const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class CheckInOutEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}
    
    @Effect() checkoutDateValidation$: Observable<Action> = this.actions$
        .ofType<any>(CheckInOutActions.CheckInOutActionTypes.GetCheckoutDateValidations)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/assetdatevalidation`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(
                    res['error'] ||
                    res['hasError']
                ){
                    return new CheckInOutActions.SetCheckoutDateValidations({hasError : true});
                }
                return new CheckInOutActions.SetCheckoutDateValidations(res);               
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CheckInOutActions.SetCheckoutDateValidations({hasError : true});
            })
        })
    )

    @Effect() checkoutRecords$: Observable<Action> = this.actions$
        .ofType<any>(CheckInOutActions.CheckInOutActionTypes.CheckoutAssets)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/checkout`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(
                    res['error'] ||
                    res['hasError']
                ){
                    return new CheckInOutActions.SetCheckoutResults({hasError : true});
                }else{
                    return new CheckInOutActions.SetCheckoutResults(res);  
                }
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CheckInOutActions.SetCheckoutResults({hasError : true});
            })
        })
    )

    @Effect() checkinRecords$: Observable<Action> = this.actions$
        .ofType<any>(CheckInOutActions.CheckInOutActionTypes.CheckinAssets)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/checkin`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(
                    res['error'] ||
                    res['hasError']
                ){
                    return new CheckInOutActions.SetCheckinResults({hasError : true});
                }else{
                    return new CheckInOutActions.SetCheckinResults(res); 
                }
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CheckInOutActions.SetCheckinResults({hasError : true});
            })
        })
    )

    @Effect() cancelCheckout$: Observable<Action> = this.actions$
        .ofType<any>(CheckInOutActions.CheckInOutActionTypes.CancelCheckout)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/cancelcheckout`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(
                    res['error'] ||
                    res['hasError']
                ){
                    return new CheckInOutActions.SetCancelCheckoutResults({hasError : true});
                }else{
                    return new CheckInOutActions.SetCancelCheckoutResults(res); 
                }
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CheckInOutActions.SetCancelCheckoutResults({hasError : true});
            })
        })
    )

    @Effect() cancelHardReservations$: Observable<Action> = this.actions$
        .ofType<any>(CheckInOutActions.CheckInOutActionTypes.CancelHardReservations)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/hardreserve/remove`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(
                    res['error'] ||
                    res['hasError']
                ){
                    return new CheckInOutActions.SetCancelHardReservationResults({hasError : true});
                }else{
                    return new CheckInOutActions.SetCancelHardReservationResults(res); 
                }
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CheckInOutActions.SetCancelHardReservationResults({hasError : true});
            })
        })
    )

    @Effect() editCheckout$: Observable<Action> = this.actions$
        .ofType<any>(CheckInOutActions.CheckInOutActionTypes.EditCheckout)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/checkinout/updateCheckout`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(
                    res['error'] ||
                    res['hasError']
                ){
                    return new CheckInOutActions.SetEditCheckoutResults({hasError : true});
                }else{
                    return new CheckInOutActions.SetEditCheckoutResults(res);  
                }
            })
            .catch(error => {
                console.log('fetch error', error);
                return new CheckInOutActions.SetEditCheckoutResults({hasError : true});
            })
        })
    )

    @Effect() getEditHardReserve$: Observable<Action> = this.actions$
        .ofType<any>(CheckInOutActions.CheckInOutActionTypes.GetEditHardReserve)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/hardreserve/edithardreserve`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        return new CheckInOutActions.SetEditHardReserve(res);
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new CheckInOutActions.SetEditHardReserve({ hasError: true });
                    })
            })
        )

}