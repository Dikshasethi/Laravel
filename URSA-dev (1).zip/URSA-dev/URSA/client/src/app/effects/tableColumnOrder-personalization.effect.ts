import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect} from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as TableColumnPersonalizationActions from '../actions/tableColumnOrderPersonalization.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';


const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class TableColumnPersonalizationEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

       //get TableColumn Personalization data
       @Effect() getPersonalizationTableColumnData$: Observable<Action> = this.actions$
       .ofType<any>(TableColumnPersonalizationActions.PersonalizationActionTypes.GetPersonalizationTableColumnData)
       .pipe(
       switchMap(action => {
           this.cookieService.put('last_action_timestamp', moment().unix().toString());
           return this.http.post<any>(`/api/personalization/getpersonalizations`, action.payload, httpOptions)
           .toPromise()
           .then(res => { 

               if(res.error){
                   return new TableColumnPersonalizationActions.SetError({ hasError: true, error: res.error });
               }else{
                   return new TableColumnPersonalizationActions.SetPersonalizationTableColumnData(res);  
               }             
           })
           .catch(error => {
               return new TableColumnPersonalizationActions.SetError({ hasError: true});
           })
          })
        )

    //Add TableColumn Personalization Data
        @Effect() savePersonalizationTableColumnData$: Observable<Action> = this.actions$
        .ofType<any>(TableColumnPersonalizationActions.PersonalizationActionTypes.AddPersonalizationTableColumnData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/personalization/create`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(res.error){
                    return new TableColumnPersonalizationActions.SetError({ hasError: true, error: res });
                }else{
                    return new TableColumnPersonalizationActions.SetAddedPersonalizationTableColumnData(res);    
                }
            })
            .catch(error => {
                return new TableColumnPersonalizationActions.SetError({ hasError: true});
            })
        })
      )

    //Update Personalization Data 
    @Effect() updatePersonalizationTableColumnData$: Observable<Action> = this.actions$
    .ofType<any>(TableColumnPersonalizationActions.PersonalizationActionTypes.UpdatePersonalizationTableColumnData)
    .pipe(
    switchMap(action => {
        this.cookieService.put('last_action_timestamp', moment().unix().toString());
        return this.http.post<any>(`/api/personalization/edit`, action.payload, httpOptions)
        .toPromise()
        .then(res => {  
            if(res.error){
                return new TableColumnPersonalizationActions.SetError({ hasError: true, error: res });
            }else{
                return new TableColumnPersonalizationActions.SetUpdatePersonalizationTableColumnData(res);    
            }
        })
        .catch(error => {
            return new TableColumnPersonalizationActions.SetError({ hasError: true});
        })
    })
    )

     //Delete from Personalization Data List
     @Effect() deletePersonalizationTableColumnData$: Observable<Action> = this.actions$
     .ofType<any>(TableColumnPersonalizationActions.PersonalizationActionTypes.DeleteTableColumnPersonalizationData)
     .pipe(
     switchMap(action => {
         this.cookieService.put('last_action_timestamp', moment().unix().toString());
         return this.http.post<any>(`/api/personalization/delete`, action.payload, httpOptions)
         .toPromise()
         .then(res => {  
             if(res.error){
                 return new TableColumnPersonalizationActions.SetError({ hasError: true, error: res });
             }else{
                 return new TableColumnPersonalizationActions.SetDeletedTableColumnPersonalizationData(res);    
             }
         })
         .catch(error => {
             return new TableColumnPersonalizationActions.SetError({ hasError: true});
         })
     })
   )
}