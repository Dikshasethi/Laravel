import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as ProposalListDataActions from '../actions/proposalList.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class ProposalListEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}
    //details
    @Effect() proposalList$: Observable<Action> = this.actions$
        .ofType<any>(ProposalListDataActions.ProposalListDataActionTypes.GetProposalListData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/proposal/getproposals`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalListDataActions.SetError(res.error.message);
                }else{
                    return new ProposalListDataActions.SetProposalListData(res);
                }  
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401 ) {
                    return new ProposalListDataActions.SetProposalListData({ isAuthenticate: 'not authenticated' });
                }
                else{
                    return error;
                }
            })
        })
    )

}