
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as DashboardActions from '../actions/dashbord.action'
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';


const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class DashboardEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ) { }

    @Effect() getUtilizationChart$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.GetUtilizationChart)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/getmetrics`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'utilization' });
                        } else {
                            return new DashboardActions.SetUtilizationChart(res);
                        }

                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'utilization' });
                    })
            })
        )

    @Effect() getSoftReservationChart$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.GetSoftReservationChart)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/softreservationmetrics`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'softReservation' });
                        } else {
                            return new DashboardActions.SetSoftReservationChart(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'softReservation' });
                    })
            })
        )

    @Effect() getHardReservationChart$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.GetHardReservationChart)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/hardreservemetrics`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'hardReservation' });
                        } else {
                            return new DashboardActions.SetHardReservationChart(res);
                        }

                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'hardReservation' });
                    })
            })
        )

    @Effect() getShippedChart$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.GetShippedChart)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/onhiremetrics`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'shipped' });
                        } else {
                            return new DashboardActions.SetShippedChart(res);
                        }

                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'shipped' });
                    })
            })
        )

    @Effect() GetAssetCount$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.GetAssetCount)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/assetcount`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'asset' });
                        } else {
                            return new DashboardActions.SetAssetCount(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'asset' });
                    })
            })
        )

    @Effect() getPastDueCheckOutCount$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.GetPastDueCheckOutCount)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/pastduecheckoutcount`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'pastDue' });
                        } else {
                            return new DashboardActions.SetPastDueCheckOutCount(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'pastDue' });
                    })
            })
        )

        @Effect() getHardReservationCount$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.GetHardReservationCount)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/hardreservecount`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'hardReservationCount' });
                        } else {
                            return new DashboardActions.SetHardReservationCount(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'hardReservationCount' });
                    })
            })
        )

        @Effect() getSoftReservationCount$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.GetSoftReservationCount)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/softreservecount`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'softReservationCount' });
                        } else {
                            return new DashboardActions.SetSoftReservationCount(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'softReservationCount' });
                    })
            })
        )

        @Effect() getCheckoutCount$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.GetCheckoutCount)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/checkinoutcount`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'checkout' });
                        } else {
                            return new DashboardActions.SetCheckoutCount(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'checkout' });
                    })
            })
        )


        @Effect() getCheckoutmetrics$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.GetCheckoutmetrics)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/checkoutmetrics`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'checkoututilization' });
                        } else {
                            return new DashboardActions.SetCheckoutmetrics(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'checkoututilization' });
                    })
            })
        )


        @Effect() getonhiremetrics$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.Getonhiremetrics)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/onhiremetrics`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'onhire' });
                        } else {
                            return new DashboardActions.Setonhiremetrics(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'onhire' });
                    })
            })
        )



        @Effect() getreceivecount$: Observable<Action> = this.actions$
        .ofType<any>(DashboardActions.DashboardActionTypes.Getreceivecount)
        .pipe(
            switchMap(action => {
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(`/api/reservationmetrics/receivecount`, action.payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        if (res.error) {
                            return new DashboardActions.SetError({ hasError: true, error: res.error, apiName: 'receivecount' });
                        } else {
                            return new DashboardActions.Setreceivecount(res);
                        }
                    })
                    .catch(error => {
                        console.log('fetch error', error);
                        return new DashboardActions.SetError({ hasError: true, apiName: 'receivecount' });
                    })
            })
        )

        

}