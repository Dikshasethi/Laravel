import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap, concatMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as UtilizationAction from '../actions/utilization.actions';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class UtilizationEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

  
    @Effect() getUtilization$: Observable<Action> = this.actions$
        .ofType<any>(UtilizationAction.UtilizationActionType.GetUtilization)
        .pipe(
            concatMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/product/getUtilization`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(res.error){
                    return new UtilizationAction.SetUtilization({hasError : true});
                }else{
                    return new UtilizationAction.SetUtilization(res);    
                }
                        
            })
            .catch(error => {
                console.log('fetch error', error);
                if (error.error.isAuth || error.status==401) {
                    return new UtilizationAction.SetUtilization({isAuthenticate: 'not authenticated' });
                }
                else{
                    return new UtilizationAction.SetUtilization({hasError : true});
                }
            })
        })
    )
}