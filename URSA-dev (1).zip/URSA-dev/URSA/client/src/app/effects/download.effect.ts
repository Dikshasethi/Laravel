import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as DownloadActions from '../actions/download.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

const urlMapping = {
    'checkout': '/api/hardreserve/gethrassets',
    'checkin': '/api/checkinout/getcheckedinoutassets',
    'proposallist': '/api/proposal/getproposals',
    'emolist': '/api/emo/get',
    'receivinglist': '/api/receiving/get',
    'calloutlist': '/api/masterdata/getcalloutlist',
    'assetlogs': '/api/masterdata/getassetlogs',
    'cart': '/api/cart/getcart'
}

@Injectable()
export class DownloadEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ) { }

    @Effect() getDownloadData$: Observable<Action> = this.actions$
        .ofType<any>(DownloadActions.DownloadActionTypes.GetDownloadData)
        .pipe(
            switchMap(action => {
                const { urlType, payload } = action.payload;
                this.cookieService.put('last_action_timestamp', moment().unix().toString());
                return this.http.post<any>(urlMapping[urlType], payload, httpOptions)
                    .toPromise()
                    .then(res => {
                        let result = [];
                        if (urlType === "calloutlist") {
                            result = res.callouts;
                        } else if (urlType === "cart") {
                            result = res;
                        } else {
                            result = res.results;
                        }
                        return new DownloadActions.SetDownloadData(result);
                    })
                    .catch(error => {
                        return new DownloadActions.GetDownloadData({ hasError: true });
                    })
            })
        )

}