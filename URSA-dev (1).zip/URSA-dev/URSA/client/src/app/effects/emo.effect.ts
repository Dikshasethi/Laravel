import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as EmoActions from '../actions/emo.actions';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

@Injectable()
export class EmoEffects{
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    @Effect() emoList$: Observable<Action> = this.actions$
        .ofType<any>(EmoActions.EmoActionTypes.GetEmoList)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/emo/get`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(res.error){
                    return new EmoActions.SetEmoList({hasError : true});
                }else{
                    return new EmoActions.SetEmoList(res);
                }  
               
            })
            .catch(error => {
                console.log('fetch error', error);
                return new EmoActions.SetEmoList({hasError : true});
            })
        })
    )

    @Effect() saveEmoData$: Observable<Action> = this.actions$
    .ofType<any>(EmoActions.EmoActionTypes.GenerateEmoData)
    .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/emo/create`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if (res.error) {
                        return new EmoActions.SetEmoData({ hasError: true , error:res.error });
                    } else {
                        res['save'] = true;
                        return new EmoActions.SetEmoData(res);
                    }

                })
                .catch(error => {
                    return new EmoActions.SetEmoData({ hasError: true });
                })
        })
    )



@Effect() getEmoData$: Observable<Action> = this.actions$
    .ofType<any>(EmoActions.EmoActionTypes.GetEmoData)
    .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.get<any>(`/api/emo/get/${action.payload.filter.emoid}`, action.payload)
                .toPromise()
                .then(res => {
                    if (res['error']) {
                        return new EmoActions.SetEmoData({ hasError: true });
                    } else {
                        return new EmoActions.SetEmoData(res);
                    }

                })
                .catch(error => {
                    return new EmoActions.SetEmoData({ hasError: true });
                })
        })
    )

@Effect() ShipEmoData$: Observable<Action> = this.actions$
    .ofType<any>(EmoActions.EmoActionTypes.ShipEmo)
    .pipe(
        switchMap(action => {
            const { cancelship } = action.payload;
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/emo/ship`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if (res.error) {
                        return new EmoActions.SetEmoData({ hasError: true , error:res.error  });
                    } else {
                        res['ship'] = !cancelship;
                        res['refresh'] = true;
                        return new EmoActions.SetEmoData(res);
                    }

                })
                .catch(error => {
                    return new EmoActions.SetEmoData({ hasError: true });
                })
        })
    )
@Effect() updateEmoData$: Observable<Action> = this.actions$
    .ofType<any>(EmoActions.EmoActionTypes.updateEmo)
    .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/emo/edit`, action.payload, httpOptions)
                .toPromise()
                .then(res => {
                    if (res.error) {
                        return new EmoActions.SetEmoData({ hasError: true , error:res.error });
                    } else {
                        res['save'] = true;
                        return new EmoActions.SetEmoData(res);
                    }

                })
                .catch(error => {
                    return new EmoActions.SetEmoData({ hasError: true });
                })
        })
    )

}