import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as ServiceRequestDataActions from '../actions/serviceRequest.actions';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class ServiceRequestDataEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    @Effect() requestTypeData$: Observable<Action> = this.actions$
        .ofType<any>(ServiceRequestDataActions.ServiceRequestDataActionTypes.GetRequestType)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.get<any>(`/api/servicerequest/getrequesttype`)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ServiceRequestDataActions.SetError(res.error);
                }else{
                    return new ServiceRequestDataActions.SetRequestType(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ServiceRequestDataActions.SetError({
                    errorcode: 500,
                    message: 'Something went wrong'
                });
            })
        })
    )

    @Effect() workTypeData$: Observable<Action> = this.actions$
        .ofType<any>(ServiceRequestDataActions.ServiceRequestDataActionTypes.GetWorkType)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/servicerequest/getworktype`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ServiceRequestDataActions.SetError(res.error);
                }else{
                    return new ServiceRequestDataActions.SetWorkType(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ServiceRequestDataActions.SetError({
                    errorcode: 500,
                    message: 'Something went wrong'
                });
            })
        })
    )
    
    @Effect() scopeTypeData$: Observable<Action> = this.actions$
        .ofType<any>(ServiceRequestDataActions.ServiceRequestDataActionTypes.GetScopeType)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/servicerequest/getScopeType`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ServiceRequestDataActions.SetError(res.error);
                }else{
                    return new ServiceRequestDataActions.SetScopeType(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ServiceRequestDataActions.SetError({
                    errorcode: 500,
                    message: 'Something went wrong'
                });
            })
        })
    ) 

    @Effect() serviceGropuData$: Observable<Action> = this.actions$
    .ofType<any>(ServiceRequestDataActions.ServiceRequestDataActionTypes.GetServiceGroup)
    .pipe(
    switchMap(action => {
        this.cookieService.put('last_action_timestamp', moment().unix().toString());
        return this.http.post<any>(`/api/servicerequest/getservicegroup`, action.payload, httpOptions)
        .toPromise()
        .then(res => {
            if(
                res.error ||
                res.hasError
            ){
                return new ServiceRequestDataActions.SetError(res.error);
            }else{
                return new ServiceRequestDataActions.SetServiceGroup(res);
            }  
        
        })
        .catch(error => {
            console.log('fetch error', error);
            return new ServiceRequestDataActions.SetError({
                errorcode: 500,
                message: 'Something went wrong'
            });
        })
    })
    )

    @Effect() treeNodeData$: Observable<Action> = this.actions$
    .ofType<any>(ServiceRequestDataActions.ServiceRequestDataActionTypes.GetTreeNode)
    .pipe(
    switchMap(action => {
        this.cookieService.put('last_action_timestamp', moment().unix().toString());
        return this.http.post<any>(`/api/servicerequest/gettreenode`, action.payload, httpOptions)
        .toPromise()
        .then(res => {
            if(
                res.error ||
                res.hasError
            ){
                return new ServiceRequestDataActions.SetError(res.error);
            }else{
                return new ServiceRequestDataActions.SetTreeNode(res);
            }  
        
        })
        .catch(error => {
            console.log('fetch error', error);
            return new ServiceRequestDataActions.SetError({
                errorcode: 500,
                message: 'Something went wrong'
            });
        })
    })
    ) 

    @Effect() serviceCenterData$: Observable<Action> = this.actions$
    .ofType<any>(ServiceRequestDataActions.ServiceRequestDataActionTypes.GetServiceCenter)
    .pipe(
    switchMap(action => {
        this.cookieService.put('last_action_timestamp', moment().unix().toString());
        return this.http.post<any>(`/api/servicerequest/getservicecenter`, action.payload, httpOptions)
        .toPromise()
        .then(res => {
            if(
                res.error ||
                res.hasError
            ){
                return new ServiceRequestDataActions.SetError(res.error);
            }else{
                return new ServiceRequestDataActions.SetServiceCenter(res);
            }  
        
        })
        .catch(error => {
            console.log('fetch error', error);
            return new ServiceRequestDataActions.SetError({
                errorcode: 500,
                message: 'Something went wrong'
            });
        })
    })
    ) 


    @Effect() getSRListData$: Observable<Action> = this.actions$
        .ofType<any>(ServiceRequestDataActions.ServiceRequestDataActionTypes.GetServiceRequestList)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/servicerequest/getServiceRequests`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ServiceRequestDataActions.SetError(res.error);
                }else{
                    return new ServiceRequestDataActions.SetServiceRequestList(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ServiceRequestDataActions.SetError({
                    errorcode: 500,
                    message: 'Something went wrong'
                });
            })
        })
    )
    
    @Effect() getServiceRequestdata$: Observable<Action> = this.actions$
        .ofType<any>(ServiceRequestDataActions.ServiceRequestDataActionTypes.GetServiceRequestData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.get<any>(`/api/servicerequest/getServiceRequest/${action.payload.serviceRequestId}`)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ServiceRequestDataActions.SetError(res.error);
                }else{
                    return new ServiceRequestDataActions.SetServiceRequestData(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ServiceRequestDataActions.SetError({
                    errorcode: 500,
                    message: 'Something went wrong'
                });
            })
        })
    )

    @Effect() createServiceRequest$: Observable<Action> = this.actions$
        .ofType<any>(ServiceRequestDataActions.ServiceRequestDataActionTypes.CreateServiceRequest)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/servicerequest/create`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ServiceRequestDataActions.SetError(res.error);
                }else{
                    return new ServiceRequestDataActions.SetCreateServiceRequestData(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ServiceRequestDataActions.SetError({
                    errorcode: 500,
                    message: 'Something went wrong'
                });
            })
        })
    )

    @Effect() editServiceRequest$: Observable<Action> = this.actions$
        .ofType<any>(ServiceRequestDataActions.ServiceRequestDataActionTypes.EditServiceRequest)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/servicerequest/edit`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ServiceRequestDataActions.SetError(res.error);
                }else{
                    return new ServiceRequestDataActions.SetCreateServiceRequestData(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ServiceRequestDataActions.SetError({
                    errorcode: 500,
                    message: 'Something went wrong'
                });
            })
        })
    )

    @Effect() deleteServiceRequest$: Observable<Action> = this.actions$
        .ofType<any>(ServiceRequestDataActions.ServiceRequestDataActionTypes.DeleteServiceRequest)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/servicerequest/delete`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ServiceRequestDataActions.SetError(res.error);
                }else{
                    return new ServiceRequestDataActions.SetDeleteServiceRequestData(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ServiceRequestDataActions.SetError({
                    errorcode: 500,
                    message: 'Something went wrong'
                });
            })
        })
    )
}