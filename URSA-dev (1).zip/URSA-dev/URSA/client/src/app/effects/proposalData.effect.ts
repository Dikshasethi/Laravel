import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as ProposalDataActions from '../actions/proposalData.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class ProposalDataEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    //details
    @Effect() proposalNewData$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.GetProposalData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/proposal/getproposal`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    return new ProposalDataActions.SetProposalData(res);
                }  
               
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )
    
    @Effect() createProposal$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.CreateProposal)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/proposal/create`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    return new ProposalDataActions.SetCreatedProposalData(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )

    @Effect() editProposal$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.EditProposal)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/proposal/edit`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    res = {
                        ...res,
                        editProposal : true  
                    }
                    return new ProposalDataActions.SetCreatedProposalData(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )

    @Effect() updateProposal$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.UpdateProposalStatus)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/proposal/updatestatus`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    return new ProposalDataActions.SetCreatedProposalData(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )

    @Effect() changeProposalVersion$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.ChangeProposalVersion)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/proposal/changeversion`, action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    return new ProposalDataActions.SetCreatedProposalData(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )

    @Effect() getProposalVersions$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.GetProposalVersions)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.get<any>(`api/proposal/getversiontracker/${action.payload.proposalid}`)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    return new ProposalDataActions.SetProposalVersions(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )

    @Effect() getCrewRequirementType$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.GetCrewRequirementType)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.get<any>(`/api/proposal/crew/getcrewrequirementtypes`)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    return new ProposalDataActions.SetCrewRequirementType(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )

    @Effect() getcrewpositions$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.GetCrewPositions)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.get<any>(`/api/proposal/crew/getcrewpositions`)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    return new ProposalDataActions.SetCrewPositions(res);
                }  
            
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )

    @Effect() getJobTitles$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.GetJobTitles)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/proposal/crew/getcrewpositionjobtitlelist`, 
            {crewPositionId: action.payload.crewPositionId}, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    return new ProposalDataActions.SetJobTitlesInProposalDetail({
                        result : res,
                        crewJobtitleAppendIndex: action.payload.crewJobtitleAppendIndex
                    });
                }  
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )

    @Effect() createCrewDraft$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.CreateCrewDraft)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/proposal/crew/savecrewrequirement`,
             action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    return new ProposalDataActions.SetCreatedProposalData(res);
                }  
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )

    @Effect() cancelproposal$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.CancelProposal)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/proposal/cancel`,action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    return new ProposalDataActions.SetCreatedProposalData(res);
                }  
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )

    @Effect() setPermanetprojectId$: Observable<Action> = this.actions$
        .ofType<any>(ProposalDataActions.ProposalDataActionTypes.SetPermanentProjectId)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/proposal/setpermanentprojectid`,action.payload, httpOptions)
            .toPromise()
            .then(res => {
                if(
                    res.error ||
                    res.hasError
                ){
                    return new ProposalDataActions.SetError(res.error.message);
                }else{
                    return new ProposalDataActions.SetCreatedProposalData(res);
                }  
            })
            .catch(error => {
                console.log('fetch error', error);
                return new ProposalDataActions.SetError('Something went wrong');
            })
        })
    )
}