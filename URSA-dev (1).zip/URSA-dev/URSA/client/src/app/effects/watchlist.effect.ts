import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Actions, Effect} from '@ngrx/effects';
import { Observable } from 'rxjs';
import {switchMap} from 'rxjs/operators'
import { Action } from '@ngrx/store';
import * as WatchListActions from '../actions/watchlist.action';
import { CookieService } from "angular2-cookie/core";
import * as moment from 'moment';


const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
@Injectable()
export class WatchListEffects {
    constructor(
        private http: HttpClient,
        private actions$: Actions,
        private cookieService: CookieService
    ){}

    //get watch list data
    @Effect() getWatchListData$: Observable<Action> = this.actions$
        .ofType<any>(WatchListActions.WatchListActionTypes.GetWatchListData)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/watchlist/getwatchlist`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(res.error){
                    return new WatchListActions.SetError({ hasError: true, error: res.error });
                }else{
                    return new WatchListActions.SetWatchListData(res);  
                }             
            })
            .catch(error => {
                console.log('fetch error', error);
                return new WatchListActions.SetError({ hasError: true});
            })
        })
    )

    //delete from watchlist
    @Effect() deleteFromWatchList$: Observable<Action> = this.actions$
        .ofType<any>(WatchListActions.WatchListActionTypes.DeleteFromWatchList)
        .pipe(
        switchMap(action => {
            this.cookieService.put('last_action_timestamp', moment().unix().toString());
            return this.http.post<any>(`/api/watchlist/remove`, action.payload, httpOptions)
            .toPromise()
            .then(res => {  
                if(res.failList && res.failList.length > 0){
                    return new WatchListActions.SetError({ hasError: true, error: res });
                }else{
                    return new WatchListActions.SetDeletedWatchListData(res.successList);      
                }
            })
            .catch(error => {
                console.log('fetch error', error);
                return new WatchListActions.SetError({ hasError: true});
            })
        })
    )

       //add in watchlist
       @Effect() addToWatchList$: Observable<Action> = this.actions$
       .ofType<any>(WatchListActions.WatchListActionTypes.AddToWatchList)
       .pipe(
       switchMap(action => {
           this.cookieService.put('last_action_timestamp', moment().unix().toString());
           return this.http.post<any>(`/api/watchlist/add`, action.payload, httpOptions)
           .toPromise()
           .then(res => {  
               if(res.failList && res.failList.length > 0){
                   return new WatchListActions.SetError({ hasError: true, error: res });
               }else{
                   return new WatchListActions.SetAddedWatchListData(res.successList);      
               }
           })
           .catch(error => {
               console.log('fetch error', error);
               return new WatchListActions.SetError({ hasError: true});
           })
       })
   )

    //edit in watchlist
    @Effect() editInWatchList$: Observable<Action> = this.actions$
    .ofType<any>(WatchListActions.WatchListActionTypes.EditInWatchList)
    .pipe(
    switchMap(action => {
        this.cookieService.put('last_action_timestamp', moment().unix().toString());
        return this.http.post<any>(`/api/watchlist/set`, action.payload, httpOptions)
        .toPromise()
        .then(res => {  
            if(res.failList && res.failList.length > 0){
                return new WatchListActions.SetError({ hasError: true, error: res });
            }else{
                   return new WatchListActions.SetAddedWatchListData(res.successList);      
               }
           })
        .catch(error => {
               console.log('fetch error', error);
               return new WatchListActions.SetError({ hasError: true});
        })
    })

   )
    
}