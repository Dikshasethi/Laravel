import { Routes } from '@angular/router';
import { AssetHistoryComponent } from './components/asset-history/asset-history.component';
import { AssetLogsComponent } from './components/asset-logs/asset-logs.component';
import { EmoListComponent } from './components/emo-list/emo-list.component';
import { AssetsServiceRequestListComponent } from './components/assets-service-request-list/assets-service-request-list.component';
import { ErrorComponent } from './components/error/error.component';
import { LoginComponent } from './components/login/login.component';
import { PagelayoutComponent } from './components/pagelayout/pagelayout.component';
import { ReceivingListComponent } from './components/receiving-list/receiving-list.component';

export const AppRoutes: Routes = [
    {
        path: '',
        component: PagelayoutComponent,
        children: [
            {
                path: 'product',
                loadChildren: './components/product/product.module#ProductModule'
            },
            { path: '', redirectTo: 'login', pathMatch: 'full' },
            { path: 'login', component: LoginComponent },
            {
                path: 'landing',
                loadChildren: './components/landing/landing.module#LandingModule'
            },
            {
                path: 'proposalinfo',
                loadChildren: './components/proposaldata/proposaldata.module#ProposalDataModule'
            },
            {
                path: 'proposal',
                loadChildren: './components/proposal-data/proposaldata.module#ProposalDataModule'
            },
            {
                path: 'readyToCheckout',
                loadChildren: './components/ready-checkout/readycheckout.module#ReadyCheckoutModule'
            },
            {
                path: 'readyToCheckin',
                loadChildren: './components/ready-to-checkin/readytocheckin.module#ReadytoCheckinModule'
            },
            {
                path: 'proposallist',
                loadChildren: './components/proposal-list/proposallist.module#ProposalListModule'
            },
            {
                path: 'cart',
                loadChildren: './components/cart/cart.module#CartModule'
            },
            {
                path: 'calloutlist',
                loadChildren: './components/callout-list/calloutlist.module#CalloutListModule'
            },
            {
                path: 'calloutinfo',
                loadChildren: './components/callout-details/calloutdetails.module#CalloutDetailsModule'
            },
            {
                path: 'checkedinAssets',
                loadChildren: './components/checked-in-assets/checkedinassets.module#CheckedinassetsModule'
            },
            {
                path: 'emolist',
                component: EmoListComponent
            },
            {
                path: 'emodetails',
                loadChildren: './components/emodetails/emodetails.module#EmoDetailsModule'
            },
            {
                path: 'receiving',
                loadChildren: './components/receiving/receiving.module#ReceivingModule'
            },
            {
                path: 'receivinglist',
                component: ReceivingListComponent
            },
            {
                path: 'roleMatrix',
                loadChildren: './components/role-matrix/roleMatrix.modue#RoleMatrixModule'
            },
            { path: 'assetlogs', component: AssetLogsComponent },

            { path: 'assethistory/:businessunit/:assetid', component: AssetHistoryComponent },

            {
                path: 'notifications',
                loadChildren: './components/notifications/notifications.module#NotificationsModule'
            },
            {
                path: 'watchlist',
                loadChildren: './components/watch-list/watch-list.module#WatchListModule'
            },
            {
                path: 'servicerequest',
                loadChildren: './components/assets-service-request/assets-service-request.module#AssetsServiceRequestModule'
            },
            {
                path: 'servicerequestlist',
                component: AssetsServiceRequestListComponent
            },
            {
                path: '**',
                component: ErrorComponent
            }

        ]
    }
];
