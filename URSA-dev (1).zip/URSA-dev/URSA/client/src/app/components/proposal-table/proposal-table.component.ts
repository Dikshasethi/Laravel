import { Component, OnInit, Input, SimpleChange, Output, EventEmitter } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { Router, ActivatedRoute } from '@angular/router';
import { 
  SetHardReserveMode, 
  CreateReservation, ResetProposalPageData 
} from '../../actions/proposalPageData.action';
import { 
  RemoveReadyToCheckoutData, 
} from '../../actions/checkout.action';
import { SetDateRange } from '../../actions/search.actions';
import localDate from '../../utils/date/localDate';
import {hardReservePermission} from '../../utils/config/config';
import { SetViewPreference } from '../../actions/user.actions';
import * as _ from 'lodash';
import * as moment from 'moment';

@Component({
  selector: 'app-proposal-table',
  templateUrl: './proposal-table.component.html',
  styleUrls: ['./proposal-table.component.css']
})
export class ProposalTableComponent implements OnInit {

  constructor(
    private store: Store<AppState>, 
    private route:ActivatedRoute, 
    private router:Router
  ) { }

  @Input() proposalDetails:any;
  @Input() hardReservedList: any;
  @Input() checkedOutList: any;
  @Input() checkedInList: any;
  @Input() proposalData: any;
  @Input() userPermissions: any;
  @Input() proposalid: any;
  @Input() height: any;
  @Output() resetShowModal = new EventEmitter<any>();
  parsedPSData=[];
  filteredPSData=[];
  rowMap={};
  filterByObj:any={};
  hrRemovalObj;
  hrPermission;
  hardReservedReference = [];
  actionableStatusList = ['committed'];
  state={
    hrResponseError : false,
    activeTable : 1,
    hrRemovalObj : {
      assetId : ''
    },
    hrCreateObj : {
      assetId : '',
      serialid : '',
      tagnumber : ''
    },
  };
  modalDisplay='none';
  hrResponseObj={};

  ngOnInit() {
    this.parsePeopleSoftData(
      this.proposalDetails,
      this.hardReservedList,
      this.checkedOutList,
      this.checkedInList
    );
    this.hrPermission = this.userPermissions && 
    this.userPermissions.includes(hardReservePermission); 
  }

  ngOnChanges(changes: SimpleChange){
    if(
      changes['proposalDetails'] && 
      changes['hardReservedList'] && 
      changes['checkedOutList'] && 
      changes['checkedInList'] &&
      (
        !_.isEqual(
          changes['proposalDetails']['currentValue'],
          changes['proposalDetails']['previousValue']
        ) || 
        !_.isEqual(
          changes['hardReservedList']['currentValue'],
          changes['hardReservedList']['previousValue']
        ) || 
        !_.isEqual(
          changes['checkedOutList']['currentValue'],
          changes['checkedOutList']['previousValue']
        ) || 
        !_.isEqual(
          changes['checkedInList']['currentValue'],
          changes['checkedInList']['previousValue']
        )
      )
    ){
      this.parsePeopleSoftData(
        changes['proposalDetails']['currentValue'],
        changes['hardReservedList']['currentValue'],
        changes['checkedOutList']['currentValue'],
        changes['checkedInList']['currentValue']
      );
    }

    if(
      changes['userPermissions'] &&
      !_.isEqual(
        changes['userPermissions']['currentValue'],
        changes['userPermissions']['previousValue']
      )
    ){
      this.hrPermission = changes['userPermissions']['currentValue'] && 
      changes['userPermissions']['currentValue'].includes(hardReservePermission); 
    }
  }

  getTableWrapperHeight = () => {
    return `${this.height * 0.8}vh`;
  }

  setState = (field, value) => {
    this.state[field] = value;
  }

  parsePeopleSoftData = (
    proposaldetails=[],
    hardreservedassets=[],
    checkedoutassets=[],
    checkedinassets=[]
  ) => {
    let proposalDetails = (Array.isArray(proposaldetails) && proposaldetails.slice()) || [];
    let hardReservedAssets = (Array.isArray(hardreservedassets) && hardreservedassets) || [];
    let checkedOutAssets = (Array.isArray(checkedoutassets) && checkedoutassets) || [];
    let checkedInAssets = (Array.isArray(checkedinassets) && checkedinassets) || [];
    this.parsedPSData = [];

    for (let i = 0; i < proposalDetails.length; i++){
      let detail = proposalDetails[i];
      detail['project']=detail.project || "";
      detail['productcategory']=detail.productcategory || "";
      detail['oiamsubtype2']=detail.oiamsubtype2 || "";
      detail['productcategory']=detail.productcategory || "";
      detail['assetdescription']=detail.assetdescription || "";
      detail['assetid']=detail.assetid || "";
      detail.begindate= detail.begindate ? localDate(detail.begindate, 'DD-MMM-YYYY') : "";
      detail.enddate= detail.enddate ? localDate(detail.enddate, 'DD-MMM-YYYY') : "";
      detail['hrQty']=0;
      detail['coQty']=0;
      detail['assetserialid'] = detail.assetserialid || "";
      detail['assettagnumber'] = detail.assetserialid || "";

      for(let j=0;j<hardReservedAssets.length;j++){
        if(detail.pdid===hardReservedAssets[j].pdid){
          detail['hrQty']+=1
        }
      }
      
      for(let j=0;j<checkedOutAssets.length;j++){
        if(detail.pdid === checkedOutAssets[j].pdid && !checkedOutAssets[j].checkedin )
          detail['coQty']+=1
      }

      for(let j=0;j<checkedInAssets.length;j++){
        if(detail.pdid === checkedInAssets[j].pdid)
          detail['coQty']+=1
      }
      this.parsedPSData.push(detail);
      this.filteredPSData = this.parsedPSData.slice();
      this.rowMap[i] = detail;
      this.rowMap[i]['showCheck'] = true;
      this.rowMap[i]['showAddAsset'] = true;
      this.rowMap[i]['showX'] = true;
      if ('assetid' in detail){
        this.rowMap[i]['hasPill'] = true;
      }
    }
    this.checkRows();
  }

  updateFilter = (obj, field, e) => {
    if(!this[obj][field]){
      this[obj][field] = '';
    }
    this[obj][field] = e.target.value;
    this.executeFilter(
      'parsedPSData', 
      'filteredPSData', 
      obj
    );
  }

  executeFilter = (mainList, filterList, filterObj) => {
    let accumulator = [];
    for (let i = 0; i < this[mainList].length; i++){
      let dataObj = this[mainList][i];
      let counts = 0, match = 0, filterValueCount=0;
      for (let k in this[filterObj]){
        let value = this[filterObj][k];
        if(typeof value === 'string'){
          counts++;
          if(value){
            filterValueCount++;
          }
          if(
            dataObj[k] &&
            dataObj[k].toLowerCase().includes(value.toLowerCase())
          ){
            match++;
          }
        }
      }
      if(filterValueCount){
        if(match === counts){
          accumulator.push(dataObj);
        }
      }else{
        accumulator.push(dataObj);
      }
    }
    this[filterList] = accumulator;
  }

  initiateHardReserve = (detail, proposalNumber, i) => {
    const {
      proposalid='',
      productcategory='', oiamsubtype2='',
      begindate='', enddate='',
      quantity=0, hrQty=0,
      businessunit='', pdid='',
      pcbusinessunit='', project='',
      custodian=''
    } = detail;
    
    const hrObj = {
      proposalNumber : proposalNumber,
      projectNumber : project,
      category :productcategory,
      subtype2 : oiamsubtype2,
      startDate : moment(begindate).format('YYYY-MM-DD'),
      endDate : moment(enddate).format('YYYY-MM-DD'),
      businessUnit : businessunit,
      maxHrCount : quantity - hrQty,
      pdid,
      pdidIndex : i,

      pcbusinessunit : pcbusinessunit, 
      projectid : project, 
      custodian : custodian, 

      customerName : this.proposalData['customer'],
      proposalDescription : this.proposalData['description'],
      crmnumber:this.proposalData.oicrmbidnumber
    }
    
    let projectStart = new Date(begindate).getTime();
    let today = new Date().getTime();
    let dateGreater;

    if(projectStart && today){
      dateGreater = projectStart > today;
    }

    this.store.dispatch(new ResetProposalPageData());
    this.store.dispatch(new SetHardReserveMode(hrObj));
    this.store.dispatch(new SetViewPreference('details'))
    this.store.dispatch(new SetDateRange({
      startDate : dateGreater ? moment(begindate).format('YYYY-MM-DD') : moment().format('YYYY-MM-DD'), 
      endDate : dateGreater ? moment(enddate).format('YYYY-MM-DD') : moment().add(6, 'months').format('YYYY-MM-DD')
    }));
    this.router.navigate(['/product/:']);
  }

  removeReservation2 = (rowData, proposalNumber, boolean) => {
    let obj = [{
       assetId : rowData['assetid'],
       subType2 : rowData['subtype2'],
       assetCategory : rowData['category'],
       assetDescription : rowData['assetdescription'],
       hrStartDate : rowData['begindate'],
       hrEndDate : rowData['enddate'],
       proposalNumber,
       projectNumber : rowData['project'],
       businessUnit : rowData['businessunit'],
       pdid : rowData['pdid']

     }]
   
     this.hrRemovalObj = {assetList : obj}
 }

 createReservation2 = (rowData, proposalNumber, i) => {
  let focusedAsset = rowData['assetid'];
  let checkFurther = false;
  for (let hrAsset of this.hardReservedReference){
    if (hrAsset.assetid === rowData.assetid){
      checkFurther = true;
    }
  }
  if (checkFurther){
    for (let row of this.parsedPSData){
      if (row.assetid === focusedAsset && row.pdid !== rowData.pdid){
        if (rowData.begindate > row.enddate || rowData.enddate < row.begindate){}
        else{
        }
      }
    }
  }
  let obj = {
    assetId : rowData['assetid'],
    subType2 : rowData['oiamsubtype2'],
    assetCategory : rowData['productcategory'],
    assetDescription : rowData['assetdescription'],
    hrStartDate : moment(rowData['begindate']).format('YYYY-MM-DD'),
    hrEndDate : moment(rowData['enddate']).format('YYYY-MM-DD'),
    proposalNumber,
    projectNumber : rowData['project'],
    businessUnit : rowData['businessunit'],
    pdid : rowData['pdid'],
    pdidIndex : i,
    customerName : this.proposalData['customername'],
    proposalDescription : this.proposalData['proposaltitle'],
    pcbusinessunit : this.proposalData['pcbusinessunit'],
    projectid : this.proposalData['project'],
    custodian : rowData['custodian'],
    serialid : rowData['assetserialid'],
    tagnumber : rowData['assettagnumber']

  }
  this.setState('hrCreateObj', obj);
}

onRemoveHardReserve(obj) {
  this.resetShowModal.emit();
  this.store.dispatch(new RemoveReadyToCheckoutData(obj));
}

cancelHrRemoval = () => {
  this.hrRemovalObj = {};
}

finalizeHrCreate = async() => {
  this.resetShowModal.emit();
  this.store.dispatch(new CreateReservation({
    assetList : [this.state['hrCreateObj']],
    proposalid : this.proposalid
  }));
  this.hrResponseObj={};
  this.checkRows()
}

checkRows = async() => {
  let showCheckBox = true;
  let showAddAssetBox = true;
  let showXBox = true;
  
  for (let row in this.rowMap){

    //Partial Check on Check Box : Full Check On AddAsset
    let result = await this.assetPillQuantitiesCheckMap(this.rowMap[row])
    showCheckBox = result.showCheck;
    showAddAssetBox = !result.showAddAsset;
  
    //Partial Check on Check Box
    if (showCheckBox){
      let result2 = await this.assetPillCheckDateMap(this.rowMap[row])
      showCheckBox = result2;
    }

    //Full Check on X Box
    let result3 = this.assetPillCheckMap(this.rowMap[row])
    showXBox = result3
    
    this.rowMap[row].showCheck = showCheckBox;
    this.rowMap[row].showAddAsset = showAddAssetBox;
    this.rowMap[row].showX = showXBox;
  }
}

assetPillQuantitiesCheckMap(asset) {
  let isWarning : boolean = true;
  let isAddAssetDisable : boolean = false;
  if(asset.coQty >= Number(asset.quantity)){ // Check Out = Needed Amount
    isWarning = false;
    isAddAssetDisable = true;
  }
  else if(asset.hrQty === Number(asset.quantity)){ // Needed Amout = Hard Reserved
      isWarning = false;
      isAddAssetDisable = true;
  }
  else if(
    asset.coQty !== Number(asset.quantity) && asset.hrQty === 0   // Check Out != Needed Amount : Hard Reserved Assets = 0
  ){
      isWarning = true
  }
  else if(asset.coQty !== Number(asset.quantity) && // Check Out != Needed Amount :  Hard Reserved Assets > 0
    asset.hrQty > 0){
      for(let i = 0; i < this.hardReservedReference.length; i++){
        if(this.hardReservedReference[i]['assetid'] === asset.assetid){
          isWarning = false;
          if(asset.hrQty + asset.coQty === Number(asset.quantity)){
            isAddAssetDisable = false
          }
          break;
        }
      }
      if (isWarning && asset.hrQty + asset.coQty === Number(asset.quantity)){
        isWarning = false;
      }  

  }
  let usageObj = {
    showCheck : isWarning,
    showAddAsset : isAddAssetDisable
  }
  return usageObj
}

assetPillCheckMap(asset){ //Checks if asset in pill is Hard Reserved
  let pillInHR : boolean = false;
  for(let i =0; i< this.hardReservedReference.length; i++){
    if(this.hardReservedReference[i]['assetid'] == asset.assetid){
      if (this.hardReservedReference[i]['checkedout'] == false && 
          this.hardReservedReference[i].pdid === asset.pdid){
        pillInHR = true
        break;
      }
    }
  }
  return pillInHR
}

assetPillCheckDateMap(rowData){
  let isCheck = true;
  for (let hrAsset of this.hardReservedReference){
    if (hrAsset.assetid === rowData.assetid && hrAsset.pdid !== rowData.pdid){
      if ((Date.parse(rowData.enddate) < Date.parse(hrAsset.startdate)) || (Date.parse(rowData.begindate) > Date.parse(hrAsset.enddate))){
      }
      else{
        isCheck = false;
        break;
      }
    }
  }
  return isCheck
}

}
