import { AppState } from '../../models/appState';
import { Component, OnInit, Input, SimpleChange, EventEmitter, Output } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Router, ActivatedRoute } from '@angular/router';
import * as _ from 'lodash';
import { GetCheckInOutAssets, GetReadyToCheckoutData } from '../../actions/checkout.action';
import { Subscription } from 'rxjs';
import { SelectedAssetsdetailsModel } from '../../utils/serviceRequest/SelectedAssetsDetailsModel';
import { SetAdditionalAssetinServiceRequest } from '../../actions/serviceRequest.actions';
import localDate from '../../utils/date/localDate';

@Component({
  selector: 'app-table-pop-up-modal',
  templateUrl: './table-pop-up-modal.component.html',
  styleUrls: ['./table-pop-up-modal.component.css']
})
export class TablePopUpModalComponent implements OnInit {
  showPopUPModal: string = 'none';
  hardreservedassets = [];
  checkInOutRecords = [];
  readyToCheckOutSubscription: Subscription;
  checkInOutSubscription: Subscription;
  allRowsSelected: boolean = false;
  selectedAssets = [];
  selectedPopUPItem=[];
  tablePopUpCheckboxMap = {};
  skip: number = 0;
  limit: number = 50;
  tranformedTextObj = {
    hard_reserve_table: 'Hard Reserved',
    checkin_table: 'Checked Out',
    checkedin_table: 'Checked In'
  }
  localDate = localDate;
  @Input() tableBuilderList: any;
  @Input() showTableModal: boolean = false;
  @Input() actionButtonElements: any;
  @Input() originmodule: string;
  @Input() requestObject: any;
  @Input() tablePopUPData: any;
  @Output() resetPopUpModal = new EventEmitter<any>();
  constructor(
    private store: Store<AppState>, 
    private route:ActivatedRoute, 
    private router:Router
  ) { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChange) {
    if(
      changes['showTableModal'] &&
      (
        !_.isEqual(
          changes['showTableModal']['currentValue'],
          changes['showTableModal']['previousValue']
        ) 
      )
    ){
      this.showModal();
    }
  }

  fetchDetails = () => {
    this.requestObject = {
      ...this.requestObject,
      skip: this.skip,
      limit: this.limit
    }
    if(this.originmodule === 'hard_reserve_table') {
     this.store.dispatch(new GetReadyToCheckoutData(this.requestObject));
    }else{
     this.store.dispatch(new GetCheckInOutAssets(this.requestObject));
    }
  }

  private showModal = () => {
    if(this.showTableModal) {
      this.showPopUPModal = 'block';
      if(this.originmodule) {
        this.fetchDetails();
      }
    }
  }

  dynamicActionButton = (type) => {
     if(type === 'cancelModal'){
      this.closePopUpModal();
     }else if(type === 'saveModal') {
      this.submitModal();
     }
  }
  
  closePopUpModal = () => {
    this.resetModal();
  }

  resetModal = () => {
    this.showPopUPModal = 'none';
    this.selectedAssets = [];
    this.selectedPopUPItem=[];
    this.tablePopUpCheckboxMap = {};
    this.allRowsSelected = false;
    this.tablePopUPData = [];
    this.resetPopUpModal.emit();
  } 

  submitModal = () => {
    let arrayObj = [];
    for(let detail of this.selectedAssets) {
      let obj: SelectedAssetsdetailsModel = new SelectedAssetsdetailsModel();
      obj = {
       ...obj,
       "assetid": detail.assetid,
       "businessunit": detail.businessunit,
       "enddate": detail.enddate,
       "startdate": detail.startdate,
       "serialid":detail.serialid,
       "tagnumber":detail.tagnumber,
       "projectnumber":detail.projectnumber,
       "assetdescription":detail.assetdescription,
       "projectmanagername": detail.projectmanagername,
      }
      arrayObj.push(obj)
    }
    let reqObj = {
      reqObj: arrayObj
    }
    this.store.dispatch(new SetAdditionalAssetinServiceRequest(reqObj));
    this.resetModal();
  }

  onAllAssetSelection() {
    this.allRowsSelected = !this.allRowsSelected;
    this.normalizeCheckboxes(this.tablePopUPData.length, this.allRowsSelected);
    if (this.allRowsSelected) {
      this.selectedAssets = this.tablePopUPData;
    }
    else {
      this.selectedAssets = [];
    }
    this.selectedPopUPItem = JSON.parse(JSON.stringify(this.selectedAssets));
  }

  normalizeCheckboxes(length, allRowsSelected) {
    for (let i=0; i< length; i++ ) {
      if(!this.tablePopUpCheckboxMap[i]){
        this.tablePopUpCheckboxMap[i] = {
          selected : false
        }
      }
      this.tablePopUpCheckboxMap[i]['selected'] = allRowsSelected;
    }
  }

  onAssetSelection(data, i) {
    if (!this.tablePopUpCheckboxMap[i]) {
      this.tablePopUpCheckboxMap[i] = {
        selected: false
      }
    }
    if (!this.tablePopUpCheckboxMap[i]['selected']) {
      this.tablePopUpCheckboxMap[i]['selected'] = true;
      this.selectedAssets.push(data);
    }else {
      this.tablePopUpCheckboxMap[i]['selected'] = false;
      this.selectedAssets = this.selectedAssets.filter(function (obj) {
        return obj._id !== data._id;
      });
    }
    this.selectedPopUPItem = JSON.parse(JSON.stringify(this.selectedAssets));
  }

  isPopUPtemSelected(i) {
    return (this.tablePopUpCheckboxMap[i] && this.tablePopUpCheckboxMap[i]['selected']) || false;
  }

  buttonIsDisabled(type) {
    switch (type) {
      case 'saveModal':
     if(this.selectedPopUPItem.length < 1) {
       return true;
     }
     default:
      return false
    }
  }
}
