import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TablePopUpModalComponent } from './table-pop-up-modal.component';

describe('TablePopUpModalComponent', () => {
  let component: TablePopUpModalComponent;
  let fixture: ComponentFixture<TablePopUpModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TablePopUpModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TablePopUpModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
