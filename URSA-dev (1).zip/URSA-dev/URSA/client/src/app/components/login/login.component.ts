import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { LoginUser, GetUserDetail, ClearUserDetail, SetUserDetailReducer } from '../../actions/userDetail.actions';
import { MsalService, BroadcastService } from '@azure/msal-angular';
import { CookieService } from "angular2-cookie/core";
import * as _ from 'lodash';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  model: any = {}
  modalDisplay = "none";
  message = ""
  userDetailSubscription;
  error;
  user;
  redirectUrl: any;
  redirectParams: any;
  loginFail : boolean = false;
  loggedIn = false;
  constructor( 
    private router: Router, 
    private store: Store<AppState>,
    private authService: MsalService,
    private http: HttpClient,
    private broadcastService: BroadcastService,
    private cookieService: CookieService
  ) {}

  ngOnInit() {
    this.checkLoginStatus();

    this.broadcastService.subscribe('msal:loginSuccess', () => {
      this.checkAccount();
    });

    this.authService.handleRedirectCallback((authError, response) => {
      if (authError) {
        console.error('Redirect Error: ', authError.errorMessage);
        return;
      }
      this.checkAccount();
    });

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
      .subscribe(obj => {
        if(obj){
          const {details, isfetch, isLoginError} = obj;
          if(isfetch){
            this.modalDisplay = "block";
          }
          else{
            this.modalDisplay = "none";
            // if (isLoginError){
            //   this.loginFail = true
            // }
          }
          let uDate = (Date.now() / 1000)
          if(details && !_.isEmpty(details) && details['authTokenExpiryTime'] > uDate)
          {
            if(
              sessionStorage.getItem('lastRoute') && 
              sessionStorage.getItem('lastRoute')!= ''
            ){
              let previousRoute = window.atob(sessionStorage.getItem('lastRoute')) 
              window.location.href = previousRoute;
            }else{
              this.renderView(details);
            }
          }
        }
      })
  }

  ngOnDestroy(){
    this.userDetailSubscription.unsubscribe();
  }

  renderView(userData) {
    if(userData.hasError){
      this.message = "Something went wrong."
    }
    if (!userData.hasError){
      this.router.navigate(['/landing']); 
    }

  }

  onSubmit() {
    this.store.dispatch(new ClearUserDetail());
    this.store.dispatch(new LoginUser({ username: this.model.username, password: this.model.password }));
  }

  onPasswordInput(){
    if(this.loginFail){
      this.loginFail = false
    }
  }

  login() {
    const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;

    if (isIE) {
      this.authService.loginRedirect({
        extraScopesToConsent: ["user.read", "openid", "profile"]
      });
    } else {
      this.authService.loginPopup({
        extraScopesToConsent: ["user.read", "openid", "profile"]
      });
    }
  }

  checkLoginStatus = async () => {
    this.loggedIn = !!this.authService.getAccount();
  }

  checkAccount = async () => {
    let loggedIn = !!this.authService.getAccount();
    if(loggedIn){
      let token = await this.authService.acquireTokenSilent({
        scopes: ["user.read"]
      });
      this.store.dispatch(new SetUserDetailReducer({
        isloggedOut : false
      }));
      this.cookieService.put('msalaccesstoken', token.accessToken);
      this.cookieService.put('msalaccesstokenexpiration', `${new Date(token.expiresOn).getTime()}`);
      this.store.dispatch(new GetUserDetail({}));
    }else{
      this.store.dispatch(new SetUserDetailReducer({
        isloggedOut : true
      }));
    }
  }

}
