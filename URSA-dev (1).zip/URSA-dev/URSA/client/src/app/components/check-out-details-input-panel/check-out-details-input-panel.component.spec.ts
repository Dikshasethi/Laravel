import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckOutDetailsInputPanelComponent } from './check-out-details-input-panel.component';

describe('CheckOutDetailsInputPanelComponent', () => {
  let component: CheckOutDetailsInputPanelComponent;
  let fixture: ComponentFixture<CheckOutDetailsInputPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckOutDetailsInputPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckOutDetailsInputPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
