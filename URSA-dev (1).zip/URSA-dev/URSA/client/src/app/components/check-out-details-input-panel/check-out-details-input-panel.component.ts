import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { AppState } from '../../models/appState';
import { Store, select } from '@ngrx/store';
import * as moment from 'moment';
import { LogoutUser } from '../../actions/userDetail.actions';
import { DestroyAutocompleteList, GetCheckoutAutocomplete, GetCustodianAutocompleteList } from '../../actions/autocomplete.actions';
import { DatePipe } from '@angular/common';
import {checkinPermission,cancelCheckoutPermission} from '../../utils/config/config';
@Component({
  selector: 'app-check-out-details-input-panel',
  templateUrl: './check-out-details-input-panel.component.html',
  styleUrls: ['./check-out-details-input-panel.component.css','../ready-checkout/ready-checkout.component.css']
})
export class CheckOutDetailsInputPanelComponent implements OnInit {

  constructor( private store: Store<AppState>, private datePipe: DatePipe) { }
  newDetails={};
  suggestionList=[];
  autocompleteSubscription;
  isAreaDisabled = true;
  destinationLocation='';
  destinationArea ='';  
  selectedLocationCode = "";
  selectedAreaCode="";
  checkinDate= new Date() ;
  custodian="";
  currentDate = moment(new Date()).format('YYYY-MM-DD')
  isShowDateWarning = false;
  isAreaWarning:boolean=false;
  isLocationWarning:boolean=false;
  checkinPermission:string = checkinPermission;
  cancelCheckoutPermission:string = cancelCheckoutPermission;
  maxCheckinDate : any;
  @Input() selectedCheckoutLocationCode
  @Input() selectedCheckoutAreaCode
  @Input() actualCheckinDate
  @Input() selectedAssets
  @Input() hrPermission

  @Output() locationSelected = new EventEmitter<any>();
  @Output() areaSelected = new EventEmitter<any>();
  @Output() checkinDateChanged = new EventEmitter<any>();
  @Output() custodianSelected = new EventEmitter<any>();
  @Output() closeModal = new EventEmitter<any>();

  @Output() checkinAsset = new EventEmitter<string>();
  @Output() cancelCheckin = new EventEmitter<string>();

  @Input()   
  set modalType( val ) {
    if(val){    
      if(val === "checkin"){
        this.actionButton = "Checkin"
        this.modalTitle = "Checkin"
        this._modalType = val
      }
      else if(val === "cancel"){
        this.actionButton = "Cancel Checkout"
        this.modalTitle = "Cancel Checkout"
        this._modalType = val

      }    
    }    
  }
  actionButton : String = "";
  modalTitle : String = "";
  _modalType : String = "";
  maxDate : any;
  @Input()
  set checkinDetails( val ) {
    if(val){
      this.destinationLocation = val.destinationLocation;
      this.destinationArea = val.destinationArea;
      this.checkinDate = val.checkinDate;
      if(val.custodian && val.custodian.empName){
        this.custodian = val.custodian.empName;
        this.custodianSelected.next( val.custodian);  
      }
    }    
  }

  ngOnInit() {
    if(this._modalType === "checkin"){
      this.maxDate  = new Date();  
    }

    this.autocompleteSubscription = this.store.pipe(select(state => state.Autocomplete.checkoutAutocomplete))
    .subscribe(autocompleteObject => {
      const {
        suggestionList,isFetchingAutocompleteList, field
      } = autocompleteObject;   
      if(suggestionList && suggestionList['isAuthenticate']=="not authenticated"){
        this.store.dispatch(new LogoutUser({}));
      }
      if(!isFetchingAutocompleteList && (suggestionList && suggestionList.length==0)){
        let obj = [];
        if(field=="location"){
          obj=[{
            "locationText":"No data found",
            "areaText":"No data found"
          }]
        }else if(field=="area"){
          obj=[{
            areaCode: "NA",
            areaText: "NA"
          }]
        }
       
        this.suggestionList = obj;
      }else{
        if(suggestionList &&  (field=="location" || field=="custodian")){
          this.suggestionList = suggestionList;
        }else if(suggestionList && field=="area"){
          let obj = {
            areaCode: "NA",
            areaText: "NA"
          }
          this.suggestionList = suggestionList;
          this.suggestionList.splice( 0, 0, obj );
        }
      }
      
    });    

  }

 
  handleAutocompleteInputChange(text,field){
    this.suggestionList = [];
    if(field=='custodian'){
      if(text.length>=2){
        let obj={
          "index":"employeesearch",
          "search_keyword":text,
          "field":"custodian"
        }
        this.store.dispatch(new DestroyAutocompleteList());
        this.store.dispatch(new GetCustodianAutocompleteList(obj));
      }     
    }else{
      if(text=="" && field=="location"){
        this.isAreaDisabled = true;
        this.destinationArea = '';
        this.selectedLocationCode = '';
        this.locationSelected.next('');
      }else if(text=="" && field=="area"){
        this.selectedAreaCode = '';
        this.areaSelected.next('')
      }
      
      if(text.length>=2){
        let obj =  {
          "field" : field     
        }
        if(field === "location"){
          this.isAreaDisabled = true;
          this.destinationArea = '';
          obj['locationDescription'] = text
        }
        if(field === "area"){
          obj['locationCode'] = this.selectedLocationCode;
          obj['areaDescription'] = text 
        }
           
        this.store.dispatch(new DestroyAutocompleteList());
        this.store.dispatch(new GetCheckoutAutocomplete(obj));
      }
    }
    
  }


  suggestionSelected(suggestion,field){
    if(field==='location' && suggestion.locationText!="No data found"){
      this.destinationLocation = suggestion.locationText;
      this.selectedLocationCode = suggestion.locationCode;
      this.isAreaDisabled = false;
      this.locationSelected.next(suggestion);
    }
      
    if(field==='area' && suggestion.areaText!="No data found"){
      this.destinationArea = suggestion.areaText;
      this.selectedAreaCode = suggestion.areaCode;
      this.areaSelected.next(suggestion);      
    }

    if(field==='custodian' && suggestion.locationText!="No data found"){
      this.custodian = suggestion.empName;
      this.custodianSelected.next(suggestion);
    }
  }

  onCheckinDateChanged(event){
    let enteredDate = new Date(event).getTime()
    let todayDate =  new Date().getTime();
    if(enteredDate>todayDate){
      this.isShowDateWarning = true
    }else{
      this.isShowDateWarning = false
    }
    this.checkinDateChanged.next(event);
  }  

  modalAction(){
    if(this._modalType === "checkin"){
      this.checkinAsset.next();
    }
    else if(this._modalType === "cancel"){
      this.cancelCheckin.next();
    }
  }

  ngOnDestroy(){
    this.autocompleteSubscription.unsubscribe();
  }

  _closeModal(){
    this.closeModal.next();
  }
}
