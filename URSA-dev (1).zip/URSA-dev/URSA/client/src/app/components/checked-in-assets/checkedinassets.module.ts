import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { CheckedinassetsRoutes } from './checkedinassets.routes';
import { CheckoutCheckin } from './checked-in-assets.component';

@NgModule({
    declarations: [
        CheckoutCheckin
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(CheckedinassetsRoutes)
    ],
    exports: [
        RouterModule
    ]
})

export class CheckedinassetsModule { }