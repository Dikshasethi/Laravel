import { Routes } from '@angular/router';
import { CheckoutCheckin } from './checked-in-assets.component';

export const CheckedinassetsRoutes: Routes = [
    { path: '', component: CheckoutCheckin }
];