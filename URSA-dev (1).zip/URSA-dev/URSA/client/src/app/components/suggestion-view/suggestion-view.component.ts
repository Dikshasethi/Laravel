import { Component, OnInit, Input, SimpleChange,Output, EventEmitter } from '@angular/core';
import { Store, select } from '@ngrx/store';
import {AppState} from '../../models/appState';
import { SetSearchKeyword, SetSearchKeywordLocalStorage } from '../../actions/search.actions';
import { DestroyDataObject, ClearProductsObjectCache, ClearProductsHierarchyObject } from '../../actions/product.actions';
import { ResetFilters } from '../../actions/refinedBy.actions';
import { ManageAdvancedSearchDisplay, ResetSearch } from '../../actions/advancedSearch.actions';
import { DestroyProductSummary, ClearProductSummaryCache } from '../../actions/productSummary.actions';
import * as _ from 'lodash';

@Component({
  selector: 'app-suggestion-view',
  templateUrl: './suggestion-view.component.html',
  styleUrls: ['./suggestion-view.component.css']
})
export class SuggestionViewComponent implements OnInit {

  @Input() suggestionData:any;
  @Output() suggestionSearchSubmit: EventEmitter<any>  = new EventEmitter();
  searchedProduct = '';
  refinedByFilterKey = 'productFilterObject';
  suggestions=[];
  userView;
  searchSubscription;



  constructor(
    private store: Store<AppState>
  ) { }
  

  ngOnInit() {    
    this.searchSubscription = this.store.pipe(select(state => state.Search))
    .subscribe(searchState => {
      const {localStorageKeyword} = searchState;
      this.searchedProduct = localStorageKeyword;
    })
  }

  ngOnChanges(changes: SimpleChange) {
    let dataReference = changes['suggestionData'];
    let dataProp = Object.assign({}, dataReference);
    if (dataReference) {
        let currentDataProp = dataProp.currentValue;
        let previousDataProp = dataProp.previousValue;
        if (!_.isEqual(currentDataProp, previousDataProp)) {
            this.suggestions = currentDataProp || [];
        }
    }
  }

  searchProduct(value){
    this.store.dispatch(new SetSearchKeywordLocalStorage(value))
    this.store.dispatch(new ResetSearch());
    this.store.dispatch(new SetSearchKeyword(value));
    this.store.dispatch(new ManageAdvancedSearchDisplay('none'));
    this.store.dispatch(new ResetFilters());
    this.store.dispatch(new DestroyProductSummary());
    this.store.dispatch(new DestroyDataObject());
    this.store.dispatch(new ClearProductSummaryCache());
    this.store.dispatch(new ClearProductsObjectCache());
    this.store.dispatch(new ClearProductsHierarchyObject());
    this.suggestionSearchSubmit.emit();
  }
}
