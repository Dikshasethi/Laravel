import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-calendar-component',
  templateUrl: './calendar-component.component.html',
  styleUrls: ['./calendar-component.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CalendarComponentComponent implements OnInit {

  constructor() { }
  calendarHtml = '';
  private calendarTable = '';
  private year = new Date().getFullYear();
  private finalYear  = 9999;
  private finalMonth  = 99;

  ngOnInit() {
    // this.go12();
  }

    pad(d) {
        return (d < 10) ? '0' + d.toString() : d.toString();
    }

  calendar(month,year,data,statesdata,reservationData,finalSlidingDate) {

    //Variables to be used later.  Place holders right now.
    let padding = "";
    let totalFeb = 0;
    let i = 1;
    let testing = "";

    let current = new Date();
    let calanderScrollerDate = new Date(finalSlidingDate);
    let cmonth = current.getMonth();
    let day = current.getDate();
    let cyear = current.getFullYear();
    let tempMonth = month + 1; //+1; //Used to match up the current month with the correct start date.
    let prevMonth = month - 1;
    let dateClass="";
    let dateStatus = "";
    let maintenanceStatus=false;

    //Determing if Feb has 28 or 29 days in it.  
    if (month == 1) {
        if ((year % 100 !== 0) && (year % 4 === 0) || (year % 400 === 0)) {
            totalFeb = 29;
        } else {
            totalFeb = 28;
        }
    }

    //////////////////////////////////////////
    // Setting up arrays for the name of    //
    // the	months, days, and the number of	//
    // days in the month.                   //
    //////////////////////////////////////////

    let monthNames = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
    let dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    let totalDays = ["31", "" + totalFeb + "", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31"];

    //////////////////////////////////////////
    // Temp values to get the number of days//
    // in current month, and previous month.//
    // Also getting the day of the week.	//
    //////////////////////////////////////////

    let tempDate = new Date(tempMonth + ' 1 ,' + year);
    let tempweekday = tempDate.getDay();
    let tempweekday2 = tempweekday;
    let dayAmount = parseInt(totalDays[month]);
    // var preAmount = totalDays[prevMonth] - tempweekday + 1;	

    //////////////////////////////////////////////////
    // After getting the first day of the week for	//
    // the month, padding the other days for that	//
    // week with the previous months days.  IE, if	//
    // the first day of the week is on a Thursday,	//
    // then this fills in Sun - Wed with the last	//
    // months dates, counting down from the last	//
    // day on Wed, until Sunday.                    //
    //////////////////////////////////////////////////
   
    while (tempweekday > 0) {
        padding += "<td class='premonth'></td>";
        //preAmount++;
        tempweekday--;
    }
    //////////////////////////////////////////////////
    // Filling in the calendar with the current     //
    // month days in the correct location along.    //
    //////////////////////////////////////////////////

    while (i <= dayAmount) {

        //////////////////////////////////////////
        // Determining when to start a new row	//
        //////////////////////////////////////////

        if (tempweekday2 > 6) {
            tempweekday2 = 0;
            padding += "</tr><tr>";
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////
        // checking to see if i is equal to the current day, if so then we are making the color of //
        //that cell a different color using CSS. Also adding a rollover effect to highlight the  //
        //day the user rolls over. This loop creates the acutal calendar that is displayed.		//
        //////////////////////////////////////////////////////////////////////////////////////////////////
        if(reservationData && reservationData.length>0){
            for (let j = 0; j < reservationData.length; j++) {
                let key = j.toString()
                let thisDate = Date.parse(year+"-"+this.pad(month+1)+"-"+this.pad(i));
                let compStartDate = Date.parse(reservationData[key].reservationStartDate);
                let compEndDate = Date.parse(reservationData[key].reservationEndDate);
                if(thisDate >= compStartDate && thisDate <= compEndDate ){
                    dateStatus = "Hard Reserved" ;
                    break;
                }else{
                    dateStatus = this.checkDateSatus(data,year,month,i)
                }
            }
        }else{
            dateStatus = this.checkDateSatus(data,year,month,i)
        }
        
        switch (dateStatus) {
            case "Hard Reserved":
                dateClass = "hardReserved"
                break;
            case "Available":
                dateClass = "available"
                break;
            case "OnHire":
                dateClass = "onhire"
                break;   
            case "Unavailable":
                dateClass = "unavailable"
                break;
            case "Checked Out":
                dateClass = "checkedout"
                break;
            default:
                dateClass = "available"
                break;
        }
        for (let j = 0; j < statesdata.length; j++) {
            let key = j.toString()
            let thisDate = Date.parse(year+"-"+this.pad(month+1)+"-"+this.pad(i));
            let compStartDate = Date.parse(statesdata[key].startdate);
            let compEndDate = Date.parse(statesdata[key].enddate);
           
            if(thisDate >= compStartDate && thisDate <= compEndDate ){
                maintenanceStatus = true ;
                break;
            }else
                maintenanceStatus = false ;
        }
        if(maintenanceStatus){
            switch (dateClass) {
                case "available":
                    dateClass = "avail-main"
                    break;
                case "unavailable":
                    dateClass = "unavailable-workorder"
                    break;
                case "hardReserved":
                    dateClass = "hardReserved-main"
                    break;    
                case "onhire":
                    dateClass = "hire-main"
                    break;   
                case "checkedout":
                    dateClass = "checkedOut-main"
                    break;
                default:
                    dateClass = "available"
                    break;
            }
        }
        padding += "<td width='30'><div class=' "+dateClass+"'>" + i + "</div></td>";
        tempweekday2++;
        i++;
    }


    /////////////////////////////////////////
    // Ouptputing the calendar onto the	//
    // site.  Also, putting in the month	//
    // name and days of the week.		//
    /////////////////////////////////////////

    this.calendarTable = "<tr><th><div><table class='calendarTable' border='0' cellspacing='0' cellpadding='2'> <tr><td colspan='7'><div class='month'>" + monthNames[month] + " " + year + "</div></td></tr>";
    if(month === calanderScrollerDate.getMonth() && year === calanderScrollerDate.getFullYear())
    {
        this.calendarTable = '<tr><th><div class="scrollcalander"><table class="calendarTable" border="0" cellspacing="0" cellpadding="2"> <tr><td colspan="7"><div class="month">' + monthNames[month] + ' ' + year + '</div></td></tr>';
    }
    this.calendarTable += "<tr><td width='30'><div class='sunday'>Sun</div></td>  <td width='30'><div class='week'>Mon</div></td>"+
        "<td width='30'><div class='week'>Tue</div></td> <td width='30'><div class='week'>Wed</div></td>"+
        "<td width='30'><div class='week'>Thu</div></td> <td width='30'><div class='week'>Fri</div></td>"+
        "<td width='30'><div class='week'>Sat</div></td> </tr>";
    this.calendarTable += "<tr>";
    this.calendarTable += padding;
    this.calendarTable += "</tr></table></div></th></tr>";
    this.calendarHtml += this.calendarTable
  }

  checkDateSatus(data,year,month,i){

    for (let j = 0; j < data.length; j++) {
        let key = j.toString()
        let thisDate = Date.parse(year+"-"+this.pad(month+1)+"-"+this.pad(i));
        let compStartDate = Date.parse(data[key].startdate);
        let compEndDate = Date.parse(data[key].enddate);
        if(thisDate >= compStartDate && thisDate <= compEndDate ){
            return data[key].status ;
        }
    }
  }

  go12(data, statesdata,reservationData) {
    let year_timeSeriesStartDate = 9999;
    let month_timeSeriesStartDate = 99;
    if(data && data.length >= 1){
        let raw_timeSeriesStartDate : Date = new Date(data[0].startdate);
        // let raw_timeSeriesStartDate : Date = new Date(Date.parse(data[0].startdate));

        // year_timeSeriesStartDate = raw_timeSeriesStartDate.getFullYear();
        year_timeSeriesStartDate = data[0].startdate.split('-') ? (parseInt(data[0].startdate.split('-')[0], 10)) : new Date().getFullYear();

        // month_timeSeriesStartDate = raw_timeSeriesStartDate.getMonth(); 
        month_timeSeriesStartDate = data[0].startdate.split('-') ? (parseInt(data[0].startdate.split('-')[1], 10)-1) : 1;
        // this.finalMonth = new Date(data[(data.length - 1)].enddate).getMonth() ;
        this.finalMonth = data[(data.length - 1)].enddate.split('-') ? (parseInt(data[(data.length - 1)].enddate.split('-')[1], 10)) : 1;
        this.finalYear = new Date(data[(data.length - 1)].enddate).getFullYear();
    }

    let finalSlidingDate = this.calculateSlidingDate(data, statesdata);
    this.calendarHtml = "";
    this.calendarTable = "";

    for (let i = month_timeSeriesStartDate; i < 12; i++) {
      this.calendar(i,year_timeSeriesStartDate,data,statesdata,reservationData,finalSlidingDate);
    }
    let past = year_timeSeriesStartDate;
    let diffrence = (this.finalYear - past)
    let pYear = 9999;
    for(let j=1; j <= diffrence; j++){
        pYear = year_timeSeriesStartDate +j;
        if(pYear != this.finalYear){
            for (let i = 0; i < 12; i++){
                this.calendar(i,pYear,data,statesdata,reservationData,finalSlidingDate);
            }
        }
        else{
            for (let i = 0; i < this.finalMonth; i++){
                this.calendar(i,pYear,data,statesdata,reservationData,finalSlidingDate);
            }
        }
    }
  }

  fetchDateObj(data){
    let newobj = {};
    if(Array.isArray(data)){
         let maxtimestamp = 0; 
        for(let i in data){
            let date = data[i].enddate
            let timestamp = new Date(date).getTime();
            
            if(timestamp > maxtimestamp){
                maxtimestamp = timestamp;
                newobj = data[i];
            }
        }
        data = newobj;
        return data;
    }
  }

  calculateStatesDate(currentDate,statesdata,timeseriesEndDate=null){
    let statesDate = currentDate;
    if(statesdata && statesdata.length >= 1){
       let finalStateDateObj = this.fetchDateObj(statesdata);
       if(typeof finalStateDateObj !== "undefined"){
            if(currentDate > finalStateDateObj.enddate ){
                statesDate =  finalStateDateObj.enddate;
                if(timeseriesEndDate && timeseriesEndDate > finalStateDateObj.enddate){
                    statesDate = timeseriesEndDate;
                }
            }
       }
    }else{
        if(timeseriesEndDate && currentDate > timeseriesEndDate){
            statesDate = timeseriesEndDate;
        }
    }
    return statesDate
  }

  calculateSlidingDate(data, statesdata){
    let currentDate = new Date().toLocaleDateString('en-CA');
    let slidingDate = currentDate;
    if(data && data.length > 0){
        let filteredData = data.filter((filterItem) => filterItem.status != 'Unavailable');
        if(filteredData && filteredData.length > 0) {
            let findFinaltimeseriesObj = this.fetchDateObj(filteredData);
            if(typeof findFinaltimeseriesObj !== "undefined") {
                if(findFinaltimeseriesObj.status == 'Available') {
                    slidingDate  = this.calculateStatesDate(currentDate,statesdata);
                }else{
                    if(currentDate > findFinaltimeseriesObj.enddate){
                        slidingDate  =  this.calculateStatesDate(currentDate,statesdata,findFinaltimeseriesObj.enddate);
                    }
                }
            }
        }
    }else{
        slidingDate  =  this.calculateStatesDate(currentDate,statesdata);
    }
    return slidingDate
  }

}