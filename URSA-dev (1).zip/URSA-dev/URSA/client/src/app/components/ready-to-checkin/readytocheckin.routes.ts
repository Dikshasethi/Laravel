import { Routes } from '@angular/router';
import { ReadyToCheckinComponent } from './ready-to-checkin.component';

export const ReadytoCheckinRoutes: Routes = [
    { path: '', component: ReadyToCheckinComponent }
];