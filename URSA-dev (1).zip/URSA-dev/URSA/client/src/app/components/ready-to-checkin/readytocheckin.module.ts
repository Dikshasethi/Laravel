import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { ReadytoCheckinRoutes } from './readytocheckin.routes';
import { ReadyToCheckinComponent } from './ready-to-checkin.component';

@NgModule({
    declarations: [
        ReadyToCheckinComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(ReadytoCheckinRoutes)
    ],
    exports: [
        RouterModule
    ]
})

export class ReadytoCheckinModule { }