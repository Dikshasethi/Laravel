import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadyToCheckinComponent } from './ready-to-checkin.component';

describe('ReadyToCheckinComponent', () => {
  let component: ReadyToCheckinComponent;
  let fixture: ComponentFixture<ReadyToCheckinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReadyToCheckinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadyToCheckinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
