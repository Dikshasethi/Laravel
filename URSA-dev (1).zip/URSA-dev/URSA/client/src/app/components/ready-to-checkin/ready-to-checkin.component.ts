import { Component, OnInit, HostListener } from '@angular/core';
import { AppState } from '../../models/appState';
import { Store, select } from '@ngrx/store';
import { GetCheckInOutAssets, ClearCheckInOutAssets } from '../../actions/checkout.action';
import tableStructure from '../../utils/checkInOut/readyToCheckinTableStructure';
import * as $ from 'jquery';
import checkInOutFilterMapFunction from '../../utils/checkInOut/checkInOutFilterMapFunction';
import filterObjectDateFormat from '../../utils/checkInOut/filterObjectDateFormat';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import checkInOutFilterMap from '../../utils/checkInOut/checkInOutFilterMap';
import { ReSetSorting } from '../../actions/checkInOut.action';
import { ClearDownloadData, GetDownloadData } from '../../actions/download.action';
import downlaodcsv from '../../utils/downloadCSV/downlaodcsv';
import checkInOutSortMap from "../../utils/checkInOut/checkInOutSortMap";

@Component({
  selector: 'app-ready-to-checkin',
  templateUrl: './ready-to-checkin.component.html',
  styleUrls: ['./ready-to-checkin.component.css']
})
export class ReadyToCheckinComponent implements OnInit {

  constructor(private store: Store<AppState>, private route:ActivatedRoute) { }
  public innerHeight: any;
  skip:number = 0;
  limit:number = 20;
  recordCount: number = 0;
  total_count = 0;
  filterObj = {
    "checkInOutRecords.checkedin": false,
    "checkInOutRecords.cancelled": false
  };
  tableBuilderList = tableStructure.slice();
  checkInOutSubscription;
  modalDisplay = 'none';
  checkInOutError = false;
  tableViewHeight = 0;
  checkInOutRecords = [];
  calloutIdParam:any;
  checkInOutSortingSubscription:Subscription;
  downloadSubscription:Subscription;
  sortObj :any ={
    "checkoutdatems" : -1
  };
  filters : any = {};
  checkInOutLoading:boolean;
  donwloadDataListIsLoading:boolean;
  alertState: string;
  alertMessage: string;
  PersonalizationSubscription;
  personalizationTableColumnLoading: boolean = false;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;    
  }

  ngOnInit() {
    this.fetchReadyToCheckinData({});
    this.innerHeight = window.innerHeight;
    this.checkInOutSubscription = this.store.pipe(select(state => state.CheckOutPageData))
      .subscribe(data => {
        const {
          checkInOutData={}
        } = data;
        this.checkInOutRecords = checkInOutData['checkInOutRecords'];
        this.checkInOutLoading = checkInOutData['checkInOutIsLoading'];
        this.checkInOutError = checkInOutData['checkInOutError'];
        this.total_count = checkInOutData['checkInOutTotalCount'];
        this.getTableViewHeight();
      });

      this.route.queryParams.subscribe(params => {
        this.calloutIdParam = params['checkoutid'];
    });

    this.checkInOutSortingSubscription = this.store.pipe(select(state => state.CheckInOut))
    .subscribe(data => {
      const {sort:{checkin}}=data;
        let obj={};
        for(let key in checkin){
          obj[checkInOutSortMap[key]] = checkin[key];
        }
        this.sortObj = obj;
    });

    this.downloadSubscription = this.store.pipe(select(state => state.Download))
    .subscribe(data => {
      const { downloadData = [],isLoading} = data;
      this.donwloadDataListIsLoading = isLoading;
      if(!isLoading && downloadData.length){
        let mappedData = this.mappDownloadData(downloadData);
        downlaodcsv('checkedout', mappedData);
      }
    });

    this.PersonalizationSubscription = this.store.pipe(select(state => state.TableColumnPersonalization))
    .subscribe(personalizationData => {
      const {
        personalizationTableColumnData:  {  personalizationTableColumnLoading },
      }  = personalizationData
        this.personalizationTableColumnLoading = personalizationTableColumnLoading;
    })

    if(this.calloutIdParam){
      let obj = {
        peoplesoftcheckoutid: this.calloutIdParam 
      }
      this.filterFunction(obj);
    }
  }

  ngOnDestroy(){
    this.checkInOutSubscription.unsubscribe();
    this.checkInOutSortingSubscription.unsubscribe();
    this.downloadSubscription.unsubscribe();
    this.store.dispatch(new ClearCheckInOutAssets());
    this.store.dispatch(new ReSetSorting());
  }

  mappDownloadData = (downloadData) => {
    let _downloadData = [...downloadData];
    return _downloadData.map(record => {
      const { projectnumber = '', emoid = '', receivingid = '', projectmanagername = '', serialid = '', tagnumber = '',
        assetdescription = '', checkoutdate = '', expectedcheckindate = '', destinationlocationdescription = '',
        destinationareadescription = '', proposalnumber = '', calloutid = '', assetcategory = '', subtype2 = '',
        peoplesoftcheckoutid = '', businessunit = '', crmnumber = '', customerreferencenumber = '', assetid = ''
        , checkoutcustodianname = '' } = record;
      let obj = {
        projectnumber, emoid, receivingid, projectmanagername, serialid, tagnumber, assetdescription, checkoutdate,
        expectedcheckindate, destinationlocationdescription, destinationareadescription, proposalnumber, calloutid,
        assetcategory, subtype2, peoplesoftcheckoutid, businessunit, crmnumber, customerreferencenumber, assetid,
        checkoutcustodianname
      };
      return obj;
    })
  }

  resetSearchMeta = () => {
    this.skip = 0;
    this.store.dispatch(new ClearCheckInOutAssets());
    this.filterObj={
      "checkInOutRecords.checkedin": false,
      "checkInOutRecords.cancelled": false
    };
  }

  fetchReadyToCheckinData = (filterObject) => {
    let filterObjectWithNormalizedDate = filterObjectDateFormat(filterObject);
    let obj = {
        "skip": this.skip,
        "limit": this.limit,
        "filter": typeof filterObject === 'object' ? {
          ...this.filterObj,
          ...checkInOutFilterMapFunction(filterObjectWithNormalizedDate)
        } : this.filterObj,
        "sort": {
          ...this.sortObj,
        },
        "checkinList": true
    }
    this.store.dispatch(new GetCheckInOutAssets(obj));
  }

  scrollFunction = (filterObject) => {
    let recordCount = this.checkInOutRecords.length || 0;
    if(
      this.skip <= recordCount
    ){
      this.skip = recordCount;
      this.fetchReadyToCheckinData(filterObject);
    }
  }

  filterFunction = (filterObject) => {
    this.skip = 0;
    this.store.dispatch(new ClearCheckInOutAssets());
    this.fetchReadyToCheckinData(filterObject);
    this.filters = filterObject;
  }

  refreshParent = (filterObject) => {
    this.limit = this.skip ? this.skip : this.limit;
    this.skip = 0;   
    this.store.dispatch(new ClearCheckInOutAssets());
    this.fetchReadyToCheckinData(filterObject);
  }

  getTableViewHeight = () => {
    let windowHeight = $(window).height();    
    let readyToCheckoutHeader = $('#readyToCheckinHeader').height();
    let appHeaderHeight = $('#appHeaderComponent').height();
    let nonTableVH = ((
      readyToCheckoutHeader + appHeaderHeight
      ) / windowHeight) * 100;
    this.tableViewHeight = 100 - nonTableVH;    
  }

  sortingFunction = ()=>{
    this.skip = 0;
    this.store.dispatch(new ClearCheckInOutAssets());
    this.fetchReadyToCheckinData({});   
  }

  downloadcsv = () => {
    let filterObject = {...this.filters};
    let filterObjectWithNormalizedDate = filterObjectDateFormat(filterObject);
    let obj = {
      "filter": typeof filterObject === 'object' ? {
        ...this.filterObj,
        ...checkInOutFilterMapFunction(filterObjectWithNormalizedDate)
      } : this.filterObj,
      "sort": {
        ...this.sortObj,
      },
      "checkinList": true
    }
    this.store.dispatch(new ClearDownloadData());
    this.store.dispatch(new GetDownloadData({ urlType: 'checkin', payload: obj }))
  }

  modalDisplayFunction = () =>{
    if(this.donwloadDataListIsLoading  || this.personalizationTableColumnLoading){
      return 'block';
    }
    if (this.checkInOutLoading  && !this.skip) {
      return 'block';
    }
    return 'none';
  }

  triggerAlertMessage = (alertObject) => {
    this.alertMessage = alertObject.message;
    this.alertState = alertObject.state
  }

  resetErrorMessages() {
    this.alertMessage = '';
    this.alertState = ''
  }
}
