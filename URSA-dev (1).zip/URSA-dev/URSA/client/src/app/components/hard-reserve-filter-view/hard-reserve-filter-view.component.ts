import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';

@Component({
  selector: 'app-hard-reserve-filter-view',
  templateUrl: './hard-reserve-filter-view.component.html',
  styleUrls: ['./hard-reserve-filter-view.component.css']
})
export class HardReserveFilterViewComponent implements OnInit {

  proposalDataSubscription;
  category;
  subtype2;
  businessUnit;
  hardReserveMode;

  constructor(
    private store: Store<AppState>
  ) { }

  ngOnInit() {
    this.proposalDataSubscription = this.store.pipe(select(state => state.ProposalPageData))
    .subscribe(proposalObj => {
      this.category = proposalObj['category'];
      this.subtype2 = proposalObj['subtype2'];
      this.businessUnit = proposalObj['businessUnit'];
      this.hardReserveMode = proposalObj['hardReserveMode']
    })
  }

  ngOnDestroy(){
    if(this.proposalDataSubscription){  this.proposalDataSubscription.unsubscribe();  }
  }

}
