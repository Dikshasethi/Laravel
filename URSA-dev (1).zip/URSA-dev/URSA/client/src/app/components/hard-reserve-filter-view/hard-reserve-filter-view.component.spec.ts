import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HardReserveFilterViewComponent } from './hard-reserve-filter-view.component';

describe('HardReserveFilterViewComponent', () => {
  let component: HardReserveFilterViewComponent;
  let fixture: ComponentFixture<HardReserveFilterViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HardReserveFilterViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HardReserveFilterViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
