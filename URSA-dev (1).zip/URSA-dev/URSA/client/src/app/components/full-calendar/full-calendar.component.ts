import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-calendar',
  templateUrl: './full-calendar.component.html',
  styleUrls: ['./full-calendar.component.css']
})
export class FullCalendarComponent implements OnInit {

  constructor() { }
  calendarHtml = '';
  private calendarTable = '';
  private monthnum = 0;
  private year = new Date().getFullYear();
  private timeSeriesData = [];
  private statesdata = [];
  private reservationData =[];
  private iteratior_year_timeseries = 9999
  private month_timeSeries = 99;
  private year_timeseries = 9999;
  private finalMonth = 99;
  private finalYear = 9999;
  private atMaxAge = false;

  ngOnInit() {
    this.monthnum = 0;
  }

  pad(d) {
      return (d < 10) ? '0' + d.toString() : d.toString();
  }

  calendar(month, year, data, statesdata,reservationData) {

    //Variables to be used later.  Place holders right now.
    var padding = "";
    var totalFeb = 0;
    var i = 1;
    var testing = "";
    this.monthnum++;
    var current = new Date();
    var cmonth = current.getMonth();
    var day = current.getDate();
    // var year = current.getFullYear();
    var tempMonth = month + 1; //+1; //Used to match up the current month with the correct start date.
    var prevMonth = month - 1;
    var dateClass = "";
    var dateStatus = "";
    var maintenanceStatus = false;



    //Determing if Feb has 28 or 29 days in it.  
    if (month == 1) {
      if ((year % 100 !== 0) && (year % 4 === 0) || (year % 400 === 0)) {
        totalFeb = 29;
      } else {
        totalFeb = 28;
      }
    }

    //////////////////////////////////////////
    // Setting up arrays for the name of    //
    // the	months, days, and the number of	//
    // days in the month.                   //
    //////////////////////////////////////////

    var monthNames = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
    var dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    var totalDays = ["31", "" + totalFeb + "", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31"];

    //////////////////////////////////////////
    // Temp values to get the number of days//
    // in current month, and previous month.//
    // Also getting the day of the week.	//
    //////////////////////////////////////////

    var tempDate = new Date(tempMonth + ' 1 ,' + year);
    var tempweekday = tempDate.getDay();
    var tempweekday2 = tempweekday;
    var dayAmount = parseInt(totalDays[month]);
    // var preAmount = totalDays[prevMonth] - tempweekday + 1;	

    //////////////////////////////////////////////////
    // After getting the first day of the week for	//
    // the month, padding the other days for that	//
    // week with the previous months days.  IE, if	//
    // the first day of the week is on a Thursday,	//
    // then this fills in Sun - Wed with the last	//
    // months dates, counting down from the last	//
    // day on Wed, until Sunday.                    //
    //////////////////////////////////////////////////

    while (tempweekday > 0) {
      padding += "<td class='premonth'></td>";
      //preAmount++;
      tempweekday--;
    }
    //////////////////////////////////////////////////
    // Filling in the calendar with the current     //
    // month days in the correct location along.    //
    //////////////////////////////////////////////////

    while (i <= dayAmount) {

      //////////////////////////////////////////
      // Determining when to start a new row	//
      //////////////////////////////////////////

      if (tempweekday2 > 6) {
        tempweekday2 = 0;
        padding += "</tr><tr>";
      }

      //////////////////////////////////////////////////////////////////////////////////////////////////
      // checking to see if i is equal to the current day, if so then we are making the color of //
      //that cell a different color using CSS. Also adding a rollover effect to highlight the  //
      //day the user rolls over. This loop creates the acutal calendar that is displayed.		//
      //////////////////////////////////////////////////////////////////////////////////////////////////
      if(reservationData && reservationData.length>0){
        for (let j = 0; j < reservationData.length; j++) {
            let key = j.toString()
            let thisDate = Date.parse(year+"-"+this.pad(month+1)+"-"+this.pad(i));
            let compStartDate = Date.parse(reservationData[key].reservationStartDate);
            let compEndDate = Date.parse(reservationData[key].reservationEndDate);
            if(thisDate >= compStartDate && thisDate <= compEndDate ){
                dateStatus = "Hard Reserved" ;
                break;
            }else{
                dateStatus = this.checkDateSatus(data,year,month,i)
            }
        }
    }else{
      dateStatus = this.checkDateSatus(data,year,month,i)
    }
      switch (dateStatus) {
        case "Hard Reserved":
          dateClass = "hardReserved"
          break;
        case "Available":
          dateClass = "available"
          break;
        case "OnHire":
          dateClass = "onhire"
          break;   
        case "Unavailable":
            dateClass = "unavailable"
            break;
        case "Checked Out":
            dateClass = "checkedout"
            break;  
        default:
          dateClass = "available"
          break;
      }
      for (var j = 0; j < statesdata.length; j++) {
        let key = j.toString()
        let thisDate = Date.parse(year+"-"+this.pad(month+1)+"-"+this.pad(i));
        let compStartDate = Date.parse(statesdata[key].startdate);
        let compEndDate = Date.parse(statesdata[key].enddate);

        if (thisDate >= compStartDate && thisDate <= compEndDate) {
          maintenanceStatus = true;
          break;
        }else
          maintenanceStatus = false;
      }
      if(maintenanceStatus){
        switch (dateClass) {
            case "available":
                dateClass = "avail-main"
                break;
            case "unavailable":
                dateClass = "unavailable-workorder"
                break;
            case "hardReserved":
                dateClass = "hardReserved-main"
                break;    
            case "onhire":
                dateClass = "hire-main"
                break;   
            case "checkedout":
                dateClass = "checkedOut-main"
                break;
            default:
                dateClass = "available"
                break;
        }
    }
      padding += "<td width='30'><div class=' " + dateClass + "'>" + i + "</div></td>";
      tempweekday2++;
      i++;
    }


    /////////////////////////////////////////
    // Ouptputing the calendar onto the	//
    // site.  Also, putting in the month	//
    // name and days of the week.		//
    /////////////////////////////////////////
    if (this.monthnum % 4 == 1) {
      this.calendarTable = "<div class='row'> <div class='col-lg-3 col-md-3 col-sm-3'><table class='calendarTable' border='0' cellspacing='0' cellpadding='2'> <tr><td colspan='7'><div class='month'>" + monthNames[month] + " " + year + "</div></td></tr>";
    } else {
      this.calendarTable = " <div class='col-lg-3 col-md-3 col-sm-3'><table class='calendarTable' border='0' cellspacing='0' cellpadding='2'> <tr><td colspan='7'><div class='month'>" + monthNames[month] + " " + year + "</div></td></tr>";
    }
    // this.calendarTable = " <div class='col-lg-3 col-md-3 col-sm-3'><table class='calendarTable' border='0' cellspacing='0' cellpadding='2'> <tr><td colspan='7'><div class='month'>" + monthNames[month] + " " + year + "</div></td></tr>";
    this.calendarTable += "<tr><td width='30'><div class='sunday'>Sun</div></td>  <td width='30'><div class='week'>Mon</div></td>" +
      "<td width='30'><div class='week'>Tue</div></td> <td width='30'><div class='week'>Wed</div></td>" +
      "<td width='30'><div class='week'>Thu</div></td> <td width='30'><div class='week'>Fri</div></td>" +
      "<td width='30'><div class='week'>Sat</div></td> </tr>";
    this.calendarTable += "<tr>";
    this.calendarTable += padding;
    // this.calendarTable += "</tr></table></div>";
    if (this.monthnum % 4 == 0) {
      this.calendarTable += "</tr></table></div></div>";
    } else {
      this.calendarTable += "</tr></table></div>";
    }
    this.calendarHtml += this.calendarTable
  }

  checkDateSatus(data,year,month,i){
    for (let j = 0; j < data.length; j++) {
        let key = j.toString()
        let thisDate = Date.parse(year+"-"+this.pad(month+1)+"-"+this.pad(i));
        let compStartDate = Date.parse(data[key].startdate);
        let compEndDate = Date.parse(data[key].enddate);
        if(thisDate >= compStartDate && thisDate <= compEndDate ){
            return data[key].status ;
        }
    }
  }


  go12(data, btn, statesdata,reservationData) {
    if(btn === 'new'){
      this.atMaxAge = false
    }
    var current = new Date();
    var cmonth = current.getMonth();
    var year = current.getFullYear();

    if (data != undefined && data.length >= 1){
      let raw_timeSeriesStartDate : Date = new Date(data[0].startdate);

      this.timeSeriesData = data;
      this.statesdata = statesdata;
      this.reservationData = reservationData
      // this.year_timeseries = raw_timeSeriesStartDate.getFullYear();
      this.year_timeseries = data[0].startdate.split('-') ? (parseInt(data[0].startdate.split('-')[0], 10)) : new Date().getFullYear();

      this.iteratior_year_timeseries = this.year_timeseries;
      // this.month_timeSeries = raw_timeSeriesStartDate.getMonth();
      
      this.month_timeSeries = data[0].startdate.split('-') ? (parseInt(data[0].startdate.split('-')[1], 10)-1) : 1;

      let raw_finalMonth = new Date(data[(data.length - 1)].startdate)
      // this.finalMonth = raw_finalMonth.getMonth();
      this.finalMonth = data[(data.length - 1)].enddate.split('-') ? (parseInt(data[(data.length - 1)].enddate.split('-')[1], 10)) : 1;
      this.finalYear = new Date(data[(data.length - 1)].enddate).getFullYear()

    }

    switch (btn) {
      case 'new':
        year = new Date().getFullYear();
        this.calendarHtml = "";
        this.calendarTable = "";
        this.monthnum = 0;
        for (let i = this.month_timeSeries; i < 12; i++) {
          this.calendar(i, this.year_timeseries, this.timeSeriesData, this.statesdata,this.reservationData);
        }
        for (let i = 0; i < this.month_timeSeries; i++) {
          this.calendar(i, this.year_timeseries + 1, this.timeSeriesData, this.statesdata,this.reservationData);
        }
        break;
      case 'previous':
        if (this.year_timeseries != this.iteratior_year_timeseries) {
          if(this.atMaxAge){
            this.atMaxAge = false
          }
          this.calendarHtml = "" ;
          this.calendarTable = "";
          this.monthnum = 0;
          this.iteratior_year_timeseries--;
          for (let i = this.month_timeSeries; i < 12; i++) {
            this.calendar(i, this.iteratior_year_timeseries, this.timeSeriesData, this.statesdata,this.reservationData);
          }
          for (let i = 0; i < this.month_timeSeries; i++) {
            this.calendar(i, this.iteratior_year_timeseries + 1, this.timeSeriesData, this.statesdata,this.reservationData);
          }
        }
        break;
      case 'next':
        // let isMaxYearAndMaxMonth = ((this.iteratior_year_timeseries == this.finalYear) && !this.atMaxAge);
        if (this.iteratior_year_timeseries != this.finalYear && !this.atMaxAge) {
            this.nextProcess()
        }

        break;

      default:
        break;
    }
  }


  nextProcess(){
    this.calendarHtml = "";
    this.calendarTable = "";
    this.monthnum = 0;
    this.iteratior_year_timeseries++;

    for (let i = this.month_timeSeries; i < 12; i++) {
      this.calendar(i, this.iteratior_year_timeseries, this.timeSeriesData, this.statesdata,this.reservationData);
    }
    if ((this.iteratior_year_timeseries + 1) < this.finalYear){

      for (let i = 0; i < this.month_timeSeries; i++) {
          this.calendar(i, this.iteratior_year_timeseries + 1, this.timeSeriesData, this.statesdata,this.reservationData);
        }

      
    }
    else if ((this.iteratior_year_timeseries + 1) == this.finalYear){
      for (let i = 0; i < this.finalMonth; i++) {
          this.calendar(i, this.iteratior_year_timeseries + 1, this.timeSeriesData, this.statesdata,this.reservationData);
          if(i == this.finalMonth-1){
            this.atMaxAge = true;
          }

        }

    }
  }

}
