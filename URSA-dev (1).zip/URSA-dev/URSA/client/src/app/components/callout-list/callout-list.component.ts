import { Component, OnInit, HostListener } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { GetCalloutList, SetCalloutList, ResetCalloutDetails } from '../../actions/callout.action';
import * as _ from 'lodash';
import localDate from '../../utils/date/localDate';
import calloutFilterMap from '../../utils/calloutDetails/calloutFilterMap';
import { SetSorting } from '../../actions/checkInOut.action';
import { Subscription } from 'rxjs/Subscription';
import { ClearDownloadData, GetDownloadData } from '../../actions/download.action';
import downlaodcsv from '../../utils/downloadCSV/downlaodcsv';

@Component({
  selector: 'app-callout-list',
  templateUrl: './callout-list.component.html',
  styleUrls: ['./callout-list.component.css']
})
export class CalloutListComponent implements OnInit {
  calloutSubscription;
  calloutList=[];
  refinedCalloutList=[];
  refinedCalloutListCopy=[];
  calloutListIsLoading=false;
  calloutListError=false;
  filters: any = {
    calloutid : '',
    projectnumber : '',
    projectstartdate : '',
    projectenddate : '',
    customername : '',
    createdby : ''
  };
  skip:number = 0;
  limit:number = 50;
  recordCount: number = 0;
    timeout = null;
  filterObj = {
  };
  sort :any = {"createdAt" : -1};
  calloutCount:number = 0;

  spinnerDisplay:boolean = false;
  sortingIcon :any={};
  checkInOutSortingSubscription:Subscription;
  downloadSubscription:Subscription;
  donwloadDataListIsLoading:boolean;

  constructor(
    private store: Store<AppState>
  ) { }

  public innerHeight: any;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;
  }

  ngOnInit() {
    this.innerHeight = window.innerHeight;
    this.fetchReadyToCheckinData();
    this.calloutSubscription = this.store.pipe(select(state => state.Callout))
    .subscribe(calloutData => {
      const {
        calloutList=[], 
        calloutListError=false, 
        calloutListIsLoading=false,
        calloutCount = 0
      } = calloutData;
      
      this.calloutList = calloutList.slice();
      if(this.calloutList)
      this.recordCount = this.calloutList.length
      this.calloutListError = calloutListError;
      this.calloutListIsLoading = calloutListIsLoading;
      this.calloutCount = calloutCount;
      this.refinedCalloutList = this.refineCalloutList(calloutList.slice());
      this.refinedCalloutListCopy = this.refinedCalloutList.slice();

      })

      this.checkInOutSortingSubscription = this.store.pipe(select(state => state.CheckInOut))
      .subscribe(data => {
        const {sort:{proposal}}=data;
          let obj={};
          for(let key in proposal){
            obj[key] = proposal[key];
          }
          this.sort = obj;
      });

      this.downloadSubscription = this.store.pipe(select(state => state.Download))
      .subscribe(data => {
        const { downloadData = [],isLoading} = data;
        this.donwloadDataListIsLoading = isLoading ;
        if(!isLoading && downloadData.length){
          let mappedData = this.mappDownloadData(downloadData);
          downlaodcsv('calloutlist', mappedData);
        }
      });
  }

  ngOnDestroy(){
    this.calloutSubscription.unsubscribe();
    this.store.dispatch(new SetCalloutList({callouts : []}));
  }


  mappDownloadData = (downloadData) => {
    let _downloadData = [...downloadData];
    return _downloadData.map(record => {
      const { calloutid = '', projectnumber = '', createdAt = '',
        customername = '', createdby = '' } = record;
      let obj = {
        calloutid, projectnumber, createdAt,
        customername, createdby
      };
      return obj;
    })
  }

  refineCalloutList = (calloutList=[]) => {
    let newArray = [];
    let sortedArray = _.orderBy(calloutList, 'createdAt', 'desc');
    for (let i = 0; i < sortedArray.length; i++){
      let callout = sortedArray[i];
      let {
        projectstartdate='', projectenddate='', createdAt=''
      } = callout;
      newArray.push({
        ...callout,
        projectstartdate : projectstartdate ? localDate(projectstartdate, 'DD-MMM-YYYY') : '',
        projectenddate : projectenddate ? localDate(projectenddate, 'DD-MMM-YYYY') : '',
        createdAt : createdAt ? localDate(createdAt, 'DD-MMM-YYYY') : '',
      });
    }

    return newArray;
  } 

  updateFilter(map: string, text) {
   
    this.filters[map] = text.target.value;
    this.executeFilter();

    clearTimeout(this.timeout);
    // Make a new timeout set to go off in 600ms 
    this.timeout = setTimeout( ()=> {
      if(map != 'createdAt' ){
        this.resetSearchMeta();
        this._executeFilter();     
      }
    }, 600);
    
  }

  resetSearchMeta = () => {
    this.skip = 0;
    this.store.dispatch(new ResetCalloutDetails());
    this.filterObj = {
    }
}

  executeFilter = () => {
    let accumulator = [];
    for(let i = 0; i < this.refinedCalloutListCopy.length; i++){
      let callout = this.refinedCalloutListCopy[i];
      let counts = 0, match = 0, filterValueCount=0;
      for (let k in this.filters){
        let value = this.filters[k]
        if(typeof value === 'string'){
          counts++;
          if(value){
            filterValueCount++;
          }
          if(
            callout[k] && 
            callout[k].toLowerCase().includes(value.toLowerCase())
          ){
            match++;
          }
        }
      }
      if(filterValueCount){
        if(match === counts){
          accumulator.push(callout);
        }
      }else{
        accumulator.push(callout);
      }
      
    }
    this.refinedCalloutList = _.orderBy(accumulator, 'createdAt', 'desc')
  }

  _executeFilter = () => {
    for (let k in this.filters){
        let value = this.filters[k];
        if(
            value || 
            ['number', 'boolean'].includes(typeof value)
        ){
            this.filterObj[calloutFilterMap[k]] = {
              $regex : `.*${value}.*`,
              $options : 'i'
          };
        }
    }
    this.fetchReadyToCheckinData();
}


fetchReadyToCheckinData() {
 if(this.skip)
  this.spinnerDisplay = true;
  let obj = {
    "skip": this.skip,
    "limit": this.limit,
    "filter":  this.filterObj,
    "sort": this.sort
  }
  this.store.dispatch(new GetCalloutList(obj));
}
  errorDisplayFunction = () => {
    if (this.calloutListError) {
      return 'block';
    } else {
      return 'none';
    }
  }

  modalDisplayFunction = () => {
    if (this.donwloadDataListIsLoading) {
      return 'block';
    }
    if (this.calloutListIsLoading && !this.spinnerDisplay) {
      return 'block';
    }
    return 'none';
  }

  onScroll(){
    if(
      this.skip <=  this.recordCount
  ){
      this.skip = this.recordCount;
      this.fetchReadyToCheckinData();
  }
  }

  setSorting=(key)=>{
    let sort = {};
    sort['componentType'] = "proposal";
    sort['dataKey'] = key;
    this.store.dispatch(new SetSorting(sort))
  }
  
  sortData = (dataKey) => {
    this.setSorting(dataKey);
    this.skip = 0;
    this.store.dispatch(new ResetCalloutDetails());
    this.fetchReadyToCheckinData();
    this.visualizeSortingIcon();
  }

  visualizeSortingIcon = () => {
    let sortData = JSON.parse(JSON.stringify(this.sort));
    let obj={}
    for(let key in sortData){
       if(sortData[key] === 1){
        obj[key] = "fa fa-arrow-up"
       }else if(sortData[key] === -1){
        obj[key] = "fa fa-arrow-down"
       }
    }
    this.sortingIcon = obj;  
  }

  downloadcsv = () => {
    let obj = {
      "filter":  this.filterObj,
      "sort": this.sort
    }
    this.store.dispatch(new ClearDownloadData());
    this.store.dispatch(new GetDownloadData({ urlType: 'calloutlist', payload: obj }))
  }

}
