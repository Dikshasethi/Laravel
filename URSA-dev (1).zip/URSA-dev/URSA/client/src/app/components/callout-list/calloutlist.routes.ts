import { Routes } from '@angular/router';
import { CalloutListComponent } from './callout-list.component';

export const CalloutlistRoutes: Routes = [
    { path: '', component: CalloutListComponent }
];