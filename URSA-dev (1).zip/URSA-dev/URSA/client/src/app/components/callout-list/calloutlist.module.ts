import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { CalloutlistRoutes } from './calloutlist.routes';
import { CalloutListComponent } from '../callout-list/callout-list.component';

@NgModule({
    declarations: [
        CalloutListComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(CalloutlistRoutes)
    ]
})

export class CalloutListModule { }