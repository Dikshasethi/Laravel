import { Routes } from '@angular/router';
import { AssetsServiceRequestComponent } from './assets-service-request.component';

export const AssetsServiceRequestRoutes: Routes = [
    { path: '', component: AssetsServiceRequestComponent },
    { path: ':servicerequestid', component: AssetsServiceRequestComponent }
];
