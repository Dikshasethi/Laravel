import { AppState } from '../../models/appState';
import  actionButtonsList  from '../../utils/serviceRequest/actionButtonsList'
import { Component, OnInit } from '@angular/core';
import { contact_detail_form_template } from '../../utils/serviceRequest/contactDetailformTemplate';
import contactPreferenceList from '../../utils/serviceRequest/contactPreferenceList';
import { DestroyAutocompleteList, GetProjectData, 
  GetCustodianAutocompleteList, SetAutoCompleteDisplayKey } from '../../actions/autocomplete.actions';
import { CreateServiceRequest, DeleteServiceRequest, EditServiceRequest, GetRequestType, GetScopeType, GetServiceCenter, 
GetServiceGroup, GetServiceRequestData, GetTreeNode, GetWorkType, ResetScopeType, 
ResetServiceCenter, ResetServiceGroup, ResetServiceRequest, ResetServiceRequestError, ResetTreeNode, ResetWorkType } from '../../actions/serviceRequest.actions';
import { Router, ActivatedRoute } from '@angular/router';
import { request_detail_form_template } from '../../utils/serviceRequest/requestDetailFormTemplate';
import { ServiceRequestModel } from '../../utils/serviceRequest/serviceRequestModel';
import { ServiceRequestAssetsModel } from '../../utils/serviceRequest/serviceRequestModel';
import { Store, select } from '@ngrx/store';
import { work_shop_form_template } from '../../utils/serviceRequest/workShopFormTemplate';
import tabMenuList from '../../utils/serviceRequest/tabMenuList';
import * as _ from 'lodash';
import { Subscription } from 'rxjs';
import {ChangeDetectorRef } from '@angular/core';
import reformatDate from '../../utils/date/reformatDate';
import localDate from '../../utils/date/localDate';
import confirmationActionButtonElements from '../../utils/serviceRequest/confirmationActionButtonElements';

@Component({
  selector: 'app-assets-service-request',
  templateUrl: './assets-service-request.component.html',
  styleUrls: ['./assets-service-request.component.css']
})
export class AssetsServiceRequestComponent implements OnInit {
  requestDetailFormTemplate: any = request_detail_form_template;
  workShopFormTemplate: any = work_shop_form_template;
  contactDetailFormTemplate: any = contact_detail_form_template;
  serviceRequestObject: ServiceRequestModel = <ServiceRequestModel>[];
  selectedAssetDetails: ServiceRequestAssetsModel[] = [];
  localDate = localDate;
    contactPreferenceList = {
      contactpreference:  contactPreferenceList
  }
  requestDetailOptionlist: any =  {
    requesttype: [],
    worktype : [],
    servicegroup : [],
    scopetype:  [],
    servicecenter: []
  }
  requestTypeDataLoading: boolean = false;
  scopeTypeDataLoading: boolean = false;
  workTypeDataLoading: boolean = false;
  serviceGroupDataLoading: boolean = false;
  treeNodeDataLoading: boolean = false;
  serviceCenterDataLoading: boolean = false;
  serviceRequestId: string;
  isAddMode: boolean;
  alertState: string;
  alertMessage: string = '';
  suggestionList=[];
  displayKey: string;
  autocompleteSkip: number = 0;
  autocompleteLimit: number = 10;
  autocompleteRecordCount: number = 10;
  autocompleteText: string = '';
  autocompleteField: string = '';
  autocompleteScrolledActive: boolean = false;
  projectAutocompleteSubscription: Subscription;
  userDetailSubscription: Subscription;
  serviceRequestSubscription: Subscription;
  checkinCheckoutSubscription: Subscription;
  autocompleteCheckoutSubscription: Subscription;
  serviceCenterRequestIdentifier: boolean = false;
  selectTypeIdentifier: boolean = false;
  treeNodeData:any = [];
  tabMenuBuilder = tabMenuList.slice();
  tableInFocus: string = 'notes';
  serviceRequestDataLoading: boolean = false;
  defaultCustodian: string;
  empId: string;
  userPermissions = [];
  readytocheckoutLoading: boolean = false;
  checkInOutLoading: boolean = false;
  addServiceRequestLoading: boolean = false;
  readyToCheckoutError: boolean = false;
  checkInOutError: boolean = false;
  deleteServiceRequestLoading: boolean = false;
  actionButtonElements = actionButtonsList;
  serviceRequestNotes: string = ''
  originmodule: string = ''
  projectNumber: string = ''
  showConfirmationModal: boolean = false;
  confirmModalClass: string = '';
  confirmationActionButtonElements = confirmationActionButtonElements;
  confirmationModalMessage: string = '';
  constructor(
    private store: Store<AppState>, 
    private route:ActivatedRoute, 
    private router:Router,
    private cdref: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.fetchRequestType();
    this.serviceRequestId = this.route.snapshot.paramMap.get('servicerequestid');
    this.isAddMode = !this.serviceRequestId;
    if(!this.isAddMode) {
      this.fetchServiceRequest()
    }
    this.serviceRequestSubscription = this.store.pipe(select(state => state.ServiceRequest))
    .subscribe(serviceRequestObject => {
      const {
        serviceRequestData: {serviceRequestData= [], serviceRequestDataLoading= false},
        requestType: { requestTypeData = [],requestTypeDataLoading=false },
        scopeType: { scopeTypeData= [], scopeTypeDataLoading=false},
        workType: {workTypeData= [], workTypeDataLoading=false},
        serviceGroup: {serviceGroupData=[], serviceGroupDataLoading=false},
        treeNode: {treeNodeData=[], treeNodeDataLoading=false},
        serviceCenter: {serviceCenterData=[], serviceCenterDataLoading=false},
        createdServiceRequestData: {addServiceRequestData=[], addServiceRequestLoading=false},
        deletedServiceRequestData: {deleteServiceRequestData={}, deleteServiceRequestLoading=false },
        errorState: { errorLoading = false, error = {} }
      } = serviceRequestObject;
      this.serviceRequestObject = serviceRequestData;
      this.selectedAssetDetails = this.serviceRequestObject.assets || [];
      if(!this.isAddMode && !_.isEmpty(this.serviceRequestObject)){
        this.fetchSelectBoxDetails();
      }
      if(this.serviceRequestObject['notes']){
        this.serviceRequestNotes = this.serviceRequestObject.notes
      }
      if(this.serviceRequestObject['originmodule']){
        this.originmodule = this.serviceRequestObject.originmodule;
      }
      if(this.serviceRequestObject['projectnumber']){
        this.projectNumber = this.serviceRequestObject.projectnumber
      }
      this.serviceRequestDataLoading = serviceRequestDataLoading;
      this.requestDetailOptionlist.requesttype = requestTypeData; 
      this.requestDetailOptionlist.scopetype = scopeTypeData; 
      this.requestDetailOptionlist.worktype = workTypeData;
      this.requestDetailOptionlist.servicegroup = serviceGroupData;
      this.requestDetailOptionlist.servicecenter = serviceCenterData;
      this.treeNodeData = treeNodeData;
      if(this.treeNodeData.length > 0 && 
        !this.serviceCenterRequestIdentifier && 
        this.requestDetailOptionlist.servicecenter.length === 0) {
        this.serviceCenterRequestIdentifier = true;
        let Objvalue = this.treeNodeData[0]
        this.fetchServiceCenter({treenode:  Objvalue.Value});
      }
      this.requestTypeDataLoading = requestTypeDataLoading;
      this.scopeTypeDataLoading = scopeTypeDataLoading;
      this.workTypeDataLoading = workTypeDataLoading;
      this.serviceGroupDataLoading = serviceGroupDataLoading;
      this.treeNodeDataLoading = treeNodeDataLoading;
      this.serviceCenterDataLoading = serviceCenterDataLoading;
      this.addServiceRequestLoading = addServiceRequestLoading;
      this.deleteServiceRequestLoading = deleteServiceRequestLoading;
      if (error['message']) {
        this.alertState = 'error'
        this.alertMessage = error.message
        this.store.dispatch(new ResetServiceRequestError());
      }

      if(this.isAddMode && !_.isEmpty(addServiceRequestData) 
        && addServiceRequestData['_id']) {
        this.router.navigate([`./servicerequest/${addServiceRequestData['_id']}`]);
      }

      if(!this.isAddMode && !_.isEmpty(addServiceRequestData)) {
        this.fetchServiceRequest();
      }

      if(!this.isAddMode && !_.isEmpty(deleteServiceRequestData)) {
        this.router.navigate([`./servicerequestlist`]);
      }
    })

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(userDetailObj => {
      const {
        details
      } = userDetailObj;
      this.defaultCustodian = `${details['first_name']} ${details['last_name']}`;
      this.empId = details['employee_id'];
      this.userPermissions = details['permission'] || [];
    })

    this.checkinCheckoutSubscription = this.store.pipe(select(state => state.CheckOutPageData))
    .subscribe(data => {
      const {
        readyToCheckOutData={},checkInOutData={}
      } = data;
      if(this.serviceRequestObject['originmodule']){
        if(this.serviceRequestObject['originmodule'] === 'hard_reserve_table'){
          this.checkInOutLoading = readyToCheckOutData['readyToCheckoutDataLoading'];
        }else{
          this.checkInOutLoading = checkInOutData['checkInOutIsLoading'];
        }
      }
      this.readyToCheckoutError = readyToCheckOutData['readyToCheckoutDataError'];
      this.checkInOutError = checkInOutData['checkInOutError'];
      if(this.readyToCheckoutError || this.checkInOutError){
        this.alertState = 'error'
        this.alertMessage = ' An error occured. Transaction was not successful.'
      }
    });

    this.projectAutocompleteSubscription = this.store.pipe(select(state => state.Autocomplete.projectAutocomplete))
    .subscribe(autocompleteObject => {
      const {
        suggestionList
      } = autocompleteObject;
      if (suggestionList) {
        this.autocompleteRecordCount = suggestionList.length;
        this.suggestionList = suggestionList;
      }
    });

    this.autocompleteCheckoutSubscription = this.store.pipe(select(state => state.Autocomplete.checkoutAutocomplete))
      .subscribe(autocompleteObject => {
        const {
          suggestionList,isFetchingAutocompleteList, field
        } = autocompleteObject;
        if(suggestionList && field=="custodian") {
          this.autocompleteRecordCount = suggestionList.length;
          this.suggestionList = suggestionList;
        }
      });
  }

  ngAfterContentChecked() {
    this.cdref.detectChanges();
  }

  ngOnDestroy() {
    this.store.dispatch(new ResetServiceRequest);
    this.projectAutocompleteSubscription.unsubscribe();
    this.userDetailSubscription.unsubscribe();
    this.serviceRequestSubscription.unsubscribe();
    this.autocompleteCheckoutSubscription.unsubscribe();
    this.checkinCheckoutSubscription.unsubscribe();
  }

  private fetchServiceRequest = () => {
    let obj = {
      serviceRequestId:  this.serviceRequestId
    }
    this.store.dispatch(new GetServiceRequestData(obj));
  }

  private fetchSelectBoxDetails = () => {
    if(this.serviceRequestObject.requesttype && !this.selectTypeIdentifier){
      this.fetchScopeType({requesttype: this.serviceRequestObject.requesttype});
    }
    if(this.serviceRequestObject.scopetype && !this.selectTypeIdentifier) {
      this.fetchWorkType({
        requesttype:  this.serviceRequestObject.requesttype || '', 
        scopetype: this.serviceRequestObject.scopetype
      })
    }
    if(this.serviceRequestObject.worktype && !this.selectTypeIdentifier) {
      this.fetchServiceGroup({
        requesttype:  this.serviceRequestObject.requesttype || '',
        scopetype: this.serviceRequestObject.scopetype || '',
        worktype: this.serviceRequestObject.worktype
      })
    }
    if(this.serviceRequestObject.servicegroup && !this.selectTypeIdentifier) {
      this.serviceCenterRequestIdentifier = false;
      this.fetchTreeNode({
        requesttype:  this.serviceRequestObject.requesttype || '',
        scopetype: this.serviceRequestObject.scopetype || '',
        worktype: this.serviceRequestObject.worktype || '',
        servicegroup: this.serviceRequestObject.servicegroup
      })
    }
    this.selectTypeIdentifier = true;
  }

  private fetchRequestType = () => {
    this.store.dispatch(new GetRequestType());
  }

  private fetchScopeType = (obj) => {
    this.store.dispatch(new GetScopeType(obj));
  }

  private fetchWorkType = (obj) => {
    this.store.dispatch(new GetWorkType(obj));
  }

  private fetchServiceGroup = (obj) => {
    this.store.dispatch(new GetServiceGroup(obj));
  }

  private fetchServiceCenter = (obj) => {
    this.store.dispatch(new GetServiceCenter(obj));
  }

  private fetchTreeNode = (obj) => {
    this.store.dispatch(new GetTreeNode(obj));
  }

  fetchRequestDeatilsData = (selectedvalue: string, requestDetailFormObj) => {
    this.resetRequestDetailsOnSelection(requestDetailFormObj);
    if(requestDetailFormObj.dataKey === 'requesttype') {
      this.store.dispatch(new ResetScopeType);
      this.store.dispatch(new ResetWorkType);
      this.store.dispatch(new ResetServiceGroup);
      this.store.dispatch(new ResetTreeNode);
      this.store.dispatch(new ResetServiceCenter);
      this.fetchScopeType({requesttype: selectedvalue});
    }else if(requestDetailFormObj.dataKey === 'scopetype') {
      this.store.dispatch(new ResetWorkType);
      this.store.dispatch(new ResetServiceGroup);
      this.store.dispatch(new ResetTreeNode);
      this.store.dispatch(new ResetServiceCenter);
      this.fetchWorkType({
        requesttype:  this.serviceRequestObject['requesttype'] || '', 
        scopetype: selectedvalue
      })
    }else if(requestDetailFormObj.dataKey === 'worktype') {
      this.store.dispatch(new ResetServiceGroup);
      this.store.dispatch(new ResetTreeNode);
      this.store.dispatch(new ResetServiceCenter);
      this.fetchServiceGroup({
        requesttype:  this.serviceRequestObject['requesttype'] || '',
        scopetype: this.serviceRequestObject['scopetype'] || '',
        worktype: selectedvalue
      })
    }else if(requestDetailFormObj.dataKey === 'servicegroup') {
      this.store.dispatch(new ResetTreeNode);
      this.store.dispatch(new ResetServiceCenter);
      this.serviceCenterRequestIdentifier = false;
      this.fetchTreeNode({
        requesttype:  this.serviceRequestObject['requesttype'] || '',
        scopetype: this.serviceRequestObject['scopetype'] || '',
        worktype: this.serviceRequestObject['worktype'] || '',
        servicegroup: selectedvalue
      })
    }
  }
  
  private resetRequestDetailsOnSelection = (requestDetailFormObj) => {
    if(requestDetailFormObj.resetSelectedField) {
      for(let values of requestDetailFormObj.resetSelectedField) {
        this.serviceRequestObject[values] = '';
        this.requestDetailOptionlist[values] = [];
      }
    }
  }

  triggerAlertMessage = (alertObject) => {
    this.alertMessage = alertObject.message;
    this.alertState = alertObject.state
  }

  resetErrorMessages() {
    this.alertMessage = '';
    this.alertState = ''
  }

  modalDisplayFunction() {
    if(this.requestTypeDataLoading || this.scopeTypeDataLoading 
      || this.workTypeDataLoading || this.serviceGroupDataLoading || this.treeNodeDataLoading || 
      this.serviceCenterDataLoading || this.serviceRequestDataLoading 
      || this.checkInOutLoading || this.addServiceRequestLoading || this.deleteServiceRequestLoading) {
      return 'block';
    } else {
      return 'none';
    }
  }

  handleAutocompleteInputChange(text, field) {
    this.setAutocompleteDisplayKey('');
    this.suggestionList = [];
    this.resetAutocompletePagination();
    if (text.length > 1 &&  !this.serviceRequestObject[field]) {
      this.autocompletePayload(text, field)
    }else {
        this.resetServiceRequestData(field)
        this.destroyAutoCompleteList()
    }
  }

  private autocompletePayload (text, field) {
    this.autocompleteText = text;
    this.autocompleteField = field;
    if (field === 'projectnumber') {
      this.displayKey = 'PROJECTID';
      let obj = {
          "skip": this.autocompleteSkip,
          "limit": this.autocompleteLimit,
          "filter": {}
      }
      obj.filter['PROJECTID'] = text
      this.destroyAutoCompleteList();
      this.setAutocompleteDisplayKey(field);
      obj.filter["PROJECTSTATUS"] = "A";
      this.store.dispatch(new GetProjectData(obj));
    }else if(field === 'requestedbyname' || field === 'requestedforname') {
      this.displayKey = 'empName';
      this.destroyAutoCompleteList();
      this.setAutocompleteDisplayKey(field);
      let obj={
       "index":"employeesearch",
       "search_keyword":text,
       "field":"custodian"
      }
      this.store.dispatch(new GetCustodianAutocompleteList(obj));
    }
  } 

  private destroyAutoCompleteList() {
       if(!this.autocompleteScrolledActive) {
         this.store.dispatch(new DestroyAutocompleteList());
       }
  }

  private setAutocompleteDisplayKey = (keyValue: string) => {
     this.store.dispatch(new SetAutoCompleteDisplayKey({identifierKey: keyValue}));
  }

  dispatchInitialRequest = (text, field: string) =>  {
      this.setAutocompleteDisplayKey(field);
      this.suggestionList = [];
      this.resetAutocompletePagination();
      if (!this.serviceRequestObject[field]) {
          this.autocompletePayload(text, field)
        }
  }

  private resetAutocompletePagination () {
      this.autocompleteSkip = 0;
      this.autocompleteScrolledActive = false;
      this.autocompleteRecordCount = 10;
  }

  private resetServiceRequestData(field) {
      this.resetAutocompletePagination();
      if(field === 'projectnumber'){
        this.projectNumber = '';
        this.serviceRequestObject['projectnumber'] = '';
        this.serviceRequestObject['projectmanagername'] = '';
        this.serviceRequestObject['customername'] = '';
        this.serviceRequestObject['customerid'] = '';
      }else if(field === 'requestedbyname') {
        this.serviceRequestObject['requestedbyname'] = '';
        this.serviceRequestObject['requestedbyid'] = '';
      }else if(field === 'requestedforname') {
        this.serviceRequestObject['requestedforname'] = '';
        this.serviceRequestObject['requestedforid'] = '';
      }
  }

  onScrollLoad = () => {
      this.autocompleteScrolledActive = true;
      this.autocompleteSkip = this.autocompleteSkip + 10;
      if(this.autocompleteRecordCount % 10 === 0) {
        this.autocompletePayload(this.autocompleteText, this.autocompleteField)
      }
  }

  serviceRequestSelected(suggestion, field) {
    if(field === 'projectnumber'){
      this.projectNumber = suggestion.PROJECTID
      this.serviceRequestObject['projectnumber'] = suggestion.PROJECTID;
      this.serviceRequestObject['projectmanagername'] = suggestion.PROJECTMANAGERNAME;
      this.serviceRequestObject['customername'] = suggestion.CUSTOMERNAME;
      this.serviceRequestObject['customerid'] = suggestion.CUSTOMERID;
    }else if(field === 'requestedbyname'){
      this.serviceRequestObject['requestedbyid'] = suggestion.empId;
      this.serviceRequestObject['requestedbyname'] = suggestion.empName;
    }else if(field === 'requestedforname') {
      this.serviceRequestObject['requestedforid'] = suggestion.empId;
      this.serviceRequestObject['requestedforname'] = suggestion.empName;
    }
  }

  setTableInFocus = (tab) => {
    this.tableInFocus = tab['tableInFocus'];
  }

  permissionDisplayCheck = (buttonObject) => {
    const {
      permissionBasedDisplay=false, permission='',type='', 
    } = buttonObject;

    switch(true) {
      case  this.isAddMode && type === 'create':
        return true;
      case  !this.isAddMode && type === 'save':  
        return true;
      case  !this.isAddMode && type === 'delete':
        return true;
      case  !this.isAddMode && type === 'submit':
        return true;
      default:
        return false;
    }
  }

  checkDisable(buttonType: string) {
    if(buttonType === 'create'){
     return this.checkEnableButton();
    }else if(buttonType === 'save') {
     return this.checkEnableButton();
    }else if(buttonType === 'delete') {
      // to be implemented
     }
    return false;
  }

  checkEnableButton = () => {
    if(this.verifyButtonAccess(this.requestDetailFormTemplate) ||
    this.verifyButtonAccess(this.workShopFormTemplate) 
    || this.verifyButtonAccess(this.contactDetailFormTemplate) || _.isEmpty(this.serviceRequestObject['assets'])){
      return true;
    }
    return false;
  }

  verifyButtonAccess(formTemplateType) {
    for(let value of formTemplateType) {
      if(!value.hasOwnProperty('required') || (value.required && 
        this.serviceRequestObject.hasOwnProperty(value.dataKey) &&
        this.serviceRequestObject[value.dataKey] !== '')) {
          continue;
      }else{
        return true
      }
    }
    return false;
  }

  triggerSubmit = (btnType) => {
    if(btnType === 'create'){
      this.createServiceRequest();
    }else if(btnType === 'save') {
      this.saveServiceRequest();
    }else if(btnType === 'delete') {
      this.confirmationModal();
    }else if(btnType === 'cancel') {
      this.cancelServiceRequest();
    }else if(btnType === 'submit') {
      this.submitServiceRequest();
    }
  }

  private mappeddata() {
    return this.serviceRequestObject;
  }

  private createServiceRequest() {
   let payload = this.mappeddata()
   this.store.dispatch(new CreateServiceRequest(payload));
  }

  private saveServiceRequest() {
    let payload = this.mappeddata()
    this.store.dispatch(new EditServiceRequest(payload));
  }

  private deleteServiceRequest() {
    let payload = {
      idList: [this.serviceRequestId]
    }
    this.store.dispatch(new DeleteServiceRequest(payload));
  }

  private cancelServiceRequest() {
    // to be done
  }

  private submitServiceRequest() {
    // to be done
  }

  setServiceRequestNotes = (text) => {
  this.serviceRequestNotes = text;
  this.serviceRequestObject['notes'] = text;
  }

  private confirmationModal(modeltype='') {
    this.showConfirmationModal = true;
    this.confirmationModalMessage = 'Please confirm if you want to delete this service request'
    this.confirmModalClass = 'sr-modal'
  }

  resetConfirmationModal() {
    this.showConfirmationModal = false;
    this.confirmationModalMessage = ''
    this.confirmModalClass = ''
  }

  confirmationButtonAction = (buttontype) => {
   if(buttontype === 'cancelconfirmationmodal') {
     this.resetConfirmationModal();
   }else if(buttontype === 'confirmconfirmationmodal') {
     this.deleteServiceRequest();
     this.resetConfirmationModal();
   }
  }
}