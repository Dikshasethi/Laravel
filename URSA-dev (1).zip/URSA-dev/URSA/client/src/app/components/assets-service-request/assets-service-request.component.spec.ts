import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetsServiceRequestComponent } from './assets-service-request.component';

describe('AssetsServiceRequestComponent', () => {
  let component: AssetsServiceRequestComponent;
  let fixture: ComponentFixture<AssetsServiceRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetsServiceRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetsServiceRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
