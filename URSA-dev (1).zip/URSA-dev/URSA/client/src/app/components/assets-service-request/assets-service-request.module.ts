import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { AssetsServiceRequestRoutes } from './assets-service-request-routes';
import { AssetsServiceRequestComponent  } from './assets-service-request.component';
import { ServiceRequestSelectedAssetsComponent } from '../service-request-selected-assets/service-request-selected-assets.component';
import { ServiceRequestNotesComponent } from '../service-request-notes/service-request-notes.component';
import { TablePopUpModalComponent } from '../table-pop-up-modal/table-pop-up-modal.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(AssetsServiceRequestRoutes)
  ],
  declarations: [
    AssetsServiceRequestComponent,
    ServiceRequestSelectedAssetsComponent,
    ServiceRequestNotesComponent,
    TablePopUpModalComponent
  ],
  exports: [
      RouterModule
  ]
})
export class AssetsServiceRequestModule { }
