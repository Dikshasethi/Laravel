import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HardReserveDetailsPanelComponent } from './hard-reserve-details-panel.component';

describe('HardReserveDetailsPanelComponent', () => {
  let component: HardReserveDetailsPanelComponent;
  let fixture: ComponentFixture<HardReserveDetailsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HardReserveDetailsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HardReserveDetailsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
