import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import dateValidation from '../../utils/date/dateValidator';

@Component({
  selector: 'app-hard-reserve-details-panel',
  templateUrl: './hard-reserve-details-panel.component.html',
  styleUrls: ['./hard-reserve-details-panel.component.css']
})
export class HardReserveDetailsPanelComponent implements OnInit {

  constructor() { }
  dateRange={
    hardReserveStartDate:'',
    hardReserveEndDate:'',
    startDateFlag : false,
    endDateFlag : false,
  }
  

  @Output() dateChanged = new EventEmitter<any>();
  @Input()
  set dateValues( val ) {
    this.dateRange.hardReserveStartDate = val.startDate;
    this.dateRange.hardReserveEndDate = val.endDate
  }
  ngOnInit() {
  }

  onDateChange(event,field){
    if(field=='start'){
      this.dateRange.startDateFlag = false;
      this.dateRange.hardReserveStartDate=event;
      if(!dateValidation(event)){
        this.dateRange.startDateFlag = true;
      }
      else{
        this.dateRange.hardReserveEndDate="";
      }
     
    }
    else if(field=='end'){
        this.dateRange.endDateFlag = false;
        this.dateRange.hardReserveEndDate=event;
      if(!dateValidation(event)){
        this.dateRange.endDateFlag = true;   
      }
    }  

    this.dateChanged.next(this.dateRange)
  }

}
