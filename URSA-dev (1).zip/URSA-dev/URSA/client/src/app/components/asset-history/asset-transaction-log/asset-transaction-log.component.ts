import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'lodash';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../models/appState';
import { GetProductCalendar } from '../../../actions/product.actions';
import { CalendarComponentComponent } from '../../calendar-component/calendar-component.component';
import { SetAssetIdBusinessUnit } from '../../../actions/assetLogs.actions';


@Component({
  selector: 'app-asset-transaction-log',
  templateUrl: './asset-transaction-log.component.html',
  styleUrls: ['./asset-transaction-log.component.css']
})
export class AssetTransactionLogComponent implements OnInit {

  @Input() index;
  @ViewChild(CalendarComponentComponent) calendarComponentComponent: CalendarComponentComponent;

  activeRoute: string = '';
  productSubscription;
  assetHistoryDetails;
  assetId;
  businessunit;
  _calendarMap

  constructor(
    private store: Store<AppState>,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.activeRoute = this.route.snapshot.queryParamMap.get('view') || '';
    this.assetId = this.route.snapshot.paramMap.get('assetid');
    this.businessunit = this.route.snapshot.paramMap.get('businessunit');

    let obj = {
      assetid: this.assetId,
      businessunit: this.businessunit
    }
    this.store.dispatch(new SetAssetIdBusinessUnit(obj))

    let getCalObj = {
      bu: this.businessunit,
      assetid: this.assetId,
      _index: this.index
    }
    this.store.dispatch(new GetProductCalendar(getCalObj))

    this.productSubscription = this.store.pipe(select(state => state.Product))
      .subscribe(productData => {
        const { calendarMap, calendarDataIsLoading } = productData;

        if (!calendarDataIsLoading) {
          this._calendarMap = calendarMap;
          this.calendarDataWaitListHandshake();

        }

      })
  }

  calendarDataWaitListHandshake() {
    if (this._calendarMap[this.index]) {
      this.calendarComponentComponent.go12(this._calendarMap[this.index].timeseries || [], this._calendarMap[this.index].stateData || [], this._calendarMap[this.index].reservationData || [])
    }
  }
}
