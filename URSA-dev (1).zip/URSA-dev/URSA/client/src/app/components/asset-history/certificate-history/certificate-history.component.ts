import { Component, Input, OnInit } from '@angular/core';
import * as _ from 'lodash';
import localDate from '../../../utils/date/localDate';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../models/appState';
import { ReSetSorting, SetSorting } from '../../../actions/checkInOut.action';

@Component({
    selector: 'app-certificate-history',
    templateUrl: './certificate-history.component.html',
    styleUrls: ['./certificate-history.component.css']
})
export class CertificateHistoryComponent implements OnInit {
    @Input() certificateDetails;

    refinedCertificateDetails = []
    filters: any = {
        agencyid: '',
        oiamcertid: '',
        licstartdt: '',
        licenddt: '',
        renewaldt: ''
    }
    checkInOutSortingSubscription: any;
    sort: any = {};
    sortingIcon: any = {};

    constructor(private store: Store<AppState>) { }

    ngOnInit() {

        if (!_.isEmpty(this.certificateDetails)) {

            this.certificateDetails = this.refineCertificateList(this.certificateDetails.slice());
            this.refinedCertificateDetails = this.certificateDetails.slice();

        }
        this.checkInOutSortingSubscription = this.store.pipe(select(state => state.CheckInOut))
            .subscribe(data => {
                const { sort: { certificatehistory } } = data;
                let obj = {};
                for (let key in certificatehistory) {
                    obj[key] = certificatehistory[key] === 1 ? "asc" : "desc";
                }
                this.sort = obj;
            });
    }

    ngOnDestroy() {
        this.checkInOutSortingSubscription.unsubscribe();
        this.store.dispatch(new ReSetSorting());
    }

    refineCertificateList = (certificateList = []) => {
        let newArray = [];
        let sortedArray = _.orderBy(certificateList, 'licstartdt', 'desc');
        for (let i = 0; i < sortedArray.length; i++) {
            let workorder = sortedArray[i];
            let {
                licstartdt = '', licenddt = '', renewaldt = ''
            } = workorder;
            newArray.push({
                ...workorder,
                licstartdt: licstartdt ? localDate(licstartdt, 'DD-MMM-YYYY') : '',
                licenddt: licenddt ? localDate(licenddt, 'DD-MMM-YYYY') : '',
                renewaldt: renewaldt ? localDate(renewaldt, 'DD-MMM-YYYY') : '',
            });
        }

        return newArray;
    }

    localDateWrapper = (date) => {
        return date ? localDate(date, 'DD-MMM-YYYY') : '';
    }

    updateFilter(map: string, text) {
        this.refinedCertificateDetails = this.certificateDetails;
        this.filters[map] = text.target.value;
        this.executeFilter();
    }

    executeFilter = () => {
        let accumulator = [];
        for (let i = 0; i < this.refinedCertificateDetails.length; i++) {
            let certificate = this.refinedCertificateDetails[i];
            let counts = 0, match = 0, filterValueCount = 0;
            for (let k in this.filters) {
                let value = this.filters[k]
                if (typeof value === 'string') {
                    counts++;
                    if (value) {
                        filterValueCount++;
                    }
                    if (
                        certificate[k] &&
                        certificate[k].toLowerCase().includes(value.toLowerCase())
                    ) {
                        match++;
                    }
                }
            }
            if (filterValueCount) {
                if (match === counts) {
                    accumulator.push(certificate);
                }
            } else {
                accumulator.push(certificate);
            }

        }
        this.refinedCertificateDetails = _.orderBy(accumulator, 'startdate', 'desc')
    }

    setSorting = (key) => {
        let sort = {};
        sort['componentType'] = "certificatehistory";
        sort['dataKey'] = key;
        this.store.dispatch(new SetSorting(sort))
    }

    sortData = (dataKey) => {
        this.setSorting(dataKey);
        this.sortExistingData();
        this.visualizeSortingIcon();
    }

    sortExistingData = () => {
        let keys: any[] = Object.keys(this.sort);
        let values: any[] = Object.values(this.sort);
        this.refinedCertificateDetails = _.orderBy(this.refinedCertificateDetails, keys, values);
    }

    visualizeSortingIcon = () => {
        let sortData = JSON.parse(JSON.stringify(this.sort));
        let obj = {}
        for (let key in sortData) {
            if (sortData[key] === "asc") {
                obj[key] = "fa fa-arrow-up"
            } else if (sortData[key] === "desc") {
                obj[key] = "fa fa-arrow-down"
            }
        }
        this.sortingIcon = obj;
    }

}