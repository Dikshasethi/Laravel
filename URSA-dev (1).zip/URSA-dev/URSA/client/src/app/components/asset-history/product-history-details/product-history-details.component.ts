import { Component, EventEmitter, Input, OnInit, Output, SimpleChange } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../models/appState';
import * as _ from 'lodash';
import { AddToCart, DeleteFromCart, GetCartData } from '../../../actions/cart.action';
import { environment } from '../../../../environments/environment';
import { GetWatchListData, AddToWatchList, EditInWatchList } from '../../../actions/watchlist.action';

const applicatonObj = {
  "appid": environment.appID,
  "appname": environment.appName,
}

@Component({
  selector: 'app-product-history-details',
  templateUrl: './product-history-details.component.html',
  styleUrls: ['./product-history-details.component.css']
})
export class ProductHistoryDetailsComponent implements OnInit {


  @Input() assetDetails;
  cartData = [];
  productCartHierarchy = [];
  cartDescription;
  cartModalDisplay = 'none';
  cartTitle: string = "";
  cartFetchIsLoading = false;
  cartSubscription;
  watchListSubscription;
  userDetailSubscription;
  empId;
  selectedAsset;
  haltModal;
  show_errorMessage: boolean = false;
  error_message: string;
  addedCartFetchLoading: boolean = false;
  deletedCartFetchLoading: boolean = false;
  certExpirationMessage: string = "";
  WatchListLoading: boolean = false;
  addedWatchListLoading: boolean = false;
  watchListData = [];
  watchListModalDisplay: boolean = false;
  watchListHeader = '';
  filteredWatchListData = [];
  selectedWatchListActions = [];
  selectedWatchListAsset: any;
  watchListModalProperties: any = {
    watchlistHeader: '',
    watchListModalDisplay: false,
    watchListModalData: {
        assetid: '',
        businessunit: ''
    },
    selectedWatchListActions: []
};

  constructor(private store: Store<AppState>) { }

  ngOnInit() {
    this.cartSubscription = this.store.pipe(select(state => state.Cart))
      .subscribe(cartObj => {
        const {
          addedCartData: { addedCartData, addedCartFetchLoading },
          deletedCartData: { deletedCartData, deletedCartFetchLoading },
          cartData: { cartData, cartFetchIsLoading },
          errorState: { error = false, error_message }
        } = cartObj
        this.cartFetchIsLoading = cartFetchIsLoading;
        this.addedCartFetchLoading = addedCartFetchLoading;
        this.deletedCartFetchLoading = deletedCartFetchLoading;
        if (cartData.length) {
          this.cartData = cartData;
        }

        if (!_.isEmpty(addedCartData) && !addedCartFetchLoading && !cartFetchIsLoading && !addedCartData['hasError']) {
          this.fetchCartData();
        }

        if (!_.isEmpty(deletedCartData) && !deletedCartFetchLoading && !cartFetchIsLoading && !deletedCartData['hasError']) {
          this.fetchCartData();
        }

        if (error) {
          this.showErrorMessage(error_message);
        }
      })

      this.watchListSubscription = this.store.pipe(select(state => state.WatchList))
      .subscribe(WchListData => {
          const {
            watchListData: { watchListLoading, watchListData },
            addedWatchListData: { addedWatchlistData, addedWatchListLoading },
            errorState: { error = false, error_message }
          } = WchListData
        
         this.WatchListLoading = watchListLoading;
         this.addedWatchListLoading = addedWatchListLoading;
         if(watchListData.length) {
          this.watchListData = watchListData; 
        }
  
        if (!_.isEmpty(addedWatchlistData) && !addedWatchListLoading) {
          this.fetchWatchListForLoggedInUser();
        }
         if (error) {
          this.showErrorMessage(error_message);
        }
      })

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
      .subscribe(userDetailObj => {
        const {
          details
        } = userDetailObj;
        this.empId = details['employee_id'];
      })
  }

  ngOnDestroy() {
    this.userDetailSubscription.unsubscribe();
    this.watchListSubscription.unsubscribe();
    this.cartSubscription.unsubscribe();
  }

  fetchCartData() {
    if (this.empId) {
      let obj = {
        "userId": this.empId,
        "appId": applicatonObj.appid,
        "limit": 0,
        "skip": 0
      }
      this.store.dispatch(new GetCartData(obj));
    }
  }

  fetchWatchListForLoggedInUser() {
    this.store.dispatch(new GetWatchListData({
      "limit" : 0,
      "filter": {
        "userid": this.empId
      },
      "skip" : 0,
      "sort": {}
    }));
  }

  showErrorMessage(errorMsg) {
    this.error_message = errorMsg && errorMsg.error && errorMsg.error.message ? errorMsg.error.message : 'Something went wrong';
    alert(this.error_message);
  }

  statusClassFunction = (product) => {
    return `badge-${this.badgeClassParser(product.statustext, product.pastduecheckout)}`
  }

  badgeClassParser = (status, pastDue) => {
    if (status) {
      let statusText;
      let statusList = status.split(' ');
      if (statusList && statusList.length > 0) {
        statusText = statusList[0];
      } else {
        statusText = status
      }
      if (pastDue) {
        statusText = 'past';
      }
      let statusMap = {
        Available: 'available',
        Checked: 'Checked',
        Reserverd: 'warning',
        Status: 'secondary',
        Hard: 'hardReserved',
        checked: 'danger',
        Disposed: 'danger',
        past: 'danger',
        "On-Hire": 'On-Hire'
      }
      return statusMap[statusText];
    }
    return 'secondary'
  }

  checkAssetDisposed = () => {
    let status = 'Disposed';
    return `badge-${this.badgeClassParser(status, '')}`;
  }

  openCartModal(event: any) {
    if (event['isdisposed'] != '1') {
      this.cartModalDisplay = 'block';
      this.selectedAsset = event;
      this.certExpirationMessage = !event['activeCertificate'] ? 'This assets certification is expired' : '';
      this.cartDescription = event['isAddedToCart'] ? "By removing the selected asset from your cart, you will also be removing any of its child assets from your cart, if they exist." :
        "By adding the selected asset to your cart you will also be adding any of its child assets to your cart, if they exist.";
      this.cartTitle = event['isAddedToCart'] ? "Remove from Cart" : "Add to Cart";
    }
  }

  confirmButton() {
    this.cartModalDisplay = 'none';
    if (!this.selectedAsset.isAddedToCart) {
      this.onItemAddedToCart(this.selectedAsset);
    } else {
      this.itemRemovedFromCart(this.selectedAsset);
    }
  }

  onItemAddedToCart(asset) {
    let cartItems = [{
      serialNumber: asset.serialid,
      tagNumber: asset.tagnumber,
      description: asset.descrlong,
      category: asset.psamsubtypedescr,
      subtype2: asset.assetsubtype2,
      businessunit: asset.businessunit,
      cartId: asset.cartId,
      assetid: asset.assetid,
      location: asset.location,
      area: asset.areaid
    }]
    let cartObj = {
      cartItems: cartItems,
      appName: "URSA",
      appId: applicatonObj.appid
    }

    this.haltModal = false;
    this.store.dispatch(new AddToCart(cartObj));
  }

  itemRemovedFromCart(asset) {
    let cartArray = this.cartData.filter(val => val.data.cartId === asset.cartId);
    let cartId = cartArray[0]["_id"];
    let obj = {
      appId: applicatonObj.appid,
      userId: this.empId,
      cartItemsIdList: [cartId]
    }
    this.haltModal = false;
    this.store.dispatch(new DeleteFromCart(obj));
  }

  openWatchListModal(assetDetails: any) {
    this.watchListModalDisplay = true;
    this.watchListHeader = "Add Watch List Actions";
    this.selectedWatchListAsset = assetDetails;
    if(assetDetails.isAddedToWatchList)
    {
      this.watchListHeader = "Edit Watch List Actions"
       this.filteredWatchListData =  this.filterWatchListActions(assetDetails);
  
       if(this.filteredWatchListData && this.filteredWatchListData.length > 0)
       {
         this.selectedWatchListActions = this.filteredWatchListData[0].actionsToWatch
       }
    }
    
    this.watchListModalProperties = {
       watchListHeader: this.watchListHeader,
       watchListModalDisplay: true,
       watchListModalData: {
           assetid: assetDetails.assetid,
           businessunit: assetDetails.businessunit
       },
       selectedWatchListActions: this.selectedWatchListActions
    }
  }

  closeWatchListModal() {
    this.watchListModalDisplay = false;
    this.selectedWatchListActions = [];
  }
  
  submitWatchListForm(Obj: any) {
    if(this.selectedWatchListAsset && !this.selectedWatchListAsset.isAddedToWatchList) {
      this.store.dispatch(new AddToWatchList(Obj));
    }else{
      this.store.dispatch(new EditInWatchList(Obj));
    }
      this.closeWatchListModal();
  }

  filterWatchListActions(assetDetails)  {
    if(this.watchListData.length > 0) {
     return this.watchListData.filter(wListData => ((wListData.assetid === assetDetails.assetid) &&  (wListData.businessunit === assetDetails.businessunit)))
    }
   }

  modalDisplayFunction = () => {
    if (this.addedCartFetchLoading || this.deletedCartFetchLoading || this.WatchListLoading || this.addedWatchListLoading) {
      return 'block';
    } else {
      return 'none';
    }
  }

}