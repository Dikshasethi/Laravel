import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductHistoryDetailsComponent } from './product-history-details.component';

describe('ProductHistoryDetailsComponent', () => {
  let component: ProductHistoryDetailsComponent;
  let fixture: ComponentFixture<ProductHistoryDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductHistoryDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductHistoryDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
