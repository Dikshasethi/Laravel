import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'lodash';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { GetAssetHistory } from '../../actions/product.actions';
import { GetWatchListData, ResetWatchListData } from '../../actions/watchlist.action';

@Component({
  selector: 'app-asset-history',
  templateUrl: './asset-history.component.html',
  styleUrls: ['./asset-history.component.css']
})
export class AssetHistoryComponent implements OnInit {
  productSubscription;
  assetHistoryDetails;
  assetId;
  businessunit;
  assetDetails = {};
  assetworkorderdetails = [];
  certificateDetails = [];
  activeRoute: string = '';
  index;
  cartData = [];
  productCartHierarchy = [];
  cartSubscription;
  cartFetchIsLoading;
  watchListSubscription;
  userDetailSubscription;
  watchListData = [];
  empId;
  show_errorMessage: boolean = false;
  error_message: string;
  emodetailsFlag:boolean = true;

  constructor(
    private store: Store<AppState>,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.activeRoute = this.route.snapshot.queryParamMap.get('view') || '';
    this.index = this.route.snapshot.queryParamMap.get('index') || 0;
    this.assetId = this.route.snapshot.paramMap.get('assetid');
    this.businessunit = this.route.snapshot.paramMap.get('businessunit');
    this.store.dispatch(new GetAssetHistory(
      {
        businessunit: this.businessunit,
        assetid: this.assetId,
      }));

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
      .subscribe(userDetailObj => {
        const {
          details
        } = userDetailObj;
        this.empId = details['employee_id'];
        if(this.empId) {
          this.fetchWatchListForLoggedInUser();
        }
    })

    this.productSubscription = this.store.pipe(select(state => state.Product))
      .subscribe(productData => {
        this.assetHistoryDetails;
        this.assetDetails = {};
        const { assetHistoryDetails, productFetchIsLoading } = productData
        const { assetdetails, statustext, statusbackgroundcolor, pastduecheckout, assetworkorderdetails, licensedetails, activeCertificate } = assetHistoryDetails;
        if (!_.isEmpty(assetHistoryDetails)) {
          let asset = {
            ...assetdetails,
            statustext,
            statusbackgroundcolor,
            pastduecheckout,
            activeCertificate
          };
          this.assetDetails = asset;
        }

        if (!_.isEmpty(assetworkorderdetails)) {
          this.assetworkorderdetails = assetworkorderdetails;
        }
        if (!_.isEmpty(licensedetails)) {
          this.certificateDetails = licensedetails;
        }
        

      })

    this.cartSubscription = this.store.pipe(select(state => state.Cart))
      .subscribe(cartObj => {
        const {
          cartData,
          errorState: { error = false, error_message }
        } = cartObj;

        if (!_.isEmpty(cartData) && !cartData['hasError']) {
          this.cartData = cartData['cartData'];
          this.cartFetchIsLoading = cartData['cartFetchIsLoading']
          this.editProductAccordingToCart();
        }if (error) {
          this.showErrorMessage(error_message);
        }
      })

      this.watchListSubscription = this.store.pipe(select(state => state.WatchList))
      .subscribe(WchListData => {
        const {
            watchListData: { watchListLoading, watchListData },
            errorState: { error = false, error_message }
        } = WchListData
        
        if (!_.isEmpty(watchListData) && !watchListData['hasError']) {
          this.watchListData = watchListData;
          this.filterProductAccordingToWatchlist();
        }
        if (error) {
          this.showErrorMessage(error_message);
        }
      })
  }

  ngOnDestroy() {
    this.userDetailSubscription.unsubscribe();
    this.watchListSubscription.unsubscribe();
    this.store.dispatch(new ResetWatchListData());
  }

  editProductAccordingToCart() {
    if (!_.isEmpty(this.cartData) && !_.isEmpty(this.assetDetails)) {
      let productListObject = this.assetDetails;
      let cartId = productListObject['businessunit'] + "" + productListObject['assetid'];
      productListObject = {
        ...productListObject,
        isAddedToCart: false,
        bu: productListObject['businessunit'],
        cartId: cartId
      }
      this.cartData.forEach(cdata => {
        if (
          cdata.data &&
          (cdata.data.cartId === productListObject['cartId'])
        ) {
          productListObject["isAddedToCart"] = true;
        }
      })
      this.assetDetails = productListObject;
    }
  }

  filterProductAccordingToWatchlist() {
    if(!_.isEmpty(this.watchListData) && !_.isEmpty(this.assetDetails)) {
      let assetDetailsObject = this.assetDetails;
      assetDetailsObject = {
        ...assetDetailsObject,
        isAddedToWatchList: false
      }

      for(let i=0; i < this.watchListData.length; i++) {
        if((this.watchListData[i].assetid === assetDetailsObject['assetid']) 
        && (this.watchListData[i].businessunit === assetDetailsObject['businessunit'])) {
          assetDetailsObject["isAddedToWatchList"] = true;
          break;
        }
      }
      this.assetDetails = assetDetailsObject;
    }
  }

  fetchWatchListForLoggedInUser() {
    this.store.dispatch(new GetWatchListData({
      "limit" : 0,
      "filter": {
        "userid": this.empId
      },
      "skip" : 0,
      "sort": {}
    }));
  }

  showErrorMessage(errorMsg) {
    this.error_message = errorMsg && errorMsg.error && errorMsg.error.message ? errorMsg.error.message : 'Something went wrong';
    alert(this.error_message);
}

  navigateToRoute(params) {
    this.router.navigate([`/assethistory/${this.businessunit}/${this.assetId}`], { queryParams: { view: params } });
  }

  routeWithQueryParams($event) {
    const selectedRoute = $event.target.innerHTML;
    if (selectedRoute == 'Product Detail') {
      this.navigateToRoute('assetdetails');
    } 
    else if (selectedRoute == 'Asset Transaction Log') {
      this.navigateToRoute('assettransaction');
    }
    else if (selectedRoute == 'Certificate History') {
      this.navigateToRoute('certificatehistory');
    }
    else if (selectedRoute == 'Work Order History') {
      this.navigateToRoute('workorderhistory');
    }
    else if (selectedRoute == 'EMO') {
      this.navigateToRoute('EMO');
    }
    else if (selectedRoute == 'Receiving Inspection') {
      this.navigateToRoute('receivinginspection');
    }
  }
}
