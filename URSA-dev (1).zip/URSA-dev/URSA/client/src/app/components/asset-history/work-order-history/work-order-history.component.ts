import { Component, Input, OnInit } from '@angular/core';
import * as _ from 'lodash';
import localDate from '../../../utils/date/localDate';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../models/appState';
import { ReSetSorting, SetSorting } from '../../../actions/checkInOut.action';

@Component({
  selector: 'app-work-order-history',
  templateUrl: './work-order-history.component.html',
  styleUrls: ['./work-order-history.component.css']
})

export class WorkOrderHistory implements OnInit {

  @Input() assetworkorderdetails;
  refinedWorkOrderDetails = [];
  filters: any = {
    wotype: '',
    woid: '',
    shopbu: '',
    wobu:'',
    startdate: '',
    enddate: ''
  }
  checkInOutSortingSubscription: any;
  sort: any = {};
  sortingIcon: any = {};

  constructor(private store: Store<AppState>) { }

  ngOnInit() {

    if (!_.isEmpty(this.assetworkorderdetails)) {

      this.assetworkorderdetails = this.refineWorkOrderList(this.assetworkorderdetails.slice());
      this.refinedWorkOrderDetails = this.assetworkorderdetails.slice();

    }

    this.checkInOutSortingSubscription = this.store.pipe(select(state => state.CheckInOut))
      .subscribe(data => {
        const { sort: { workorderhistory } } = data;
        let obj = {};
        for (let key in workorderhistory) {
          obj[key] = workorderhistory[key] === 1 ? "asc" : "desc";
        }
        this.sort = obj;
      });
  }

  ngOnDestroy() {
    this.checkInOutSortingSubscription.unsubscribe();
    this.store.dispatch(new ReSetSorting());
  }

  refineWorkOrderList = (workOrderList = []) => {
    let newArray = [];
    let sortedArray = _.orderBy(workOrderList, 'startdate', 'desc');
    for (let i = 0; i < sortedArray.length; i++) {
      let workorder = sortedArray[i];
      let {
        startdate = '', enddate = ''
      } = workorder;
      newArray.push({
        ...workorder,
        startdate: startdate ? localDate(startdate, 'DD-MMM-YYYY') : '',
        enddate: enddate ? localDate(enddate, 'DD-MMM-YYYY') : '',
      });
    }

    return newArray;
  }

  localDateWrapper = (date) => {
    return date ? localDate(date, 'DD-MMM-YYYY') : '';
  }

  updateFilter(map: string, text) {
    this.refinedWorkOrderDetails = this.assetworkorderdetails;
    this.filters[map] = text.target.value;
    this.executeFilter();
  }

  executeFilter = () => {
    let accumulator = [];
    for (let i = 0; i < this.refinedWorkOrderDetails.length; i++) {
      let workorder = this.refinedWorkOrderDetails[i];
      let counts = 0, match = 0, filterValueCount = 0;
      for (let k in this.filters) {
        let value = this.filters[k]
        if (typeof value === 'string') {
          counts++;
          if (value) {
            filterValueCount++;
          }
          if (
            workorder[k] &&
            workorder[k].toLowerCase().includes(value.toLowerCase())
          ) {
            match++;
          }
        }
      }
      if (filterValueCount) {
        if (match === counts) {
          accumulator.push(workorder);
        }
      } else {
        accumulator.push(workorder);
      }

    }
    this.refinedWorkOrderDetails = _.orderBy(accumulator, 'startdate', 'desc')
  }

  setSorting = (key) => {
    let sort = {};
    sort['componentType'] = "workorderhistory";
    sort['dataKey'] = key;
    this.store.dispatch(new SetSorting(sort))
  }

  sortData = (dataKey) => {
    this.setSorting(dataKey);
    this.sortExistingData();
    this.visualizeSortingIcon();
  }

  sortExistingData = () => {
    let keys: any[] = Object.keys(this.sort);
    let values: any[] = Object.values(this.sort);
    this.refinedWorkOrderDetails = _.orderBy(this.refinedWorkOrderDetails, keys, values);
  }

  visualizeSortingIcon = () => {
    let sortData = JSON.parse(JSON.stringify(this.sort));
    let obj = {}
    for (let key in sortData) {
      if (sortData[key] === "asc") {
        obj[key] = "fa fa-arrow-up"
      } else if (sortData[key] === "desc") {
        obj[key] = "fa fa-arrow-down"
      }
    }
    this.sortingIcon = obj;
  }

}