import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetTransactionLogComponent } from './asset-transaction-log.component';

describe('AssetTransactionLogComponent', () => {
  let component: AssetTransactionLogComponent;
  let fixture: ComponentFixture<AssetTransactionLogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetTransactionLogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetTransactionLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
