import { Component, OnInit, Output, EventEmitter, Input, SimpleChange } from '@angular/core';
import { AppState } from '../../models/appState';
import { Store, select } from '@ngrx/store';
import * as moment from 'moment';
import { LogoutUser } from '../../actions/userDetail.actions';
import { DestroyAutocompleteList, GetCheckoutAutocomplete, GetCustodianAutocompleteList, GetLocationAreasCheck } from '../../actions/autocomplete.actions';
import dateValidation from '../../utils/date/dateValidator';
import defaultValues from '../../utils/autoComplete/defaultValues'

@Component({
  selector: 'app-details-panel',
  templateUrl: './details-panel.component.html',
  styleUrls: ['./details-panel.component.css','../ready-checkout/ready-checkout.component.css']
})
export class DetailsPanelComponent implements OnInit {
  constructor( private store: Store<AppState>) { }
  newDetails : any={};
  enterDateModalDisplay="none";
  suggestionList=[];
  areaSuggestionList=[]
  changePayload = [];
  autocompleteCheckoutSubscription;
  autocompleteSubscription;
  dateChangeConfirmationModalDisplay = "none";
  isAreaDisabled = true;
  destinationLocation='';
  destinationArea ='';  
  custodian="";
  selectedLocationCode = "";
  selectedAreaCode="";
  isShowCustodian=true;
  isShowApply=false;
  checkStartDate = true;
  checkEndDate = true;
  isGetAreaCount = false;

  isAreaSuggest = false;
  cachedAreaList = [];
  @Output() dateChangeConfirmed = new EventEmitter<any>();
  @Output() dateChanged = new EventEmitter<any>();
  @Output() locationSelected = new EventEmitter<any>();
  @Output() areaSelected = new EventEmitter<any>();
  @Output() refnoChanged = new EventEmitter<any>();
  @Output() custodianSelected = new EventEmitter<any>();
  @Output() applyClicked = new EventEmitter<any>();
  @Input() recheckout : boolean = false;
  @Input() checkout : boolean = false;
  @Input()
  set dateRange( val ) {
    if(val){
      this.newDetails = val;
      this.newDetails['refno'] = "";
      this.custodian = "";
      if(val.showCustodian == 'false')
        this.isShowCustodian = false;
      if(val.showApply == 'true')
        this.isShowApply = true;
      if(val.custodian && val.custodian.empName){
        this.custodian = val.custodian.empName;
        this.custodianSelected.next( val.custodian);  
      }
    }    
  }

  currentDate = moment(new Date()).format('YYYY-MM-DD');
  minDate = "";

  ngOnInit() {
    this.autocompleteCheckoutSubscription = this.store.pipe(select(state => state.Autocomplete.checkoutAutocomplete))
    .subscribe(autocompleteObject => {
      const {
        suggestionList,isFetchingAutocompleteList, field
      } = autocompleteObject;   
      if(suggestionList && suggestionList['isAuthenticate']=="not authenticated"){
        this.store.dispatch(new LogoutUser({}));
      }
      if(!isFetchingAutocompleteList && (suggestionList && suggestionList.length==0)){
        let obj = [];
        if(field=="location"){
          obj=[{
            "locationText":"No data found",
            "areaText":"No data found"
          }]
        }else if(field=="area"){
          obj=[{
            areaCode: "NA",
            areaText: "NA"
          }]
        }
       
        this.suggestionList = obj;
      }else{
        if(suggestionList && (field=="location" || field=="custodian")){
          this.suggestionList = suggestionList;
        }else if(suggestionList && field=="area"){
          let obj = {
            areaCode: defaultValues.areaText,
            areaText: defaultValues.areaText
          }
          this.suggestionList = suggestionList;
          this.suggestionList.splice( 0, 0, obj );
        }
      }
      
    });
    this.autocompleteSubscription = this.store.pipe(select(state => state.Autocomplete))
    .subscribe(autoFillData=> {
      let { areaCountForCurrentLocation, isLoading, cachedArea } = autoFillData;
      if(this.isGetAreaCount && !isLoading){
        this.isGetAreaCount = false;
        this.cachedAreaList = cachedArea;
        if(Number(areaCountForCurrentLocation) === 0){
          this.destinationArea = defaultValues.areaText;
          this.selectedAreaCode=defaultValues.areaText;
          let temporaryAreaObj = {
            areaCode : defaultValues.areaText,
            areaText : defaultValues.areaText
          }
          this.areaSelected.next(temporaryAreaObj)
        }
      }
    });
  }
  
  handleChangeDateRange(){
    if(this.newDetails['isChangeDateRange'] || this.recheckout || this.checkout){
      if((!this.newDetails["newstartdate"] || this.newDetails["newstartdate"]=='') || 
      (!this.newDetails["newenddate"] || this.newDetails["newenddate"]=='')){
        this.enterDateModalDisplay = "block";
      }
      else{
        this.changePayload=[];
        let assetValidationDetails = {
          ...this.newDetails,
          destinationLocation :this.selectedLocationCode
        }
        this.dateChanged.next(assetValidationDetails);
        this.dateChangeConfirmationModalDisplay = 'block';
      }
    }else
      this.newDetails['isChangeDateRange'] = true;    
  }

  confirmChangeDateRange(){
    this.dateChangeConfirmationModalDisplay = 'none';
    this.dateChangeConfirmed.next("date changed");
  }

  
  onStartDateChange(event){
    let todayDate = new Date();
    let selectedDate = new Date(event);
    this.checkStartDate = dateValidation(event);
    if(this.recheckout){
      this.newDetails['newstartdate'] = event;
    }else{
      if(selectedDate > todayDate){
        this.newDetails['newstartdate'] =  moment(new Date()).format('YYYY-MM-DD');
      }else{
        this.newDetails['newstartdate'] = event;
      }
    }
    this.newDetails['newenddate'] = '';
    this.checkEndDate = false;
  }

  onEndDateChange(event){
    this.checkEndDate = dateValidation(event);
  }

  getDateRangeDisabled(){
    if(!this.checkStartDate || !this.checkEndDate){
       return true;
    }
    if(!this.selectedLocationCode || !this.selectedAreaCode || !this.newDetails['newstartdate'] || !this.newDetails['newenddate']){
      return true;
    }
    return false;
  }

  handleAutocompleteInputChange(text,field){
    this.suggestionList = [];
    if(field=='custodian'){
      if(text.length>=2){
        let obj={
          "index":"employeesearch",
          "search_keyword":text,
          "field":"custodian"
        }
        this.store.dispatch(new DestroyAutocompleteList());
        this.store.dispatch(new GetCustodianAutocompleteList(obj));
      }     
    }else{
      if(text=="" && field=="location"){
        this.isAreaDisabled = true;
        this.destinationArea = '';
        this.selectedLocationCode = '';
        this.locationSelected.next('');
      }else if(text=="" && field=="area"){
        this.selectedAreaCode = '';
        this.areaSelected.next('')
      }
      if(text.length>=2){
        let obj =  {
          "field" : field     
        }
        if(field === "location"){
          this.isAreaDisabled = true;
          this.destinationArea = '';
          this.locationSelected.next('');
          this.areaSelected.next('')
          obj['locationDescription'] = text
        }
        if(field === "area"){
          this.isAreaSuggest = true;
          obj['locationCode'] = this.selectedLocationCode;
          this.areaSelected.next('')
          obj['areaDescription'] = text 
        }
        if(this.isAreaSuggest){
          this.filterAreaList(obj)
          this.isAreaSuggest = false;
        }else{
          this.store.dispatch(new DestroyAutocompleteList());
          this.store.dispatch(new GetCheckoutAutocomplete(obj));
        }
      }
    }
    
  }

  filterAreaList(filterObj){
    let newSuggestionList = [];
    let subString = filterObj.areaDescription && filterObj.areaDescription || '';

    for(let areaItem of this.cachedAreaList){
      if(
        areaItem.LOCATION && 
        areaItem.SETID && 
        areaItem.DESCR && 
        areaItem.DESCR.toLowerCase().includes(subString.toLowerCase())
      ){
        let areaDescription = areaItem.DESCR
        let areaTextRef = 
          (
            subString.toLowerCase() === 'na' || 
            subString.toLowerCase() === ''
          ) ? 
          'NA' : areaDescription;

        let areaObject = {
          areaCode : areaItem.LOCATION || '',
          areaText : areaTextRef
        }
        newSuggestionList.push(areaObject)
      }
    }
    this.areaSuggestionList = newSuggestionList;
  }

  suggestionSelected(suggestion,field){
    if(field==='location' && suggestion.locationText!="No data found"){
      this.destinationLocation = suggestion.locationText;
      this.selectedLocationCode = suggestion.locationCode;
      this.isAreaDisabled = false;
      this.locationSelected.next(suggestion);
      let areaCheckObj = {
        locationId : suggestion.locationCode
      }
      this.isGetAreaCount = true;
      this.store.dispatch(new GetLocationAreasCheck(areaCheckObj));

    }
      
    if(field==='area' && suggestion.areaText!="No data found"){
      this.destinationArea = suggestion.areaText;
      this.selectedAreaCode = suggestion.areaCode;
      this.areaSelected.next(suggestion);      
    }

    if(field==='custodian' && suggestion.locationText!="No data found"){
      this.custodian = suggestion.empName;
      this.custodianSelected.next(suggestion);
    }
  }

  onRefNoChange(refno){
    this.refnoChanged.next(refno);
  }

  onApplyClick(){
    this.applyClicked.next('Apply clicked');
  }

  ngOnDestroy(){
    this.autocompleteSubscription.unsubscribe();
    this.autocompleteCheckoutSubscription.unsubscribe();
  }

}


