import { Component, OnInit, HostListener, ViewChild, Input } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { GetServiceRequestList, ResetServiceRequestListData, ReSetSorting, SetSorting } from '../../actions/serviceRequest.actions';
import * as moment from 'moment';
import * as _ from 'lodash';
import localDate from '../../utils/date/localDate';
import serviceRequestFilterMap from '../../utils/serviceRequest/serviceRequestFilterMap';
import filterObjectDateFormat from '../../utils/checkInOut/filterObjectDateFormat';
//import { ReSetSorting, SetSorting } from '../../actions/checkInOut.action';


@Component({
  selector: 'app-assets-service-request-list',
  templateUrl: './assets-service-request-list.component.html',
  styleUrls: ['./assets-service-request-list.component.css']
})
export class AssetsServiceRequestListComponent implements OnInit {

  serviceRequestListSubscription;
  serviceRequestList=[];
  refinedList: any[];
  refinedListCopy = [];
  serviceRequestListLoading=false;
  alertState: string;
  alertMessage: string;
  isShowAlert: boolean = false;
  filters: any = {
    requesttype : '',
    sourcetype : '',
    worktype : '',
    servicegroup : '',
    subject : '',
    projectnumber : '',
    activityid : '',
    projectmanagername : '',
    customername : '',
    servicecenter : '',
    createdAt:'',
    updatedAt : ''
  };
  skip:number = 0;
  limit:number = 50;
  recordCount: number = 0;
    timeout = null;
  filterObj = {
  };
  sort :any = {"createdAt" : -1};
  sortkey:any ={};
  onScrollLoading:boolean = false;
  selectedData = [];
  sortingIcon :any={};
  selectedAssetsCount : number = 0;
  headingLabel = 'Service Request List';
  totalCount: number = 0;
  constructor(
    private store: Store<AppState>
  ) { }

  public innerHeight: any;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;
  }
  ngOnInit() {
    this.innerHeight = window.innerHeight;
    this.fetchServiceRequestListData();
    this.serviceRequestListSubscription = this.store.pipe(select(state => state.ServiceRequest))
    .subscribe(serviceRequestData => {
          const {
            serviceRequestListData: {  serviceRequestListData, serviceRequestListLoading, serviceRequestListError, totalCount },
            errorState: { errorLoading = false, error = {} },
            onScrollLoading = false,
          } = serviceRequestData
          if(serviceRequestListData && !serviceRequestListLoading){
            this.serviceRequestList = serviceRequestListData;
            this.recordCount = serviceRequestListData.length
            this.totalCount = totalCount;
          }
          
          this.serviceRequestList = serviceRequestListData;
          this.recordCount = this.serviceRequestList.length
          this.serviceRequestListLoading = serviceRequestListLoading;
          this.onScrollLoading = onScrollLoading;
          if (error['message']) {
            this.showAlertMessage('error', error.message);
          }
          this.refinedList = this.refineList(this.serviceRequestList.slice());
          this.refinedList = this.refinedList.map(val => {
            val.isSelected = false;
            return val;
          });
          this.refinedListCopy = this.refinedList;

          const {sort}=serviceRequestData;
          let obj={};
          for(let key in sort){
             obj[key] = sort[key];
          }
          if(Object.keys(obj).length != 0){
             this.sort = obj;
          }
      })
  }

  ngOnDestroy(){
    this.serviceRequestListSubscription.unsubscribe();
    this.store.dispatch(new ResetServiceRequestListData());
    this.store.dispatch(new ReSetSorting());
  }

  updateFilter(map: string, text) {
    this.filters[map] = text.target.value;
    this.resetSearchMeta();
    this.fetchServiceRequestListData();
  
  }

  resetSearchMeta = () => {
    this.skip = 0;
    this.store.dispatch(new ResetServiceRequestListData());
    this.filterObj = {
    }
  }

  fetchServiceRequestListData() {
    for (let k in this.filters){
      let value = this.filters[k];
      if(value){
          this.filterObj[serviceRequestFilterMap[k]] = value
      }
    }
    this.fetchServiceRequestListDetails();
  }

  fetchServiceRequestListDetails = ()=>{
    let filterObjectWithNormalizedDate = filterObjectDateFormat(this.filterObj);
    let obj = {
      "skip": this.skip,
      "limit": this.limit,
      "filter":  filterObjectWithNormalizedDate,
      "sort": this.sort
    }
    this.store.dispatch(new GetServiceRequestList(obj));
    
  }

  refineList = (serviceRequestList = []) => {
    let newArray = [];
    for (let i = 0; i < serviceRequestList.length; i++) {
      let serviceRequestData = serviceRequestList[i];
      let {
        createdAt = '', updatedAt = ''
      } = serviceRequestData;
      newArray.push({
        ...serviceRequestData,
        createdAt: createdAt ? localDate(createdAt, 'DD-MMM-YYYY') : '',
        updatedAt: updatedAt ? localDate(updatedAt, 'DD-MMM-YYYY') : ''
      });
    }

    return newArray;
  }

  modalDisplayFunction = () => {
    if (this.serviceRequestListLoading && !this.onScrollLoading) {
      return 'block';
    }
    return 'none';
  }

  onScroll(){
    if(
      this.skip <=  this.recordCount
    ){
      this.skip = this.recordCount;
      this.fetchServiceRequestListData();
  }
  }

  selectRecords(data, i) {
    if (data.isSelected) {
      this.selectedData.push(data);
    }
    else {
      this.selectedData = this.selectedData.filter(function (obj) {
        return obj._id !== data._id;
      });
    }
    this.selectedAssetsCount = this.selectedData.length;
  }

  buttonIsDisabled = () => {
    if(
      this.selectedData.length < 1
    ){
      return true;
    }else{
      return false;
    }
  }

  setSorting=(key)=>{
    if (this.sortkey[key] === -1) {
      this.sortkey={}; this.sort={};
    }
    else if(this.sortkey[key] === 1){
      this.sortkey[key] = -1;
    }
    else{
      this.sortkey[key] = 1
    }
    this.store.dispatch(new SetSorting(this.sortkey))
  }
  
  sortData = (dataKey) => {
    this.setSorting(dataKey);
    this.skip = 0;
    this.store.dispatch(new ResetServiceRequestListData());
    this.fetchServiceRequestListDetails();
    this.visualizeSortingIcon();
  }

  visualizeSortingIcon = () => {
    let sortData = JSON.parse(JSON.stringify(this.sort));
    let obj={}
    for(let key in sortData){
       if(sortData[key] === 1){
        obj[key] = "fa fa-arrow-up"
       }else if(sortData[key] === -1){
        obj[key] = "fa fa-arrow-down"
       }
    }
    this.sortingIcon = obj;  
  }

  private showAlertMessage(state, message) {
    if (state === "error") {
      this.alertState = "alert-danger";
    } else {
      this.alertState = "alert-success";
    }
    this.alertMessage = message
    this.isShowAlert = true;
  }

  removeAlertIcon() {
    this.isShowAlert = false;
  }
}
