import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetsServiceRequestListComponent } from './assets-service-request-list.component';

describe('AssetsServiceRequestListComponent', () => {
  let component: AssetsServiceRequestListComponent;
  let fixture: ComponentFixture<AssetsServiceRequestListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetsServiceRequestListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetsServiceRequestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
