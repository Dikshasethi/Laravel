import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Router } from '@angular/router';
import { AppState } from '../../models/appState';
import { GetCalloutList, GetCalloutDetails, ResetCalloutDetails, DeleteCallout } from '../../actions/callout.action';
import * as moment from 'moment';
import * as _ from 'lodash';
import * as $ from 'jquery';
import { ActivatedRoute } from '@angular/router';
import descrBuilder from '../../utils/calloutDetails/descriptionBuilder';
import tabMenuList from '../../utils/calloutDetails/tabMenu';
import tableStructure from '../../utils/checkInOut/tableStructure';
import { ResetCheckInOut } from '../../actions/checkInOut.action';
import localDate from '../../utils/date/localDate';

@Component({
  selector: 'app-callout-details',
  templateUrl: './callout-details.component.html',
  styleUrls: ['./callout-details.component.css']
})
export class CalloutDetailsComponent implements OnInit {
  calloutid;
  calloutSubscription;
  calloutDetails = {};
  checkedOutAssets=[];
  checkedInAssets=[];
  hardreservedassets=[];
  calloutDetailsError=false;
  calloutDetailsIsLoading=false;
  descriptionBuilder = descrBuilder.slice();
  tabMenuBuilder = tabMenuList.slice();
  tableBuilderList = tableStructure.slice()
  sortMap = {
    sortedHardReservedAssets : [],
    sortedCheckedOutAssets : [],
    sortedCheckedInAssets : []
  }
  mobileView = false;
  tableInFocus='checkout';
  formMap = {}
  tableViewHeight=0;
  showDeleteCalloutButton=false;
  deleteCalloutLoading=false;
  deleteCalloutError=false;
  deleteCalloutSuccess=false;
  deleteCalloutErrorMessage='';
  alertState: string;
  alertMessage: string;
  checkInOutReducerSubscription: any;
  constructor(
    private store: Store<AppState>,
    private route: ActivatedRoute,
    private router:Router, 
  ) { }

  ngOnInit() {
    this.calloutid = this.route.snapshot.paramMap.get('calloutid');
    this.store.dispatch(new GetCalloutDetails({calloutid : this.calloutid}));
    this.calloutSubscription = this.store.pipe(select(state => state.Callout))
    .subscribe(data => {
      const {
        calloutDetails={}, calloutDetailsError=false,
        calloutDetailsIsLoading=false, deleteCalloutLoading=false,
        deleteCalloutError=false, deleteCalloutSuccess=false,
        deleteCalloutErrorMessage=''
      } = data;
      this.calloutDetails = calloutDetails['calloutDetails']
      this.calloutDetailsError = calloutDetailsError;
      this.calloutDetailsIsLoading = calloutDetailsIsLoading;
      this.deleteCalloutLoading = deleteCalloutLoading;
      this.deleteCalloutError = deleteCalloutError;
      this.deleteCalloutErrorMessage = deleteCalloutErrorMessage;
      this.initCheckoutData(calloutDetails['checkInOutList']);
      this.initHardReservedData(calloutDetails['hardReservedList']);
      this.getTableViewHeight();
      this.showDeleteCalloutButton = calloutDetails['isDeleteBtnAvailable']
      if(deleteCalloutSuccess){
        this.router.navigate(['/calloutlist']);  
      }
    })

    this.checkInOutReducerSubscription = this.store.pipe(select(state => state.CheckInOut))
      .subscribe(data => {
        const { checkout = {}, checkin = {} } = data;
        let checkoutSubmitResults = checkout['submitResults'];
        let checkinSubmitResults = checkin['submitResults'];
        if (checkoutSubmitResults['successList'] && checkoutSubmitResults['successList'].length){
          this.getcalloutDetails()
        }
        if (checkinSubmitResults['successList'] && checkinSubmitResults['successList'].length){
          this.getcalloutDetails();
        }
      });
  }

  private getcalloutDetails() {
    this.store.dispatch(new GetCalloutDetails({ calloutid: this.calloutid }));
  }

  ngOnDestroy(){
    this.calloutSubscription.unsubscribe();
    this.store.dispatch(new ResetCalloutDetails());
    this.store.dispatch(new ResetCheckInOut());
  }

  getDeleteCalloutText = () => {
    return this.deleteCalloutLoading ? 'Deleting...' : 'Delete Callout';
  }

  refreshParent = () => {
    this.store.dispatch(new GetCalloutDetails({calloutid : this.calloutid}));
  }

  tabClass = (tab) => {
    return `d-flex cursor p-1 ${this.tableInFocus === tab['tableInFocus'] ? 'bg-secondary active-tab text-white' : 'bg-white inactive-tab text-secondary'}`;
  }

  setTableInFocus = (tab) => {
    this.tableInFocus = tab['tableInFocus'];
  }

  initCheckoutData = (checkInOutList=[]) => {
    let checkedout=[], checkedinArray=[];
    for (let i = 0; i < checkInOutList.length; i++){
      const record = checkInOutList[i];
      const {
        checkedin=false, cancelled=false
      } = record;
      if(cancelled){
        continue;
      }
      if(checkedin){
        checkedinArray.push(record);
      }
      checkedout.push(record);
    }
    this.checkedOutAssets = checkedout;
    this.checkedInAssets = checkedinArray;
    this.initCheckoutFormat();
  }

  initHardReservedData = (hardReserveList=[]) => {
    let list = [];
    for (let i = 0; i < hardReserveList.length; i++){
      const record = hardReserveList[i];
      const {reservation={}} = record;
      let obj = {
        ...record,
        ...reservation
      };
      delete obj['reservation'];
      list.push(obj);
    }
    this.hardreservedassets = list;
    this.sortList(
      'sortedHardReservedAssets', this.hardreservedassets, 
      'startdate', 'desc'
    );
  }

  initCheckoutFormat = () => {
    this.sortList(
      'sortedCheckedOutAssets', this.checkedOutAssets, 
      'checkoutdate', 'desc'
    );
    this.sortList(
      'sortedCheckedInAssets', this.checkedInAssets, 
      'checkoutdate', 'desc'
    );
  }

  sortList = (
    variableName='', array=[], orderField='',
    orderType=''
  ) => {
    this.sortMap[variableName] = _.orderBy(
      array, 
      orderField, 
      ['', 'desc'].includes(orderType) ? 'desc' : 'asc'
    );
  }

  builderLabelClass = (builder) => {
    return `${builder.labelClassName} mb-1`
  }

  builderData = (builder) => {
    const {
      dataKey='', transformBody=false,
      transformType='date'
    } = builder;
    let value = this.calloutDetails && this.calloutDetails[dataKey] || '';
    if(transformBody){
      if(transformType === 'date'){
        if(value){
          return localDate(value, 'DD-MMM-YYYY');
        }else{
          return '';
        }
      }
    }else{
      return value;
    }
  }

  getTableViewHeight = () => {
    let windowHeight = $(window).height();
    let calloutDetailsHeight = $('#calloutDetailsBlock').height();
    let calloutHeader = $('#calloutHeader').height();
    let tableTabHeaders = $('#tabSelector').height();
    let appHeaderHeight = $('#appHeaderComponent').height();
    let deleteCallout = $('#deleteCallout').height();
    let deleteCalloutHeight = typeof deleteCallout === 'number' ? deleteCallout : 0;
    let nonTableVH = ((
      calloutDetailsHeight + calloutHeader + 
      tableTabHeaders + appHeaderHeight + deleteCalloutHeight
      ) / windowHeight) * 100;
    this.tableViewHeight = 100 - nonTableVH;
  }

  modalDisplayFunction = () => {
    if (this.calloutDetailsIsLoading) {
      return 'block';
    } else {
      return 'none';
    }
  }

  deleteCallout = () => {
    this.store.dispatch(new DeleteCallout({
      calloutid : this.calloutid
    }))
  }

  triggerAlertMessage = (alertObject) => {
    this.alertMessage = alertObject.message;
    this.alertState = alertObject.state
  }

  resetErrorMessages() {
    this.alertMessage = '';
    this.alertState = ''
  }
}
