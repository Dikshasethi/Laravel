import { Routes } from '@angular/router';
import { CalloutDetailsComponent } from './callout-details.component';

export const CalloutDetailsRoutes: Routes = [
    { path: ':calloutid', component: CalloutDetailsComponent }
];