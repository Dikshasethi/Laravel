import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { CalloutDetailsRoutes } from './calloutdetails.routes';
import { CalloutDetailsComponent } from './callout-details.component';
@NgModule({
    declarations: [
        CalloutDetailsComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(CalloutDetailsRoutes)
    ],
    exports: [
        RouterModule
    ]
})

export class CalloutDetailsModule { }