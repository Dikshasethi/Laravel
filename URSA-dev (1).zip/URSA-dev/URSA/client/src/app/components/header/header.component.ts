import { Component, OnInit, HostListener, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { trigger, style, state, transition, animate } from '@angular/animations';
import { Router } from "@angular/router";
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { MsalService } from '@azure/msal-angular';
import { CookieService } from "angular2-cookie/core";
import { SetViewPreference } from '../../actions/user.actions';
import { LogoutUser, ClearUserDetail, GetUserDetail } from '../../actions/userDetail.actions';
import * as _ from 'lodash';
import { GetCartData } from '../../actions/cart.action';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  animations: [

    trigger('ExpandCollapse', [
      state('hide', style({ display: 'none', transform: 'translateY(0)' })),
      state('show', style({ display: 'block', transform: 'translateY(0)' })),
      transition('hide => show', [
        style({ transform: 'translateY(-5%)' }),
        animate(400)
      ]),
      transition('show => hide', [
        style({ transform: 'translateY(0%)' }),
        animate(100)
      ])
    ]),

    trigger('display', [
      state('hide', style({ display: 'none' })),
      state('show', style({ display: 'block' })),
    ]),

    trigger('show1', [
      state('hide', style({ display: 'none' })),
      state('show', style({ display: 'block' })),
    ])
  ]
})
export class HeaderComponent implements OnInit {

  public dispblock: string = 'hide';
  public dispblock2: string = 'hide';
  public dispblock3: string = 'hide';
  public show1: string = 'hide';
  displayName = '';
  private advancesearch = 'none';
  routerUrl;
  productToSearch;
  userViewPreference;
  userDetailSubscription;
  proposalSubscription;
  notificationSubscription;
  userSubscription;
  noUserCount=0;
  hardReserveMode;
  permissionDetails=[];
  userViewPreferenceBtnDisabled;
  cartItems:Number=0;
  cartItemsInDB:boolean;
  cartSubscription;
  empId;
  userRole : any = [];
  userRoles : any = [];
  clientNotifications=[];
  clientNotificationCount=0;
  showNotifications=false;

  @ViewChild('menuBtn') menuBtn: ElementRef;
  @ViewChild('menu') menu: ElementRef;
  @ViewChild('menuBars') menuBars: ElementRef;
  constructor(
    private router: Router,
    private store: Store<AppState>,
    private renderer: Renderer2,
    private authService: MsalService,
    private cookieService: CookieService
  ) {

    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };

    this.router.events.subscribe(param => {
      if (param["snapshot"] != undefined) {
        if (param["snapshot"].params.search_keyword != undefined)
          this.productToSearch = param["snapshot"].params.search_keyword
      }
    }) 
  }

  showHide1(): void {
    this.dispblock = this.dispblock === 'hide' ? 'show' : 'hide';
  }
  showHide2(): void {
    this.dispblock2 = this.dispblock2 === 'hide' ? 'show' : 'hide';
  } 
  showQuickNotifications = () => {
    this.showNotifications = !this.showNotifications;
    this.dispblock3 = this.dispblock3 === 'hide' ? 'show' : 'hide';
  }

  ngOnInit() {
    this.routerUrl = this.router.url;
    if( this.routerUrl != '/login'){
      this.renderer.listen('window', 'click',(e:Event)=>{
        if(e.target !== this.menuBtn.nativeElement && e.target!==this.menu.nativeElement 
          && e.target!==this.menuBars.nativeElement){
           this.dispblock2="hide";
        }
      });
    }

    this.userSubscription = this.store.pipe(select(state => state.User))
    .subscribe(user => {
      if(user){
        this.userViewPreference = user.userViewPreference;
      }
    })

    this.setButtonDisable();
    this.proposalSubscription = this.store.pipe(select(state => state.ProposalPageData))
    .subscribe(proposalObj => {
      const {
        hardReserveMode=false
      } = proposalObj;

      this.hardReserveMode = hardReserveMode;
    })

    this.cartSubscription = this.store.pipe(select(state => state.Cart.cartData))
    .subscribe(cartObj => {
      const {
        cartData=[],iscartItemsInDB
      } = cartObj;
      this.cartItemsInDB = iscartItemsInDB;
     this.cartItems=cartData.length;
    });

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
      .subscribe(obj => {
        const {details, isloggedOut} = obj;
        this.empId = details['employee_id'];

        if(
          !this.cartItems && !this.cartItemsInDB &&
          this.empId
        ){
          this.fetchCartData();
        }

        if (
          details && !_.isEmpty(details) && 
          !details['error'] && !details['hasError']
        ) {
          this.displayName = details['first_name'] + " " + details['last_name'];
          this.permissionDetails = details['permission'] ? details['permission'] : []
          this.userRoles = details['roleList'];  
        }

        if (isloggedOut) {
          this.store.dispatch(new ClearUserDetail());
          this.router.navigate(['/login']);
        }

    });

    this.notificationSubscription = this.store.pipe(select(state => state.Notification))
    .subscribe(obj => {
      const {
        usersNotifications=[]
      } = obj;
      this.clientNotifications = usersNotifications;
      this.clientNotificationCount = Array.isArray(usersNotifications) ? 
      usersNotifications.length : 0;
    })

  }

  ngOnDestroy() {
    if(this.userSubscription){  this.userSubscription.unsubscribe();  }
    if(this.userDetailSubscription){  this.userDetailSubscription.unsubscribe();  }
    if(this.proposalSubscription){  this.proposalSubscription.unsubscribe();  }
    if(this.cartSubscription){  this.cartSubscription.unsubscribe();  }
    if(this.notificationSubscription){this.notificationSubscription.unsubscribe();}
  }

  fetchCartData(){
    let obj={
      "userId" : this.empId,
      "appId" : "001",
      "limit" : 0,
      "skip" : 0	
    }
    
    this.store.dispatch(new GetCartData(obj));
  }

  setUserViewPreference = (view) => {
    this.store.dispatch(new SetViewPreference(view));
  }

  onLogout() {
    if(sessionStorage.getItem('lastRoute')){
      sessionStorage.removeItem('lastRoute') 
    }
    if(sessionStorage.getItem('defaultRefiendByPersonalization')){
      sessionStorage.removeItem('defaultRefiendByPersonalization') 
    }
    this.clearMsalCache();
    this.authService.logout();
    this.store.dispatch(new LogoutUser({}));
  }

  clearMsalCache = () => {
    this.cookieService.remove('msalaccesstoken');
    this.cookieService.remove('msalaccesstokenexpiration');
    this.cookieService.remove('es_access_token');
    this.cookieService.remove('es_token_expiry_time');
    this.cookieService.remove('authToken');
    this.cookieService.remove('authTokenExpiryTime');
    this.cookieService.remove('schedulinkToken');
    this.cookieService.remove('schedulinkTokenExpiryTime');
  }

  setButtonDisable(){
    if(
      this.routerUrl != '/landing' &&
      this.routerUrl != '/login' && !this.routerUrl.includes('/cart') &&
      !this.routerUrl.includes('/proposalinfo') &&
      !this.hardReserveMode && !this.routerUrl.includes('/readyToCheckout') &&
      !this.routerUrl.includes('/readyToCheckin') && !this.routerUrl.includes('/proposallist') &&
      !this.routerUrl.includes('/emolist') && !this.routerUrl.includes('/calloutlist') &&
      !this.routerUrl.includes('/checkedinAssets') && !this.routerUrl.includes('/usermanagement') &&
      !this.routerUrl.includes('/receivinglist')
    ){
      this.userViewPreferenceBtnDisabled = false;
      // return false;
    }     
    else{
      this.userViewPreferenceBtnDisabled = true;
      // return true;
    }
  }

  userViewPreferenceClassFunction(label){
    if(this.userViewPreferenceBtnDisabled)
      return 'disabledBtn';
    else if(this.userViewPreference == label && !this.userViewPreferenceBtnDisabled)
      return 'enabledSelectedButton'
    else if(this.userViewPreference != label && !this.userViewPreferenceBtnDisabled)
      return 'enabledUnSelectedButton'
  }

  getMargin(cart) {
    let cartLength= String(cart).length;
    switch (cartLength) {
    case 1:
    return '14px';
    case 2:
    return '11px';
    case 3:
    return '8px';
    }
  }

}
