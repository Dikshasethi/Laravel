import { Routes } from '@angular/router';
import { ProposalListComponent } from './proposal-list.component';

export const ProposallistRoutes: Routes = [
    { path: '', component: ProposalListComponent }
];