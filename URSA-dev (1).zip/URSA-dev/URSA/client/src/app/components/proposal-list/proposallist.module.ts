import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { ProposallistRoutes } from './proposallist.routes';
import { ProposalListComponent } from '../proposal-list/proposal-list.component';

@NgModule({
    declarations: [
        ProposalListComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(ProposallistRoutes)
    ]
})

export class ProposalListModule { }