import { Component, OnInit, HostListener } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { ClearProposalListData, GetProposalListData } from '../../actions/proposalList.action';
import { DatePipe } from '@angular/common';
import { ThrowStmt } from '@angular/compiler';
import filterObjectDateFormat from '../../utils/checkInOut/filterObjectDateFormat';
import localDate from '../../utils/date/localDate';
import { ReSetSorting, SetSorting } from '../../actions/checkInOut.action';
import { Subscription } from 'rxjs/Subscription';
import { ClearDownloadData, GetDownloadData } from '../../actions/download.action';
import downlaodcsv from '../../utils/downloadCSV/downlaodcsv';
import { Router } from '@angular/router';
import { createProposalPermission } from '../../utils/config/config';
import { 
  ResetProductProposalCartData
} from '../../actions/proposalData.action';

@Component({
  selector: 'app-proposal-list',
  templateUrl: './proposal-list.component.html',
  styleUrls: ['./proposal-list.component.css']
})
export class ProposalListComponent implements OnInit {
  Queryfilter: any = {
    activeversion: true
  };
  proposalListData: any = [];
  proposalListIsLoading: any = {};
  proposalListError: any = {};
  proposalListSubscription;

  filteredProposalListData: any = [];
  isBottom : boolean = false;
  proposalListCount :any = 0;
  total_proposals: number = 0;
  skip : number = 0;
  limit : number = 50;
  isLazyLoad : boolean = true
  islazyLoadLimiter : boolean = false;
  filters: any = {
    proposalid: "",
    submitstatus: "",
    begindate: "",
    enddate: "",
    version: "",
    customername: "",
    project: "",
    projectmanagername:"",
    servicelinename:"",
    oicrmbidnumber: "",
    activeversion: true
  };

  sortObj :any ={
    "createdAt" : -1
  };
  sortingIcon :any={};
  checkInOutSortingSubscription:Subscription;
  downloadSubscription:Subscription;
  donwloadDataListIsLoading:boolean;
  isShowAlert: boolean = false;
  alertState: string;
  alertMessage: string;
  permissions: any = [];
  userDetailSubscription;
  constructor(private store: Store<AppState>,private datePipe :DatePipe,
    private router:Router  
  ) { }
  public innerHeight: any;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;
    
  }
  ngOnInit() {
    this.innerHeight = window.innerHeight;
    let proposalRequestObj = {
      filter : this.Queryfilter,
      isProposalListPage : this.isLazyLoad,
      skip : 0,
      limit : this.limit,
      sort : this.sortObj
    }
    this.store.dispatch(new GetProposalListData(proposalRequestObj));
    this.proposalListSubscription = this.store.pipe(select(state => state.ProposalList))
      .subscribe(propListData => {
        const {
          proposalListData = [],
          proposalListLoading, proposalListCount = 0,
          total_proposals=0,
          errorState: { error = false, error_message },
        } = propListData;
        if (error) {
          this.showAlertMessage('error', error_message);
        }
        if(proposalListData && !proposalListLoading) {
          if(proposalListData.length < this.limit){
            this.islazyLoadLimiter = true;
          }
          this.proposalListCount = proposalListData.length || 0;
          this.proposalListData = proposalListData;
          this.total_proposals = total_proposals;
          this.replicateProposals();
          this.getDistinctProjects();
        }
        this.proposalListIsLoading = proposalListLoading;
      });

      this.checkInOutSortingSubscription = this.store.pipe(select(state => state.CheckInOut))
      .subscribe(data => {
        const {sort:{proposal}}=data;
          let obj={};
          for(let key in proposal){
            obj[key] = proposal[key];
          }
          this.sortObj = obj;
      });

      this.downloadSubscription = this.store.pipe(select(state => state.Download))
      .subscribe(data => {
        const { downloadData = [],isLoading} = data;
        this.donwloadDataListIsLoading = isLoading ;
        if(!isLoading && downloadData.length){
          let mappedData = this.mappDownloadData(downloadData);
          downlaodcsv('proposallist', mappedData);
        }
      });

      this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
      .subscribe(userDetails => {
        const { details } = userDetails;
        this.permissions = details['permission'] || [];
      });

  }

  mappDownloadData(downloadData) {
    let _downloadData = [...downloadData];
    return _downloadData.map(record => {
      const { proposalid = '', projectmanagername = '', oicrmbidnumber = '', submitstatus = '',
        begindate = '', enddate = '', project = '', version = '', customername = '',  servicelinename = ''
      } = record;
      let obj = {
        proposalid, customername, oicrmbidnumber, submitstatus, begindate, enddate, 
        version,  servicelinename, projectmanagername, project
      };
      return obj;
    })
  }
  
  ngOnDestroy(){
    this.proposalListSubscription.unsubscribe();
    this.checkInOutSortingSubscription.unsubscribe();
    this.downloadSubscription.unsubscribe();
    this.store.dispatch(new ReSetSorting());
  }

  replicateProposals(){
    this.filteredProposalListData = [];
    for (let data of this.proposalListData) {
      this.filteredProposalListData.push(data);
    }
  }

  getDistinctProjects(){
    let carry: any = []
    let newList = [];
    for (let data of this.filteredProposalListData){
      let disnitictCarry=[];
      for (let data2 of data.proposaldetails){
        if (
          data2['projectid'] && 
          (!carry || !carry.includes(data2.projectid))
        ){
           carry.push(data2.projectid);
           disnitictCarry.push({
             projectid:data2.projectid,
             projectstatus:data2.projectstatus,
             projectmanagername:data2.projectmanagername
           })
        }
      }
      carry = [];
      newList.push({
        ...data,
        distinctProjects : disnitictCarry,
        begindate : localDate(data.begindate, 'YYYY-MM-DD'),
        enddate : localDate(data.enddate, 'YYYY-MM-DD')
      });
    }
    this.filteredProposalListData = newList;
  }

  updateFilter(map: string, text) {
    this.filters[map] = text.target.value;
    this.filters['activeversion'] = true;
    this.queryFilter();
  }
  queryFilter(){
    this.skip = 0;
    let filterObjectWithNormalizedDate = filterObjectDateFormat(this.filters);
    this.store.dispatch(new ClearProposalListData());
    let proposalRequestObj = {
      filter : filterObjectWithNormalizedDate,
      isProposalListPage : this.isLazyLoad,
      skip : this.skip,
      limit : this.limit,
      sort : this.sortObj
    }
    this.proposalListData = [];
    this.isBottom = false;
    this.islazyLoadLimiter = false;
    this.store.dispatch(new GetProposalListData(proposalRequestObj));

  }
  onScroll(){
    if(
      this.skip <=  this.proposalListCount
    ){
      this.skip = this.proposalListCount;
      let proposalRequestObj = {
        filter : this.filters,
        isProposalListPage : this.isLazyLoad,
        skip : this.skip,
        limit : this.limit,
        sort : this.sortObj
      }
      this.store.dispatch(new GetProposalListData(proposalRequestObj));
    }
  }


  executeFilter() {
    let accumulator = [];
    for (let i = 0; i < this.proposalListData.length; i++) {
      let obj = this.proposalListData[i];
      let counts = 0;
      let match = 0;
      for (let k in this.filters) {
        let value = this.filters[k];
        if (value) {
          counts++;
          if (k !== 'project' && k !== 'begindate' && k !== 'enddate' && obj[k] && obj[k].toLowerCase().includes(value.toLowerCase()) ) {
            match++;
          }else if((k === 'begindate' || k === 'enddate')  && obj[k] && this.datePipe.transform(obj[k],'dd-MMM-yyyy').toLowerCase().includes(value.toLowerCase())){
            match++;
          }
          else if (k === 'project') {
            for (let data2 of obj.distinctProjects) {
              if (data2.projectid !== undefined) {
                if (data2.projectid.indexOf(value) !== -1 && accumulator.indexOf('distinctProjects') === -1) {
                  match++
                  break;
                }
              }
            }
          }
          else if(k === 'projectmanagername'){
            for (let data2 of obj.distinctProjects) {
              if (data2.projectmanagername !== undefined) {
                if (data2.projectmanagername.toLowerCase().includes(value.toLowerCase())){
                  match++
                  break;
                }
              }
            }
          }
        }
      }
      if (match === counts) {
        accumulator.push(obj);
      }
    }
    accumulator = this.dateSort(accumulator)
    this.filteredProposalListData = accumulator;

  }



  dateSort(arrayIn) {
    arrayIn.sort(function(a,b){
      return new Date(b.begindate).getTime() - new Date(a.begindate).getTime();
    });
    return arrayIn;
  }


  modalDisplayFunction = () => {
    let hasFilter = false;

    for (let _filter in this.filters) {
      if (_filter !== 'activeversion' && this.filters[_filter] != null && this.filters[_filter] != ""){
        hasFilter = true
        break;
      }
    }
    if ((this.proposalListIsLoading || this.donwloadDataListIsLoading) && !this.skip && !hasFilter) {
      return 'block';
    } else {
      return 'none';
    }
  }

  newTab(urlStr: string, directory: string){
    window.open(urlStr+directory, "_blank");
  }


  setSorting=(key)=>{
    let sort = {};
    sort['componentType'] = "proposal";
    sort['dataKey'] = key;
    this.store.dispatch(new SetSorting(sort))
  }
  
  sortData = (dataKey) => {
    this.setSorting(dataKey);
    this.skip = 0;
    this.store.dispatch(new ClearProposalListData());
    let proposalRequestObj = {
      filter : this.filters,
      isProposalListPage : this.isLazyLoad,
      skip : this.skip,
      limit : this.limit,
      sort : this.sortObj
    }
    this.store.dispatch(new GetProposalListData(proposalRequestObj));
    this.visualizeSortingIcon();
  }

  visualizeSortingIcon = () => {
    let sortData = JSON.parse(JSON.stringify(this.sortObj));
    let obj={}
    for(let key in sortData){
       if(sortData[key] === 1){
        obj[key] = "fa fa-arrow-up"
       }else if(sortData[key] === -1){
        obj[key] = "fa fa-arrow-down"
       }
    }
    this.sortingIcon = obj;  
  }

  downloadcsv = () => {
    let obj = {
      filter : this.filters,
      isProposalListPage : this.isLazyLoad,
      sort : this.sortObj
    }
    this.store.dispatch(new ClearDownloadData());
    this.store.dispatch(new GetDownloadData({ urlType: 'proposallist', payload: obj }))
  }

  triggerProposal = () => {
    this.store.dispatch(new ResetProductProposalCartData());
    this.router.navigate([`/proposal`])
  }

  removeAlertIcon() {
    this.isShowAlert = false;
  }

  showAlertMessage(state, message) {
    if (state === "error") {
      this.alertState = "alert-danger";
    } else {
      this.alertState = "alert-success";
    }
    this.alertMessage = message
    this.isShowAlert = true;
  }

  permissionDisplayCheck = () => {
    return this.permissions.includes(createProposalPermission);
  }
}
