import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-notification-unit',
  templateUrl: './notification-unit.component.html',
  styleUrls: ['./notification-unit.component.css']
})
export class NotificationUnitComponent implements OnInit {

  constructor() { }

  @Input() notification: any;
  @Output() markAsRead = new EventEmitter<any>();
  hover=false
  ngOnInit() {
  }

  getClass = () => {
    return `p-1 bg-${this.hover ? 'light' : 'white'}`
  }

  markAsReadFunction = (notification:any) => {
    this.markAsRead.emit(notification);
  }

}
