import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotificationUnitComponent } from './notification-unit.component';

describe('NotificationUnitComponent', () => {
  let component: NotificationUnitComponent;
  let fixture: ComponentFixture<NotificationUnitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotificationUnitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationUnitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
