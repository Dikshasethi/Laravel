import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadyCheckoutComponent } from './ready-checkout.component';

describe('ReadyCheckoutComponent', () => {
  let component: ReadyCheckoutComponent;
  let fixture: ComponentFixture<ReadyCheckoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReadyCheckoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadyCheckoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
