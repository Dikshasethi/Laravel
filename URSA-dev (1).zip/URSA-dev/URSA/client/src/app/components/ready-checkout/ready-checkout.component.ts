import { Component, OnInit, HostListener } from '@angular/core';
import {RemoveReadyToCheckoutData, GetReadyToCheckoutData,  ChangeReadyToCheckoutData,  CheckOutAsset, GetProjectStatus ,ClearCheckoutData} from '../../actions/checkout.action';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import tableStructure from '../../utils/checkInOut/readyToCheckoutTableStructure';
import * as $ from 'jquery';
import filterObjectDateFormat from '../../utils/checkInOut/filterObjectDateFormat';
import hardreserveSortMap from '../../utils/hardreserve/hardreserveSortMap';
import { Subscription } from 'rxjs/Subscription';
import { ReSetSorting } from '../../actions/checkInOut.action';
import { ClearDownloadData, GetDownloadData } from '../../actions/download.action';
import downlaodcsv from '../../utils/downloadCSV/downlaodcsv';

@Component({
  selector: 'app-ready-checkout',
  templateUrl: './ready-checkout.component.html',
  styleUrls: ['./ready-checkout.component.css']
})


export class ReadyCheckoutComponent implements OnInit {
  readyToCheckoutSubscription;
  hardreservedassets = [];
  tableBuilderList = tableStructure.slice()
  filterObj = {
    "checkedout":false,
    "checkedin":false
  };
  skip = 0;
  limit = 20;
  total_count = 0;
  tableViewHeight = 0;
  modalDisplay="none";
  readyToCheckoutError=false;
  checkInOutSortingSubscription:Subscription;
  sortObj : any ={
    updatedAt : -1
  };
  downloadSubscription:Subscription;
  filters : any = {};
  readytocheckoutLoading:boolean;
  donwloadDataListIsLoading:boolean;
  alertState: string;
  alertMessage: string;
  constructor( private store: Store<AppState>) { }
  public innerHeight: any;
  PersonalizationSubscription;
  personalizationTableColumnLoading: boolean = false;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;
    
  }
  ngOnInit() {    
    this.fetchReadyToCheckoutData({});  
    this.innerHeight = window.innerHeight;
    this.readyToCheckoutSubscription = this.store.pipe(select(state => state.CheckOutPageData))
    .subscribe(data => {
      const {
        readyToCheckOutData={}
      } = data;
      this.readytocheckoutLoading = readyToCheckOutData['readyToCheckoutDataLoading'];
      this.readyToCheckoutError = readyToCheckOutData['readyToCheckoutDataError'];
      this.hardreservedassets = this.initHardReservedData(readyToCheckOutData['hardReservedAssets']);
      this.total_count = readyToCheckOutData['hardReservedAssetsTotalCount'] || 0;
      this.getTableViewHeight();
    });   

    this.PersonalizationSubscription = this.store.pipe(select(state => state.TableColumnPersonalization))
    .subscribe(personalizationData => {
      const {
        personalizationTableColumnData:  {  personalizationTableColumnLoading },
      }  = personalizationData
        this.personalizationTableColumnLoading = personalizationTableColumnLoading;
    })
    
    this.checkInOutSortingSubscription = this.store.pipe(select(state => state.CheckInOut))
    .subscribe(data => {
      const {sort:{checkout}}=data;
        let obj={};
        for(let key in checkout){
          obj[hardreserveSortMap[key]] = checkout[key];
        }
        this.sortObj = obj;
    });

    this.downloadSubscription = this.store.pipe(select(state => state.Download))
    .subscribe(data => {
      const { downloadData = [],isLoading} = data;
      this.donwloadDataListIsLoading = isLoading;
      let hardReserveData = this.initHardReservedData(downloadData);
      if(!isLoading && hardReserveData.length){
        let mappedData = this.mappDownloadData(hardReserveData);
        downlaodcsv('hardreserve',mappedData );
      }
    });

  }
  

  ngOnDestroy(){
    this.readyToCheckoutSubscription.unsubscribe();
    this.checkInOutSortingSubscription.unsubscribe();
    this.downloadSubscription.unsubscribe();
    this.store.dispatch(new ClearCheckoutData());
    this.store.dispatch(new ReSetSorting());
  }


  mappDownloadData = (downloadData) => {
    let _downloadData = [...downloadData];
    return _downloadData.map(record => {
      const { projectnumber = '', projectmanagername = '', serialid = '', tagnumber = '',
        sourcelocation = '', sourcearea = '', proposalnumber = '', calloutid = '', assetcategory = '',
        subtype2 = '', businessunit = '', crmnumber = '', assetid = '', createdby = '' } = record;
      let obj = {
        projectnumber, projectmanagername, serialid, tagnumber, sourcelocation, sourcearea,
        proposalnumber, calloutid, assetcategory, subtype2, businessunit, crmnumber,
        assetid, createdby
      };
      return obj;
    })
  }

  fetchReadyToCheckoutData(filterObject) {
    let filterObjectWithNormalizedDate = filterObjectDateFormat(filterObject);
    let obj = {
        "skip": this.skip,
        "limit": this.limit,
        "filter": typeof filterObject === 'object' ? {
          ...this.filterObj,
          ...filterObjectWithNormalizedDate
        } : this.filterObj,
        "sort": {
          ...this.sortObj,
        },
        "hardReserverList": true
    }
    this.store.dispatch(new GetReadyToCheckoutData(obj));
  } 

  scrollFunction = (filterObject) => {
    let recordCount = this.hardreservedassets.length || 0;
    if(
      this.skip <= recordCount
    ){
      this.skip = recordCount;
      this.fetchReadyToCheckoutData(filterObject);
    }
  }

  filterFunction = (filterObject) => {
    this.skip = 0;
    this.store.dispatch(new ClearCheckoutData());
    this.fetchReadyToCheckoutData(filterObject);
    this.filters = filterObject;
  }

  refreshParent = (filterObject) => {
    this.limit = this.skip ? this.skip : this.limit;
    this.skip = 0;   
    this.store.dispatch(new ClearCheckoutData());
    this.fetchReadyToCheckoutData(filterObject);
  }

  initHardReservedData = (hardReserveList=[]) => {
    let list = [];
    for (let i = 0; i < hardReserveList.length; i++){
      const record = hardReserveList[i];
      const {reservation={}} = record;
      let obj = {
        ...record,
        ...reservation
      };
      delete obj['reservation'];
      list.push(obj);
    }
     return list;
  }

  getTableViewHeight = () => {
    let windowHeight = $(window).height();
    let readyToCheckoutHeader = $('#readyToCheckoutHeader').height();
    let appHeaderHeight = $('#appHeaderComponent').height();
    let nonTableVH = ((
      readyToCheckoutHeader + appHeaderHeight
      ) / windowHeight) * 100;
    this.tableViewHeight = 100 - nonTableVH;
  }

  sortingFunction = ()=>{
    this.skip = 0;
    this.store.dispatch(new ClearCheckoutData());
    this.fetchReadyToCheckoutData({});   
  }

  downloadcsv = () => {
    let filterObject = {...this.filters}
    let filterObjectWithNormalizedDate = filterObjectDateFormat(filterObject);
    let obj = {
        "filter": typeof filterObject === 'object' ? {
          ...this.filterObj,
          ...filterObjectWithNormalizedDate
        } : this.filterObj,
        "sort": {
          ...this.sortObj,
        },
        "hardReserverList": true
    }
    this.store.dispatch(new ClearDownloadData());
    this.store.dispatch(new GetDownloadData({ urlType: 'checkout', payload: obj }))
  }

  modalDisplayFunction = () =>{
    if(this.donwloadDataListIsLoading || this.personalizationTableColumnLoading){
      return 'block';
    }
    if (this.readytocheckoutLoading  && !this.skip) {
      return 'block';
    }
    return 'none';
  }

  triggerAlertMessage = (alertObject) => {
    this.alertMessage = alertObject.message;
    this.alertState = alertObject.state
  }

  resetErrorMessages() {
    this.alertMessage = '';
    this.alertState = ''
  }
}