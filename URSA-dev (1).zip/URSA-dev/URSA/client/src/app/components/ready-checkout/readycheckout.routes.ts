import { Routes } from '@angular/router';
import { ReadyCheckoutComponent } from './ready-checkout.component';

export const ReadyCheckoutRoutes: Routes = [
    { path: '', component: ReadyCheckoutComponent }
];