import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckInOutClientPanelComponent } from './check-in-out-client-panel.component';

describe('CheckInOutClientPanelComponent', () => {
  let component: CheckInOutClientPanelComponent;
  let fixture: ComponentFixture<CheckInOutClientPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckInOutClientPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckInOutClientPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
