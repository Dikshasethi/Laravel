import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-receiving-print-report',
  templateUrl: './receiving-print-report.component.html',
  styleUrls: ['./receiving-print-report.component.css']
})
export class ReceivingPrintReportComponent implements OnInit {
   
  constructor() { }
  @Input() receivingPrintData;
  ngOnInit() {
  }
  printReceivingReport() {
    let printReceivingContent = "";
    let previewWindow;
    printReceivingContent = document.getElementById('receivingReport').innerHTML;
    previewWindow = window.open('', '_blank', 'top=0,left=0,height=auto,width=auto');
    previewWindow.document.open();
    setTimeout(function () {
      previewWindow.document.write(`
        <html>
          <head>
            <title>Receiving Print Report</title>
            <style>
            body {
              font-family: Arial, Helvetica, sans-serif;
              font-size: 12px;
              color: #000;
            }
            table tr td {
              color: #000;
              font-weight: bold;
              padding: 2px;
              border-bottom:0px;
              border-right:0px;
            }
            table tr .tdContent td{
              font-weight: normal;
            }
            #table-2 tr td {
              color: #000;
              padding: 5px;
            }
              .border-top0{border-top:0px;}
              .border-btm0{border-bottom:0px;}
            </style>
          </head>
          <body onload='window.print()'>${printReceivingContent}</body>
        </html>`);
      previewWindow.document.close();
    }, 3000);

  }

}
