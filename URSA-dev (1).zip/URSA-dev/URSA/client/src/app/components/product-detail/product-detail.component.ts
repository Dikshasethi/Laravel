import { Component, OnInit, Input, SimpleChange, ViewChild, Output, EventEmitter, ElementRef} from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import * as _ from 'lodash';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { Router } from '@angular/router';
import { trigger, style, state, transition, animate, group } from '@angular/animations';
import { SetImageActiveList, GetImageFile, CancelImageUpload, SubmitFileToApi, CallChangeThumbnail, SendRemoveImage } from '../../actions/imageUpload.actions';
import fileToBase64 from '../../utils/fileUpload/fileToBase64';
import { ClearProductsHierarchyObject, GetHieararchy, GetProductCalendar, SetHieararchy } from '../../actions/product.actions';
import localDate from '../../utils/date/localDate';
import imageTags from '../../utils/images/imageTags';
import { CalendarComponentComponent } from '../calendar-component/calendar-component.component';
import { SetHardReserveCart } from '../../actions/proposalPageData.action';
import { SetProductProposalCartData } from '../../actions/proposalData.action';
import { imageUploadPermission } from '../../utils/config/config';
import { AssetModel } from '../../utils/proposal/assetdetailModel';
import { createProposalPermission } from '../../utils/config/config';

interface preImageData {
  index: number,
  lastModified: number,
  lastModifiedDate: Date,
  name: string,
  size: number,
  to64: string,
  type: string,
  webkitRelativePath: string,
  isHover: boolean,
  makeThumbnail: boolean,
  isPreImageThumbnail: boolean
}
@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css'],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        'max-height': '100%', 'opacity': '1', 'visibility': 'visible'
      })),
      state('out', style({
        'max-height': '0px', 'opacity': '0', 'visibility': 'hidden'
      })),
      transition('in => out', [group([
        animate('400ms ease-in-out', style({
          'opacity': '0'
        })),
        animate('600ms ease-in-out', style({
          'max-height': '0px'
        })),
        animate('700ms ease-in-out', style({
          'visibility': 'hidden'
        }))
      ]
      )]),
      transition('out => in', [group([
        animate('1ms ease-in-out', style({
          'visibility': 'visible'
        })),
        animate('600ms ease-in-out', style({
          'max-height': '100%'
        })),
        animate('800ms ease-in-out', style({
          'opacity': '1'
        }))
      ]
      )])
    ]),

    //Filters
    trigger('slideInOutF', [
      state('in', style({
        'max-height': '1100px', 'opacity': '1', 'visibility': 'visible'
      })),
      state('out', style({
        'max-height': '85px', 'opacity': '1', 'visibility': 'visible', 'overflow': 'hidden'
      })),
      transition('in => out', [group([
        animate('200ms ease-in-out', style({
          'opacity': '1'
        })),
        animate('300ms ease-in-out', style({
          'max-height': '85px'
        })),
        animate('200ms ease-in-out', style({
          'visibility': 'visible'
        }))
      ]
      )]),
      transition('out => in', [group([
        animate('400ms ease-in-out', style({
          'visibility': 'visible'
        })),
        animate('600ms ease-in-out', style({
          'max-height': '1100px'
        })),
        animate('700ms ease-in-out', style({
          'opacity': '1'
        }))
      ]
      )])
    ])

  ]
})
export class ProductDetailComponent implements OnInit {

  @Input() data: any;
  @Input() index: any;
  @Input() productList:any;
  @Input() totalCount: any;
  @Input() searchStartDate: any;
  @Input() searchEndDate: any;
  @Input() imageActiveList: any;
  @Input() thumbnailMap: any;
  @Input() fileDataObject: any;
  @Input() imageUploadErrorList: any;
  @Input() hardReserveMode: any;
  @Input() activeView: any;
  @Input() reservationCart: any;
  @Input() maxHrCount: any;
  @Input() proposalCart: any;
  @Input() isProposalMode: any;
  @Output() productProposalEvent = new EventEmitter<any>();
  @Output() toggleCart = new EventEmitter<{ data: any, index: number }>();
  @Output() toggleWatchList = new EventEmitter<{ data: any, index: number }>();
  @Output() viewFullCalendar = new EventEmitter<any>();
  @Output() deletedImageProduct = new EventEmitter<any>();
  @ViewChild(CalendarComponentComponent) calendarComponentComponent: CalendarComponentComponent;

  productSubscription: any;
  product = {};
  productCount = 0;
  displayfullcalendar = 'none';
  userSubscription: any;
  userDetailSubscription: any;
  browserLocale;
  hasImageUploadPermission;
  proposalDetailRecord: AssetModel;
  indexedData: any = [];
  imgRdy: boolean = false;
  imageMap = new Map<number, object[]>();
  imageSelectMap = new Map<number, preImageData[]>();
  isImageModal: boolean = false;
  mainImageSelectMap = -1;
  modalImage: any = "";
  modalIndex: any;
  preImageThumbnailMap = new Map<number, preImageData>(); //make sure to remove from here when removing pre image
  ByteToMb_7Mb = 5000000
  _calendarMap: any = {};
  index_calendarWaitSpot: any = -1;;
  component_calendarWaitSpot: any;
  calComp: Component;
  waitForCalendarMap: boolean = false;
  calendarDataReady: boolean = false;
  imageSubmitRefreshTracker = 0;
  isSubmitImage = false;
  cartModalDisplay = 'none';
  cartTitle: string = "";
  cartDescription: string = "";
  selectedAsset: any;
  renderOnlyOnce = true;
  isIconsOnHover = false;
  permissions: any = [];

  constructor(
    private store: Store<AppState>,
    private router: Router,
    private _sanitizer: DomSanitizer,
    private htmlElement: ElementRef
  ) { }


  ngOnInit() {
    this.browserLocale = window.navigator.languages[0]
    this.product = this.data || {};
    if (Object.keys(this.product).length && this.product.hasOwnProperty('certification') &&
        this.product['certification'].length) {
        this.product['certification'] = this.product['certification'].sort(function(certObj1, certObj2) {
        return new Date(certObj2.expiryDate).getTime() - new Date(certObj1.expiryDate).getTime();
      });
    }
    this.productCount = (this.data && this.data.length) || 0;
    this.totalCount = this.totalCount || 0;
    this.userSubscription = this.store.pipe(select(state => state.User))
      .subscribe(user => {
        if (this.product['animationState'] == "in") {
          this.product['animationState'] = "out"
          this.product['showIcon'] = false

        }

      })

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
      .subscribe(userDetails => {
        const { details } = userDetails;
        this.permissions = details['permission'] || [];
        if (details['permission'] && details['permission'].includes(imageUploadPermission)) {
          this.hasImageUploadPermission = true;
        } else {
          this.hasImageUploadPermission = false;
        }
      });

    this.productSubscription = this.store.pipe(select(state => state.Product))
      .subscribe(productData => {
        const { productList, calendarMap, calendarDataIsLoading } = productData;
        this.productList = productList;
        this.productCount = productList && productList.length || 0;
        if (!calendarDataIsLoading && this.waitForCalendarMap) {
          this.waitForCalendarMap = false;
          this._calendarMap = calendarMap;
          this.calendarDataWaitListHandshake();

        }

      })
  }

  ngOnChanges(changes: SimpleChange) {
    let totalCount = changes['totalCount'];

    if (totalCount) {
      if (!_.isEqual(totalCount.currentValue, totalCount.previousValue)) {
        this.totalCount = totalCount.currentValue || 0;
      }
    }

    if (this.productList && this.productList.length > 0) {

      this.findThumbnails();
      this.organizeImages();
      this.imageConsistency();
    }
  }

  ngDoCheck(){
    const scrollCalander = this.htmlElement.nativeElement.querySelector('.scrollcalander');
     if(scrollCalander !== null && this.renderOnlyOnce)
     {
      scrollCalander.scrollIntoView({behavior: "smooth",inline: "start"});
        this.renderOnlyOnce = false;
     }

     //for coursel active class fix for images and white indicator
     const coursel = this.htmlElement.nativeElement.querySelector('#productDetailCarousel'+this.index);
     if(coursel !== null) {     
        const courselImageElements = this.htmlElement.nativeElement.querySelectorAll('.carousel-item');
        const checkClass = [];
        for(let individualDiv of courselImageElements) {
          if(individualDiv.classList.contains('active')){
           checkClass.push(individualDiv.classList);
         }
        }
        if(checkClass.length == 0){
          courselImageElements[0].classList.add('active');
        }

        const courselIndicatorElements = this.htmlElement.nativeElement.querySelectorAll('.carousel-indicators > li');
        const checkLiClass = [];
        for(let individualLi of courselIndicatorElements) {
          if(individualLi.classList.contains('active')){
            checkLiClass.push(individualLi.classList);
          }
        }
        if(checkLiClass.length == 0){
          courselIndicatorElements[0].classList.add('active');
        }
     }
  }

  ngOnDestroy() {
    this.userSubscription.unsubscribe();
    this.productSubscription.unsubscribe();
    this.userDetailSubscription.unsubscribe();
  }


  calendarDataWaitListHandshake() {
    if (this._calendarMap[this.index_calendarWaitSpot]) {
      this.calendarComponentComponent.go12(this._calendarMap[this.index_calendarWaitSpot].timeseries || [], this._calendarMap[this.index_calendarWaitSpot].stateData || [], this._calendarMap[this.index_calendarWaitSpot].reservationData || [])
      this.index_calendarWaitSpot = -1
    }
  }

  setReservationCart = (index) => {
    this.store.dispatch(new SetHardReserveCart(index));
  }

  checkReservationCart = (index) => {
    return this.reservationCart.includes(index)
  }

  setProposalCart = (product: any, index: number) => {
    this.proposalDetailRecord = new AssetModel();
    // not choosen index beacuse data was overriding when navigating between view
    let proposalCartData = {
      ...this.proposalDetailRecord,
      assetid:   product.assetid || '',
      businessunit: product.bu || '',
      oiamsubtype2: product.subtype || '',
      view:   'productList', //keyword view to diiferentiate from which view
      itemtype: 'asset',
      productcategory: product.psamsubtypedescr,
      index: index,
      proposalMode: (this.isProposalMode) ? true : false // if true then added to cart when in proposal mode
    }
    this.store.dispatch(new SetProductProposalCartData(proposalCartData));
  }

  checkProposalCart = (product: any, index: number) => {
    if(this.proposalCart && this.proposalCart.length > 0) {
      return  this.proposalCart.some(cartValue => {
        return cartValue.view === 'productList' && cartValue.assetid === product.assetid 
        && cartValue.businessunit === product.bu && cartValue.oiamsubtype2 === product.subtype;
      })
    }
  }

  showHrCheckBox = (index) => {
    return this.hardReserveMode && (this.reservationCart.length < this.maxHrCount) || this.reservationCart.includes(index);
  }

  imageCarousel(index, direction, type) {
    let masterIndex = type === 'main' ? index : this.modalIndex;

    switch (direction) {
      case 'R':
        if (this.indexedData[masterIndex] &&
          ((this.indexedData[masterIndex].currentImageIndex + 1) >= this.indexedData[masterIndex].imageList.length)) {
          this.indexedData[masterIndex].currentImageIndex = 0;
        }
        else {
          this.indexedData[masterIndex].currentImageIndex++;
        }
        break;
      case 'L':
        if (this.indexedData[masterIndex] &&
          ((this.indexedData[masterIndex].currentImageIndex - 1) < 0)) {
          this.indexedData[masterIndex].currentImageIndex = this.indexedData[masterIndex].imageList.length - 1;
        }
        else {
          this.indexedData[masterIndex].currentImageIndex--;
        }
        break;

      default:
    }
  }

  mainImageHoverRegister(index) {
    this.mainImageSelectMap = index;
  }

  mainImageHoverUnRegister() {
    this.mainImageSelectMap = -1
  }

  checkIsHover(img) {
    return img.isHover
  }

  //Find and Set every product objects thumbnail id
  findThumbnails() {
    if (this.thumbnailMap && Object.keys(this.thumbnailMap).length) {

      let thumbnailKeys: any[] = [];
      for (let key in this.thumbnailMap) {
        thumbnailKeys.push(key)
      }
      if (
        this.product[thumbnailKeys[0]] &&
        this.product[thumbnailKeys[0]].assetimagedetails &&
        this.product[thumbnailKeys[0]].assetimagedetails.thumbnailindex &&
        this.product[thumbnailKeys[0]].assetimagedetails.thumbnailindex != -1
      ) {
        this.product[thumbnailKeys[0]].assetimagedetails.thumbnailindex = this.thumbnailMap[thumbnailKeys[0]];
      }
    }
  }
  //Add images and thumbsnails to respective places
  organizeImages() {
    this.indexedData = [];
    let preImgList: any = [];
    let thumbnailFilteredList = [];
    let thumbnailIndex: any;
    let tempIndex: number = 0;
    let hasThumbnail: boolean = false;

    for (let prod of this.productList) {
      let assetRefrencedThumbnailIndex = (prod.assetimagedetails && prod.assetimagedetails.thumbnailurl) || 'none';

      if ("imageList" in prod && prod["imageList"]) {

        for (let i = 0; i < prod['imageList'].length; i++) {

          let { imageUrl = 'none' } = prod.imageList[i];
          let temp = {
            id: imageUrl,
            index: i,
          }

          if (
            imageUrl &&
            assetRefrencedThumbnailIndex != 'none' &&
            imageUrl === assetRefrencedThumbnailIndex
          ) {
            thumbnailIndex = i;
            hasThumbnail = true;
          }
          preImgList.push(temp)
        }
        if (!hasThumbnail) {
          thumbnailFilteredList = preImgList;
        }

        //Filter Out list of found thumbnails
        //Then add thumbnail on top
        else {
          for (let refImageObject of preImgList) {
            if (
              refImageObject &&
              refImageObject.id &&
              refImageObject.id != assetRefrencedThumbnailIndex
            ) {
              thumbnailFilteredList.push(refImageObject)
            }
          }

          let thumbnailObj = {
            id: assetRefrencedThumbnailIndex,
            index: thumbnailIndex
          }
          thumbnailFilteredList.unshift(thumbnailObj)
        }
      }

      let obj = {
        productRefrence: prod,
        productIndex: tempIndex,
        imageList: thumbnailFilteredList.length > 0 ? thumbnailFilteredList : undefined,
        currentImageIndex: 0,
        thumbnailIndex: assetRefrencedThumbnailIndex,
        hasThumbnail: (assetRefrencedThumbnailIndex != -1) ? true : false
      }
      this.indexedData.push(obj)
      preImgList = [];
      thumbnailFilteredList = [];
      thumbnailIndex = undefined;
      hasThumbnail = false;
      tempIndex++;

    }

  }

  imageConsistency() {
    this.imgRdy = true; //Makes Sure There is Image Data so We Dont Error
    let allKeys = Array.from(this.imageMap.keys());

    for (let key of allKeys) { //Makes Sure PreImage and The State Match Up

      if (!this.fileDataObject[key] || _.isEmpty(this.fileDataObject[key])) {
        let emptyArray: object[] = [];
        this.imageMap.set(key, emptyArray)
      }
    }
  }

  togglemodalindex = (indexToward) => {
    if (
      this.product && this.product['imageList'] && 
      this.product['imageList'].length > 0
    ) {
       let totalImageCount = this.product['imageList'].length;
       if(this.modalIndex < totalImageCount - 1 && this.modalIndex > 0 ) {
         this.modalIndex =  indexToward === 'L' ? this.modalIndex - 1 : this.modalIndex + 1
       }else if(this.modalIndex == 0 && totalImageCount > 1) {
         this.modalIndex =  indexToward === 'L' ? totalImageCount - 1 : this.modalIndex + 1
       }else if(this.modalIndex == totalImageCount - 1) {
         this.modalIndex = indexToward === 'L' ? this.modalIndex - 1 : 0
       }
    }
  }

  imageDataParse = () => {
    if (
      this.product && this.product['imageList'] && 
      this.product['imageList'].length > 0
    ) {
      let image = this.product['imageList'][this.modalIndex]
        if (image && image.imageUrl) {
          let tempSignedUrl = image.signedUrl_compressed;
          return tempSignedUrl;
        }
    }  
    return './assets/images/no-image.png';
  }

  toggleImageModal(imageIndex) {
    this.isImageModal = !this.isImageModal;
    if (this.isImageModal) {
      this.modalIndex = imageIndex;
    }
    else {
      this.modalImage = "";
    }
  }

  makeMainThumbnail(index) {
    if (
      this.product && 
      this.product['imageList'] && 
      this.product['imageList'].length > 0
    ) {

      let imageData = this.product['imageList'][index]
      let { imageUrl = '' } = imageData;
      let imageObject: object = {
        assetid: this.product['assetid'] || '',
        businessunit: this.product['bu'] || '',
        newThumbnailUrl: imageUrl
      }
      this.store.dispatch(new CallChangeThumbnail(({
        file: JSON.stringify(imageObject),
        view: 'detailsView',
        index
      })))
    }
  }

  removeMainImage = (product, index) => {
    if (
      this.product &&
      this.product['imageList'] &&
      this.product['imageList'][index]
    ) {
      let imageData = this.product['imageList'][index]
      let { imageUrl = '' } = imageData
      let imageObject = {
        assetid: product.assetid || '',
        businessunit: product.bu || '',
        imageUrl: imageUrl
      }
      this.store.dispatch(new SendRemoveImage(({
        data: imageObject,
        view: 'detailsView',
        index
      })))

      let deletedImageProductObj = {
        product : product,
        index: this.index
      }
      this.deletedImageProduct.emit(deletedImageProductObj);
    }
  }

  preImageOnHover(img) {
    img.isHover = !img.isHover;

  }

  iconsOnHover() {
    this.isIconsOnHover = !this.isIconsOnHover;
  }

  getImageTo64(img) {
    return img.to64
  }

  preImageSelectHandler(index, imageInterfaceObj) {
    if (index && this.imageSelectMap.get(index)) {
      let imageObjCompare = this.imageSelectMap.get(index)
      if (imageObjCompare != imageInterfaceObj) {
        this.imageSelectMap.delete(index);
        this.imageSelectMap.set(index, imageInterfaceObj)
      }
      else {
        this.imageSelectMap.delete(index);
      }
    }
    else {
      this.imageSelectMap.set(index, imageInterfaceObj)
    }
  }

  assetImageFinder = (index) => {
    if (this.fileDataObject[index]) {
      return this.fileDataObject[index];
    }
    return '';
  }

  preImageMakeThumbnail = (index, imgObj) => {
    let preImages: object[] = this.assetImageFinder(index);
    imgObj.isPreImageThumbnail = true;
    this.preImageThumbnailMap.set(index, imgObj);
  }

  removePreImageUpload = (view, index, imgObj) => {
    let imgName = imgObj.name;
    if (
      index &&
      this.preImageThumbnailMap.get(index) &&
      _.isEqual(this.preImageThumbnailMap.get(index), imgObj)
    ) {
      this.preImageThumbnailMap.delete(index)
    }

    this.store.dispatch(new CancelImageUpload({ view, index, imgName }))

    let temp = this.imageMap.get(index);
    for (let i = 0; i < temp.length; i++) {

      if (temp[i]['name'] == imgName) {

        temp.splice(i, 1)
      }
    }

    this.imageMap.set(index, temp)
  }

  preImageCheck(index, neededData) {
    if (index && this.imageSelectMap.get(index)) {
      let imgObj = this.imageSelectMap.get(index)
      return imgObj[neededData];
    }
  }

  submitImageFile = async (product, index) => {
    let imageFile = this.assetImageFinder(index);
    let imageObject = {}
    let isThumbnail = this.preImageThumbnailMap.get(index) ? true : false;
    let thumbnailRefrence = this.preImageThumbnailMap.get(index) || undefined;
    let thumbnailLocation: Number;
    let exportImagesList: any = [];

    if (imageFile.length > 0) {
      for (let i = 1; i < imageFile.length; i++) {

        //Find Location Of Pre Image Thumbnail
        //Backend Will Use This Index To Add thumbnail To DB.
        if (thumbnailRefrence) {
          if (imageFile[i].name == thumbnailRefrence.name) {
            thumbnailLocation = i - 1; //-1 Due To Init Placeholder
          }
        }

        if (imageFile[i] != 'init') {
          let processedImage = await this.exportReadyImageList(imageFile[i], product);
          if (product.bu && product.assetid) {
            let newGroupId = `${product.assetid}${product.bu}`;
            processedImage['groupId'] = newGroupId
          }
          exportImagesList.push(processedImage)
        }
      }

      imageObject = {
        assetid: product.assetid || '',
        businessunit: product.bu || '',
        imageList: exportImagesList,
        isThumbnail: isThumbnail,
        thumbnailArrayIndex: thumbnailLocation
      }
    }
    this.isSubmitImage = true;
    this.store.dispatch(new SubmitFileToApi({
      file: JSON.stringify(imageObject),
      view: 'detailsView',
      index
    }))
    if (isThumbnail) { this.preImageThumbnailMap.delete(index) }
    this.imageSelectMap.clear()
  }

  loadTags(assetData, keys) {
    let loadedTags = [];
    for (let tag of keys) {
      loadedTags.push(assetData[tag])
    }
    return loadedTags;
  }

  //Transfer Images to API Ready List
  exportReadyImageList = async (imgObj, product) => {
    let base64 = await fileToBase64(imgObj);
    let tags = this.loadTags(product, imageTags);

    let indexOfDash = imgObj.type.lastIndexOf('/');
    let _fileExtension = imgObj.type.substring(indexOfDash + 1);
    let _fileName = imgObj.name.substring(0, imgObj.name.lastIndexOf('.'));

    let obj = {
      imageBase64: base64,
      imageType: 'asset',
      fileName : _fileName,
      fileExtension : _fileExtension,
      category : 'asset',
      filetype : 'image',
      tags : tags
    }

    return obj;
  }

  setToImageActiveList = (view, index) => {
    this.store.dispatch(new SetImageActiveList({ view, index }));

  }

  getImageFile = async (event, view, index) => {
    let foundLargeFile = false;
    for (let file of event.target.files) {
      if (file.size < this.ByteToMb_7Mb) {
        file.index = index;
        file.isNewThumbnail = false;
        let imgObj = await this.toImageInterfaceObj(file);
        if (this.imageMap.get(index)) {
          let tempArray = this.imageMap.get(index)
          this.imageMap.set(index, tempArray.concat(imgObj))
        }
        else {
          let tempArray = [];
          tempArray.push(imgObj)
          this.imageMap.set(index, tempArray)
        }

        this.store.dispatch(new GetImageFile({
          imageFile: file,
          view,
          index
        }));
      }
      else {
        foundLargeFile = true;
      }
    }
  }

  toImageInterfaceObj = async (imgFile) => {
    let imgObj: preImageData = {
      index: imgFile.index,
      lastModified: imgFile.lastModified,
      lastModifiedDate: imgFile.lastModifiedDate,
      name: imgFile.name,
      size: imgFile.size,
      to64: "",
      type: imgFile.type,
      webkitRelativePath: imgFile.webkitRelativePath,
      isHover: false,
      makeThumbnail: false,
      isPreImageThumbnail: false
    };
    let temp64 = await fileToBase64(imgFile);
    imgObj.to64 = <string>temp64;

    return imgObj
  }

  column3Class = () => {
    if (this.hardReserveMode) {
      return 'col-lg-9 col-md-9 col-sm-9 col-xs-10'
    } else if(this.activeView === 'details' && !this.hardReserveMode){
      return 'col-lg-10 col-md-10 col-sm-10 col-xs-11'
    }else{
      return 'col-lg-9 col-md-9 col-sm-9 col-xs-10'
    }
  }

  openCartModal(product) {
    this.toggleCart.emit(product)
  }

  statusClassFunction = (product) => {
    return `badge-${this.badgeClassParser(product.statustext, product.pastduecheckout)}`
  }

  badgeClassParser = (status, pastDue) => {
    if (status) {
      let statusText;
      let statusList = status.split(' ');
      if (statusList && statusList.length > 0) {
        statusText = statusList[0];
      } else {
        statusText = status
      }
      if (pastDue) {
        statusText = 'past';
      }
      let statusMap = {
        Available: 'available',
        Checked: 'Checked',
        Reserverd: 'warning',
        Status: 'secondary',
        Hard: 'hardReserved',
        checked: 'danger',
        Disposed: 'danger',
        past: 'danger',
        "On-Hire": 'On-Hire'
      }
      return statusMap[statusText];
    }
    return 'secondary'
  }

  checkAssetDisposed = () => {
    let status = 'Disposed';
    return `badge-${this.badgeClassParser(status, '')}`;
  }


  parseCheckInOut = (projects) => {
    if (projects) {
      let list, copy;
      let subAccumulator = [];
      let pushedIndex = [];
      if (!Array.isArray(projects)) {
        copy = Object.assign({}, projects);
        list = [copy];
      } else {
        copy = projects.slice();
        list = copy
      }

      for (let i = 0; i < list.length; i++) {
        let project = list[i];
        if (this.isWithinSearchRange(project, 'checkInOut')) {
          subAccumulator.push(project);
          pushedIndex.push(i);
        }
      }
      return subAccumulator;
    }
    return [];
  }

  isWithinSearchRange = (obj, field) => {
    if (obj) {
      let searchStartDate = new Date(this.searchStartDate).getTime();
      let searchEndDate = new Date(this.searchEndDate).getTime();
      let start, end;
      if (field === 'workOrder') {
        const { startdate = '', enddate = '' } = obj;
        start = new Date(startdate).getTime();
        end = new Date(enddate).getTime();
      } else if (field === 'checkInOut') {
        const { checkoutDate = '', estimatedCheckinDate = '', actualCheckinDate = '' } = obj;
        start = new Date(checkoutDate).getTime();
        end = actualCheckinDate ? new Date(actualCheckinDate).getTime() : new Date(estimatedCheckinDate).getTime();
      }
      if (searchStartDate < start && end < searchEndDate) {
        return true;
      } else if (searchStartDate === start) {
        return true;
      } else if (searchStartDate === end) {
        return true;
      } else if (searchEndDate === start) {
        return true;
      } else if (searchStartDate > start && end > searchEndDate) {
        return true;
      } else if (searchStartDate > start && end > searchStartDate && end < searchEndDate) {
        return true;
      } else {
        return false;
      }
    }
    return false;
  }


  showWorkOrderTable = (workOrders) => {
    let boolean;
    if (!Array.isArray(workOrders)) {
      if (this.isWithinSearchRange(workOrders, 'workOrder')) {
        boolean = true;
      } else {
        boolean = false;
      }
    } else if (Array.isArray(workOrders)) {
      let counter = 0
      for (let i = 0; i < workOrders.length; i++) {
        let workOrder = workOrders[i];
        if (this.isWithinSearchRange(workOrder, 'workOrder')) {
          counter++;
        }
      }
      if (counter > 0) {
        boolean = true;
      } else {
        boolean = false
      }
    }
    return boolean;
  }

  workOrderParser = (workOrders) => {
    let accumulator = [];
    if (workOrders) {
      if (!Array.isArray(workOrders)) {
        if (this.isWithinSearchRange(workOrders, 'workOrder')) {
          accumulator.push(workOrders);
        }
      } else if (Array.isArray(workOrders)) {
        for (let i = 0; i < workOrders.length; i++) {
          let workOrder = workOrders[i];
          if (this.isWithinSearchRange(workOrder, 'workOrder')) {
            accumulator.push(workOrder);
          }
        }
      }
      return accumulator;
    }
    return accumulator;
  }


  localDateWrapper = (date) => {
    return date ? localDate(date, 'DD-MMM-YYYY') : '';
  }

  showCheckInOutTable = (checkInOutList) => {

    if (checkInOutList && this.parseCheckInOut(checkInOutList).length > 0) {
      let checkInOut = checkInOutList[0];
      let { checkoutDate = '', estimatedCheckinDate = '', actualCheckinDate = '' } = checkInOut;
      let startDate = checkoutDate;
      let endDate = actualCheckinDate ? actualCheckinDate : estimatedCheckinDate;
      if (startDate && endDate) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  ShowCalenderPopup() {
    this.viewFullCalendar.emit({ data: this._calendarMap, index: this.index });
  }

  toggleShowDiv(calComponent) {
    if(this.product['animationState'] != 'in'){
      this.waitForCalendarMap = true;
      this.index_calendarWaitSpot = this.index;
      this.component_calendarWaitSpot = this.calendarComponentComponent;
      let getCalObj = {
        bu: this.product['bu'],
        assetid: this.product['assetid'],
        _index: this.index
      }
      this.store.dispatch(new GetProductCalendar(getCalObj));

      if (!this.product['proposalList']) {
        let obj = {
          "index": this.index,
          "view": "detail",
          "assetid": this.product['assetid'],
          "bu": this.product['bu']
        }
        this.productProposalEvent.next(obj);
      }
    }
    this.product['animationState'] = this.product['animationState'] === 'out' ? 'in' : 'out';
    this.product['showIcon'] = !this.product['showIcon'];
  }


  trackByIndex = (index): string => {
    if(!index) return undefined;
      return index;
  };

  // Hierarchy function Here
  displayHierarchy(assetid, bu) {
    this.store.dispatch(new ClearProductsHierarchyObject());
    this.productList.map((val, index) => {
      if (index == this.index) {
        val.showIcon = true
      } else {
        val.showIcon = false
      }
    })

    let obj = {
      assetid: assetid,
      businessunit: bu
    }
    this.store.dispatch(new GetHieararchy(obj));
  }

  openWatchListModal(product) {
      this.toggleWatchList.emit(product)
  }

  permissionDisplayCheck = () => {
    return this.permissions.includes(createProposalPermission);
  }

}
