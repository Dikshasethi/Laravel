import { Component , OnInit , Input , Output , EventEmitter } from '@angular/core';
import * as _ from 'lodash';
import { AppState } from '../../models/appState';
import { Store, select } from '@ngrx/store';
import {hardReservePermission,cancelHardReservePermission} from '../../utils/config/config';

@Component({
  selector: 'app-hard-reserve-assets-table',
  templateUrl: './hard-reserve-assets-table.component.html',
  styleUrls: ['./hard-reserve-assets-table.component.css','../ready-checkout/ready-checkout.component.css']
})
export class HardReserveAssetsTableComponent implements OnInit  {

  constructor(private store: Store<AppState>, ) { }
  hardReserveData;
  isLoading;
  filterByObj:any={};
  maxLength = 60;
  isShowStatus = false;
  hrPermission;
  cancelhrPermission;
  userDetailSubscription;
  hrRemovalObj;
  @Input() fromProposal : any;
  @Output() assetSelected = new EventEmitter<any>();
  @Output() allAssetSelected = new EventEmitter<any>();
  @Output() removeHardReservation = new EventEmitter<any>();

  @Output() confirmCheckout = new EventEmitter<any>();
  @Output() cancelCheckout  = new EventEmitter<any>();
  @Output() filter = new EventEmitter<any>();

  @Input() checkoutConfirmationModalDisplay :string;

  @Input()
  set readyToCheckoutTableData( val ) {
    if(val){
      this.hardReserveData = val.obj;
      this.hrRemovalObj={};
      if(this.hardReserveData && this.hardReserveData.length>0){
        this.dataFormatter();
        this.arrangeHardReserveData();
      }
      this.isLoading = val.isLoading;
      this.isShowStatus = val.isShowStatus;
    }    
  }

  dataFormatter(){
    this.hardReserveData.forEach((obj, i) => {
      obj['maxLength'] = this.maxLength;
      obj['startdate']=obj.startdate || "";
      obj['enddate']=obj.enddate || "";
      obj['projectId'] = obj['projectId'] || "";
      obj['projectmanagername'] = obj['projectmanagername'] || "";
      obj['serialnumber'] =obj['serialnumber'] || "";
      obj['tagnumber'] = obj['tagnumber'] || "";
      obj['assetDesc'] = obj['assetDesc'] || "";
      obj['sourcelocation'] = obj['sourcelocation'] || "";
      obj['sourcearea'] =obj['sourcearea'] || "";
      obj['category'] =obj['category'] || "";
      obj['subtype2'] =obj['subtype2'] || "";
      obj['businessunit'] =obj['businessunit'] || "";
      obj['proposalnumber'] =obj['proposalnumber'] || "";
      obj['proposaldescription'] =obj['proposaldescription'] || "";
      obj['crmnumber'] =obj['crmnumber'] || "";
      obj['assetid'] =obj['assetid'] || "";
      obj['createdby'] =obj['createdby'] || "";
      if( !obj.isShowWarning){
        if(obj.checkOutFail)
          obj['isShowWarning']=true;
        else
          obj['isShowWarning']=false;
      }
    });
  }

  onAssetSelection(data,index){
    data['index'] = index;
    this.assetSelected.next(data);
  }

  onAllAssetSelection(event){
    this.allAssetSelected.next(event.target.checked);
  }

  showMoreLess(i,label){
    if(label=="more")
      this.hardReserveData[i].maxLength = this.hardReserveData[i].assetDesc.length ;
    else if(label=="less")
      this.hardReserveData[i].maxLength = this.maxLength;
  }

  arrangeHardReserveData(){
    const hrData = this.hardReserveData.filter(data => (!data.checkedin && !data.checkedout));
    const otherData = this.hardReserveData.filter(data => (data.checkedin || data.checkedout));
    this.hardReserveData = hrData.concat(otherData);
  }

  ngOnInit() {
    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(userDetailObj => {
      const {
        details
      } = userDetailObj;
      this.hrPermission = details['permission'] && details['permission'].includes(hardReservePermission);
      this.cancelhrPermission = details['permission'] && (details['permission'].includes(hardReservePermission) || details['permission'].includes(cancelHardReservePermission));
    })
  }

  removeReservation = (data) => {
    let obj = [{	
      proposalNumber : data.proposalnumber,
      assetId : data.assetid,
      hrStartDate : data.startdate,
      hrEndDate : data.enddate,
      projectNumber : data.projectnumber,
      pdid : data.pdid,
      calloutid :data.calloutid,
      businessUnit:data.businessunit
    }]
    this.hrRemovalObj = {assetList : obj}
  }

  finalizeHrRemoval = () => {    
    this.removeHardReservation.next(this.hrRemovalObj);
  }

  cancelHrRemoval = () => {
    this.hrRemovalObj = {};
  }

  _confirmCheckout(){
    this.confirmCheckout.next('confirm');
  }
  _cancelCheckout(){
     this.cancelCheckout.next('cancel');
  }

  updateFilter(name:string,event:any){
    this.filter.next({name:name,event:event.target.value});
  }
}
