import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HardReserveAssetsTableComponent } from './hard-reserve-assets-table.component';

describe('HardReserveAssetsTableComponent', () => {
  let component: HardReserveAssetsTableComponent;
  let fixture: ComponentFixture<HardReserveAssetsTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HardReserveAssetsTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HardReserveAssetsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
