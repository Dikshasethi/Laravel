import { Component, OnInit, ViewChild } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { form_template, action_buttons } from '../../utils/receiving/receiving_template';
import { receivingDetails } from '../../utils/receiving/receivingdetails_template';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { AppState } from '../../models/appState';
import { GetReceivingData, ResetReceivingRecord, SetReceivingMode, CreateReceivingData, UpdateReceivingData, Received } from '../../actions/receiving.actons';
import { ReceivingModel, ReceivingDetailsModel } from '../../utils/receiving/receivingModel';
import { Subscription } from 'rxjs';
import * as _ from 'lodash';
import { DestroyAutocompleteList, GetCheckoutAutocomplete, GetLocationAreasCheck,GetUOMAutoComplete } from '../../actions/autocomplete.actions';
import dateValidation from '../../utils/date/dateValidator';
import { receivingFilter } from '../../utils/receiving/receivingFilter';
import { DragulaService } from 'ng2-dragula';

import { CheckinAssets } from '../../actions/checkInOut.action';
import clientPanelStructure from '../../utils/checkInOutClientDetails/panelStructure';

import { ReceivingPrintReportComponent } from '../receiving-print-report/receiving-print-report.component';
import localDate from '../../utils/date/localDate';

import defaultValues from '../../utils/autoComplete/defaultValues'
import { createReceivingPermission, checkinPermission, receivePermission , cancelReceivePermission } from '../../utils/config/config';
import downlaodcsv from '../../utils/downloadCSV/downlaodcsv';

@Component({
    selector: 'app-receiving',
    templateUrl: './receiving.component.html',
    styleUrls: ['./receiving.component.css']
})

export class ReceivingComponent implements OnInit {
    formTemplate: any = form_template;
    actionButtons: any = action_buttons;
    receivingDetails: any = receivingDetails;
    receivingFilter: any = receivingFilter;

    receivingObject: ReceivingModel = new ReceivingModel();
    receivingdetailRecord: ReceivingDetailsModel = new ReceivingDetailsModel();
    existingReceivingRecord: ReceivingModel = new ReceivingModel();
    details: ReceivingDetailsModel[] = [];

    addedReceivingSubScription: Subscription;
    receivingSubScription: Subscription;
    userDetailSubscription: Subscription;
    autocompleteCheckoutSubscription: Subscription;
    checkInOutSubscription: Subscription;

    receiving_disableObj: any = {};
    editableRecordInput: any = {};
    selectedRecord: any = [];
    receivingid: string;
    modalDisplay = 'none';
    showDublError: boolean = false;
    editMode: boolean;
    editindex: number;
    previousValue: any;
    isShowAlert: boolean = false;
    alertState: string;
    alertMessage: string;
    isDisplayTypeBtn: boolean = false;
    receivingdate: any = moment().format('YYYY-MM-DD');
    previousUrl: string;
    receivingMode: boolean;
    receivingConfirmationModal: string = "none";
    empName: string;
    empId: string;
    suggestionList: any = [];
    permissions: any = [];
    receivingPermission = 'EMO';
    isReceived: boolean = false;
    displayKey: string;
    mode: String = 'create';

    custodainName: string;
    custodianId: string;
    displayClientPanelModal = false;
    panelStructureList = [];
    clientPanel = {};
    currentAction = '';

    printModal = 'none';
    receivingData: any = {};
    printData: any[] = [];
    successListCount: number = 0;
    failListCount: number = 0;
    totalCount: number = 0;
    disableHeaderCheckbox: boolean;
    isSelectedeaderCheckbox: boolean;

    isGetAreaCount: boolean = true;
    autocompleteSubscription: Subscription;
    cachedAreaList = [];
    maxLength: number = 20;
    textDisplayLengthMap = {};
    receiveActionDisabled: boolean;
    checkinActionDisabled: boolean;
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private dragulaService: DragulaService,
        private store: Store<AppState>) {
        this.dragulaService
            .drop()
            .subscribe(value => {
                this.updateItemNo();
            });
    }
    @ViewChild(ReceivingPrintReportComponent) receivingPrintReportComponent: ReceivingPrintReportComponent;
    ngOnInit() {
        this.initUiBuilder(clientPanelStructure.slice(), 'panelStructureList');
        this.receivingid = this.route.snapshot.paramMap.get('receivingid');
        if (this.receivingid) {
            this.fetchReceivingDetails(this.receivingid);
            this.mode = "edit";
        }
        this.addedReceivingSubScription = this.store.pipe(select(state => state.Receiving.addedReceivingData))
            .subscribe(data => {
                if (data) {
                    const { receivingMode, addedReceivingData = [], previousUrl, receivingHeaderRecord } = data;
                    this.receivingMode = receivingMode;
                    this.details = addedReceivingData;
                    this.previousUrl = previousUrl;
                    if (!this.receivingid && !this.receivingMode && receivingHeaderRecord) {
                        this.receivingObject = receivingHeaderRecord;
                    }
                    this.updateItemNo();
                }
            })

        this.receivingSubScription = this.store.pipe(select(state => state.Receiving.receivingData))
            .subscribe(data => {
                if (data) {
                    const { receivingData = {}, receivingFetchisLoading } = data;
                    this.receiveActionDisabled = receivingFetchisLoading;
                    this.modalDisplay = receivingFetchisLoading ? "block" : 'none';
                    if (receivingData && !receivingData['hasError']) {
                        if (receivingData.receivingid) {
                            this.receivingid = receivingData.receivingid;
                            this.receivingData = receivingData;
                            this.refineReceivingDate(this.receivingData);
                        }
                        if (receivingData.receivingdate) {
                            this.receivingdate = receivingData.receivingdate;
                        }
                        this.isReceived = receivingData.received;
                        if (receivingData['save']) {
                            if (this.mode === 'create') {
                                this.router.navigate(['/receiving', receivingData.receivingid]);
                            } else {
                                this.showAlertMessage('success', 'Success !');
                                this.fetchReceivingDetails(this.receivingid);
                            }
                        } else if (receivingData['receive']) {
                            this.isReceived = true;
                            this.showAlertMessage('success', 'Success !');
                        } else if (!receivingFetchisLoading && receivingData && receivingData.receivingid) {
                            this.details = [...receivingData.receivingdetails, ...this.details];
                            this.updateReceivingRecord(receivingData);
                            this.getUniqueRecord();
                        }
                        if(receivingData['refresh']){
                            this.fetchReceivingDetails(this.receivingid);
                        }
                        if (this.isReceived) {
                            this.disableAllField();
                            this.disableHeaderCheckBox();
                        }
                    } else {
                        let errorMessage = receivingData.error && receivingData.error.message ? receivingData.error.message : 'Something went wrong';
                        this.showAlertMessage('error', errorMessage);
                    }
                }
            })


        this.checkInOutSubscription = this.store.pipe(select(state => state.CheckInOut))
            .subscribe(data => {
                const {
                    checkin = {}
                } = data;
                this.checkinActionDisabled = checkin['isLoading'];
                this.modalDisplay = checkin['isLoading'] ? "block" : 'none';
                if (checkin && checkin['hasError']) {
                    let errorMessage = 'Something went wrong';
                    this.showAlertMessage('error', errorMessage);
                } else {
                    if (!_.isEmpty(checkin['submitResults'])) {
                        this.updateStatusAfterCheckin(checkin['submitResults']);
                    }
                }
            });

        this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
            .subscribe(userDetailObj => {
                const {
                    details
                } = userDetailObj;
                this.empName = `${details['first_name']} ${details['last_name']}`;
                this.empId = details['employee_id'];
                this.permissions = details['permission'] || []
            })

        this.autocompleteCheckoutSubscription = this.store.pipe(select(state => state.Autocomplete.checkoutAutocomplete))
            .subscribe(autocompleteObject => {
                const {
                    suggestionList
                } = autocompleteObject;
                if (suggestionList) {
                    if (this.displayKey === 'uom') {
                        this.suggestionList = [...suggestionList];
                    } else {
                        this.suggestionList = [...suggestionList, { 'areaText': 'NA', 'areaCode': 'NA' }];
                    }
                }
            });

        this.autocompleteSubscription = this.store.pipe(select(state => state.Autocomplete))
        .subscribe(autoFillData=> {
            let { areaCountForCurrentLocation, isLoading, cachedArea } = autoFillData;
            if(this.isGetAreaCount && !isLoading){
            this.isGetAreaCount = false;
            this.cachedAreaList = cachedArea;

            if(Number(areaCountForCurrentLocation) === 0){
                this.receivingObject['receivingareadescription'] = defaultValues.areaText;
                this.receivingObject['receivingarea'] = defaultValues.areaText;
            }else{
                this.receivingObject['receivingareadescription'] = '';
                this.receivingObject['receivingarea'] = '';
            }
            }
        });

    }


    ngOnDestroy() {
        this.addedReceivingSubScription.unsubscribe();
        this.receivingSubScription.unsubscribe();
        this.userDetailSubscription.unsubscribe();
        this.autocompleteCheckoutSubscription.unsubscribe();
        this.checkInOutSubscription.unsubscribe();
        this.autocompleteSubscription.unsubscribe;

    }

    disableHeaderCheckBox() {
        let assetRecord = this.details.filter(record => record.itemtype === 'asset');
        let notCheckedInAsset = assetRecord.filter(record => !record['checkedin']).length;
        this.disableHeaderCheckbox = !notCheckedInAsset;
    }

    updateStatusAfterCheckin(submitResults: any = {}) {
        if (submitResults['successList'] && submitResults['successList'].length) {
            this.mapSubmitResults(true, submitResults['successList']);
            this.successListCount = submitResults['successList'].length;
        }

        if (submitResults['failList'] && submitResults['failList'].length) {
            this.mapSubmitResults(false, submitResults['failList']);
            this.failListCount = submitResults['failList'].length;
        }

        this.totalCount = this.successListCount + this.failListCount;
        this.disableHeaderCheckBox();
        this.isSelectedeaderCheckbox = false;
    }

    mapSubmitResults = (success: boolean = false, list: any = []) => {
        for (let j = 0; j < list.length; j++) {
            let record = list[j];
            for (let i = 0; i < this.details.length; i++) {
                if (this.details[i].assetid === record.assetid) {
                    this.details[i]['success'] = success ? 'success' : 'fail';
                    this.details[i]['checkedin'] = success ? true : false;
                    this.details[i]['submitMessage'] = success ? 'Successful' : (record['failMessage'] || record['message']);
                }
            }
        }
    }

    getBackgroundColor(state) {
        let obj = {
            className: ''
        }
        if (state === 'success') {
            obj['className'] = 'rowSuccess'
        } else if (state === 'fail') {
            obj['className'] = 'rowIsUnavailable'
        } else {
            obj['className'] = 'vamp_color'
        }
        return obj;
    }

    refineReceivingDate(receiveData) {
        let newArray = [];
        let {
            receivingdate = ''
        } = receiveData;
        newArray.push({
            ...receiveData,
            receivingdate: receivingdate ? localDate(receivingdate, 'DD-MMM-YYYY') : ''
        })
        this.printData = newArray;
    }

    updateItemNo() {
        let containerIndex = 0, nonContainerIndex = 0, subcontainerIndex = 0, updatedArray = [];
        for (let i = 0; i < this.details.length; i++) {
            let detail = this.details[i];
            let { itemtype = '' } = detail;
            if (itemtype === 'container') {
                subcontainerIndex = 0;
                containerIndex = nonContainerIndex > containerIndex ? nonContainerIndex + 1 : containerIndex + 1;
                let ismodified = this.isitemNoModified(detail, String(containerIndex));
                updatedArray.push({
                    ...detail,
                    modified: ismodified,
                    itemno: String(containerIndex)
                })
            } else {
                if (!containerIndex) {
                    nonContainerIndex++;
                    let ismodified = this.isitemNoModified(detail, String(nonContainerIndex));
                    updatedArray.push({
                        ...detail,
                        modified: ismodified,
                        itemno: String(nonContainerIndex)
                    })
                } else {
                    subcontainerIndex++;
                    let ismodified = this.isitemNoModified(detail, `${containerIndex}.${subcontainerIndex}`);
                    updatedArray.push({
                        ...detail,
                        modified: ismodified,
                        itemno: `${containerIndex}.${subcontainerIndex}`

                    })
                }
            }
        }
        this.details = updatedArray;
    }

    isitemNoModified(detail, updatedItemNo) {
        if (this.mode === "edit") {
            if (detail.modified) {
                return true;
            } else if (detail.newdetail) {
                return false
            } else {
                return detail.itemno !== updatedItemNo ? true : false
            }
        }
    }

    displayReceiving(receivingValue) {
        return this.receivingFilter[receivingValue] ? this.receivingFilter[receivingValue] : receivingValue;
    }
    fetchReceivingDetails(receivingid) {
        this.store.dispatch(new GetReceivingData({
            "filter": {
                "receivingid": receivingid
            }
        }))
    }

    updateReceivingRecord(receivingData) {
        let receivingRecord = JSON.parse(JSON.stringify(receivingData));
        this.receivingObject = receivingRecord;
        this.existingReceivingRecord = JSON.parse(JSON.stringify(receivingData));
    }

    getUniqueRecord() {
        let dublicateAsset = [];
        let uniqueAsset = [];
        let receivingRecord = JSON.parse(JSON.stringify(this.details));
        receivingRecord.forEach(val => {
            if (val.itemtype === "asset") {
                if (dublicateAsset.indexOf(val['assetid']) === -1) {
                    uniqueAsset.push(val);
                    dublicateAsset.push(val['assetid']);
                }
            } else if (val.itemtype === "container") {
                let description = val['description'].toLowerCase();
                if (dublicateAsset.indexOf(description) === -1) {
                    uniqueAsset.push(val);
                    dublicateAsset.push(description);
                }
            } else {
                if (dublicateAsset.indexOf(val['partno']) === -1) {
                    uniqueAsset.push(val);
                    dublicateAsset.push(val.partno);
                }
            }
        })
        this.details = uniqueAsset;
        this.updateItemNo();
    }

    handleAutocompleteInputChange(text, field) {
        this.suggestionList = [];
        if (text.length > 1) {
            if (field === 'receivinglocation') {
                this.displayKey = 'locationText';
                let obj = {
                    field: 'location'
                }
                obj['locationDescription'] = text;
                this.destroyAutoCompleteList();
                this.getCheckoutComplete(obj);
            } else if (field === 'receivingarea') {
                this.displayKey = 'areaText';
                let obj = {
                    field: 'area'
                }
                obj['locationCode'] = this.receivingObject['receivinglocation'];
                obj['areaDescription'] = text;
                this.destroyAutoCompleteList();
                this.getCheckoutComplete(obj);
            }else if (field === 'uom') {
                this.displayKey = 'uom';
                let obj = {
                  filter: {}
                }
                obj.filter['uom'] = text
                this.destroyAutoCompleteList();
                this.getUOM(obj);
              }
        }else{
            if(text=="" && field === 'receivinglocation'){
              this.receivingObject['receivingareadescription'] = '';
              this.receivingObject['receivingarea'] = '';
            }
          }
    }

    private getCheckoutComplete(obj: { field: string; }) {
        this.store.dispatch(new GetCheckoutAutocomplete(obj));
    }

    private destroyAutoCompleteList() {
        this.store.dispatch(new DestroyAutocompleteList());
    }

    private getUOM(queryObj) {
        this.store.dispatch(new GetUOMAutoComplete(queryObj));
    }

    suggestionSelected(suggestion, field) {
        if (field === "receivinglocation") {
            this.receivingObject['receivinglocationdescription'] = suggestion.locationText;
            this.receivingObject['receivinglocation'] = suggestion.locationCode;

            let areaCheckObj = {
                locationId : suggestion.locationCode
              }
              this.isGetAreaCount = true;
              this.store.dispatch(new GetLocationAreasCheck(areaCheckObj));
        
        } else {
            this.receivingObject['receivingareadescription'] = suggestion.areaText;
            this.receivingObject['receivingarea'] = suggestion.areaCode;
        }
    }

    receivingSuggestionSelected(suggestion, state, index, field) {
        if (state === "receivingdetail") {
          this.editableRecordInput[field] = suggestion[this.displayKey];
          this.onBlur(index, field);
        } else {
          this.receivingdetailRecord[field] = suggestion[this.displayKey];
        }
      }

    showAlertMessage(state, message) {
        if (state === "error") {
            this.alertState = "alert-danger";
        } else {
            this.alertState = "alert-success";
        }
        this.alertMessage = message
        this.isShowAlert = true;
    }

    selectItemType(event: any, field) {
        if (event === 'container' || event === "part") {
            this.enabelAllField();
            this.disableInput(field, event);
            this.isDisplayTypeBtn = false;
        } else if (event === "asset") {
            this.enabelAllField();
            this.disableInput(field, event);
            this.isDisplayTypeBtn = true;
        }
    }

    clearReceivingDetails() {
        this.receivingdetailRecord = new ReceivingDetailsModel();
    }


    disableInput(input_field, itemType) {
        let itemType_field = input_field.filter(_val => _val.value === itemType)[0];
        itemType_field.disabledField.forEach(val => {
            this.receiving_disableObj[val] = true;
        })
    }

    enabelAllField() {
        this.receivingDetails.forEach(val => {
            this.receiving_disableObj[val.dataKey] = false;
        })
    }

    disableAllField() {
        this.receivingDetails.forEach(val => {
            this.receiving_disableObj[val.dataKey] = true;
        })
    }

    removeReceivingDetails(index: number) {
        let remove_details = JSON.parse(JSON.stringify(this.details));
        remove_details.splice(index, 1);
        this.details = remove_details;
        this.updateItemNo();
    }

    preventDublicate(event: Event, input) {
        if (input.uniqueValue) {
            let inputKeyArray = this.details.filter(value => value[input.dataKey]);
            inputKeyArray = inputKeyArray.map(value => value[input.dataKey]);
            if (inputKeyArray.indexOf(event.target['value']) !== -1) {
                this.showDublError = true
            } else {
                this.showDublError = false
            }
        }
    }

    validateEmoDetailsForm() {
        if (this.receivingdetailRecord.itemtype) {
            let options = this.itemTypeOptions.filter(option => option.value === this.receivingdetailRecord.itemtype);
            let required = options[0].requiredField;
            if (required && required.length > 0) {
                for (let i = 0; i < required.length; i++) {
                    if (this.receivingdetailRecord[required[i]]) {
                        continue;
                    } else {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }
        return true;
    }


    addRecievingDetails() {
        if (this.validateEmoDetailsForm()) {
            if (this.receivingid) {
                this.receivingdetailRecord['newdetail'] = true;
            }
            this.details = [...this.details, this.receivingdetailRecord];
            this.selectedRecord = [...this.selectedRecord, this.receivingdetailRecord];
            this.clearReceivingDetails();
            this.enabelAllField();
            this.updateItemNo();
        }
    }

    setReceivingMode() {
        this.router.navigate(['/readyToCheckin']);
        let receivingObj: any = {
            receivingMode: true,
            receivingRecord: this.details,
            isReceivingDataMerged: false,
            receivingPath: this.receivingid ? `/receiving/${this.receivingid}` : '/receiving'
        };
        if (!this.receivingid) {
            receivingObj['receivingHeaderRecord'] = this.receivingObject;
          }
        this.store.dispatch(new ResetReceivingRecord());
        this.store.dispatch(new SetReceivingMode(receivingObj));
    }

    getButtonPermission(btnType: string) {
        if ('saveReceiving' === btnType) {
            return this.permissions.includes(createReceivingPermission);
        } else if ('received' === btnType) {
            return this.permissions.includes(receivePermission);
        } else if('cancelreceive' === btnType){
            return this.permissions.includes(cancelReceivePermission);
        }else if ('checkin' === btnType) {
            return this.permissions.includes(checkinPermission);
        } else {
            return true;
        }
    }

    getButtonDisabled(btnType: string) {
        if (['saveReceiving', 'close'].includes(btnType)) {
            return this.isReceived ? true : false;
        } else if (btnType === 'received') {
            return !this.isReceived && this.receivingid ? false : true;
        } else if (btnType === 'cancelreceive') {
            return this.isReceived && this.receivingid ? false : true;
        } else if (btnType === 'printReceiving') {
            return false;
        } else if (btnType === 'checkin') {
            let selectedRecord = this.details.filter(field => field['isAssetSelected']).length;
            return selectedRecord && this.isReceived ? false : true;
        }
    }

    isDisableField(form_element) {
        if (this.isReceived) {
            return true;
        } else {
            if (form_element.dataKey === "receivingarea") {
                if (this.receivingObject['receivinglocation']) {
                    return false;
                } else {
                    return true;
                }
            } else {
                return false;
            }
        }
    }
    checkDisable(btnType) {
        let actionDisabled = this.getButtonDisabled(btnType);
        let hasPermission = this.getButtonPermission(btnType);
        if (actionDisabled || !hasPermission || this.receiveActionDisabled || this.checkinActionDisabled) {
            return true;
        } else {
            return false;
        }
    }

    permissionDisplayCheck = (buttonObject) => {
        const {
          permissionBasedDisplay=false, permission=''
        } = buttonObject;
    
        if(!permissionBasedDisplay){
          return true;
        }else{
          return this.permissions.includes(permission);
        }
      }

    get itemTypeOptions() {
        let itemTypeOption = this.receivingDetails.filter(itemType => itemType.dataKey === "itemtype");
        return itemTypeOption[0].options;
    }

    onBlur(index, input) {
        this.editMode = false;
        this.receivingDetails = this.updateViewMode(input);
        this.editindex = index;
        if (!this.showDublError) {
            if (this.editableRecordInput[input]) {
                this.details[index][input] = this.editableRecordInput[input];
                if (this.receivingid && !this.details[index]['newdetail']) {
                    this.details[index]['modified'] = true;
                }
            }
        }
        this.showDublError = false;
    }

    showViewEdit(index, input) {
        if (!input.editable || this.isReceived) {
            return false;
        }
        let allDisableField = this.itemTypeOptions.filter(option => option.value === this.details[index].itemtype);
        let nonEditableField = allDisableField[0].disabledField;
        if (nonEditableField && nonEditableField.length > 0) {
            if (nonEditableField.includes(input.dataKey)) {
                return false;
            }
        }
        return (this.editindex === index) && !input.viewMode
    }

    edit(i, input) {
        if (this.editMode) {
            this.onBlur(this.previousValue.index, this.previousValue.input);
            return;
        }
        this.editableRecordInput[input] = this.details[i][input];
        this.previousValue = { index: i, input: input }
        this.receivingDetails = this.updateViewMode(input);
        this.editindex = i;
        this.editMode = true;
    }

    updateViewMode(input) {
        let receivingDetailsRecord = JSON.parse(JSON.stringify(this.receivingDetails));
        receivingDetailsRecord.forEach(val => {
            if (input === val.dataKey) {
                val['viewMode'] = !val['viewMode'];
            }
        })

        return receivingDetailsRecord;
    }

    removeAlertIcon() {
        this.isShowAlert = false;
    }

    onSubmit(btnType: string) {
        let payload = this.receivingObject;
        payload.receivingdetails = this.details;
        if (btnType === 'saveReceiving') {
            this.saveReceiving(payload);
        } else if (btnType === 'received') {
            this.inspectionReport(false);
        } else if(btnType === 'cancelreceive'){
            this.inspectionReport(true);
        } else if (btnType === "close") {
            this.cancelReceiving();
        } else if (btnType === 'printReceiving') {
            this.printReceivingReport()
        } else if (btnType === 'checkin') {
            this.openClientPanelModal(btnType);
            this.currentAction = btnType;
        }
    }

    checkUnsavedData() {
        if (this.receivingid) {
            let isEqual = _.isEqual(this.receivingObject, this.existingReceivingRecord);
            if (!isEqual) {
                return true;
            } else {
                return false;
            }
        } else {
            if (this.details.length > 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    mappedReceivingDetailsRecord(receivingdetail_record) {
        let detail_record = [];
        for (let i = 0; i < receivingdetail_record.length; i++) {
            let record_details = receivingdetail_record[i];
            let newRecord = {
                ...record_details,
                "createdby": record_details.createdby || this.empName,
                "createddate": dateValidation(record_details.createddate) ? moment(record_details.createddate).format('YYYY-MM-DD') : '',
                "modifiedby": this.empName,
                "modifieddate": dateValidation(record_details.modifieddate) ? moment(record_details.modifieddate).format('YYYY-MM-DD') : ''
            }
            detail_record.push(newRecord);
        }
        return detail_record;
    }

    mappedRecords = (record, state = 'save') => {
        let receivingdetail_record = record.receivingdetails;
        let mappedRecords: any = {};
        if (state === 'update') {
            mappedRecords = {
                ...record,
                "receivingdate": this.receivingdate || "",
                "receivingid": this.receivingid,
                "receivingdetails": this.mappedReceivingDetailsRecord(receivingdetail_record)
            }
        } else {
            mappedRecords = {
                ...record,
                "receivingdate": this.receivingdate || "",
                "receivingdetails": receivingdetail_record
            }
        }
        return mappedRecords;
    }

    mapReceivingRecordsForSave = (record) => {
        let record_save = this.mappedRecords(record);
        return record_save;
    }

    mapReceivingRecordsForUpdate = (record) => {
        let record_update = this.mappedRecords(record, 'update');
        return record_update;
    }

    saveReceiving(payload) {
        if (this.receivingid) {
            let mappedRecords = this.mapReceivingRecordsForUpdate(payload);
            this.store.dispatch(new UpdateReceivingData(mappedRecords));
        } else {
            let mappedRecords = this.mapReceivingRecordsForSave(payload);
            this.store.dispatch(new CreateReceivingData(mappedRecords));
        }
    }

    inspectionReport(cancelreceive) {
        let receivePayload = {
            receivingid: this.receivingid,
            cancelreceive
        }
        this.store.dispatch(new Received(receivePayload));
    }

    cancelReceiving() {
        if (this.checkUnsavedData()) {
            this.receivingConfirmationModal = "block";
        } else {
            this.backToPreviousPage();
        }
    }

    backToPreviousPage() {
        if (this.previousUrl) {
            this.router.navigate([this.previousUrl]);
        } else {
            window.close();
        }
    }

    ConfirmSave() {
        this.receivingConfirmationModal = "none";
        this.onSubmit('saveReceiving');
    }

    confirmClose() {
        this.receivingConfirmationModal = "none";
        this.backToPreviousPage();
    }

    printReceivingReport() {
        this.receivingPrintReportComponent.printReceivingReport();
    }

    selectAllAsset(event: any) {
        this.details.forEach(record => {
            if (record.itemtype === 'asset' && !record['checkedin']) {
                record['isAssetSelected'] = event.target.checked;
            }
        })
    }

    selectAssetForCheckin(event: any, index: number) {
        this.details[index]['isAssetSelected'] = event.target.checked;
    }

    mappedRecordsForCheckin = (selectedRecords) => {
        let mappedRecords = [];
        for (let i = 0; i < selectedRecords.length; i++) {
            let record = selectedRecords[i];
            let newRecord = {
                destinationlocation: record.destinationlocation,
                destinationarea: record.destinationarea,
                assetid: record.assetid,
                businessunit: record.businessunit,
                checkoutdate: record['checkoutdate'],
                checkouttime: '00:00:00',
                expectedcheckindate: record['expectedcheckindate'],
                expectedcheckintime: '00:00:00',
                peoplesoftcheckoutid: record.peoplesoftcheckoutid,
                proposalnumber: record.proposalnumber,
                projectnumber: record.projectnumber,
                pdid: record.pdid,
                calloutid: record.calloutid,
                actualcheckindate: moment(this.clientPanel['checkindate']).isValid() ?
                    moment(this.clientPanel['checkindate']).format('YYYY-MM-DD') : moment().format('YYYY-MM-DD'),
                actualcheckintime: '00:00:00',
                checkinarea: this.receivingObject.receivingarea,
                checkinlocation: this.receivingObject.receivinglocation,
                pcbusinessunit: record.pcbusinessunit,
                customerreferencenumber: record.customerreferencenumber,
                crmnumber: record.crmnumber,
                checkinlocationdescription: this.receivingObject.receivinglocationdescription,
                checkinareadescription: this.receivingObject.receivingareadescription,
                checkincustodianname: this.clientPanel['custodianname'],
                checkincustodianid: this.clientPanel['custodian'],
                tagnumber: record.tagnumber,
                subtype2: record.subtype2,
                serialid: record.serialid,
            }
            mappedRecords.push(newRecord);
        }

        return mappedRecords;
    }

    checkinRecords() {
        let selectedRecords = JSON.parse(JSON.stringify(this.details)).filter(field => field['isAssetSelected']);
        if (selectedRecords.length > 0) {
            let mappedRecords = this.mappedRecordsForCheckin(selectedRecords);
            this.store.dispatch(new CheckinAssets({ assetList: mappedRecords }));
        }
        this.closeClientPanelModal();
    }

    initUiBuilder = (tableBuilderList, variableName) => {
        let array = [];
        for (let i = 0; i < tableBuilderList.length; i++) {
            let column = tableBuilderList[i];
            let { useIn = [] } = column;
            if (useIn.includes('checkin')) {
                array.push(column);
            }
        }
        this[variableName] = array;
    }

    openClientPanelModal = (action) => {
        if (action === 'checkin') {
            for (let i = 0; i < this.panelStructureList.length; i++) {
                if (
                    this.panelStructureList[i].dataKey === "location" ||
                    this.panelStructureList[i].dataKey === "area"
                ) {
                    this.panelStructureList.splice(i, 1)
                    i--;
                }
            }
        }

        this.displayClientPanelModal = true;
    }

    closeClientPanelModal = () => {
        this.displayClientPanelModal = false;
        this.currentAction = '';
        this.resetCheckbox();
    }

    resetCheckbox() {
        this.details = this.details.map(record => {
            record['isAssetSelected'] = false;
            return record;
        })
        this.isSelectedeaderCheckbox = false;
    }

    integratePanel = (panelData: any = {}) => {
        this.clientPanel = panelData;
    }

    dynamicSubmitAction = () => {
        if (this.currentAction === 'checkin') {
            this.checkinRecords();
        }
        this.closeClientPanelModal();
    }

    showMoreOrLessText = (text = '', dataKey, row) => {
        try {
          if (text.length > this.maxLength) {
            if (
              this.textDisplayLengthMap[dataKey] &&
              this.textDisplayLengthMap[dataKey][row] === 1
            ) {
              return 'show less';
            } else {
              return 'show more';
            }
          } else {
            return '';
          }
        } catch (e) {
          console.log('showMoreOrLessText catch block error', e);
          return '';
        }
      }
    
      showMoreOrLessTextToggle = (text) => {
        try {
          return text && text.toString().length > this.maxLength;
        } catch (e) {
          return false;
        }
      }
    
      toggleShowLessMoreFunction = (dataKey, row) => {
        try {
          if (
            this.textDisplayLengthMap[dataKey] &&
            this.textDisplayLengthMap[dataKey][row]
          ) {
            this.textDisplayLengthMap[dataKey][row] = 0;
          } else {
            this.textDisplayLengthMap[dataKey] = {}
            this.textDisplayLengthMap[dataKey][row] = 1;
          }
        } catch (e) {
          console.log('toggleShowLessMoreFunction catch block error', e);
        }
    
      }
    
      showText = (text = '', dataKey, row) => {
        try {
          if (
            text &&
            text.toString().length < this.maxLength
          ) {
            return text;
          } else {
            if (
              this.textDisplayLengthMap[dataKey] &&
              this.textDisplayLengthMap[dataKey][row] === 1
            ) {
              return text;
            } else {
              return text ? `${text.toString().substring(0, this.maxLength)}...` : ''
            }
          }
        } catch (e) {
          return text;
        }
      }

    downloadcsv = () => {
        let mappedData = this.mappDownloadData(this.receivingData);
        downlaodcsv('receivingDetail', mappedData);
    }

    mappDownloadData = (downloadData) => {
        let _downloadData = Object.assign(downloadData);
        const { shipmentcondition = "", projectnumber = "", receivinglocation = "", receivinglocationdescription = "",
            receivingarea = "", receivingareadescription = "", receivingdate = "",
            receivingid = "", received, receivingdetails = [] } = _downloadData;
        return receivingdetails.map((record, index) => {
            const {
                itemno = "", itemtype = "", businessunit = "", peoplesoftcheckoutid = "", serialid = "",
                tagnumber = "", partno = "", quantity, uom = "", description = "", observation = "",
                assetid = "", destinationlocation = "", destinationarea = "", checkoutdate = "",
                expectedcheckindate = "", proposalnumber = "", pdid = "",
                calloutid = "", pcbusinessunit = "", customerreferencenumber = "", crmnumber = "",
                subtype2 = ""
            } = record;
            let obj = {
                itemno, itemtype, businessunit, peoplesoftcheckoutid, pdid, calloutid, pcbusinessunit,
                serialid, tagnumber, partno, quantity, uom, description, customerreferencenumber,
                projectnumber, observation, checkoutdate, expectedcheckindate, proposalnumber, assetid,
                crmnumber, subtype2, destinationlocation, destinationarea
            }
            let detailsobj = {}
            if (index === 0) {
                detailsobj = {
                    shipmentcondition, projectnumber, receivinglocation, receivinglocationdescription,
                    receivingarea, receivingareadescription, receivingdate,
                    receivingid, received,
                    ...obj
                }
            } else {
                detailsobj = {
                    shipmentcondition : "", projectnumber: "", receivinglocation: "", receivinglocationdescription: "",
                    receivingarea: "", receivingareadescription: "", receivingdate: "",
                    receivingid: "",
                    ...obj
                }
            }
            return detailsobj;
        })
    }
}