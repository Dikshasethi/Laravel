import { Routes } from '@angular/router';
import { ReceivingComponent } from './receiving.component';

export const ReceivingRoutes: Routes = [
    { path: '', component: ReceivingComponent },
    { path: ':receivingid', component: ReceivingComponent }
];