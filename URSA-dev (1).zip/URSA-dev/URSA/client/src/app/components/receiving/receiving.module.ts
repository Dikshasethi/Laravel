import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { ReceivingRoutes } from './receiving.routes';
import { ReceivingComponent } from '../receiving/receiving.component';

@NgModule({
    declarations: [
        ReceivingComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(ReceivingRoutes)
    ]
})

export class ReceivingModule { }