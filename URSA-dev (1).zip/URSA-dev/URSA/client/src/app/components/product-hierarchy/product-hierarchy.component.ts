import { Component, EventEmitter, Input, OnInit, Output, SimpleChange } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import * as _ from 'lodash';
import { LogoutUser } from '../../actions/userDetail.actions';

@Component({
  selector: 'app-product-hierarchy',
  templateUrl: './product-hierarchy.component.html',
  styleUrls: ['./product-hierarchy.component.css']
})

export class ProductHierarchyComponent implements OnInit {
  cartData = [];
  productCartHierarchy = [];
  cartSubscription;
  watchListSubscription;
  watchListData = [];
  @Input() productHierarchyList;
  @Input() initialProductHierarchy;
  @Output() cartAction: EventEmitter<any> = new EventEmitter<any>();
  @Output() watchListAction: EventEmitter<any> = new EventEmitter<any>();

  constructor(private store: Store<AppState>,) { }
  
  ngOnInit() {
    this.cartSubscription = this.store.pipe(select(state => state.Cart.cartData))
      .subscribe(cartObj => {
        const {
          cartData
        } = cartObj;
        if (cartData && cartData['isAuthenticate'] == "not authenticated") {
          this.store.dispatch(new LogoutUser({}));
        }
        else if (cartData && !cartData['hasError']) {
          this.cartData = cartData;
          this.editProductAccordingToHierarchy(this.productCartHierarchy)
          this.editProductAccordingToCart(this.productCartHierarchy);
        } else if (cartData && cartData['hasError']) {
          alert("An error occured with the Cart transaction");
        }
      })

      this.watchListSubscription = this.store.pipe(select(state => state.WatchList))
      .subscribe(WchListData => {
          const {
            watchListData: {  watchListData },
            errorState: { error = false, error_message }
          } = WchListData
        
         if(watchListData && watchListData.length) {
          this.watchListData = watchListData;
          this.filterProductAccordingToWatchlist();
        }
         if (error) {
          alert(error_message);
        }
      })
  }

  ngOnChanges(changes: SimpleChange) {
    let dataReference = changes['productHierarchyList'];
    let initialProductHierarchy = changes['initialProductHierarchy'];
    let dataProp = Object.assign({}, dataReference);

    if (initialProductHierarchy) {
      if (!_.isEqual(initialProductHierarchy.currentValue, initialProductHierarchy.previousValue)) {
        this.initialProductHierarchy = initialProductHierarchy.currentValue
        this.productCartHierarchy = JSON.parse(JSON.stringify(this.initialProductHierarchy));
        this.editProductAccordingToHierarchy(this.initialProductHierarchy);
        this.editProductAccordingToCart((this.initialProductHierarchy));
        this.filterProductAccordingToWatchlist();
      }
    }

    if (dataProp) {
      let currentDataProp = dataProp.currentValue;
      let previousDataProp = dataProp.previousValue;
      if (!_.isEqual(currentDataProp, previousDataProp)) {
        this.productHierarchyList = currentDataProp;
        this.editProductAccordingToHierarchy(this.productHierarchyList);
        this.editProductAccordingToCart((this.initialProductHierarchy));
        this.filterProductAccordingToWatchlist();
      }
    }
  }

  editProductAccordingToHierarchy(product) {
    if (!_.isEmpty(product)) {
      product.map(val => {
        val.isAddedToCart = false;
        val.bu = val.businessunit;
        val.isAddedToWatchList = false;
        val.cartId = (val.businessunit).concat(val.assetid)
        return val;
      });

      this.productCartHierarchy = product;
      this.initialProductHierarchy = product;
    }
  }

  editProductAccordingToCart(product) {
    if (this.cartData.length && product) {
      this.cartData.forEach(cdata => {
        product.map(val => {
          if (
            cdata.data &&
            (cdata.data.cartId === val.cartId)
          ) {
            val["isAddedToCart"] = true;
          }
        });
      }
      )
    }
    this.productHierarchyList = product;
  }

  filterProductAccordingToWatchlist() {
    if(!_.isEmpty(this.watchListData) && !_.isEmpty(this.productHierarchyList)) {
      let productHierarchyListObj = this.productHierarchyList;
      for(let i=0; i < this.watchListData.length; i++) {
        if((this.watchListData[i].assetid === productHierarchyListObj[0]['assetid']) 
        && (this.watchListData[i].businessunit === productHierarchyListObj[0]['businessunit'])) {
          productHierarchyListObj[0]["isAddedToWatchList"] = true;
          break;
        }
      }
      this.productHierarchyList = productHierarchyListObj;
    }
  }

  openCartModal(product) {
    this.cartAction.emit(product)
  }

  openWatchListModal(product) {
    this.watchListAction.emit(product)
  }

  statusClassFunction = (product) => {
    return `badge-${this.badgeClassParser(product.statustext, product.pastduecheckout)}`
  }

  badgeClassParser = (status, pastDue) => {
    if (status) {
      let statusText;
      let statusList = status.split(' ');
      if (statusList && statusList.length > 0) {
        statusText = statusList[0];
      } else {
        statusText = status
      }
      if (pastDue) {
        statusText = 'past';
      }
      let statusMap = {
        Available: 'available',
        Checked: 'Checked',
        Reserverd: 'warning',
        Status: 'secondary',
        Hard: 'hardReserved',
        checked: 'danger',
        Disposed: 'danger',
        past: 'danger',
        "On-Hire": 'On-Hire'
      }
      return statusMap[statusText];
    }
    return 'secondary'
  }

  checkAssetDisposed = () => {
    let status = 'Disposed';
    return `badge-${this.badgeClassParser(status, '')}`;
  }

}
