import { Component, OnInit, ViewEncapsulation, Input, SimpleChange } from '@angular/core';
import * as _ from 'lodash';

@Component({
    selector: 'app-asset-forecast',
    templateUrl: './asset-forecast.component.html',
    styleUrls: ['./asset-forecast.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class AssetForecastComponent implements OnInit {
    component_calendar: any;
    calendarHtml = '';
    calendarTable = '';
    headingRowOfTable: { "timeseries": { "startdate": string; "enddate": string; "status": string; }[] };
    checkFlag = true;
    calendarTableRow = '';
    calendarHtmlRow = '';
    _calendarHtmlRow: any[];
    startDate = '';
    endDate = '';
    day: Number;
    month: Number;
    finalYear: any;
    startYear: any;
    today : any;
    calDayNames = '';
    calDayNamesHtml = '';

    @Input() calenderData;
    @Input() index;
    constructor() { }

    ngOnInit() {
        this.today = new Date();
        this.day = Number(this.today.getDate())
        this.month = Number(this.today.getMonth() + 1);
        this.startYear = Number(this.today.getFullYear());
        this.finalYear = Number(this.today.getFullYear() + 1);
        this.startDate = this.startYear + '-' + this.month + '-' + this.day;
        this.endDate = this.finalYear + '-' + this.month + '-' + this.day;
        this.displayCalendar(this.calenderData,this.index);

    }

    ngOnChanges(changes: SimpleChange){
       if( 
            changes['calenderData'] && 
            !_.isEqual(
            changes['calenderData']['currentValue'],
            changes['calenderData']['previousValue']
            )
       ){
        this.displayCalendar(this.calenderData,this.index);
       }

    }

    displayCalendar(calendarMap, index) {
        if(calendarMap[index]){
            this.component_calendar = {
                calendarHtml: '',
                calendarTable: '',
                year: new Date().getFullYear(),
                finalYear: 9999,
                finalMonth: 99
            }
            this._calendarHtmlRow = [];
            this.headingRowOfTable = {
                "timeseries": [
                    {
                        "startdate": this.startDate,
                        "enddate": this.endDate,
                        "status": "Available"
                    }
                ]
            }
            if (calendarMap) {
                this.checkFlag = true;
                this.component_calendar = this.setChart(this.headingRowOfTable.timeseries || [], [] || [], [] || [])
                this._calendarHtmlRow.push(this.calendarHtml);
                this._calendarHtmlRow.push(this.calDayNamesHtml);
    
                if (calendarMap[index]) {
                    this.checkFlag = false;
                    this.component_calendar = this.setChart(calendarMap[index].timeseries || [], calendarMap[index].stateData || [], calendarMap[index].reservationData || [])
                    this._calendarHtmlRow.push(this.calendarHtmlRow);
    
                }
            }
        }
    }

    pad(d) {
        return (d < 10) ? '0' + d.toString() : d.toString();
    }

    displayChart(month, year, data, statesdata, reservationData) {

        //Variables to be used later.  Place holders right now.
        let paddingMonth = "";
        let paddingData = "";
        let paddingDayNames = "";
        let totalFeb = 0;
        let i = 1;
        let dateClass = "";
        let dateStatus = "";
        let maintenanceStatus = false;
        //Determing if Feb has 28 or 29 days in it.  
        if (month == 1) {
            if ((year % 100 !== 0) && (year % 4 === 0) || (year % 400 === 0)) {
                totalFeb = 29;
            } else {
                totalFeb = 28;
            }
        }

        let monthNames = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
        let totalDays = ["31", "" + totalFeb + "", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31"];
        let dayAmount = parseInt(totalDays[month]);
        let dayNameList = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
        let day = 0;

        while (i <= dayAmount) {
            let date = ((month + 1) + "-" + i + "-" + year)
            let calDay = Number(new Date(date).getDay())
            day = calDay;
            if (day > 6) {
                day = calDay;
            }
            if (reservationData && reservationData.length > 0) {
                for (let j = 0; j < reservationData.length; j++) {
                    let key = j.toString()
                    let thisDate = Date.parse(year + "-" + this.pad(month + 1) + "-" + this.pad(i));
                    let compStartDate = Date.parse(reservationData[key].reservationStartDate);
                    let compEndDate = Date.parse(reservationData[key].reservationEndDate);
                    if (thisDate >= compStartDate && thisDate <= compEndDate) {
                        dateStatus = "Hard Reserved";
                        break;
                    } else {
                        dateStatus = this.checkDateSatus(data, year, month, i)
                    }
                }
            } else {
                dateStatus = this.checkDateSatus(data, year, month, i)
            }
            switch (dateStatus) {
                case "Hard Reserved":
                    dateClass = "hardReserved"
                    break;
                case "Available":
                    dateClass = "available"
                    break;
                case "OnHire":
                    dateClass = "onhire"
                    break;
                case "Unavailable":
                    dateClass = "unavailable"
                    break;
                case "Checked Out":
                    dateClass = "checkedout"
                    break;
                default:
                    dateClass = "available"
                    break;
            }
            for (let j = 0; j < statesdata.length; j++) {
                let key = j.toString()
                let thisDate = Date.parse(year + "-" + this.pad(month + 1) + "-" + this.pad(i));
                let compStartDate = Date.parse(statesdata[key].startdate);
                let compEndDate = Date.parse(statesdata[key].enddate);

                if (thisDate >= compStartDate && thisDate <= compEndDate) {
                    maintenanceStatus = true;
                    break;
                } else
                    maintenanceStatus = false;
            }
            if (maintenanceStatus) {
                switch (dateClass) {
                    case "available":
                        dateClass = "cart-avail-main"
                        break;
                    case "unavailable":
                        dateClass = "cart-unavailable-workorder"
                        break;
                    case "hardReserved":
                        dateClass = "cart-hardReserved-main"
                        break;
                    case "onhire":
                        dateClass = "cart-hire-main"
                        break;
                    case "checkedout":
                        dateClass = "cart-checkedOut-main"
                        break;
                    default:
                        dateClass = "cart-available"
                        break;
                }
            }

            if (this.checkFlag == true) {
                paddingDayNames += "<td><div class='monthRow '>" + dayNameList[day] + "</div></td>";
                paddingMonth += "<td><div class= 'monthRow '>" + i + "</div></td>";
            }
            else {
                paddingData += "<td class=' " + dateClass + "'><div>" + `&nbsp;` + "</div></td>";
            }
            i++;
            day++;
        }
        if (this.checkFlag == true) {
            this.calendarTable = "<tr><th><div><table class='calendarTable' border='0' cellspacing='0' cellpadding='0'> <tr><td colspan='30'><div class='month'>" + monthNames[month] + " " + year + "</div></td>";
            this.calendarTable += "<tr>";
            this.calendarTable += paddingDayNames;
            this.calendarTable += "</tr></table></div></th></tr>";
            this.calendarHtml += this.calendarTable

            this.calDayNames = "<tr><th><table class='calendarTable' border='0' cellspacing='0' cellpadding='0'>";
            this.calDayNames += "<tr>";
            this.calDayNames += paddingMonth;
            this.calDayNames += "</tr></table></th></tr>";
            this.calDayNamesHtml += this.calDayNames;
        }
        else {
            
            this.calendarTableRow = "<tr><th><div><table class='calendarTable' border='0' cellspacing='0' cellpadding='0'>";
            this.calendarTableRow += "<tr>";
            this.calendarTableRow += paddingData;
            this.calendarTableRow += "</tr></table></div></th></tr>";
            this.calendarHtmlRow += this.calendarTableRow
        }
    }

    checkDateSatus(data, year, month, i) {

        for (let j = 0; j < data.length; j++) {
            let key = j.toString()
            let thisDate = Date.parse(year + "-" + this.pad(month + 1) + "-" + this.pad(i));
            let compStartDate = Date.parse(data[key].startdate);
            let compEndDate = Date.parse(data[key].enddate);

            if (thisDate >= compStartDate && thisDate <= compEndDate) {
                return data[key].status;
            }
        }
    }

    setChart(data, statesdata, reservationData) {
        let year_timeSeriesStartDate = 0;
        let month_timeSeriesStartDate;
        this.calendarHtmlRow = "";
        this.calendarHtml = "";
        this.calDayNamesHtml = "";
        if (data && data.length >= 1) {

            year_timeSeriesStartDate = this.startYear;
            month_timeSeriesStartDate = Number(this.month)-1;

        }
        for (let i = month_timeSeriesStartDate; i < 12; i++) {
            this.displayChart(i, year_timeSeriesStartDate, data, statesdata, reservationData);
        }

        let past = year_timeSeriesStartDate;
        let diffrence = (this.finalYear - past)
        let pYear = 9999;
        for (let j = 1; j <= diffrence; j++) {
            pYear = year_timeSeriesStartDate + j;
            if (pYear != this.finalYear) {
                for (let i = 0; i < 12; i++) {
                    this.displayChart(i, pYear, data, statesdata, reservationData);
                }
            }
            else {
                for (let i = 0; i < this.month; i++) {
                    this.displayChart(i, pYear, data, statesdata, reservationData);
                }
            }
        }
    }
}
