import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { WatchListRoutes } from './watch-list.routes';
import { WatchListComponent } from './watch-list.component';

@NgModule({
    declarations: [
        WatchListComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(WatchListRoutes)
    ]
})

export class WatchListModule { }