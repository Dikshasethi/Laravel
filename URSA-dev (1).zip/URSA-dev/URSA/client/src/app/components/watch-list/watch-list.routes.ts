import { Routes } from '@angular/router';
import { WatchListComponent } from './watch-list.component';

export const WatchListRoutes: Routes = [
    { path: '', component: WatchListComponent }
];