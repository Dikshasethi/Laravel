import { Component, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { GetWatchListData, EditInWatchList, DeleteFromWatchList, ResetWatchListData} from '../../actions/watchlist.action';
import { ReSetSorting, SetSorting } from '../../actions/checkInOut.action';
import { hardReservePermission, checkoutPermission } from '../../utils/config/config';
import  actionList  from '../../utils/watchList/actionList';
import * as _ from 'lodash';

@Component({
  selector: 'app-watch-list',
  templateUrl: './watch-list.component.html',
  styleUrls: ['./watch-list.component.css']
})
export class WatchListComponent implements OnInit {

  constructor(private store: Store<AppState>,private router: Router ) { }
  watchListSubscription;
  userDetailSubscription;
  defaultCustodian;
  defaultCustodianCode;
  empId;
  permissions;
  watchListData= [];
  watchListIsLoading: boolean = false;
  sort :any = {};
  sortingIcon :any={};
  error_message: string;
  checkInOutSortingSubscription;
  deletedWatchlistIsLoading;
  watchListCheckboxMap = {};
  selectedAssets=[];
  selectedWatchListItem=[];
  allRowsSelected: boolean = false;
  isRefreshData=false;
  process;
  modalDisplay = "none";
  skip:number = 0;
  limit:number = 50;
  recordCount: number = 0;
  totalCount: number = 0;
  onScrollLoading:boolean = false;
  hardReservePermission:string = hardReservePermission;
  checkoutPermission:string = checkoutPermission;
  checkedOutSubscription;
  hardReserveSubscription;
  watchListModalDisplay: boolean = false;
  WatchListdeleteObj: any;
  confirmationMessage = '';
  addedWatchListLoading: boolean = false;
  cancelDeleteModalDisplay: string = 'none';
  actionList = actionList;
  _checkedoutData;
  _hrresponseData;
  watchListHeader = '';
  watchListModalProperties: any = {
    watchlistHeader: '',
    watchListModalDisplay: false,
    watchListModalData: {
        assetid: '',
        businessunit: ''
    },
    selectedWatchListActions: []
};
  filters: any = {
    serialid : '',
    tagnumber : '',
    description : '',
    category : '',
    subtype2 : '',
    businessunit: '',
    assetid : '',
    active : '',
    userid : '',
    actionsToWatch: '',
  }
  @Output()
  recheckoutModalProperties = {
    display: 'none',
    selectedAssets:[],
    custodian:{}
  }
  ngOnInit() {
    this.watchListSubscription = this.store.pipe(select(state => state.WatchList))
    .subscribe(WchListData => {
        const {
          watchListData: {  watchListData, watchListLoading, watchListError, totalCount },
          addedWatchListData: { addedWatchlistData, addedWatchListLoading },
          deletedWatchListData: { deletedWatchListData, deletedWatchListLoading },
          errorState: { error = false, error_message },
          onScrollLoading = false,
        } = WchListData
        if(watchListData && !watchListLoading){
          this.watchListData = watchListData;
          this.recordCount = watchListData.length
          this.totalCount = totalCount;
        }
        this.addedWatchListLoading = addedWatchListLoading;
        this.watchListIsLoading = watchListLoading;
        this.deletedWatchlistIsLoading = deletedWatchListLoading;
        this.onScrollLoading = onScrollLoading;
       
        if (error) {
          this.showErrorMessage(error_message);
        }

        if (!_.isEmpty(addedWatchlistData) && !addedWatchListLoading && !watchListLoading && !addedWatchListLoading['hasError']) {
          this.isRefreshData = true;
          this.fetchWatchListData();
        }

        if (!_.isEmpty(deletedWatchListData) && !deletedWatchListLoading && !watchListLoading && !deletedWatchListData['hasError']) {
          this.isRefreshData = true;
          this.fetchWatchListData();
        }
    })

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(userDetailObj => {
      const {
        details
      } = userDetailObj;
      this.defaultCustodian = details['first_name'] +' '+ details['last_name'];
      this.defaultCustodianCode = details['employee_id'] ;
      this.empId = details['employee_id'] ;
      this.permissions = details['permission'] || [];
      if(this.empId && !this.watchListData.length){
        this.fetchWatchListData();
      }
    })

    this.checkInOutSortingSubscription = this.store.pipe(select(state => state.CheckInOut))
      .subscribe(data => {
        const {sort:{watchlist}}=data;
          let obj={};
          for(let key in watchlist){
            obj[key] = watchlist[key];
          }
          this.sort = obj;
      });

      this.checkedOutSubscription = this.store.pipe(select(state => state.CheckOutPageData.checkedoutData))
      .subscribe(data => {      
        const {checkedoutData} = data;        
       if(checkedoutData){
        this._checkedoutData = checkedoutData;
       } 
      })
  
      this.hardReserveSubscription = this.store.pipe(select(state => state.ProposalPageData.hrResponseObj))
      .subscribe(data => {
        if(data){
          this._hrresponseData=data;
        }  
      });

  }

  ngOnDestroy(){
    this.watchListSubscription.unsubscribe();
    this.userDetailSubscription.unsubscribe();
    this.checkInOutSortingSubscription.unsubscribe();
    this.checkedOutSubscription.unsubscribe();
    this.hardReserveSubscription.unsubscribe();
    this.store.dispatch(new ResetWatchListData());
    this.store.dispatch(new ReSetSorting());
  }

  fetchWatchListData = () => {
  let updatedFilter = {
      ...this.filters,
      userid:  this.empId
    }

    let obj={
      "limit" : this.limit,
      "filter": updatedFilter,
      "skip" : this.skip,
      "sort": this.sort	
    }
    this.selectedAssets= [];
    this.modalDisplay = "block";
    this.store.dispatch(new GetWatchListData(obj));
  }

  showErrorMessage(errorMsg) {
    if(errorMsg && errorMsg.error && errorMsg.error.message)
    {
      alert(errorMsg.error.message);
    }else if(errorMsg && errorMsg.error && errorMsg.error.failList && errorMsg.error.failList.length > 0){
      for (let value of errorMsg.error.failList) {
        alert(value['failMessage']);
      }
    }else{
      alert('Something went wrong');
    }
  }

  sortData = (dataKey) => {
    this.setSorting(dataKey);
    this.skip = 0;
    this.store.dispatch(new ResetWatchListData());
    this.fetchWatchListData();
    this.visualizeSortingIcon();
  }

  setSorting = (key) => {
    let sort = {};
    sort['componentType'] = "watchlist";
    sort['dataKey'] = key;
    this.store.dispatch(new SetSorting(sort))
  }

  visualizeSortingIcon = () => {
    let sortData = JSON.parse(JSON.stringify(this.sort));
    let obj = {}
    for (let key in sortData) {
      if (sortData[key] === 1) {
        obj[key] = "fa fa-arrow-up"
      } else if (sortData[key] === -1) {
        obj[key] = "fa fa-arrow-down"
      }
    }
    this.sortingIcon = obj;
  }

  onAssetSelection(data, i) {
    if (!this.watchListCheckboxMap[i]) {
      this.watchListCheckboxMap[i] = {
        selected: false
      }
    }
    if (!this.watchListCheckboxMap[i]['selected']) {
      this.modalDisplay = 'block';
      this.watchListCheckboxMap[i]['selected'] = true;
      this.selectedAssets.push(data);
    } else {
      this.modalDisplay = 'none';
      this.watchListCheckboxMap[i]['selected'] = false;
      this.selectedAssets = this.selectedAssets.filter(function (obj) {
        return obj._id !== data._id;
      });
    }
    this.selectedWatchListItem = JSON.parse(JSON.stringify(this.selectedAssets));
  }

  isWatchListItemSelected(i){
    return (this.watchListCheckboxMap[i] && this.watchListCheckboxMap[i]['selected']) || false;
  }

  onAllAssetSelection() {
    this.allRowsSelected = !this.allRowsSelected;
    this.normalizeCheckboxes(this.watchListData.length, this.allRowsSelected);
    if (this.allRowsSelected) {
      this.selectedAssets = this.watchListData;
    }
    else {
      this.selectedAssets = [];
    }
    this.selectedWatchListItem = JSON.parse(JSON.stringify(this.selectedAssets));
  }

  normalizeCheckboxes(length, allRowsSelected){
    for (let i=0; i< length; i++ ) {
      if(!this.watchListCheckboxMap[i]){
        this.watchListCheckboxMap[i] = {
          selected : false
        }
      }
      this.watchListCheckboxMap[i]['selected'] = allRowsSelected;
    }
  }

  removeWatchListItem(rowWatchListData: any, actionToBeDeleted: any) {
    let deleteObj = {
      "assetList": [
        {
          "assetid": rowWatchListData.assetid,
          "businessunit": rowWatchListData.businessunit,
          "actionsToDelete": [
            actionToBeDeleted
          ]
        }
      ]
    }
    this.confirmationMessage = "Are you sure you want to remove this action from Watch List ?";
    this.WatchListdeleteObj = deleteObj;
    this.cancelDeleteModalDisplay = "block";
  }

  confirmDeleteAction() {
    if(this.WatchListdeleteObj) {
      this.store.dispatch(new DeleteFromWatchList(this.WatchListdeleteObj));
    }
    this.resetDeleteModalData();
  }


  onScroll(){
    if(
      this.skip <=  this.recordCount
    ){
      this.skip = this.recordCount;
      this.fetchWatchListData();
    }
  }

  buttonIsDisabled = (type) => {
    let hasPermission = this.permissions.includes(type);
    if(
      !hasPermission ||
      this.selectedWatchListItem.length < 1
    ){
      return true;
    }else{
      return false;
    }
  }

  replaceKeyInObjectArray(array) {
    for (let i = 0; i < array.length; i++) {
        let arrayObject = array[i];
        if(arrayObject['tagnumber']) {
          arrayObject['tagNumber'] = arrayObject['tagnumber'];
          delete arrayObject['tagnumber'];
        }
        if(arrayObject['serialid']) {
          arrayObject['serialNumber'] =  arrayObject['serialid'];
          delete arrayObject['serialid'];
        }
    }
    return array;
  }
  

  onReservationClick(process){
    this.process=process;    
    this.isRefreshData = false;
    let updatedSelectedAssets = JSON.parse(JSON.stringify(this.selectedAssets));
    updatedSelectedAssets = this.replaceKeyInObjectArray(updatedSelectedAssets);
    this.recheckoutModalProperties = {
      display: 'block',
      selectedAssets: updatedSelectedAssets,
      custodian:{
        'name': this.defaultCustodian,
        'code': this.defaultCustodianCode
      }
    }
  }

  onReservationModalClose(action){
    if(action != 'destroy'){
      this.navigateToCallOut()
    }
    if(this.isRefreshData){
      this.selectedAssets=[];
    }
  }

  navigateToCallOut(){
    let calloutid;
    let isfail=false;
    if(this._checkedoutData && this._checkedoutData.successList && this._checkedoutData.successList.length){
      calloutid = this._checkedoutData.successList[0].calloutid;
    } 
    if(this._hrresponseData && this._hrresponseData.successList && this._hrresponseData.successList.length){
      calloutid = this._hrresponseData.successList[0].calloutid;
    } 

    if(this._checkedoutData && this._checkedoutData.failList && this._checkedoutData.failList.length){
      isfail=true;
    } 
    if(this._hrresponseData && this._hrresponseData.failList && this._hrresponseData.failList.length){
      isfail=true;
    } 

    if(isfail){
      return ;
    }
    if(this.watchListData.length){
      let url=`/calloutinfo/${calloutid}`;
      window.open(url, "_blank");
    }else{
      this.router.navigateByUrl(`/calloutinfo/${calloutid}`);
    }
  }

  onLoaderModalStatusChange(status){
    this.modalDisplay = status
  }

  modalDisplayFunction = () => {
    if ((this.watchListIsLoading || this.deletedWatchlistIsLoading || this.addedWatchListLoading) && !this.onScrollLoading) {
      return 'block';
    } else {
      return 'none';
    }
  }

  updateFilter(map: string, event){
    this.filters[map] = event.target.value;
    this.store.dispatch(new ResetWatchListData());
    this.executeFilter();
  }
  
  closeDeleteModal() {
    this.resetDeleteModalData();
  }

  private resetDeleteModalData() {
    this.cancelDeleteModalDisplay = "none";
    this.confirmationMessage = "";
  }

  executeFilter(){
    this.skip = 0;
    this.fetchWatchListData();
  }

  openEditWatchListModal(watchListData: any) {
    this.watchListModalDisplay = true;
    this.watchListHeader = "Edit Watch List Actions";
    this.watchListModalProperties = {
       watchListHeader: this.watchListHeader,
       watchListModalDisplay: true,
       watchListModalData: {
           assetid: watchListData.assetid,
           businessunit: watchListData.businessunit
       },
       selectedWatchListActions: watchListData.actionsToWatch
    }
  }

  closeWatchListModal() {
    this.watchListModalDisplay = false;
  }
  
  submitWatchListForm(Obj: any) {
      this.store.dispatch(new EditInWatchList(Obj));
      this.closeWatchListModal();
  }

}
