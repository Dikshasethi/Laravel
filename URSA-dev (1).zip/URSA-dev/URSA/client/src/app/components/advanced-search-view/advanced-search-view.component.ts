import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { Store, select } from '@ngrx/store';
import {AppState} from '../../models/appState';
import {reducerMap, searchMap} from '../../utils/advancedSearch/advancedSearchViewMap';
import { HandleInput, SetActiveSearch, ManageAdvancedSearchDisplay, HandlePillDeletion } from '../../actions/advancedSearch.actions';
import { SetSearchKeyword } from '../../actions/search.actions';
import { GetProducts, DestroyDataObject } from '../../actions/product.actions';
import { GetProductSummary, DestroyProductSummary } from '../../actions/productSummary.actions';
import { ResetFilters } from '../../actions/refinedBy.actions';
import {advancedSearchObjectBuilder} from '../../utils/advancedSearch/queryObjectBuilder';
import { BlockSearchChangeView } from '../../actions/user.actions';

@Component({
  selector: 'app-advanced-search-view',
  templateUrl: './advanced-search-view.component.html',
  styleUrls: ['./advanced-search-view.component.css']
})
export class AdvancedSearchViewComponent implements OnInit {
  advancedSearchObject;
  objectKeys = Object.keys;
  activeSearch = false;
  refinedByFilterKey = 'productFilterObject';
  startDate;
  endDate;
  userView

  constructor(
    private store: Store<AppState>
  ) { }

  ngOnInit() {
    this.store.pipe(select(state => state.AdvancedSearch))
    .subscribe(advancedSearchObj => {
      let advancedSearchCopy = Object.assign({}, advancedSearchObj);
      const {
        categoryString='', manufacturerString='',
        modelString='', locationString='',
        subtype2String='', activeSearch = false,
        descriptionString=''
      } = advancedSearchCopy;

      let obj = {
        Category : categoryString ? categoryString.match(/^[,]+$/)!=null ? new Array(categoryString):categoryString.split(',').filter(x => x) : [],
        Manufacturer : manufacturerString ? manufacturerString.match(/^[,]+$/)!=null ? new Array(manufacturerString) : manufacturerString.split(',').filter(x => x) : [],
        Model : modelString ? modelString.match(/^[,]+$/)!=null ? new Array(modelString) : modelString.split(',').filter(x => x) : [],
        Location : locationString ? locationString.match(/^[,]+$/)!=null ? new Array(locationString) : locationString.split(',').filter(x => x) : [],
        "Sub Type 2" : subtype2String ? subtype2String.match(/^[,]+$/)!=null ? new Array(subtype2String) : subtype2String.split(',').filter(x => x) : [],
        Description : descriptionString ? descriptionString.match(/^[,]+$/)!=null ? new Array(descriptionString) : descriptionString.split(',').filter(x => x) : []
      }

      this.advancedSearchObject = obj;
      this.activeSearch = activeSearch;
    })

    this.store.pipe(select(state => state.Search))
    .subscribe(searchObject => {
      const {startDate, endDate} = searchObject;
      this.startDate = startDate;
      this.endDate = endDate;
    });

    this.store.pipe(select(state => state.User))
    .subscribe(user => {
      const {userViewPreference=''} = user;
      this.userView = userViewPreference;
    })
  }

  handleSearchwordDeletion = (key, index) => {
    let mappedObject={};
    let list = this.advancedSearchObject[key];
    let newList = list.filter((item, i) => {
      return i !== index;
    });
    let payload = {
      field : reducerMap[key],
      value : newList && newList.length > 0 ? newList.join(',') : ''
    }
    this.store.dispatch(new HandlePillDeletion(payload));
    this.store.dispatch(new SetSearchKeyword(''));
    this.store.dispatch(new DestroyDataObject());
    this.store.dispatch(new DestroyProductSummary());
    this.store.dispatch(new ResetFilters());
    this.store.dispatch(new ManageAdvancedSearchDisplay('none'));

    for (let k in this.advancedSearchObject){
      let fieldList = this.advancedSearchObject[k]
      if(fieldList && fieldList.length > 0){
        mappedObject[searchMap[k]] = fieldList;
      }
    }

    if(_.isEmpty(mappedObject)){
      this.store.dispatch(new SetActiveSearch(false));
    }

    let searchObject = {
      startDate : this.startDate,
      endDate : this.endDate,
      advancedSearch : advancedSearchObjectBuilder(mappedObject)
    };

    if(this.userView === 'mixed'){
      this.store.dispatch(new GetProducts(JSON.stringify(searchObject)));
      this.store.dispatch(new GetProductSummary(JSON.stringify({...searchObject, summary : true})));
    }else if(this.userView === 'summary'){
      this.store.dispatch(new BlockSearchChangeView('summary'));
      this.store.dispatch(new GetProductSummary(JSON.stringify({...searchObject, summary : true})));
    }else if(this.userView === 'details'){
      this.store.dispatch(new BlockSearchChangeView('details'));
      this.store.dispatch(new GetProducts(JSON.stringify(searchObject)));
    }

  }

}
