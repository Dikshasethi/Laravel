import { Component, OnInit, EventEmitter, Output, Input, HostListener } from '@angular/core';
import { LogoutUser } from '../../actions/userDetail.actions';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { DestroyAutocompleteList, GetCustodianAutocompleteList, GetProjectData, GetPcBusinessUnitAutocompleteList, GetCheckoutAutocomplete } from '../../actions/autocomplete.actions';
import { GetReservationTableData, ValidateCheckoutAsset, ReCheckoutAsset, CheckOutAsset, SetReservationTableData } from '../../actions/checkout.action';
import { DatePipe } from '@angular/common';
import { ValidateHardReserveAssetDate, CreateReservation } from '../../actions/proposalPageData.action';
import * as moment from 'moment';
import * as _ from 'lodash';
import localDate from '../../utils/date/localDate';
import dateValidation from '../../utils/date/dateValidator';

@Component({
  selector: 'app-reservation-modal',
  templateUrl: './reservation-modal.component.html',
  styleUrls: ['./reservation-modal.component.css']
})
export class ReservationModalComponent implements OnInit {

  constructor(private store: Store<AppState>,private datePipe: DatePipe) { }
  recheckoutModalDisplay="none";
  originalTableData = [];
  tableData=[];
  autocompleteSubscription;
  reservationTableSubscription;
  checkedOutSubscription;
  hardReserveSubscription;
  validatedHarReservedAssetSubscription;
  recheckoutSubscription;
  selectedProject:any={};
  projectData=[];
  suggestionList=[];
  selectedPCBusinessUnit = '';
  modalDisplay="none";
  validatedCheckoutDataSubscription;
  validatedCheckoutData;
  selectedItem;
  isShowSuggestionRequired = false;
  projectNumber = '';
  selectedValue;
  custodian;
  selectedCustodian;
  referenceNumber;
  recheckoutLocation;
  recheckoutArea;
  checkOutLocation = "";
  checkOutLocationText = "";
  checkOutAreaText = "";
  checkOutArea = "";
  recheckoutStartDate;
  recheckoutEndDate;
  checkoutStartDate;
  checkoutEndDate;
  hardReserveStartDate="";
  hardReserveEndDate="";
  hardReserveStartDateFlag  = false;
  hardReserveEndDateFlag  = false;
  isApplyDisabled=true;
  cartItemsToBeDeleted = [];
  isRefreshData=false;
  selectedTableData = [];
  isShowTable=false;
  callOutId="";
  carthardreserveConfirmationModalDisplay:string = "none";
  buttonText :string;
  maxLength = 30;
  currentDate = moment().format('YYYY-MM-DD');
  minDate = "";
  recheckoutActionDisabled: boolean;
  checkoutActionDisabled: boolean;
  hardreserveActionDisabled: boolean;
  assetValidationtLocation:string='';
  public innerHeight: any;
  @Input() process
  detailsPanelValue={
    "newstartdate":"",
    "newenddate":"",
    "isChangeDateRange":false,
    "refno":"",
    "showCustodian":"false",
    "showApply":"false"
  }
  hardReservePanelValue={
    "startDate":"",
    "endDate":""
  }

  @Input()
  set modalProperties( val ) {
    if(val){
      this.recheckoutModalDisplay = val.display;
      this.originalTableData = val.selectedAssets;
      this.isRefreshData = false;
      this.tableData = val.selectedAssets;
      this.isShowTable=false;
      this.projectNumber= '';
      this.selectedCustodian = val.custodian;
      this.custodian = val.custodian.name;
      if (this.tableData){
      this.tableData.forEach((obj, i) => 
      {
        obj['maxLength'] = this.maxLength;
        if(this.process === 'Hard Reserve'){
          obj['showWarning']=false;
        }
        obj['isAssetSelected']=false;
        if(this.process === "Re-checkout"){
          obj['isAreaDisabled'] = true,
          obj['proposalDateRange'] = [],
          obj['availability'] ="",          
          obj['isShowLocationWarning'] = false,
          obj['isShowAreaWarning'] = false,
          obj['referencenumber']=""
          this.detailsPanelValue.showApply = "true";
        }
      })
    }
    };
      
    
  }
  @Output() loaderModalStatusChange = new EventEmitter<any>();
  @Output() deleteItemsFromCart = new EventEmitter<any>();
  @Output() modalClosed = new EventEmitter<any>();
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;
  }
  ngOnInit() {
    this.innerHeight = window.innerHeight;

    this.autocompleteSubscription = this.store.pipe(select(state => state.Autocomplete.projectAutocomplete))
    .subscribe(autocompleteObject => {
      const {
        suggestionList,isFetchingAutocompleteList
      } = autocompleteObject;   
      if(suggestionList && suggestionList['isAuthenticate']=="not authenticated"){
        this.store.dispatch(new LogoutUser({}));
      }else{
        this.suggestionList = suggestionList;
      }
      
    });

    this.autocompleteSubscription = this.store.pipe(select(state => state.Autocomplete.checkoutAutocomplete))
    .subscribe(autocompleteObject => {
      const {
        suggestionList,isFetchingAutocompleteList, field
      } = autocompleteObject;   
      if(suggestionList && suggestionList['isAuthenticate']=="not authenticated"){
        this.store.dispatch(new LogoutUser({}));
      }else{
        this.suggestionList = suggestionList;
      }
      
    });

    this.reservationTableSubscription = this.store.pipe(select(state => state.CheckOutPageData.reservationTableData))
    .subscribe(reservationTableObject => {
      const {
        reservationTableData,checkoutFetchIsLoading
      } = reservationTableObject;   
      this.modalDisplay = (checkoutFetchIsLoading==undefined || checkoutFetchIsLoading) ? 'block':'none';
      this.loaderModalStatusChange.next(this.modalDisplay);
      if(reservationTableData && reservationTableData['isAuthenticate']=="not authenticated"){
        this.store.dispatch(new LogoutUser({}));
      }else{
        if(reservationTableData && reservationTableData.tableArray){
          this.projectData = reservationTableData.tableArray;
          if(this.process=='Re-checkout'){
            this.configureRecheckoutTableData()
          }else if(this.process=='Hard Reserve'){
            this.configureHardReserveTableData()
          }else if(this.process=='Check Out'){
            this.configureCheckoutTableData()
          }
        }
        
      }      
    });

    this.validatedCheckoutDataSubscription = this.store.pipe(select(state => state.CheckOutPageData.validatedCheckoutData))
    .subscribe(validatedData => {
      const {
        validatedCheckoutData,checkoutFetchIsLoading
      } = validatedData;   
      this.modalDisplay = (checkoutFetchIsLoading==undefined || checkoutFetchIsLoading) ? 'block':'none';
      this.loaderModalStatusChange.next(this.modalDisplay);
      if(validatedCheckoutData && validatedCheckoutData['isAuthenticate']=="not authenticated"){
        this.store.dispatch(new LogoutUser({}));
      }else{
        if(validatedCheckoutData){
          if(this.process=="Re-checkout"){
            this.validateReCheckoutTableData(validatedCheckoutData);
          }else if(this.process=="Check Out"){
            this.validateCheckoutTableData(validatedCheckoutData)
          }
        }
      }
      
    });

    this.validatedHarReservedAssetSubscription = this.store.pipe(select(state => state.ProposalPageData.validatedHardReservedData))
    .subscribe(validatedData => {
      const {
        validatedHardReservedData,isFetchingProposalData
      } = validatedData;   
      this.modalDisplay = (isFetchingProposalData==undefined || isFetchingProposalData) ? 'block':'none';
      this.loaderModalStatusChange.next(this.modalDisplay);
      if(validatedHardReservedData && validatedHardReservedData['isAuthenticate']=="not authenticated"){
        this.store.dispatch(new LogoutUser({}));
      }else{
        if(validatedHardReservedData){
          this.validateHardReserveTableData(validatedHardReservedData)
        }
      }
      
    });

    this.recheckoutSubscription = this.store.pipe(select(state => state.CheckOutPageData.recheckedoutData))
    .subscribe(data => {
      const {
        recheckedoutData,checkoutFetchIsLoading
      } = data;
      this.recheckoutActionDisabled = checkoutFetchIsLoading;
      this.modalDisplay = (checkoutFetchIsLoading==undefined || checkoutFetchIsLoading) ? 'block':'none';
      this.loaderModalStatusChange.next(this.modalDisplay);
      if(recheckedoutData){
        this.isRefreshData = true;
        this.editRecheckoutTableData(recheckedoutData)
      }
    });

    this.checkedOutSubscription = this.store.pipe(select(state => state.CheckOutPageData.checkedoutData))
    .subscribe(data => {  
      const {
        checkedoutData,checkoutFetchIsLoading
      } = data;
      this.checkoutActionDisabled = checkoutFetchIsLoading;
      this.modalDisplay = (checkoutFetchIsLoading==undefined || checkoutFetchIsLoading) ? 'block':'none';
      this.loaderModalStatusChange.next(this.modalDisplay);
      if(checkedoutData && checkedoutData['isAuthenticate']=="not authenticated"){
        this.store.dispatch(new LogoutUser({}));
      }
      if(checkedoutData && checkedoutData['hasError']){
        alert("There is some technical error in the application. Please contact the system administrator.");
      }else{
        if(checkedoutData){
          this.isRefreshData = true;
          this.editCheckoutTableData(checkedoutData)
        }
      }
      
    })

    this.hardReserveSubscription = this.store.pipe(select(state => state.ProposalPageData))
    .subscribe(data => {
      this.hardreserveActionDisabled = data.hrIsLoading;
      if(!_.isEmpty(data.hrResponseObj)){
        this.loaderModalStatusChange.next('none');
          this.editHardReserveTableData(data.hrResponseObj);
          this.isRefreshData = true;
      }
    });
  }

  ngOnDestroy(){
    this.hardReserveSubscription.unsubscribe();
    this.checkedOutSubscription.unsubscribe();
    this.recheckoutSubscription.unsubscribe();
    this.validatedHarReservedAssetSubscription.unsubscribe();
    this.validatedCheckoutDataSubscription.unsubscribe();
    this.reservationTableSubscription.unsubscribe();
    this.autocompleteSubscription.unsubscribe();

    this.onRecheckoutModalClose('destroy');
    this.store.dispatch(new SetReservationTableData([]));
  }

  localDateWrapper = (date) => {
    return date ? localDate(date, 'DD-MMM-YYYY') : '';
  }

  configureRecheckoutTableData(){
    let tableData= this.tableData;
    let datePipe = this.datePipe;
    this.projectData.forEach(prData =>{ 
      tableData.forEach(function(tblData){ 
        tblData["recheckoutDestinationLocationText"]=""
        tblData["recheckoutDestinationLocation"]=""
        tblData["recheckoutDestinationAreaText"]=""
        tblData["recheckoutDestinationArea"]=""
        tblData["referencenumber"]=""
        tblData["status"]=""
        tblData["isAssetSelected"]=false
        if(tblData.coid==prData.coid){         
          if(!prData.daterange || prData.daterange.length == 0){
            tblData['newcheckoutdate'] = dateValidation(prData.checkoutdate) ? moment(prData.checkoutdate).format('DD-MMM-YYYY') : '';
            tblData['newexpectedcheckindate'] = dateValidation(prData.expectedcheckindate) ? moment(prData.expectedcheckindate).format('DD-MMM-YYYY') : '';
            tblData['proposalDateRange'] = []
            tblData['recheckoutProposalNumber'] = ""
            tblData['recheckoutPdid'] = ""
            tblData['projectstartdate'] = prData.projectstartdate
            tblData['projectenddate'] = prData.projectenddate
            tblData['projectProposalNumber'] = "Callout"
            tblData['tablecalloutid'] = "Callout"
          }else{
            tblData['proposalDateRange'] = prData.daterange;
            if(prData.daterange.length>1){
              tblData['selectedValue'] = prData.daterange[0]
            }
            tblData['newcheckoutdate'] = dateValidation(prData.daterange[0].startdate) ? 
            moment(prData.daterange[0].startdate).format('YYYY-MM-DD') : '';
            tblData['newexpectedcheckindate'] = dateValidation(prData.daterange[0].enddate) ? 
            moment(prData.daterange[0].enddate).format('YYYY-MM-DD') : '';
            tblData['projectstartdate'] = ""
            tblData['projectenddate'] = ""
            tblData['recheckoutProposalNumber'] = prData.daterange[0].proposalnumber
            tblData['recheckoutPdid'] = prData.daterange[0].pdid;
            tblData['projectProposalNumber'] = prData.daterange[0].proposalnumber
            
          }
          
        }
      }) 
    })  
    this.isShowTable=true;
  }

  configureHardReserveTableData(){
    this.projectData.forEach(prData =>{ 
      this.tableData.forEach(tblData =>{
        tblData['status']=""; 
        if(prData.cartId === tblData.cartId){
          tblData['projectstartdate'] = prData.projectstartdate;
          tblData['projectenddate'] = prData.projectenddate;
          tblData['startdate'] = dateValidation(prData.startdate) ? moment(prData.startdate).format('DD-MMM-YYYY') : '';
          tblData['enddate'] = dateValidation(prData.enddate) ? moment(prData.enddate).format('DD-MMM-YYYY') : '';
          if(typeof prData.available === 'boolean'){
            if(prData.available){
              tblData['available'] = "Available"            
            }else{
              tblData['available'] = "UnAvailable";
            }
          }else{
            tblData['available'] = '';
          }
        }
      })
    })
    this.isShowTable=true;
  } 

  configureCheckoutTableData(){
    this.projectData.forEach(prData =>{ 
      this.tableData.forEach(tblData =>{
        tblData['status']=""; 
        tblData['projectstartdate'] = prData.projectstartdate;
        tblData['projectenddate'] = prData.projectenddate;
        tblData['checkoutdate'] = moment(prData.checkoutdate).isValid() ? moment(prData.checkoutdate).format('DD-MMM-YYYY') : '';
        tblData['expectedcheckindate'] = moment(prData.expectedcheckindate).isValid() ? moment(prData.expectedcheckindate).format('DD-MMM-YYYY') : '';
        if(typeof prData.available === 'boolean'){
          if(prData.available){
            tblData['available'] = "Available"            
          }else{
            tblData['available'] = "UnAvailable";
          }
        }else{
          tblData['available'] = '';
        }
      })
    })
    this.isShowTable=true;
  }

  editRecheckoutTableData(recheckedoutData){
    this.tableData.forEach(tblData => {
      tblData['isAssetSelected']=false;
      this.selectedTableData=[];
      recheckedoutData.successList.forEach(data => {
        if((data.assetid === tblData.assetid) && (data.businessunit === tblData.businessunit)){
          tblData['status']="Success";
          tblData['tablecalloutid'] = data.calloutid
        }
      })
      recheckedoutData.failList.forEach(data => {
        if((data.assetid === tblData.assetid) && (data.businessunit === tblData.businessunit)){
          tblData['status']=data.failMessage;
        }
      })
    })
  }

  editCheckoutTableData(checkedOutData){
    this.cartItemsToBeDeleted=[];
    this.tableData.forEach(tblData => {
      tblData['isAssetSelected']=false;
      this.selectedTableData=[];
      checkedOutData.successList.forEach(data => {
        this.callOutId= data.calloutid;
        if((data.assetid === tblData.assetid) && (data.businessunit === tblData.businessunit)){
          tblData['status']="Success";
          this.cartItemsToBeDeleted.push(tblData._id)
        }
      })
      checkedOutData.failList.forEach(data => {
        if((data.assetid === tblData.assetid) && (data.businessunit === tblData.businessunit)){
          tblData['status']=data.failMessage;
        }
      })
    })
    
    if(this.cartItemsToBeDeleted.length > 0){
      this.deleteItemsFromCart.emit(this.cartItemsToBeDeleted);
    }
  }

  editHardReserveTableData(hardReservedData){
    this.cartItemsToBeDeleted=[];
    this.tableData.forEach(tblData => {
      tblData['isStatusUpdated']=false;
      tblData['isAssetSelected']=false;
      this.selectedTableData=[];
    if (hardReservedData.successList){
      hardReservedData.successList.forEach(data => {
        if((data.assetId === tblData.assetid) && (data.businessUnit === tblData.businessunit)){
          tblData['status']="Success";
          this.cartItemsToBeDeleted.push(tblData._id);
        }
      })
    }
    if (hardReservedData.failList){
      hardReservedData.failList.forEach(data => {
        if((data.assetId === tblData.assetid) && (data.businessUnit === tblData.businessunit)){
          tblData['status']=data.failMessage;
          tblData['showWarning']=true;
        }
      })
    }
    })

    if(this.cartItemsToBeDeleted.length > 0){
      this.deleteItemsFromCart.emit(this.cartItemsToBeDeleted);
    }

  }

  validateHardReserveTableData(validatedHardReservedData){
    this.tableData.forEach(tblData=>{
      tblData['status']=""
      validatedHardReservedData.forEach(data=>{
        if(tblData.cartId == data.cartId){
          tblData.startdate= data.hrStartDate ;
          tblData.enddate = data.hrEndDate;
          if(typeof data.isAvailable === 'boolean'){
            if(data.isAvailable){
              tblData['available'] = "Available"            
            }else{
              tblData['available'] = "UnAvailable";
              tblData.isAssetSelected = false;
              this.selectedTableData=this.selectedTableData.filter(data=> data.cartId!=tblData.cartId)          
            }
          }else{
            tblData['available'] = "";
          }
        }
      })
    })
  }

  validateReCheckoutTableData(validatedData){
    this.tableData.forEach(function(tblData){
      validatedData.forEach(function(data){
        if(data.coid == tblData.coid){
          tblData.newcheckoutdate=data.checkoutdate;
          tblData.newexpectedcheckindate=data.expectedcheckindate;
          if(typeof data.isAvailable === 'boolean'){
            if(data.isAvailable){
              tblData.availability = "Available";        
            }else{
              tblData.availability = "UnAvailable";
            }  
          }else{
            tblData.availability = "";
          }        
        }
      });
    });
  }

  validateCheckoutTableData(validatedData){
    this.tableData.forEach(function(tblData){
      validatedData.forEach(function(data){
        if((data.assetid == tblData.assetid) && (data.businessunit == tblData.businessunit)){
          tblData.checkoutdate = data.checkoutdate;
          if(data.availableAssetsInLocationCount){
            tblData.noOfAssetDetails =  `Available Asset - ${data.availableAssetsInLocationCount} at this location`;
          }
          tblData.expectedcheckindate = data.expectedcheckindate
          if(typeof data.isAvailable === 'boolean'){
            if(data.isAvailable){
              tblData.available = "Available"            
            }else{
              tblData.available = "UnAvailable";
            }   
          }else{
            tblData['available'] = "";
          }       
        }
      });
    });
  }

  onProposalDateRangeChange(selectedDateRange,index){
    this.tableData[index].newcheckoutdate = dateValidation(selectedDateRange.startdate) ? 
    moment(selectedDateRange.startdate) : '';
    this.tableData[index].newexpectedcheckindate = dateValidation(selectedDateRange.enddate) ?
    moment(selectedDateRange.enddate).format('YYYY-MM-DD') : '';
    this.tableData[index].recheckoutPdid = selectedDateRange.pdid ;
    this.tableData[index].recheckoutProposalNumber = selectedDateRange.proposalnumber
    this.tableData[index].projectProposalNumber = selectedDateRange.proposalnumber
  }


  handleAutocompleteInputChange(text,field,index=0){
    this.suggestionList = []; 
    if(field === "location"){
      this.tableData[index]['isAreaDisabled'] = true;
      this.tableData[index]['revisedDestinationAreaText'] = '';
      this.tableData[index]['isShowLocationWarning'] = false;
    }else if(field === "area"){
      this.tableData[index]['isShowAreaWarning'] = false;
    }
    if(text!=""){
      if(field=='custodian'){
        if(text.length>=2){
          let obj={
            "index":"employeesearch",
            "search_keyword":text,
            "field":"custodian"
          }
          this.store.dispatch(new DestroyAutocompleteList());
          this.store.dispatch(new GetCustodianAutocompleteList(obj));
        }     
      }else if(field === "location" || field === "area"){
        let obj =  {
          "field" : field     
        }
        if(field === "location"){
          obj['locationDescription'] = text
        }else if(field === "area"){
          obj['locationCode'] = this.tableData[index]['revisedDestinationlocation'];
          obj['areaDescription'] = text ;
        }
        this.store.dispatch(new DestroyAutocompleteList());
        this.store.dispatch(new GetCheckoutAutocomplete(obj));
      }else{
        let obj={
          "skip" : 0,
          "limit" : 10,
          "filter":{}
        }
        obj.filter[field]=text           
        this.store.dispatch(new DestroyAutocompleteList());
        if(field=="PROJECTID"){
          this.selectedTableData.length = 0;
          this.selectedProject ={};
          this.isShowTable=false;
          if(this.selectedPCBusinessUnit !='')
            obj.filter["PCBUSINESSUNIT"]=this.selectedPCBusinessUnit;
          obj.filter["PROJECTSTATUS"]="A";
          this.store.dispatch(new GetProjectData(obj));
        }
        else if(field=="PCBUSINESSUNIT"){
          this.selectedTableData.length = 0;
          this.selectedProject ={};
          this.isShowTable=false;
          this.projectNumber = "";
          this.selectedPCBusinessUnit = text;
          this.store.dispatch(new GetPcBusinessUnitAutocompleteList(obj));
        }
        
      }
    }else{
      if(field=="PCBUSINESSUNIT"){
        this.selectedPCBusinessUnit = "";
    }
  }
}
  suggestionSelected(suggestion,field,index=0){
    if(index!=undefined && field=="location"){
      this.tableData[index]['recheckoutDestinationLocationText']=suggestion.locationText
      this.tableData[index]['recheckoutDestinationLocation']=suggestion.locationCode
      this.tableData[index]['isShowLocationWarning'] = false
      this.tableData[index]['isAreaDisabled'] = false
    }else if(index!=undefined && field=="area"){
      this.tableData[index]['recheckoutDestinationAreaText']=suggestion.areaText
      this.tableData[index]['recheckoutDestinationArea']=suggestion.areaCode
      this.tableData[index]['isShowAreaWarning'] = false
    }
    else if(field=="PROJECTID"){
      this.projectNumber=suggestion.PROJECTID;
      this.selectedPCBusinessUnit=suggestion.PCBUSINESSUNIT;
      this.selectedProject = suggestion;
      if(this.process=="Re-checkout" || this.process=="Hard Reserve" || this.process=="Check Out"){
        this.fetchProjectData()
      }
    }else if(field=="PCBUSINESSUNIT"){
      this.selectedPCBusinessUnit = suggestion.PCBUSINESSUNIT
    }else if(field=="custodian"){
      this.custodian = suggestion.empName
      this.selectedCustodian = suggestion;
    }    
  }

  fetchProjectData(){
    let assetData = []    
    let obj = {
      "projectnumber" : this.projectNumber,
    }
    if(this.process == "Re-checkout"){
      obj['fromCart'] = false
      obj['reservationType']='checkout'
    }else if(this.process=="Hard Reserve"){
      obj['fromCart'] = true
      obj['reservationType']='hardreserve'
    }if(this.process == "Check Out"){
      obj['fromCart'] = true
      obj['reservationType']='checkout'
    }
    this.tableData.forEach(tblData =>{
      let assetObj = {
        "subtype2": tblData['subtype2'],
        "coid": tblData['coid'],
        "businessunit": tblData['businessunit'],
        "assetid": tblData['assetid'],
        "cartId": tblData['cartId']
      }
      assetData.push(assetObj)       
    })
    obj['assetList']=assetData
    this.loaderModalStatusChange.next("block");
    this.store.dispatch(new GetReservationTableData(obj));
  }

  onTableSelect(data){
    if(data.isAssetSelected){
      this.selectedTableData.push(data);
    }else{
      if(this.process=="Re-checkout"){
        this.selectedTableData = this.selectedTableData.filter(function( obj ) {
          return obj.coid !== data.coid;
        });
      }else if(this.process=="Hard Reserve" || this.process=="Check Out"){
        this.selectedTableData = this.selectedTableData.filter(function( obj ) {
          return obj.cartId !== data.cartId;
        });
      }
    }

    if(this.selectedTableData.length == 1){
      if(this.process=="Re-checkout"){
        this.detailsPanelValue["newstartdate"] = this.selectedTableData[0].newcheckoutdate;
        this.detailsPanelValue["newenddate"] = this.selectedTableData[0].newexpectedcheckindate;
      }else if(this.process=="Hard Reserve"){
        this.hardReservePanelValue={
          "startDate":this.selectedTableData[0].startdate,
          "endDate":this.selectedTableData[0].enddate
        }
        this.hardReserveStartDate = this.selectedTableData[0].startdate
        this.hardReserveEndDate  = this.selectedTableData[0].enddate
      }else if(this.process=="Check Out"){
        this.detailsPanelValue["newstartdate"] = this.selectedTableData[0].checkoutdate;
        this.detailsPanelValue["newenddate"] = this.selectedTableData[0].expectedcheckindate;
      }
    }else{
      if(this.process=="Re-checkout"){
        this.detailsPanelValue["newstartdate"] = "";
        this.detailsPanelValue["newenddate"] = "";
      }else if(this.process=="Hard Reserve"){
        this.hardReservePanelValue={
          "startDate":"",
          "endDate":""
        }
        this.hardReserveStartDate = ""
        this.hardReserveEndDate = ""
      }else if(this.process=="Check Out"){
        this.detailsPanelValue["newstartdate"] = "";
        this.detailsPanelValue["newenddate"] = "";
      }
    }
  }

  onRecheckoutModalClose(action){
    this.selectedProject={};
    this.projectNumber=null;
    this.selectedPCBusinessUnit = ''
    this.custodian = ''
    this.selectedCustodian = {};
    this.recheckoutModalDisplay="none";
    this.selectedTableData = [];
    this.tableData=[]
    this.originalTableData=[]
    if(this.isRefreshData){
      this.modalClosed.next(action)
    }

  }

  onLocationSelect(loc){
    if(loc == ""){
      this.isApplyDisabled = true;
    }else{
      if(this.process === "Re-checkout"){
        this.recheckoutLocation = loc
      }else if(this.process === "Check Out"){
        this.checkOutLocation = loc.locationCode;
        this.checkOutLocationText =loc.locationText
      }
      
    }
  }

  onAreaSelect(area){
    if(area == ""){
      this.isApplyDisabled = true;
    }else{
      if(this.process=="Re-checkout"){
        this.recheckoutArea = area
        this.isApplyDisabled = false;
      }else if(this.process === "Check Out"){
        this.checkOutArea = area.areaCode;
        this.checkOutAreaText = area.areaText;
      }
      
    }
    
  }

  onReferenceNumberChange(refno){
    this.referenceNumber = refno;
  }

  onApplyClick(){
    this.selectedTableData.forEach(tableData =>{
      tableData['recheckoutDestinationLocationText']=this.recheckoutLocation.locationText
      tableData['recheckoutDestinationLocation'] = this.recheckoutLocation.locationCode
      tableData['recheckoutDestinationAreaText']=this.recheckoutArea.areaText
      tableData['recheckoutDestinationArea'] = this.recheckoutArea.areaCode
      tableData['isAreaDisabled'] = false;
      tableData['referencenumber'] = this.referenceNumber;
    });
  }

  onDateChange(details){
    if(this.process=='Re-checkout'){
      this.recheckoutStartDate = details.newstartdate;
      this.recheckoutEndDate = details.newenddate
    }else if(this.process == 'Check Out'){
      this.checkoutStartDate = details.newstartdate;
      this.checkoutEndDate = details.newenddate;
      this.assetValidationtLocation = details.destinationLocation

    }
   
  }

  getOriginalData = (assetid='', businessunit='') => {
    let originalData = {};
    for (let i = 0; i < this.originalTableData.length; i++){
      let record = this.originalTableData[i];
      if(
        record['assetid'] === assetid && 
        record['businessunit'] === businessunit
      ){
        originalData = JSON.parse(JSON.stringify(record));
        break;
      }
    }
    return originalData;
  }

  onConfirmDateChange(data){
    let selectedData=[];
    this.selectedTableData.forEach(tableData => {
      let obj={
        "assetid" : tableData.assetid,
        "businessunit" : tableData.businessunit,
      }
      if(this.process=='Re-checkout'){
        let originalData = this.getOriginalData(tableData.assetid, tableData.businessunit);
        obj["coid"]= tableData.coid;
        obj["checkoutdate"] = dateValidation(this.recheckoutStartDate) ? 
        moment(this.recheckoutStartDate).format('YYYY-MM-DD') : '';
        obj["expectedcheckindate"] = dateValidation(this.recheckoutEndDate) ? 
        moment(this.recheckoutEndDate).format('YYYY-MM-DD') : '';
        obj['calloutid'] = originalData['calloutid'] || '';
        obj['pdid'] = originalData['pdid'] || '';
      }else if(this.process == 'Check Out'){
        obj["checkoutdate"] = dateValidation(this.checkoutStartDate) ? 
        moment(this.checkoutStartDate).format('YYYY-MM-DD') : '';
        obj["expectedcheckindate"] = dateValidation(this.checkoutEndDate) ? 
        moment(this.checkoutEndDate).format('YYYY-MM-DD') : '';
        obj["location"] = this.assetValidationtLocation;
        obj["subtype2"]=tableData.subtype2
      }
      selectedData.push(obj);
    });
    let obj = {
      "assetList":selectedData,
      "apitype" : this.process
    }
    this.loaderModalStatusChange.next("block");
    this.store.dispatch(new ValidateCheckoutAsset(obj));
    
  }

  onRecheckoutClick(){
    let isProceedwithRecheckout = true
    let checkinDate = moment().format('YYYY-MM-DD');
    this.tableData.forEach(tblData => {
      if(tblData.isAssetSelected && 
        (!tblData.recheckoutDestinationLocation || tblData.recheckoutDestinationLocation=="")){
          tblData.isShowLocationWarning = true;
          isProceedwithRecheckout = false;
      }else if(tblData.isAssetSelected && 
        (!tblData.recheckoutDestinationArea || tblData.recheckoutDestinationArea=="")){
          tblData.isShowAreaWarning = true;
          isProceedwithRecheckout = false;
      }
    })
    if(isProceedwithRecheckout){
      let assetList =[];
      let tableCopy = JSON.parse(JSON.stringify(this.selectedTableData));
      tableCopy.forEach(tblData => {
        let obj = {
          checkoutobject : {
            destinationlocation : tblData.recheckoutDestinationLocation,
            destinationarea : tblData.recheckoutDestinationArea,
            destinationareadescription : tblData.recheckoutDestinationAreaText,
            destinationlocationdescription : tblData.recheckoutDestinationLocationText,
            assetid : tblData.assetid,
            businessunit : tblData.businessunit,
            checkoutdate : dateValidation(tblData.newcheckoutdate) ? 
            moment(tblData.newcheckoutdate).format('YYYY-MM-DD') : 
            '',
            checkouttime : "00:00:00",
            expectedcheckindate : dateValidation(tblData.newexpectedcheckindate) ? 
            moment(tblData.newexpectedcheckindate).format('YYYY-MM-DD') : 
            '',
            expectedcheckintime : "00:00:00",
            subtype2 : tblData.subtype2,
            peoplesoftcheckoutid : "",
            proposalnumber : tblData.recheckoutProposalNumber,
            projectnumber : this.projectNumber,
            assetcategory : tblData.assetcategory, 
            assetdescription : tblData.assetdescription,
            pdid : tblData.recheckoutPdid,
            projectdescr : this.selectedProject['PROJECTDESCRIPTION'],
            pcbusinessunit : this.selectedPCBusinessUnit,
            checkoutcustodianid : this.selectedCustodian['empId'] || this.selectedCustodian.code,
            checkoutcustodianname :this.selectedCustodian['empName'] || this.selectedCustodian.name,
            customerreferencenumber : tblData.referencenumber,
            projectstartdate : dateValidation(tblData.projectstartdate) ? 
            moment(tblData.projectstartdate).format('YYYY-MM-DD') : '',
            projectenddate : dateValidation(tblData.projectenddate) ? 
            moment(tblData.projectenddate).format('YYYY-MM-DD') : '',
            serialid : tblData.serialid,
            tagnumber : tblData.tagnumber
          },
          checkinobject : {
            checkinlocation : tblData.recheckoutDestinationLocation,
            checkinarea : tblData.recheckoutDestinationArea,
            checkinareadescription : tblData.recheckoutDestinationAreaText,
            checkinlocationdescription : tblData.recheckoutDestinationLocationText,
            assetid : tblData.assetid,
            businessunit : tblData.businessunit,
            checkoutdate : dateValidation(tblData.checkoutdate) ? 
            moment(tblData.checkoutdate).format('YYYY-MM-DD') : '',
            checkouttime : "00:00:00",
            expectedcheckindate : dateValidation(tblData.expectedcheckindate) ? 
            moment(tblData.expectedcheckindate).format('YYYY-MM-DD') : '',              
            expectedcheckintime : "00:00:00",
            peoplesoftcheckoutid : tblData.peoplesoftcheckoutid,
            proposalnumber : tblData.proposalnumber,
            projectnumber : tblData.projectnumber,
            pdid : tblData.pdid,
            calloutid : tblData.calloutid,
            actualcheckindate : checkinDate,
            actualcheckintime : "00:00:00",
            serialid : tblData.serialid,
            tagnumber : tblData.tagnumber,
            checkincustodianid : this.selectedCustodian['empId'] || this.selectedCustodian.code,
            checkincustodianname :this.selectedCustodian['empName'] || this.selectedCustodian.name,
          }
        }
        
        assetList.push(obj)
      })
      let recheckoutObj = {
        "assetList" : assetList
      }
      this.loaderModalStatusChange.next("block");
      this.store.dispatch(new ReCheckoutAsset(recheckoutObj));

    }
  }

  custodianExists = () => {
    if(
      (this.selectedCustodian['empId'] || this.selectedCustodian.code) &&
      (this.selectedCustodian['empName'] || this.selectedCustodian.name)
    ){
      return true;
    }else{
      return false;
    }
  }

  disableRecheckout = () => {
    let disable = false;
    if(!this.selectedTableData.length){
      disable = true;
    }
    for (let i = 0; i < this.selectedTableData.length; i++){
      let row = this.selectedTableData[i];
      let {
        recheckoutDestinationLocation='', recheckoutDestinationArea='',
        recheckoutDestinationAreaText='', recheckoutDestinationLocationText='',
        newcheckoutdate='', newexpectedcheckindate='', availability
      } = row;
      if(
        !recheckoutDestinationArea || !recheckoutDestinationAreaText || 
        !recheckoutDestinationLocation || !recheckoutDestinationLocationText ||
        !newcheckoutdate || !newexpectedcheckindate || !this.projectNumber || 
        availability === 'UnAvailable' || this.custodianExists() === false
      ){
        disable = true;
        break;
      }
    }
    if(this.recheckoutActionDisabled)
    {
      disable = true;
    }
    return disable;
  }

  disableHardReserve = () => {
    let disable = false;
    if(!this.selectedTableData.length){
      disable = true;
    }
    if(this.hardreserveActionDisabled) {
      disable = true;
    }
    for (let i = 0; i < this.selectedTableData.length; i++){
      let row = this.selectedTableData[i];
      let {
        availability='', enddate='', startdate=''
      } = row;
      if(
        !enddate || !startdate || 
        availability === 'UnAvailable' || !this.projectNumber
      ){
        disable = true;
        break;
      }
    }

    return disable;
  }

  disableCheckout = () => {
    const {newenddate,newstartdate}= this.detailsPanelValue;
    let disable = false;
    if(!this.selectedTableData.length){
      disable = true;
    }
    if(this.checkoutActionDisabled) {
      disable = true;
    }
    for (let i = 0; i < this.selectedTableData.length; i++){
      let row = this.selectedTableData[i];
      let {
        available=''
      } = row;
      if(
        !this.checkOutArea || !this.projectNumber ||
        !this.checkOutLocation || available === 'UnAvailable' || 
        !this.hasDates() || this.custodianExists() === false|| !newenddate|| !newstartdate
      ){
        disable = true;
        break
      }
    }
    return disable;
  }

  onHardReserveDateChange(data){
    this.hardReserveStartDate = data.hardReserveStartDate;
    this.hardReserveEndDate = data.hardReserveEndDate;

    this.hardReserveStartDateFlag  = data.startDateFlag;
    this.hardReserveEndDateFlag  =  data.endDateFlag;
    
  }

  onHardReserveApplyClick(){
    let selectedData=[];
    this.selectedTableData.forEach(tableData => {
      let obj={
        "assetId" : tableData.assetid,
        "businessUnit" : tableData.businessunit,
        "cartId": tableData.cartId,
        "hrStartDate" : this.hardReserveStartDate,
        "hrEndDate" : this.hardReserveEndDate
      }
      selectedData.push(obj);
    });
    let obj = {
      "assetList":selectedData
    }
    this.loaderModalStatusChange.next("block");
    this.store.dispatch(new ValidateHardReserveAssetDate(obj));
  }

  onHardReserve(){
    let assetList =[];
    this.selectedTableData.forEach(tblData=>{
      let obj={ 
        "proposalNumber" : "",
        "assetId" : tblData.assetid,
        "hrStartDate" : dateValidation(tblData.startdate) ? 
        moment(tblData.startdate).format('YYYY-MM-DD') : '',
        "hrEndDate" : dateValidation(tblData.enddate) ? 
        moment(tblData.enddate).format('YYYY-MM-DD') : '',
        "projectNumber" : this.projectNumber,
        "pdid" : "",
        "location" : tblData.location,
        "businessUnit" : tblData.businessunit,
        "area"  : tblData.area,
        "assetCategory" : tblData.category,
        "assetDescription" : tblData.description,
        "subType2" : tblData.subtype2,
        "customerName" : this.selectedProject['CUSTOMERNAME'] = this.selectedProject['CUSTOMERNAME']||"",
        "proposalDescription" : "",
        "serialid" : tblData.serialNumber,
        "tagnumber" : tblData.tagNumber,
        "crmnumber" : "",
        "projectstartdate" : dateValidation(this.selectedProject['STARTDATE']) ? 
        moment(this.selectedProject['STARTDATE']).format('YYYY-MM-DD') : '',
        "projectenddate" : dateValidation(this.selectedProject['ENDDATE']) ? 
        moment(this.selectedProject['ENDDATE']).format('YYYY-MM-DD') : '',
        "customerid" : this.selectedProject['CUSTOMERID'] = this.selectedProject['CUSTOMERID']||""
      }
      assetList.push(obj)
    })
    let hrObj={
      assetList: assetList
    }
    this.loaderModalStatusChange.next('block');
    this.store.dispatch(new CreateReservation(hrObj));
  }

  onCheckout(){
    let assetList =[];
    this.selectedTableData.forEach(tblData=>{
      let obj={
        destinationlocation : this.checkOutLocation,
        destinationarea : this.checkOutArea,
        destinationlocationdescription: this.checkOutLocationText,
        destinationareadescription: this.checkOutAreaText, 
        assetid : tblData.assetid,
        businessunit : tblData.businessunit,
        checkoutdate : dateValidation(tblData.checkoutdate) ? 
        moment(tblData.checkoutdate).format('YYYY-MM-DD') : '',
        checkouttime : "00:00:00",
        expectedcheckindate : dateValidation(tblData.expectedcheckindate) ? 
        moment(tblData.expectedcheckindate).format('YYYY-MM-DD') : '',
        expectedcheckintime : "00:00:00",
        subtype2 : tblData.subtype2,
        peoplesoftcheckoutid : "",
        proposalnumber : "",
        proposaldescription : "",
        projectnumber : this.projectNumber,
        assetcategory : tblData.category,
        assetdescription : tblData.description,
        pdid : "",
        calloutid : "",
        oiireferenceno : "",
        projectdescr : this.selectedProject['PROJECTDESCRIPTION'],
        serialid : tblData.serialNumber,
        tagnumber : tblData.tagNumber,
        pcbusinessunit : this.selectedPCBusinessUnit,
        crmnumber : "",
        customerreferencenumber : this.referenceNumber,
        projectstartdate : dateValidation(tblData.projectstartdate) ? 
        moment(tblData.projectstartdate).format('YYYY-MM-DD') : '',
        projectenddate : dateValidation(tblData.projectenddate) ? 
        moment(tblData.projectenddate).format('YYYY-MM-DD') : '',        
        checkoutcustodianid : this.selectedCustodian['empId'] || this.selectedCustodian.code,
        checkoutcustodianname :this.selectedCustodian['empName'] || this.selectedCustodian.name,
      }
      assetList.push(obj)
    })
    let checkoutObj={
      assetList: assetList
    }
    this.loaderModalStatusChange.next('block');
    this.store.dispatch(new CheckOutAsset(checkoutObj));
  }

  onHardReserveClick(){
    this.buttonText = "Hard Reserve";
    this.carthardreserveConfirmationModalDisplay = "block";
  }

  onCheckoutClick(){
    this.buttonText = "Check Out";
    this.carthardreserveConfirmationModalDisplay = "block";
  }
  
  confirmCartHardReserveCheckout(){
    if(this.buttonText === "Hard Reserve" && !this.hardreserveActionDisabled){
      this.carthardreserveConfirmationModalDisplay = "none";
      this.onHardReserve();
    }
    if(this.buttonText === "Check Out" && !this.checkoutActionDisabled){
      this.carthardreserveConfirmationModalDisplay = "none";
      this.onCheckout();
    }
  }

  onAllAssetSelection(event:any){
    this.tableData= this.tableData.map(val=>{
      if(val.status != "Success"){
        val['isAssetSelected']=event.target.checked;
        this.onTableSelect(val);
       
      }
      return val;
    })
  }
  hasDates(){
    for(let item of this.selectedTableData){
      if( 
        !item.checkoutdate || 
        !item.expectedcheckindate
      ){
        return false;
      }
    }
    return true;
  }

  showMoreLess(i,label){
    if(label=="more")
      this.tableData[i].maxLength = this.tableData[i].description.length ;
    else if(label=="less")
      this.tableData[i].maxLength = this.maxLength;
  }
}
