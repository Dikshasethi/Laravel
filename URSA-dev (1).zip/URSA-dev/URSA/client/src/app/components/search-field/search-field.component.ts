import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import {AppState} from '../../models/appState';
import { SetSearchKeyword, SetSearchKeywordLocalStorage, RegisterSearchCount } from '../../actions/search.actions';
import { GetProducts, DestroyDataObject, ClearProductsObjectCache, ClearProductsHierarchyObject} from '../../actions/product.actions';
import { ResetFilters } from '../../actions/refinedBy.actions';
import { ManageAdvancedSearchDisplay, ResetSearch } from '../../actions/advancedSearch.actions';
import { GetProductSummary, DestroyProductSummary, ClearProductSummaryCache, SetSummaryScrollTop } from '../../actions/productSummary.actions';
import { BlockSearchChangeView, SetViewPreference } from '../../actions/user.actions';
import { GetAutocompleteList, DestroyAutocompleteList } from '../../actions/autocomplete.actions';
import { RefreshElasticSearchTokenGet } from '../../actions/userDetail.actions';
import { ResetImageReducer } from '../../actions/imageUpload.actions';
import { ResetProposalPageData } from '../../actions/proposalPageData.action';
import { LogoutUser } from '../../actions/userDetail.actions';
import {summaryRefinedBy, detailsRefinedBy} from '../../utils/refinedBy/refinedByConstants';
import { ResetProductProposalCartData } from '../../actions/proposalData.action';
import * as _ from 'lodash';

@Component({
  selector: 'app-search-field',
  templateUrl: './search-field.component.html',
  styleUrls: ['./search-field.component.css']
})
export class SearchFieldComponent implements OnInit {
  constructor(
    private router:Router, 
    private store: Store<AppState>
  ) {}

  @Input() width : String;
  refinedByFilterKey = 'productFilterObject';
  productToSearch = '';
  startDate;
  endDate;
  advancedSearchDisplay;
  userView;
  refinedByNgrxKey;

  searchSubscription;
  refinedBySubscription;
  displaySubscription;
  userSubscription;
  autocompleteSubscription;
  routerUrl = this.router.url;
  suggestionList= [];
  userDetailSubscription : any;
  hasElasticSearchTokenError : any = false;
  defaultrefinedByObjData={};

  ngOnInit() {
    this.searchSubscription = this.store.pipe(select(state => state.Search))
    .subscribe(searchObject => {
      const {searchKeyword, startDate, endDate} = searchObject;
      this.startDate = startDate;
      this.endDate = endDate;
      this.productToSearch = searchKeyword;
    });

    this.displaySubscription = this.store.pipe(select(state => state.AdvancedSearch.display))
    .subscribe(display => this.advancedSearchDisplay = display);

    this.userSubscription = this.store.pipe(select(state => state.User))
    .subscribe(user => {
      const {userViewPreference=''} = user;
      this.userView = userViewPreference;
      if(['mixed', 'summary'].includes(this.userView)){
        this.refinedByNgrxKey = summaryRefinedBy;
      }else if(['details','hierarchy','utilization', 'forecast'].includes(this.userView)){
        this.refinedByNgrxKey = detailsRefinedBy;
      }
    });

    this.autocompleteSubscription = this.store.pipe(select(state => state.Autocomplete))
    .subscribe(autocompleteObject => {
      if(autocompleteObject['isAuthenticate']=="not authenticated"){
        this.store.dispatch(new LogoutUser({}));
      }
      
      const {globalSuggestionList} = autocompleteObject;
      
      this.suggestionList = globalSuggestionList;
    });


    
    this.refinedBySubscription = this.store.pipe(select(state => state.RefinedBy))
    .subscribe(refinedByObj => {
      this.defaultrefinedByObjData = refinedByObj[this.refinedByNgrxKey] || {};
    })


    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(userDetailObj => {
      const {
        details
      } = userDetailObj;
      if(details['esError']){
        this.hasElasticSearchTokenError = true;
      }else{
        this.hasElasticSearchTokenError = false;
      }
    })

    if(this.routerUrl === '/landing'){
      if(sessionStorage.getItem('searchKeyword')){
        sessionStorage.removeItem('searchKeyword');
        this.store.dispatch(new SetSearchKeyword(''));
      }
    }
  }

  ngOnDestroy(){
    this.searchSubscription.unsubscribe();
    this.displaySubscription.unsubscribe();
    this.userSubscription.unsubscribe();
    this.autocompleteSubscription.unsubscribe();
    this.userDetailSubscription.unsubscribe();
  }

  handleInputChange = (value) => {
    let obj={
      "autoCompleteLetter":value,
      "suggestionField":'globalSuggestionList'
    }
    this.store.dispatch(new DestroyAutocompleteList());
    this.store.dispatch(new SetSearchKeyword(value));
    this.store.dispatch(new GetAutocompleteList(obj));
    
  }

  suggestionSelected = (value) => {
    this.store.dispatch(new SetSearchKeyword(value));
    this.searchProduct(this.productToSearch);
  }

  searchProduct(keyword){
    if(this.hasElasticSearchTokenError){
      this.store.dispatch(new RefreshElasticSearchTokenGet({}));
    }

    let defaultFilters={};
    let cachedPersonalization=sessionStorage.getItem('defaultRefiendByPersonalization')
    defaultFilters = _.isEmpty(this.defaultrefinedByObjData['clickTracker']) ? JSON.parse(cachedPersonalization) : this.defaultrefinedByObjData['clickTracker'];
    let queryObj = {
      keyword,
      startDate : this.startDate,
      endDate : this.endDate,
      filters:{
        ...defaultFilters
      }
    }

    if(sessionStorage.getItem(`${summaryRefinedBy}-frozen`)){
      sessionStorage.removeItem(`${summaryRefinedBy}-frozen`);
    }
    if(sessionStorage.getItem(`${detailsRefinedBy}-frozen`)){
      sessionStorage.removeItem(`${detailsRefinedBy}-frozen`)
    }

    this.store.dispatch(new DestroyAutocompleteList());
    this.store.dispatch(new RegisterSearchCount());
    this.store.dispatch(new SetSearchKeywordLocalStorage(this.productToSearch));
    this.store.dispatch(new ResetSearch());
    this.store.dispatch(new ManageAdvancedSearchDisplay('none'));
    this.store.dispatch(new DestroyProductSummary());
    this.store.dispatch(new DestroyDataObject());
    this.store.dispatch(new ClearProductSummaryCache());
    this.store.dispatch(new ClearProductsObjectCache());
    this.store.dispatch(new ClearProductsHierarchyObject());
    this.store.dispatch(new ResetImageReducer());
    this.store.dispatch(new ResetProposalPageData());
    this.store.dispatch(new SetSummaryScrollTop(0));
    this.store.dispatch(new ResetProductProposalCartData());


    if(this.userView === 'mixed'){
      if(this.router.url === '/landing'){
        this.store.dispatch(new SetViewPreference('details'));
        this.store.dispatch(new GetProducts(JSON.stringify(queryObj)));
      }else if(this.router.url === '/product/:'){
        this.store.dispatch(new GetProducts(JSON.stringify(queryObj)));
        this.store.dispatch(new GetProductSummary(JSON.stringify({...queryObj, summary : true})));
      }
    }else if(this.userView === 'details'){
      this.store.dispatch(new GetProducts(JSON.stringify(queryObj)));
    }else if(this.userView === 'summary'){
      this.store.dispatch(new GetProductSummary(JSON.stringify({...queryObj, summary : true})));
    }
    this.router.navigate(['/product/:']);  
  }

  ShowAdvanceSearch = () => {
    let display = this.advancedSearchDisplay === 'block' ? 'none' : 'block';
    this.store.dispatch(new ManageAdvancedSearchDisplay(display));
  }
}
