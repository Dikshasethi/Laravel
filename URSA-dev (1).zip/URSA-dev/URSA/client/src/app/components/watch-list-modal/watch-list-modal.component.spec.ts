import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WatchListModalComponent } from './watch-list-modal.component';

describe('WatchListModalComponent', () => {
  let component: WatchListModalComponent;
  let fixture: ComponentFixture<WatchListModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WatchListModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WatchListModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
