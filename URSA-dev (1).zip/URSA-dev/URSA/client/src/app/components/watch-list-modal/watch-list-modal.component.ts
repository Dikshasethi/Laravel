import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { WatchList } from '../../models/watchlist.model';
import actionList  from '../../utils/watchList/actionList';

@Component({
  selector: 'app-watch-list-modal',
  templateUrl: './watch-list-modal.component.html',
  styleUrls: ['./watch-list-modal.component.css']
})
export class WatchListModalComponent implements OnInit {

  selectedWatchListActions = [];
  watchList
  watchListModalData: WatchList;
  watchListData: any = [];
  WatchlistActions = [] = actionList; 
  watchListHeader: string = '';
  updatedwatchListModalData: any = {};
  multiSelectautoCompleteData = {
    bindLabel: "label",
    bindValue: 'value',
    selectedInput: []
  };

  @Input() watchListModalDisplay:boolean;
  @Output() closeModal: EventEmitter<any> = new EventEmitter();
  @Output() submitForm: EventEmitter<any> = new EventEmitter();

  @Input()
  set modalProperties(val) {
    if (val) {
        const { watchListModalData, watchListHeader, selectedWatchListActions} = val;
        this.selectedWatchListActions = selectedWatchListActions;
          this.watchListModalData = watchListModalData;
          this.watchListHeader = watchListHeader;
          this.selectedWatchListActions = selectedWatchListActions;
          if(selectedWatchListActions && selectedWatchListActions.length > 0)
          {
              this.multiSelectautoCompleteData = {
                bindLabel: "label",
                bindValue: 'value',
                selectedInput: this.selectedWatchListActions
              };
          }
    }
  }
  constructor() { }

  ngOnInit() {
  }

  ngOnDestroy() {
  }

  submitFormFunction() {
    let obj = {
        'assetList':[this.watchListModalData],
        'actionsToWatch':this.selectedWatchListActions
    }
    this.submitForm.emit(obj);
    this.closeModalFunction();
  }

  closeModalFunction = () => {
    this.resetModal();
    this.closeModal.emit();
  }

  resetModal = () => {
    this.multiSelectautoCompleteData = {
      bindLabel: "label",
      bindValue: 'value',
      selectedInput: []
    };
    this.selectedWatchListActions = [];
  }

  shareCheckedList(selectedValue) {
     this.selectedWatchListActions = selectedValue;
  }

  isSubmitButtonDisabled() {
    return !((this.selectedWatchListActions.length > 0) && (this.watchListModalData.assetid != '') && (this.watchListModalData.businessunit != '')); 
  }

}
