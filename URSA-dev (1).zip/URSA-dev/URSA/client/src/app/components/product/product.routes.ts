import { Routes } from '@angular/router';
import { ProductComponent } from './product.component';

export const ProductRoutes: Routes = [
    { path: ':id', component: ProductComponent }
];