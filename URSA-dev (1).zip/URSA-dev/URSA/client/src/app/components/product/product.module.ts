import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { ProductRoutes } from './product.routes';
import { ProductComponent } from './product.component';
import { ProductSummaryComponent } from '../product-summary/product-summary.component';
import { ProductListComponent } from '../product-list/product-list.component';
import { ProductHierarchyComponent } from '../product-hierarchy/product-hierarchy.component';
import { HardReserveFilterViewComponent } from '../hard-reserve-filter-view/hard-reserve-filter-view.component';
import { SuggestionViewComponent } from '../suggestion-view/suggestion-view.component';
import { AdvancedSearchViewComponent } from '../advanced-search-view/advanced-search-view.component';
import { ProductDetailComponent } from '../product-detail/product-detail.component';
import { FullCalendarComponent } from '../full-calendar/full-calendar.component';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { ForecastComponent } from '../forecast/forecast.component';

@NgModule({
    declarations: [
        ProductComponent,
        ProductSummaryComponent,
        ProductListComponent,
        ProductHierarchyComponent,
        HardReserveFilterViewComponent,
        SuggestionViewComponent,
        AdvancedSearchViewComponent,
        ProductDetailComponent,
        FullCalendarComponent,
        DashboardComponent,
        ForecastComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(ProductRoutes)
    ]
})

export class ProductModule { }