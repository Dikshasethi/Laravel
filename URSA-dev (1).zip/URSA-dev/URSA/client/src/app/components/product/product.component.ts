import { Component, OnInit } from '@angular/core';
import { trigger, style, state, transition, animate, group } from '@angular/animations';
import * as _ from 'lodash';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { 
  GetProducts, DestroyDataObject, 
  CacheProductsObject, ClearProductsObjectCache, 
  SetOnlyProductsObject, GetProductProposalData, ClearProductsHierarchyObject
} from '../../actions/product.actions';
import { productRefinedByList, hardReserveModeRefinedByList } from '../../utils/product/refinedByList';
import { ResetSearch, ManageAdvancedSearchDisplay } from '../../actions/advancedSearch.actions';
import { 
  GetProductSummary, DestroyProductSummary, 
  SetSummaryStatusAndIndex, CacheProductSummaryObject, 
  ClearProductSummaryCache, SetOnlyProductSummaryObject, 
  GetSummaryProposalData, SetSummaryScrollTop 
} from '../../actions/productSummary.actions';
import { SetViewPreference, RemoveBlockSearch } from '../../actions/user.actions';
import { SetSearchKeyword } from '../../actions/search.actions';
import {advancedSearchObjectBuilder} from '../../utils/advancedSearch/queryObjectBuilder';
import { ResetImageReducer } from '../../actions/imageUpload.actions';
import { ResetProposalPageData,CreateReservation } from '../../actions/proposalPageData.action';
import { 
  SetProposalCartWithProposalMode, SetAssetDataInProposalDeatil,
  DeleteProductProposalCartData
} from '../../actions/proposalData.action';
import { SetFilters, ResetFilters } from '../../actions/refinedBy.actions';
import { LogoutUser } from '../../actions/userDetail.actions';
import {summaryRefinedBy, detailsRefinedBy, assetRefinedByMap} from '../../utils/refinedBy/refinedByConstants';
import { AddToCart, GetCartData , DeleteFromCart } from '../../actions/cart.action';
import { ResetDateRange } from '../../actions/search.actions';

import { GetAssetCount, GetCheckoutCount, GetHardReservationChart, GetHardReservationCount, GetPastDueCheckOutCount, 
  Getreceivecount, GetSoftReservationChart, GetSoftReservationCount,GetCheckoutmetrics ,GetShippedChart, Getonhiremetrics } from '../../actions/dashbord.action';
import { createProposalPermission } from '../../utils/config/config';
import { GetWatchListData, ResetWatchListData, AddToWatchList, EditInWatchList } from '../../actions/watchlist.action';
import * as moment from 'moment';
import { RefineBy} from '../../utils/config/config';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        'max-height': '100%', 'opacity': '1', 'visibility': 'visible'
      })),
      state('out', style({
        'max-height': '0px', 'opacity': '0', 'visibility': 'hidden'
      })),
      transition('in => out', [group([
        animate('400ms ease-in-out', style({
          'opacity': '0'
        })),
        animate('600ms ease-in-out', style({
          'max-height': '0px'
        })),
        animate('700ms ease-in-out', style({
          'visibility': 'hidden'
        }))
      ]
      )]),
      transition('out => in', [group([
        animate('1ms ease-in-out', style({
          'visibility': 'visible'
        })),
        animate('600ms ease-in-out', style({
          'max-height': '100%'
        })),
        animate('800ms ease-in-out', style({
          'opacity': '1'
        }))
      ]
      )])
    ]),

    //Filters
    trigger('slideInOutF', [
      state('in', style({
        'max-height': '1100px', 'opacity': '1', 'visibility': 'visible'
      })),
      state('out', style({
        'max-height': '85px', 'opacity': '1', 'visibility': 'visible', 'overflow': 'hidden'
      })),
      transition('in => out', [group([
        animate('200ms ease-in-out', style({
          'opacity': '1'
        })),
        animate('300ms ease-in-out', style({
          'max-height': '85px'
        })),
        animate('200ms ease-in-out', style({
          'visibility': 'visible'
        }))
      ]
      )]),
      transition('out => in', [group([
        animate('400ms ease-in-out', style({
          'visibility': 'visible'
        })),
        animate('600ms ease-in-out', style({
          'max-height': '1100px'
        })),
        animate('700ms ease-in-out', style({
          'opacity': '1'
        }))
      ]
      )])
    ])

  ]
})

export class ProductComponent implements OnInit {  

  constructor(
    private store: Store<AppState>,
    private router:Router
  ) { }

  refinedByNgrxKey = '';
  refinedByList = [];
  previousUserView='';
  refinedByObject={};
  productsObject = {};
  productCount = 0;
  productList = [];
  initialProductList:any =[];
  productSummaryList = [];
  productSummaryObject = {}
  productsObjectCache = {};
  productSummaryObjectCache = {};
  startDate;
  endDate;
  search_keyword = '';
  totalCount = 0;
  fromCount = 0;
  pageSize = 20;
  errorState = false;
  activeSearch=false;
  activeAdvancedSearch=false;
  activeSummarySearch=false;
  totalSummaryCount=0;
  summaryScrollTop;
  activeView;
  activeSummaryIndex = null;
  activeSummaryIndexStatusState = '';
  refinedByInitObject = {};
  summaryRefinedByObj={};
  detailsRefinedByObj={};
  cartData=[]
  advancedSearchObject;
  summarySearchCriteria;
  summaryIsLoading;
  detailsIsLoading;
  imageUploadLoading;
  haltModal;
  searchCount;
  hardReserveMode;
  reservationCart;
  hrCategory;
  hrSubType2;
  hrStartDate;
  hrEndDate;
  hrProjectNumber;
  hrProposalNumber;
  hrProposalDescription;
  hrCustomerName;
  maxHrCount;
  pdid;
  pdidIndex;
  hrBusinessUnit;
  hrIsLoading;
  cartFetchIsLoading;
  imageActiveList;
  imageThumbnailMap;
  deleteUpdateMap;
  fileDataObject;
  imageUploadErrorList;
  clickThroughMode = false;
  blockSearch;
  projectsAutocompleteList;
  getProjectsAutocompleteError;
  pcbusinessunit;
  projectid;
  custodian;
  empId;
  crmnumber;
  imageSubscription;
  productSubscription;
  userDetailSubscription
  summarySubscription;
  dashboardResetIndicator=1;
  refinedBySubscription;
  searchSubscription;
  userSubscription;
  advancedSearchSubscription;
  proposalPageSubscription;
  proposalDataSubscription;
  cartSubscription;
  PersonalizationSubscription;
  addedCartSubscription;
  suggestionList;
  showSuggestion=false;
  isActiveview=false
  deletedCartSubscription;
  normalExit=true;
  userViewPreferenceBtnDisabled;
  userViewPreference;
  backgroundFreez: boolean = false;  
  cartModalDisplay = 'none';
  cartTitle: string = "";
  cartDescription: string = "";
  certExpirationMessage: string = "";
  selectedAsset: any;
  productHierarchy = [];
  initialProductHierarchy = [];
  personalizationFilterData=[];
  addedCartFetchLoading: boolean = false;
  deletedCartFetchLoading: boolean = false;
  deletedPersonalizationRefinedByLoading: boolean = false;
  addedPersonalizationRefinedByDataLoading: boolean = false;
  personalizationRefinedByLoading: boolean = false;
  updatePersonalizationRefinedByDataLoading: boolean = false;
  show_errorMessage: boolean = false;
  error_message: string;
  detailTobeDeletedFromCart: any;
  componentName:string;
  dashboardSubScription:Subscription;
  mappPayload:any={
    "buList":"businessunit",
    "subtype":"subtype2"
  }
  filters: any = {
    name: ''
  }
  watchListSubscription: Subscription;
  watchListModalDisplay: boolean = false;
  WatchListLoading: boolean = false;
  watchListData = [];
  watchListHeader = '';
  filteredWatchListData = [];
  addedWatchListLoading: boolean = false;
  selectedWatchListActions = [];
  selectedWatchListAsset: any;
  watchListModalProperties: any = {
    watchlistHeader: '',
    watchListModalDisplay: false,
    watchListModalData: {
        assetid: '',
        businessunit: ''
    },
    selectedWatchListActions: []
};
  isShowAlert: boolean = false;
  permissions: any = [];
  proposalCart = [];
  isProposalPageType: string = '';
  isProposalMode: boolean;
  proposalButtonText: string = 'Start Proposal';
  proposalid:string;
  indexToAddAt: number = -1;
  userDetailsLoading=false;
  defaultRefinedByPersonalization={};
  
  ngOnInit() {    
    window.addEventListener('storage', this.storageChange,false)
    this.proposalPageSubscription = this.store.pipe(select(state => state.ProposalPageData))
    .subscribe(proposalObj => {
      const {
        hardReserveMode, cartIndex, category,
        startDate, endDate, projectNumber,
        subtype2, proposalNumber, hrResponseObj,
        maxHrCount, pdid, pdidIndex, businessUnit,
        hrIsLoading=false, customerName, proposalDescription,
        projectsAutocompleteList, getProjectsAutocompleteError,
        projectid, pcbusinessunit, custodian,crmnumber        
      } = proposalObj;

      this.hardReserveMode = hardReserveMode;
      this.refinedByList = hardReserveMode ? hardReserveModeRefinedByList : productRefinedByList; 
      this.reservationCart = cartIndex;
      this.hrCategory = category;
      this.hrSubType2 = subtype2;
      this.hrStartDate = startDate;
      this.hrEndDate = endDate;
      this.hrProjectNumber = projectNumber;
      this.hrProposalNumber = proposalNumber;
      this.maxHrCount = maxHrCount;
      this.pdid = pdid;
      this.pdidIndex = pdidIndex;
      this.hrBusinessUnit = businessUnit;
      this.hrIsLoading = hrIsLoading;
      this.hrCustomerName = customerName;
      this.hrProposalDescription = proposalDescription;
      this.projectsAutocompleteList = projectsAutocompleteList;
      this.getProjectsAutocompleteError = getProjectsAutocompleteError;
      this.pcbusinessunit = pcbusinessunit;
      this.projectid = projectid;
      this.custodian = custodian;
      this.crmnumber=crmnumber;

      
      if(Object.keys(hrResponseObj).length > 0){
          this.normalExit = false;
          this.destroyLocalAndGlobalState(true);
          this.router.navigate([`/proposal/${proposalNumber}`]);
      }
    });


    this.proposalDataSubscription = this.store.pipe(select(state => state.ProposalNewData))
    .subscribe(proposalDataObj => {
      const {
        productProposalCartData=[], proposalModeObj={}
      } = proposalDataObj;
      this.isProposalPageType = proposalModeObj['isProposalPageType'] || '';
      this.isProposalMode =  proposalModeObj['isProposalMode'] || false;
      this.proposalid = proposalModeObj['proposalid'] || '';
      this.proposalCart = productProposalCartData;
      this.indexToAddAt = proposalModeObj['indexToAdd'];
      this.detailTobeDeletedFromCart = proposalModeObj['detailTobeDeletedFromCart'];
      if( this.isProposalPageType !== '' && this.isProposalMode) {
        this.proposalButtonText = 'Add To Proposal'
      }
    });

    

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(userDetailObj => {
      const {
        details, isfetch
      } = userDetailObj;
      this.userDetailsLoading = isfetch;
      this.empId = details['employee_id'];
      this.permissions = details['permission'] || [];
      if(_.isEmpty(this.watchListData) && !_.isEmpty(this.initialProductList)) {
        this.fetchWatchListForLoggedInUser();
      }
      if(!_.isEmpty(details['personalizations'])) {
        for(let i = 0; i < details['personalizations'].length; i++) {
          if(details['personalizations'][i].personalizationType==RefineBy) {
            this.defaultRefinedByPersonalization=details['personalizations'][i].data;  
           }
        }  
      }
      if(_.isEmpty(this.defaultRefinedByPersonalization) && !this.userDetailsLoading){
        this.triggerNewSearch();  
      }
      
    })

    this.productSubscription = this.store.pipe(select(state => state.Product))
      .subscribe(data => {
        this.productHierarchy = [];
        this.initialProductHierarchy =[];
        this.showSuggestion=false
        const {productsObject, productList, productFetchIsLoading, productsObjectCache, productHierarchy} = data;
        this.detailsIsLoading = productFetchIsLoading;
        this.activeSearch = productFetchIsLoading;
        if(!_.isEmpty(productHierarchy)){
          this.productHierarchy.push(productHierarchy);
          this.initialProductHierarchy = JSON.parse(JSON.stringify(this.productHierarchy))
        }
        
        if(data.productsObject['isAuthenticate']=="not authenticated"){
        }
        else if(!data.productsObject['hasError'] && !data.productHierarchy['hasError']){
          if(data.productsObject['noDataFound']){
            this.handleNoData('productDetails');
            this.suggestionList=data.productsObject['suggestionList'];
            if(!this.isActiveview)
            this.showSuggestion=true;
          }else{
            if(data.productsObject['hasProposalError']){
              this.errorState = true;
              alert("There is some technical error in the application. Please contact the system administrator.");
            }
            this.productsObject = productsObject;
            this.initialProductList = productList;   
            this.productCount = productList.length;
            if(productList.length>0){
              if(_.isEmpty(this.watchListData) && this.empId){
                this.fetchWatchListForLoggedInUser();
              }else if(!_.isEmpty(this.watchListData)) {
                this.filterProductAccordingToWatchlist();
              }
              if(this.hardReserveMode)
                this.productList = this.initialProductList;
            }           
            this.totalCount = productList.length > 0 ? Number(productsObject['totalCount']) || 0 : 0;
            this.errorState = false;
            this.productsObjectCache = productsObjectCache;
            if(['mixed', 'summary'].includes(this.activeView)){
              this.refinedByInitObject = this.productSummaryObject;
              this.refinedByNgrxKey = summaryRefinedBy;
            }else if(['details','hierarchy','utilization', 'forecast'].includes(this.activeView)){
              this.refinedByInitObject = productsObject;
              this.refinedByNgrxKey = detailsRefinedBy;
            }
          }         
        }else{
          //todo : Error handling behaviour
          this.totalCount = 0;
          if(!this.errorState){
            this.errorState = true;
            alert("There is some technical error in the application. Please contact the system administrator.");
          }
        }

      }, error => {
        this.totalCount = 0;
        if(!this.errorState){
          this.errorState = true;
          alert("There is some technical error in the application. Please contact the system administrator.");
        }
      }
    );

    this.summarySubscription = this.store.pipe(select(state => state.ProductSummary))
    .subscribe(data => {
      this.showSuggestion=false;
      const {
        productSummaryFetchIsLoading, 
        productSummaryList=[], 
        productSummaryObject={},
        searchCriteria={},
        activeStatus='',
        activeIndex=null,
        productSummaryObjectCache,
        scrollTop
      } = data;
      this.activeSummarySearch = productSummaryFetchIsLoading;
      this.summaryIsLoading = productSummaryFetchIsLoading;
      this.summaryScrollTop = scrollTop;
      if(data.productSummaryObject['isAuthenticate']=="not authenticated"){
      }
      else if(!productSummaryObject['hasError']){
        if(data.productSummaryObject['noDataFound']){
          this.handleNoData('productSummary');
          this.suggestionList=data.productSummaryObject['suggestionList']
          if(!this.isActiveview)
              this.showSuggestion=true;
        }else{
          if(data.productSummaryObject['hasProposalError']){
            this.errorState = true;
            alert("There is some technical error in the application. Please contact the system administrator.");
          }
          this.summarySearchCriteria = searchCriteria;
          this.activeSummaryIndex = activeIndex;
          this.activeSummaryIndexStatusState = activeStatus;
          this.productSummaryList = productSummaryList || [];
          this.productSummaryObject = productSummaryObject || {};
          this.productSummaryObjectCache = productSummaryObjectCache; 
          this.totalSummaryCount = (productSummaryList && productSummaryList.length) || 0;
          this.errorState = false;
          if(['mixed', 'summary'].includes(this.activeView)){
            this.refinedByInitObject = productSummaryObject;
            this.refinedByNgrxKey = summaryRefinedBy;
          }else if(['details','hierarchy','utilization', 'forecast'].includes(this.activeView)){
            this.refinedByInitObject = this.productsObject;
            this.refinedByNgrxKey = detailsRefinedBy;
          }
        }
      }else{
        //todo : Error handling behaviour
        this.totalSummaryCount = 0;
        if(!this.errorState){
          this.errorState = true;
          alert("There is some technical error related to product summary. Please contact the system administrator.");
        }
      }
    }, error => {
      this.totalSummaryCount = 0;
      if(!this.errorState){
        this.errorState = true;
        alert("There is some technical error related to product summary. Please contact the system administrator.");
      }
    })

    this.refinedBySubscription = this.store.pipe(select(state => state.RefinedBy))
    .subscribe(refinedByObj => {
      const {
        summaryRefinedBy={}, detailsRefinedBy={}
      } = refinedByObj;
      this.summaryRefinedByObj = Object.assign({}, summaryRefinedBy);
      this.detailsRefinedByObj = Object.assign({}, detailsRefinedBy);
      if(this.empId){
      this.triggerNewSearch(); }
    })


    
    this.PersonalizationSubscription = this.store.pipe(select(state => state.Personalization))
    .subscribe(personalizationData => {
        const {
          personalizationRefinedByData:  { personalizationRefinedByLoading, personalizationRefinedByError },
          deletedPersonalizationRefinedByData: {  deletedPersonalizationRefinedByLoading },
          addedPersonalizationRefinedByData:{ addedPersonalizationRefinedByDataLoading },
          updatePersonalizationRefinedByData:{
          updatePersonalizationRefinedByDataLoading} ,
          errorState: { error = false, error_message },
          }  = personalizationData

         this.personalizationRefinedByLoading = personalizationRefinedByLoading;
         this.deletedPersonalizationRefinedByLoading = deletedPersonalizationRefinedByLoading;
         this.addedPersonalizationRefinedByDataLoading = addedPersonalizationRefinedByDataLoading;
         this.updatePersonalizationRefinedByDataLoading = updatePersonalizationRefinedByDataLoading;
        
        if (error) {
          this.showErrorMessage(error_message);
        }

    })

    this.cartSubscription = this.store.pipe(select(state => state.Cart))
    .subscribe(cartObj => {
      const {
        addedCartData: { addedCartData, addedCartFetchLoading },
        deletedCartData: { deletedCartData, deletedCartFetchLoading },
        cartData: { cartData, cartFetchIsLoading },
        errorState: { error = false, error_message }
      } = cartObj
      this.cartFetchIsLoading = cartFetchIsLoading;
      this.addedCartFetchLoading = addedCartFetchLoading;
      this.deletedCartFetchLoading = deletedCartFetchLoading;

      if (cartData.length) {
        this.cartData = cartData;
        this.editProductAccordingToCart();
      }{
        this.productList = this.initialProductList; 
      }

      if (!_.isEmpty(addedCartData) && !addedCartFetchLoading && !cartFetchIsLoading && !addedCartData['hasError']) {
        this.fetchCartData();
      }

      if (!_.isEmpty(deletedCartData) && !deletedCartFetchLoading && !cartFetchIsLoading && !deletedCartData['hasError']) {
        this.fetchCartData();
      }
      
      if (error) {
        this.showErrorMessage(error_message);
      }
    })

    this.searchSubscription = this.store.pipe(select(state => state.Search))
    .subscribe(searchState => {
      const {startDate, endDate, searchKeyword, searchCount} = searchState;
      this.startDate = startDate;
      this.endDate = endDate;
      this.search_keyword = searchKeyword;
      this.searchCount = searchCount;
      this.haltModal = false;
    })

    this.advancedSearchSubscription = this.store.pipe(select(state => state.AdvancedSearch))
    .subscribe(data => {
      this.isActiveview=data.activeSearch
      let dataCopy = Object.assign({}, data);
      const {
        categoryString='', manufacturerString='',
        modelString='', locationString='', subtype2String='',
        descriptionString='', activeSearch=false
      } = dataCopy;
      let list = {
        category : categoryString && categoryString.split(',') || ([]), 
        manufacturer : manufacturerString && manufacturerString.split(',')  || ([]),
        model : modelString && modelString.split(',')  || ([]), 
        currentLocationFilterList : locationString && locationString.split(',')  || ([]),
        subtype : subtype2String && subtype2String.split(',')  || ([]),
        detailDescription : descriptionString && descriptionString.split(',') || ([]) 
      };
      for (let k in list){
        let fieldList = list[k]
        if(!fieldList || !(fieldList && fieldList.length > 0)){
          delete list[k];
        }
      }
      this.advancedSearchObject = list;
      this.activeAdvancedSearch = activeSearch;
    })

    this.userSubscription = this.store.pipe(select(state => state.User))
    .subscribe(user => {
      const {userViewPreference, blockSearch, previousView} = user;
      this.activeView = userViewPreference;
      this.componentName = this.activeView;
      this.blockSearch = blockSearch;
      this.previousUserView = previousView;
      if(user){
        this.userViewPreference = user.userViewPreference;
      }
      if(['mixed', 'summary'].includes(this.activeView)){
        this.store.dispatch(new ClearProductsObjectCache());
        this.store.dispatch(new ClearProductsHierarchyObject());
        this.store.dispatch(new DestroyDataObject());
        this.refinedByInitObject = this.productSummaryObject;
        this.refinedByNgrxKey = summaryRefinedBy;
        if(!this.clickThroughMode){
          this.normalizeRefinedBy(this.refinedByNgrxKey);
        }
        this.clickThroughMode = false;
      }else if(['details', 'hierarchy','utilization', 'forecast'].includes(this.activeView)){
        this.refinedByInitObject = this.productsObject;
        this.refinedByNgrxKey = detailsRefinedBy;
        if(!this.clickThroughMode){
          this.normalizeRefinedBy(this.refinedByNgrxKey);
        }
      }
    });

    this.imageSubscription = this.store.pipe(select(state => state.ImageUpload))
    .subscribe(imageReducer => {
        const {detailsView} = imageReducer;
        this.imageThumbnailMap = detailsView.thumbnailMap
        this.deleteUpdateMap = detailsView.deleteUpdate
        this.imageActiveList = detailsView.activeList;
        this.fileDataObject = detailsView.fileData;
        this.imageUploadErrorList = detailsView.errorList;
        if(detailsView.loadingList.length > 0){
          this.imageUploadLoading = true;
        }else{
          this.imageUploadLoading = false;
        }
    })



    this.dashboardSubScription = this.store.pipe(select(state => state.Dashboard))
    .subscribe(data => {
      if (data) {
        const {
          errorState: {
            utilization, checkoututilization, onhire, hardReservation, softReservation,shipped, asset, pastDue,receivecount
          }
        } = data;
        if(utilization.error){
          this.showErrorMessage(utilization.error_message)
        }
        if(checkoututilization.error){
          this.showErrorMessage(checkoututilization.error_message)
        }
        if(onhire.error){
          this.showErrorMessage(onhire.error_message)
        }
        if(hardReservation.error){
          this.showErrorMessage(hardReservation.error_message)
        }
        if(shipped.error){
          this.showErrorMessage(shipped.error_message)
        }
        if(receivecount.error){
          this.showErrorMessage(receivecount.error_message)
        }
        if(softReservation.error){
          this.showErrorMessage(softReservation.error_message)
        }
        if(asset.error){
          this.showErrorMessage(asset.error_message)
        }
        if(pastDue.error){
          this.showErrorMessage(pastDue.error_message)
        }
      }
    });

    this.watchListSubscription = this.store.pipe(select(state => state.WatchList))
    .subscribe(WchListData => {
        const {
          watchListData: { watchListLoading, watchListData },
          addedWatchListData: { addedWatchlistData, addedWatchListLoading },
          errorState: { error = false, error_message }
        } = WchListData
      
       this.WatchListLoading = watchListLoading;
       this.addedWatchListLoading = addedWatchListLoading;
       if(watchListData.length) {
        this.watchListData = watchListData;
        this.filterProductAccordingToWatchlist();
      }{
        this.productList = this.initialProductList; 
      }

      if (!_.isEmpty(addedWatchlistData) && !addedWatchListLoading && !watchListLoading) {
        this.fetchWatchListForLoggedInUser();
      }
       if (error) {
        this.showErrorMessage(error_message);
      }
    })

  }

  storageChange (event) {
    window.location.reload();
  }

  ngOnDestroy(){
    if(this.normalExit){
      this.destroyLocalAndGlobalState(false);
      //old proposal functioning
      this.store.dispatch(new ResetProposalPageData());

    }
  }

  showErrorMessage(errorMsg) {
    this.error_message = errorMsg && errorMsg.error && errorMsg.error.message ? errorMsg.error.message : 'Something went wrong';
    this.isShowAlert = true;
  }

  editProductAccordingToCart() {
    if(this.cartData && this.productList){
      let productList = this.initialProductList;
      productList = productList.map(val=>{
          val.isAddedToCart = false;
          return val;
        });
        this.cartData.forEach(cdata=>{
          for(let i=0;i<productList.length;i++){
            if(
              cdata.data &&
              (cdata.data.cartId === productList[i].cartId)
            ){
             productList[i]["isAddedToCart"]=true;
            }
          }
        })
      this.productList = productList;      
    }
  }

  destroyLocalAndGlobalState = (keepProposalSub) => {
    if(this.productSubscription){  this.productSubscription.unsubscribe();  }
    if(this.summarySubscription){  this.summarySubscription.unsubscribe();  }
    if(this.refinedBySubscription){  this.refinedBySubscription.unsubscribe();  }
    if(this.searchSubscription){  this.searchSubscription.unsubscribe();  }
    if(this.userSubscription){  this.userSubscription.unsubscribe();  }
    if(this.advancedSearchSubscription){  this.advancedSearchSubscription.unsubscribe();  }
    if(this.imageSubscription){  this.imageSubscription.unsubscribe();  }
    if(this.cartSubscription){  this.cartSubscription.unsubscribe();  }
    if(this.deletedCartSubscription){  this.deletedCartSubscription.unsubscribe();  }
    if(this.watchListSubscription) { this.watchListSubscription.unsubscribe(); }

    this.store.dispatch(new ManageAdvancedSearchDisplay('none'));
    this.store.dispatch(new DestroyDataObject());
    this.store.dispatch(new ResetSearch());
    this.store.dispatch(new DestroyProductSummary());
    this.store.dispatch(new SetSearchKeyword(''));
    this.store.dispatch(new ClearProductSummaryCache());
    this.store.dispatch(new ClearProductsObjectCache());
    this.store.dispatch(new ClearProductsHierarchyObject());
    this.store.dispatch(new ResetImageReducer());
    this.store.dispatch(new SetSummaryScrollTop(0));
    this.store.dispatch(new ResetFilters());
    this.store.dispatch(new RemoveBlockSearch());
    this.store.dispatch(new ResetWatchListData());

    if(keepProposalSub === false){
      if(this.proposalPageSubscription){  this.proposalPageSubscription.unsubscribe();  }
      this.store.dispatch(new ResetProposalPageData());
    }


    if(sessionStorage.getItem('searchKeyword')){
      sessionStorage.removeItem('searchKeyword');
    }
    if(sessionStorage.getItem(`${summaryRefinedBy}-frozen`)){
      sessionStorage.removeItem(`${summaryRefinedBy}-frozen`);
    }
    if(sessionStorage.getItem(`${detailsRefinedBy}-frozen`)){
      sessionStorage.removeItem(`${detailsRefinedBy}-frozen`)
    }
  }

  triggerNewSearch = () => {
    if(!this.activeSearch && !this.activeSummarySearch && !this.blockSearch){
      if(this.activeView === 'details'){
        if(_.isEmpty(this.productsObject)){
          this.fetchData('', true);
        }
      }else if(this.activeView === 'summary'){
        if(_.isEmpty(this.productSummaryObject)){
          this.fetchData('', 'skipDetailSearch');
        }
      }else if(this.activeView === 'mixed'){
        if(_.isEmpty(this.productSummaryObject) && _.isEmpty(this.productsObject)){
          this.fetchData('', false);
        }else if(_.isEmpty(this.productSummaryObject) && !_.isEmpty(this.productsObject)){
          this.fetchData('', 'skipDetailSearch');
        }else if(!_.isEmpty(this.productSummaryObject) && _.isEmpty(this.productsObject)){
          this.fetchData('', true);
        }
      }else if(this.activeView === 'hierarchy'){
        if(_.isEmpty(this.productsObject)){
          this.fetchData('', true);
        }
      } else if(['utilization', 'forecast'].includes(this.activeView)){
          this.fetchData('', true);
      }
    }
  }

  resetProductList = (skipSearch) => {
    if(!skipSearch){
      this.store.dispatch(new CacheProductSummaryObject());
      this.store.dispatch(new CacheProductsObject())
    }
    this.store.dispatch(new DestroyDataObject());
    this.store.dispatch(new DestroyProductSummary());
    this.store.dispatch(new ResetImageReducer());
    this.blockSearch = false;
  }

  modalDisplayFunction = () => {
    if(
      (
      this.summaryIsLoading || this.detailsIsLoading || 
      this.imageUploadLoading || this.hrIsLoading || this.addedCartFetchLoading || this.deletedCartFetchLoading || this.WatchListLoading || this.addedWatchListLoading
      || this.deletedPersonalizationRefinedByLoading || this.personalizationRefinedByLoading || this.addedPersonalizationRefinedByDataLoading || this.updatePersonalizationRefinedByDataLoading || this.userDetailsLoading)  
      && !this.haltModal 
    ){
      return 'block';
    }else{
      return 'none';
    }
  }

  onItemAddedToCart(asset){
    let cartItems=[{
      serialNumber:asset.serialid,
      tagNumber:asset.tagnumber,
      description:asset.descrlong,
      category:asset.psamsubtypedescr,
      subtype2:asset.subtype,
      businessunit:asset.bu,
      cartId:asset.cartId,
      assetid:asset.assetid,
      location:asset.location,
      area:asset.areaid
    }]
    let cartObj= {
        cartItems : cartItems,
        appName : "URSA",
        appId : "001"
    }        
    this.cartFetchIsLoading=true;
    this.haltModal = false;
    this.store.dispatch(new AddToCart(cartObj));
  }

  itemRemovedFromCart(asset){
   let cartArray= this.cartData.filter(val=>val.data.cartId === asset.cartId);
   let cartId=cartArray[0]["_id"];
    let obj={
      appId : "001", 
      userId : this.empId, 
      cartItemsIdList : [cartId]
    }
    this.cartFetchIsLoading=true;
    this.haltModal = false;
    this.store.dispatch(new DeleteFromCart(obj));
  }

  initializeListLengthState = (refinedByList) => {
    let accumulator = {};
    if(refinedByList){
      for(let i = 0; i < refinedByList.length; i++){
        let refinedBy = refinedByList[i];
        const {label, value} = refinedBy;
        accumulator[label] = {
          hasSelectedFilters : false,
          fullViewLength : false
        } 
      }
    }
    return accumulator;
  }

  fetchCartData(){
    if(this.empId){
      let obj={
        "userId" : this.empId,
        "appId" : "001",
        "limit" : 0,
        "skip" : 0	
      }
      this.cartFetchIsLoading = true;
      this.store.dispatch(new GetCartData(obj));
    }
  }

  normalizeRefinedBy = (refinedByNgrxKey) => {
    let obj;
    let frozenSummarySection = sessionStorage.getItem(`${summaryRefinedBy}-frozen`);
    let frozenDetailsSection = sessionStorage.getItem(`${detailsRefinedBy}-frozen`);
    if(refinedByNgrxKey === summaryRefinedBy){
      obj = JSON.parse(JSON.stringify(this.detailsRefinedByObj));
      if(obj['clickTracker'] && obj['clickTracker']['statusList']){
        delete obj['clickTracker']['statusList'];
      }
      if(obj['listStateTracker'] && obj['listStateTracker']['Status']){
        delete obj['listStateTracker']['Status'];
      }
      if(!this.clickThroughMode && this.activeView !== 'mixed'){
        if(['mixed'].includes(this.previousUserView) || (this.activeView == 'summary') && !['details'].includes(this.previousUserView)){
          this.setFilters(refinedByNgrxKey, this.summaryRefinedByObj);
        }else{
          this.setFilters(refinedByNgrxKey, obj);
        }
        if(frozenDetailsSection){
          let parsedFrozenDetailsSection = JSON.parse(frozenDetailsSection);
          if(['statusList', 'utilization','dayssincelastcheckedin'].includes(parsedFrozenDetailsSection['label'])){
            sessionStorage.removeItem(`${summaryRefinedBy}-frozen`);
          }else{
            sessionStorage.setItem(`${summaryRefinedBy}-frozen`, frozenDetailsSection);
          }
        }
      }else{
        this.setFilters(refinedByNgrxKey, this.summaryRefinedByObj);
      }
    }else if(refinedByNgrxKey === detailsRefinedBy){
      obj = JSON.parse(JSON.stringify(this.summaryRefinedByObj));
      if(
        obj['clickTracker'] && 
        !obj['clickTracker']['statusList']
      ){
        obj['clickTracker']['statusList'] = [];
      }
      if(
        obj['listStateTracker'] && 
        !obj['listStateTracker']['Status']
      ){
        obj['listStateTracker']['Status'] = {
          hasSelectedFilters : false,
          fullViewLength : false
        }
      }
      if(this.clickThroughMode){
        this.setFilters(refinedByNgrxKey, obj);
        if(frozenSummarySection){
          sessionStorage.setItem(`${detailsRefinedBy}-frozen`, frozenSummarySection);
        }
      }else{
        if(['summary', 'mixed'].includes(this.previousUserView)){
          this.setFilters(refinedByNgrxKey, obj);
        }else{
          this.setFilters(refinedByNgrxKey, this.detailsRefinedByObj);
        }
      }
    }
  }

  setFilters = (key, obj) => {
    if(Object.keys(obj).length > 0){
      this.store.dispatch(new SetFilters({
        key, value : obj
      }));
    }
  }

  onDetailSearch = (product) => {
    const {
      category='', assetsubtype2='', 
      status='', bu='',
      index=null
    } = product;
    let newObj = {
      clickTracker : {},
      listStateTracker : this.initializeListLengthState(this.refinedByList)
    }

    if(status){
      newObj['clickTracker']['statusList'] = [status];
      newObj['listStateTracker'][assetRefinedByMap['statusList']] = {
        hasSelectedFilters : true,
        fullViewLength : false
      }
    }

    if(category){
      newObj['clickTracker']['category'] = [category];
      newObj['listStateTracker'][assetRefinedByMap['category']] = {
        hasSelectedFilters : true,
        fullViewLength : false
      }
    }

    if(assetsubtype2){
      newObj['clickTracker']['subtype'] = [assetsubtype2];
      newObj['listStateTracker'][assetRefinedByMap['subtype']] = {
        hasSelectedFilters : true,
        fullViewLength : false
      }
    }

    if(bu){
      newObj['clickTracker']['buList'] = [bu];
      newObj['listStateTracker'][assetRefinedByMap['buList']] = {
        hasSelectedFilters : true,
        fullViewLength : false
      }
    }

    this.store.dispatch(new SetSummaryStatusAndIndex({index, status}));
    this.store.dispatch(new DestroyDataObject());
    this.store.dispatch(new ResetImageReducer());
    this.clickThroughMode = true;
    if(this.activeView === 'summary'){
      this.store.dispatch(new SetViewPreference('details'));
    }
    this.store.dispatch(new SetFilters({
      key : detailsRefinedBy, 
      value : newObj
    }));
  }

  fetchData(scroll, skipSearch) {
    if(!scroll){
      this.fromCount = 0;
      this.pageSize = 20;
    }
    let filter = {}
    if(this.refinedByNgrxKey === summaryRefinedBy){
      if(['mixed', 'details','hierarchy'].includes(this.activeView) && !['skipDetailSearch', false].includes(skipSearch) ){
        filter = this.detailsRefinedByObj['clickTracker'] || {};
      }else{
        filter = this.summaryRefinedByObj['clickTracker'] || {};
      }
    }else if(this.refinedByNgrxKey === detailsRefinedBy){
      filter = this.detailsRefinedByObj['clickTracker'] || {};
    }

    let advancedSearchCopy = Object.assign({}, this.advancedSearchObject);
    let obj = {
      "keyword": _.isEmpty(this.advancedSearchObject) ? this.search_keyword : '',
      "endDate": this.endDate,
      "startDate": this.startDate,
      "fromCount": this.fromCount,
      "pageSize": this.pageSize,
      "filters": this.hardReserveMode ?
      {
        ...filter,
        category : [this.hrCategory],
        subtype : [this.hrSubType2],
        buList : [this.hrBusinessUnit],
        statusList : ["Available"]
      }
      :
      {
        ...filter,
      },
      "advancedSearch" : this.activeAdvancedSearch ? advancedSearchObjectBuilder(advancedSearchCopy) : {}
    }
    this.haltModal = scroll ? true : false;
    if(['mixed', 'details', 'hierarchy'].includes(this.activeView) && skipSearch !== 'skipDetailSearch'){
      this.store.dispatch(new GetProducts(obj));
    }
    if(!scroll && (!skipSearch || skipSearch === 'skipDetailSearch') && ['mixed', 'summary'].includes(this.activeView)){
      this.store.dispatch(new GetProductSummary({...obj, "summary" : true}));
    }
    if(['utilization', 'forecast'].includes(this.activeView)){
      this.store.dispatch(new GetProducts(obj));
      let payload={
        "filters":{
          ...filter,
        }
          
      }
      this.dashboardResetIndicator = (Math.random() + 1) * 0.1234;
      this.fetchMetrics(payload, this.activeView);
    }
  }

  onProductProposalEvent(obj){
    this.store.dispatch(new GetProductProposalData(obj));
  }

  onSummaryProposalEvent(obj){
    this.store.dispatch(new GetSummaryProposalData(obj));
  }

  onScroll = () => {
    if(this.productCount < this.totalCount){
      this.fromCount = this.productCount;
      let difference = this.totalCount - this.fromCount;
      this.pageSize = difference > 20 ? 20 : difference;
      if(!this.activeSearch){
        this.fetchData('scroll', true);
      }
    }
  }

  handleNoData = (dataType) => {
    if(dataType === 'productDetails'){
      if(!_.isEmpty(this.productsObjectCache)){
        this.store.dispatch(new SetOnlyProductsObject());
      }
    }else if(dataType === 'productSummary'){
      if(!_.isEmpty(this.productSummaryObjectCache)){
        this.store.dispatch(new SetOnlyProductSummaryObject());
      }
    }
  }

  resetViewMetadata = (event:any) => {
    this.store.dispatch(new SetSummaryScrollTop(0));
  }

// Redesign View options List

setUserViewPreference = (view) => {
  this.store.dispatch(new SetViewPreference(view));
}

userViewPreferenceClassFunction(label){
  if(this.userViewPreferenceBtnDisabled)
    return 'disabledBtn';
  else if(this.userViewPreference == label && !this.userViewPreferenceBtnDisabled)
    return 'enabledSelectedButton'
  else if(this.userViewPreference != label && !this.userViewPreferenceBtnDisabled)
    return 'enabledUnSelectedButton'
}

// Hard reserve mode
backToProposalPage = () => {
  this.router.navigate([`/proposal/${this.hrProposalNumber}`])
}

triggerHardReserve = () => {
  let accumulator = [];

  for (let i = 0; i < this.reservationCart.length; i++) {
      let index = this.reservationCart[i];
      let asset = this.productList[index];

      let obj = {
          assetId: asset.assetid,
          subType2: asset.subtype,
          assetCategory: asset.psamsubtypedescr,
          assetDescription: asset.descrlong,
          hrStartDate: this.hrStartDate,
          hrEndDate: this.hrEndDate,
          proposalNumber: this.hrProposalNumber,
          projectNumber: this.hrProjectNumber,
          pdid: this.pdid,
          businessUnit: asset.bu,
          pdidIndex: this.pdidIndex,
          location: asset.location,
          area: asset.areaid,
          customerName: this.hrCustomerName,
          proposalDescription: this.hrProposalDescription,
          tagnumber: asset.tagnumber,
          serialid: asset.serialid,
          projectid: this.projectid,
          pcbusinessunit: this.pcbusinessunit,
          custodian: this.custodian,
          crmnumber: this.crmnumber
      }
      accumulator.push(obj);
  }

  if (accumulator.length > 0) {
      this.store.dispatch(new CreateReservation({
          assetList: accumulator,
          proposalid: this.hrProposalNumber
      }));
      this.store.dispatch(new ResetDateRange());
  }
}

triggerProposal() {
    let obj = {
      indexToBeSliced: -1,
      detailToBeAdded: this.proposalCart
    }
    const deleteFromCartObj = this.detailTobeDeletedFromCart
    //ArrayToAddedInDetail array will have only that data with proposal mode true
    if(this.isProposalMode && this.indexToAddAt > -1) {
     const {cartArray=[] ,ArrayToAddedInDetail=[]} = this.filterProductCartData();
      obj = {
        indexToBeSliced: this.indexToAddAt,
        detailToBeAdded: ArrayToAddedInDetail
      }
      if(cartArray.length > 0) {
        //to make all proposal mode key false for cart data
        this.store.dispatch( new SetProposalCartWithProposalMode({
          cartData: cartArray
        }));
      }
      if(ArrayToAddedInDetail.length > 0 &&
        !_.isEmpty(deleteFromCartObj)
        && deleteFromCartObj.hasOwnProperty('view')) {
        const deleteobj = {
          assetid: deleteFromCartObj['assetid'] || '',
          businessunit: deleteFromCartObj['businessunit'] || '',
          oiamsubtype2:  deleteFromCartObj['oiamsubtype2'] || '',
          productcategory: deleteFromCartObj['productcategory'] || '',
          view:  deleteFromCartObj['view'] || ''
        };
        this.store.dispatch(new DeleteProductProposalCartData(deleteobj));
      }
    }
    this.store.dispatch( new SetAssetDataInProposalDeatil(obj));
    if(this.isProposalPageType == 'edit' && 
      this.proposalid && this.proposalid !== '') {
      this.router.navigate([`./proposal/${this.proposalid}`]);
      return;
    }
    this.router.navigate(['./proposal']);
}

filterProductCartData() {
  const cartArray = []; const ArrayToAddedInDetail = [];
  const cartData = this.proposalCart.slice();
  if(cartData.length > 0){
    cartData.forEach((cartData, index) => {
      cartArray.push(cartData)
      if(cartData['proposalMode']){
        ArrayToAddedInDetail.push(cartData);
        cartArray[index]['proposalMode'] = false;
      }
    });
    return {
      cartArray: cartArray,
      ArrayToAddedInDetail: ArrayToAddedInDetail
    }
  }
}

cartAction(event:any){
  if (event.isdisposed != '1') {
    this.cartModalDisplay = 'block';
    this.selectedAsset = event;
    this.certExpirationMessage = !event.activeCertificate ? 'This assets certification is expired' : '';
    this.cartDescription = event.isAddedToCart ? "By removing the selected asset from your cart, you will also be removing any of its child assets from your cart, if they exist." :
        "By adding the selected asset to your cart you will also be adding any of its child assets to your cart, if they exist.";
    this.cartTitle = event.isAddedToCart ? "Remove from Cart" : "Add to Cart";
}
}

confirmButton() {
  this.cartModalDisplay = 'none';
  if (!this.selectedAsset.isAddedToCart) {
      this.onItemAddedToCart(this.selectedAsset);
  } else {
      this.itemRemovedFromCart(this.selectedAsset);
  }
}


fetchMetrics(query, view='') {
  const {filters } = query;
  let startdate, enddate ,forecast;
  if(view === 'utilization'){
    startdate = moment().subtract(1, 'months').format('YYYY-MM-DD');
    enddate = moment().format('YYYY-MM-DD');
  }else{
    forecast=true;
    startdate = moment().format('YYYY-MM-DD');
    enddate = moment().add(1, 'months').format('YYYY-MM-DD');
  }
  let filterObj = {};
  for (let key in filters) {
    if (this.mappPayload.hasOwnProperty(key)) {
      filterObj[this.mappPayload[key]] = filters[key]
    } else {
      filterObj[key] = filters[key]
    }
  }

  this.store.dispatch(new GetHardReservationChart({
    startdate, enddate,filter: filterObj
  }));
  
  this.store.dispatch(new GetAssetCount({ filter: filterObj }))
  this.store.dispatch(new GetHardReservationCount({ filter: filterObj }))
  this.store.dispatch(new GetCheckoutCount({ filter: {
    ...filterObj,
    checkedin : false,
    cancelled : false
  } }))
  if(view === 'forecast'){
    this.store.dispatch(new Getonhiremetrics({
      startdate, enddate,filter: filterObj, forecast
    }));
    this.store.dispatch(new GetCheckoutmetrics({
      startdate, enddate,filter: filterObj, forecast
    }));
    this.store.dispatch(new GetSoftReservationCount({ filter: filterObj }));
    this.store.dispatch(new GetSoftReservationChart({
      startdate, enddate, filter: filterObj
    }));
  }

  if(view === 'utilization'){
    this.store.dispatch(new Getonhiremetrics({
      startdate, enddate,filter: filterObj
    }));
    this.store.dispatch(new GetCheckoutmetrics({
      startdate, enddate,filter: filterObj
    }));
     this.store.dispatch(new GetShippedChart({
      startdate, enddate,filter: filterObj
    }));
    this.store.dispatch(new Getreceivecount({
      startdate, enddate,filter: filterObj
    }));
    this.store.dispatch(new GetPastDueCheckOutCount({ filter: filterObj }));
  }
  
}

WatchListAction(product: any){
  this.watchListModalDisplay = true;
  this.watchListHeader = "Add Watch List Actions";
  this.selectedWatchListAsset = product;
  if(product.isAddedToWatchList)
  {
    this.watchListHeader = "Edit Watch List Actions"
     this.filteredWatchListData =  this.filterWatchListActions(product);

     if(this.filteredWatchListData && this.filteredWatchListData.length > 0)
     {
       this.selectedWatchListActions = this.filteredWatchListData[0].actionsToWatch
     }
  }
  
  this.watchListModalProperties = {
     watchListHeader: this.watchListHeader,
     watchListModalDisplay: true,
     watchListModalData: {
         assetid: product.assetid,
         businessunit: product.bu
     },
     selectedWatchListActions: this.selectedWatchListActions
  }
}

filterWatchListActions(product){
 if(this.watchListData.length > 0) {
  return this.watchListData.filter(wListData => ((wListData.assetid === product.assetid) &&  (wListData.businessunit === product.bu)))
 }
}

fetchWatchListForLoggedInUser() {
    this.store.dispatch(new GetWatchListData({
      "limit" : 0,
      "filter": {
        "userid": this.empId
      },
      "skip" : 0,
      "sort": {}
    }));
}

closeWatchListModal() {
  this.watchListModalDisplay = false;
  this.selectedWatchListActions = [];
}

submitWatchListForm(Obj: any) {
  if(this.selectedWatchListAsset && !this.selectedWatchListAsset.isAddedToWatchList) {
    this.store.dispatch(new AddToWatchList(Obj));
  }else{
    this.store.dispatch(new EditInWatchList(Obj));
  }
    this.closeWatchListModal();
}

filterProductAccordingToWatchlist() {
  if(this.watchListData && this.productList) {
    let productList = this.initialProductList;
    productList = productList.map(val=>{
        val.isAddedToWatchList = false;
        return val;
      });
      this.watchListData.forEach(watchdata=>{
        for(let i=0;i<productList.length;i++){
          if(
            watchdata &&
            (watchdata.assetid === productList[i].assetid) 
            && (watchdata.businessunit === productList[i].bu)
          ){
           productList[i]["isAddedToWatchList"]=true;
          }
        }
      })
    this.productList = productList;
  }

}

removeAlertIcon() {
  this.isShowAlert = false;
}

permissionDisplayCheck = () => {
    return this.permissions.includes(createProposalPermission);
}

}