import { Routes } from '@angular/router';
import { EmoDetailsComponent } from './emodetails.component';

export const EmoDetailsRoutes: Routes = [
    { path: '', component: EmoDetailsComponent },
    { path: ':emoid', component: EmoDetailsComponent },
];