import { Component, ViewChild } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { form_template, address_template, action_buttons } from '../../utils/emo/form_template';
import { emoDetails } from '../../utils/emo/emodetails';
import { EmoModel, EmodetailsModel } from '../../utils/emo/emoModel';
import { GenerateEmoData, GetEmoData, ShipEmo, updateEmo, resetEmoRecord, setEmoMode } from '../../actions/emo.actions';
import { AppState } from '../../models/appState';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { DestroyAutocompleteList, GetProjectData, GetCheckoutAutocomplete, GetLocationAreasCheck, GetCountriesAutoComplete, GetUOMAutoComplete } from '../../actions/autocomplete.actions';
import dateValidation from '../../utils/date/dateValidator';
import * as _ from 'lodash';
import localDate from '../../utils/date/localDate';
import { PrintReportComponent } from '../print-report/print-report.component';
import { emoFilter } from '../../utils/emo/emoFilter';
import { DragulaService } from 'ng2-dragula';
import defaultValues from '../../utils/autoComplete/defaultValues'
import { createEMOPermission,cancelEMOShipPermission, shipEMOPermission } from '../../utils/config/config';
import downlaodcsv from '../../utils/downloadCSV/downlaodcsv';

@Component({
  selector: 'app-emodetails',
  templateUrl: './emodetails.component.html',
  styleUrls: ['./emodetails.component.css']
})
export class EmoDetailsComponent {
  formTemplate: any = form_template;
  addressDetails_template: any = address_template;
  actionButtons: any = action_buttons;
  emoDetails: any = emoDetails;
  details: EmodetailsModel[] = [];
  emoFilter: any = emoFilter;
  emono: string;
  emodate: any = moment().format('YYYY-MM-DD');
  isShippedEmo: boolean = false;
  addedEMoSubScription: Subscription;
  emoDataSubscription: Subscription;
  projectAutocompleteSubscription: Subscription;
  autocompleteSubscription: Subscription;
  autocompleteCheckoutSubscription: Subscription;
  userDetailSubscription: Subscription;
  modalDisplay = 'none';
  emoMode: boolean;
  addedEmo: any = [];
  selectedRecord: any = [];
  isDisplayTypeBtn: boolean = false;
  emoObject: EmoModel = new EmoModel();
  emodetailRecord: EmodetailsModel = new EmodetailsModel();
  emoDetails_disableObj: any = {};
  editindex: any;
  isShowAlert: boolean = false;
  editMode: boolean;
  previousValue: any;
  editableRecordInput: any = {};
  suggestionList: any;
  projectNumber: string;
  empName: string;
  empId: string;
  showDublError: boolean = false;
  emoData = {};
  printData = [];
  printEmoModal = 'none';
  emoConfirmationModal: string = "none";
  existingEmoRecord: EmoModel = new EmoModel();
  previousUrl: string;
  alertState: string;
  alertMessage: string;
  permissions: any = [];
  displayKey: string;
  mode: String = 'create';

  isGetAreaCount: boolean = false;
  cachedAreaList = [];
  areaSuggestionList = [];
  maxLength: number = 20;
  textDisplayLengthMap = {};
  emoActionDisabled: boolean;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private dragulaService: DragulaService,
    private store: Store<AppState>) {
    this.dragulaService
      .drop()
      .subscribe(value => {
        this.updateItemNo();
      });
  }
  @ViewChild(PrintReportComponent) printReportComponent: PrintReportComponent;
  ngOnInit() {
    this.emono = this.route.snapshot.paramMap.get('emoid');
    if (this.emono) {
      this.fetchEmoDetails(this.emono);
      this.mode = 'edit';
    }
    this.addedEMoSubScription = this.store.pipe(select(state => state.Emo.addedEmo))
      .subscribe(data => {
        if (data) {
          const { emoMode, addedEmo = [], previousUrl, emoHeaderRecord } = data;
          this.emoMode = emoMode;
          this.details = addedEmo;
          this.previousUrl = previousUrl;
          if(!this.emono && !this.emoMode && emoHeaderRecord){
             this.emoObject = emoHeaderRecord;
          }
          this.updateItemNo();
        }
      })

    this.emoDataSubscription = this.store.pipe(select(state => state.Emo.emoData))
      .subscribe(data => {
        if (data) {
          const { emoData = {}, emoFetchisLoading } = data;
          this.emoActionDisabled = emoFetchisLoading;
          this.modalDisplay = emoFetchisLoading ? "block" : 'none';
          if (emoData && !emoData['hasError']) {
            if (emoData.emoid) this.emono = emoData.emoid;
            if (emoData.emodate) {
              this.emodate = emoData.emodate;
              this.emoData = emoData;
              this.refineEmoDate(this.emoData);
            }
            this.isShippedEmo = emoData.shipped;
            if (this.isShippedEmo) {
              this.disableAllField();
            }
            if (emoData['save']) {
              if (this.mode === 'create') {
                this.router.navigate(['/emodetails', emoData.emoid]);
              } else {
                this.showAlertMessage('success', 'Success !');
                this.fetchEmoDetails(this.emono);
              }
            } else if (emoData['ship']) {
              this.isShippedEmo = true;
              this.showAlertMessage('success', 'Success !');
            } else if (!emoFetchisLoading && emoData && emoData.emoid) {
              this.details = [...emoData.emodetails, ...this.details];
              let emoRecord = JSON.parse(JSON.stringify(emoData));
              this.emoObject = emoRecord;
              this.existingEmoRecord = JSON.parse(JSON.stringify(emoData));
              this.getUniqueRecord();
            }

            if(emoData['refresh']) {
              this.fetchEmoDetails(this.emono);
            }
          } else {
            let errorMessage = emoData.error && emoData.error.message ? emoData.error.message : 'Something went wrong';
            this.showAlertMessage('error', errorMessage);
          }
        }
      })


    this.projectAutocompleteSubscription = this.store.pipe(select(state => state.Autocomplete.projectAutocomplete))
      .subscribe(autocompleteObject => {
        const {
          suggestionList
        } = autocompleteObject;
        if (suggestionList) {
          this.suggestionList = suggestionList;
        }

      });

    this.autocompleteCheckoutSubscription = this.store.pipe(select(state => state.Autocomplete.checkoutAutocomplete))
      .subscribe(autocompleteObject => {
        const {
          suggestionList
        } = autocompleteObject;
        if (suggestionList) {
          if (this.displayKey === 'country') {
            let countrySuggestionNormalized = this.getUniqueCountries(suggestionList)
            this.suggestionList = [...countrySuggestionNormalized];
          } else if (this.displayKey === 'uom') {
            this.suggestionList = [...suggestionList];
          } else {
            this.suggestionList = [...suggestionList, { 'areaText': 'NA', 'areaCode': 'NA' }];
          }
        }
      });


      this.autocompleteSubscription = this.store.pipe(select(state => state.Autocomplete))
      .subscribe(autoFillData=> {
        let { areaCountForCurrentLocation, isLoading, cachedArea } = autoFillData;
        if(this.isGetAreaCount && !isLoading){
          this.isGetAreaCount = false;
          this.cachedAreaList = cachedArea;
          if(Number(areaCountForCurrentLocation) === 0){
            this.emoObject['destinationarea'] = defaultValues.areaText;
            this.emoObject['destinationareadescription'] = defaultValues.areaText;
          }else{
            this.emoObject['destinationarea'] = '';
            this.emoObject['destinationareadescription'] = '';
          }
        }
      });

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
      .subscribe(userDetailObj => {
        const {
          details
        } = userDetailObj;
        this.empName = `${details['first_name']} ${details['last_name']}`;
        this.empId = details['employee_id'];
        this.permissions = details['permission'] || [];
      })

  }

  ngOnDestroy() {
    this.addedEMoSubScription.unsubscribe();
    this.emoDataSubscription.unsubscribe();
    this.autocompleteSubscription.unsubscribe();
    this.autocompleteCheckoutSubscription.unsubscribe();
    this.userDetailSubscription.unsubscribe();
    this.projectAutocompleteSubscription.unsubscribe();
  }

  updateItemNo() {
    let containerIndex = 0, nonContainerIndex = 0, subcontainerIndex = 0, updatedArray = [];
    for (let i = 0; i < this.details.length; i++) {
      let detail = this.details[i];
      let { itemtype = '' } = detail;
      if (itemtype === 'container') {
        subcontainerIndex = 0;
        containerIndex = nonContainerIndex > containerIndex ? nonContainerIndex + 1 : containerIndex + 1;
        let ismodified = this.isitemNoModified(detail, String(containerIndex));
        updatedArray.push({
          ...detail,
          modified: ismodified,
          itemno: String(containerIndex)
        })
      } else {
        if (!containerIndex) {
          nonContainerIndex++;
          let ismodified = this.isitemNoModified(detail, String(nonContainerIndex));
          updatedArray.push({
            ...detail,
            modified: ismodified,
            itemno: String(nonContainerIndex)
          })
        } else {
          subcontainerIndex++;
          let ismodified = this.isitemNoModified(detail, `${containerIndex}.${subcontainerIndex}`);
          updatedArray.push({
            ...detail,
            modified: ismodified,
            itemno: `${containerIndex}.${subcontainerIndex}`

          })
        }
      }
    }
    this.details = updatedArray;
  }

  isitemNoModified(detail, updatedItemNo) {
    if (this.mode === "edit") {
      if (detail.modified) {
        return true;
      } else if (detail.newdetail) {
        return false
      } else {
        return detail.itemno !== updatedItemNo ? true : false
      }
    }
  }

  displayEmo(emoValue) {
    return this.emoFilter[emoValue] ? this.emoFilter[emoValue] : emoValue;
  }

  showAlertMessage(state, message) {
    if (state === "error") {
      this.alertState = "alert-danger";
    } else {
      this.alertState = "alert-success";
    }
    this.alertMessage = message
    this.isShowAlert = true;
  }

  refineEmoDate(emoData) {
    let newArray = [];
    let {
      emodate = '', shipmentmustarriveby = ''
    } = emoData;
    newArray.push({
      ...emoData,
      emodate: emodate ? localDate(emodate, 'DD-MMM-YYYY') : '',
      shipmentmustarriveby: shipmentmustarriveby ? localDate(shipmentmustarriveby, 'DD-MMM-YYYY') : '',
    })
    this.printData = newArray;
  }

  getUniqueRecord() {
    let dublicateAsset = [];
    let uniqueAsset = [];
    let emoRecord = JSON.parse(JSON.stringify(this.details));
    emoRecord.forEach(val => {
      if (val.itemtype === "asset") {
        if (dublicateAsset.indexOf(val['assetid']) === -1) {
          uniqueAsset.push(val);
          dublicateAsset.push(val['assetid']);
        }
      } else if (val.itemtype === "container") {
        let description = val['description'].toLowerCase();
        if (dublicateAsset.indexOf(description) === -1) {
          uniqueAsset.push(val);
          dublicateAsset.push(description);
        }
      } else {
        if (dublicateAsset.indexOf(val['partno']) === -1) {
          uniqueAsset.push(val);
          dublicateAsset.push(val.partno);
        }
      }
    })
    this.details = uniqueAsset;
    this.updateItemNo();
  }

  fetchEmoDetails(emono) {
    this.store.dispatch(new GetEmoData({
      "filter": {
        "emoid": emono
      }
    }))
  }
  validateEmoDetailsForm() {
    if (this.emodetailRecord.itemtype) {
      let options = this.itemTypeOptions.filter(option => option.value === this.emodetailRecord.itemtype);
      let required = options[0].requiredField;
      if (required && required.length > 0) {
        for (let i = 0; i < required.length; i++) {
          if (this.emodetailRecord[required[i]]) {
            continue;
          } else {
            return false;
          }
        }
      }
    } else {
      return false;
    }
    return true;
  }

  addEmoDetails() {
    if (this.validateEmoDetailsForm()) {
      if (this.emono) {
        this.emodetailRecord['newdetail'] = true;
      }
      this.details = [...this.details, this.emodetailRecord];
      this.selectedRecord = [...this.selectedRecord, this.emodetailRecord];
      this.clearEmoDetails();
      this.enabelAllField();
      this.updateItemNo();
    }
  }

  clearEmoDetails() {
    this.emodetailRecord = new EmodetailsModel();
  }


  disableInput(input_field, itemType) {
    let itemType_field = input_field.filter(_val => _val.value === itemType)[0];
    itemType_field.disabledField.forEach(val => {
      this.emoDetails_disableObj[val] = true;
    })
  }

  enabelAllField() {
    this.emoDetails.forEach(val => {
      this.emoDetails_disableObj[val.dataKey] = false;
    })
  }

  disableAllField() {
    this.emoDetails.forEach(val => {
      this.emoDetails_disableObj[val.dataKey] = true;
    })
  }

  selectItemType(event: any, field) {
    if (event === 'container' || event === "part") {
      this.enabelAllField();
      this.disableInput(field, event);
      this.isDisplayTypeBtn = false;
    } else if (event === "asset") {
      this.enabelAllField();
      this.disableInput(field, event);
      this.isDisplayTypeBtn = true;
    }
  }

  setEmoMode() {
    this.router.navigate(['/readyToCheckin']);
    let emoObj: any = {
      emoMode: true,
      emoRecord: this.details,
      isEmoDataMerged: false,
      emoPath: this.emono ? `/emodetails/${this.emono}` : '/emodetails'
    };
    if (!this.emono) {
      emoObj['emoHeaderRecord'] = this.emoObject;
    }
    this.store.dispatch(new resetEmoRecord());
    this.store.dispatch(new setEmoMode(emoObj));
  }

  onSubmit(btnType: string) {
    let payload = this.emoObject;
    payload.emodetails = this.details;
    if (btnType === 'saveemo') {
      this.saveEmo(payload);
    } else if (btnType === 'shipemo') {
      this.shipEmo(false);
    } else if (btnType === "cancelemo") {
      this.cancelEmo();
    } else if (btnType === 'printemo') {
      this.printEmoReport()
    } else if(btnType === 'cancelship'){
      this.shipEmo(true);
    }

  }

  private printEmoReport() {
    this.printReportComponent.printEmoReport();
  }

  checkUnsavedData() {
    if (this.emono) {
      let isEqual = _.isEqual(this.emoObject, this.existingEmoRecord);
      if (!isEqual) {
        return true;
      } else {
        return false;
      }
    } else {
      if (this.details.length > 0) {
        return true;
      } else {
        return false;
      }
    }
  }

  private cancelEmo() {
    if (this.checkUnsavedData()) {
      this.emoConfirmationModal = "block";
    } else {
      this.backToPreviousURL();
    }
  }

  backToPreviousURL() {
    if (this.previousUrl) {
      this.router.navigate([this.previousUrl]);
    } else {
      window.close();
    }
  }

  ConfirmSave() {
    this.emoConfirmationModal = "none";
    this.onSubmit('saveemo');
  }

  confirmClose() {
    this.emoConfirmationModal = "none";
    this.backToPreviousURL();
  }

  mappedRecords = (record, state = 'save') => {
    let emodetail_record = record.emodetails;
    let detail_record = [];
    for (let i = 0; i < emodetail_record.length; i++) {
      let record = emodetail_record[i];
      let newRecord = {
        ...record,
        "createdby": record.createdby || this.empName,
        "createddate": dateValidation(record.createddate) ? moment(record.createddate).format('YYYY-MM-DD') : '',
        "modifiedby": this.empName,
        "modifieddate": dateValidation(record.modifieddate) ? moment(record.modifieddate).format('YYYY-MM-DD') : ''
      }
      detail_record.push(newRecord);
    }
    let mappedRecords: any = {
      ...record,
      "emodate": this.emodate || "",
      "emodetails": detail_record
    }
    if (state === 'update') {
      mappedRecords = {
        ...mappedRecords,
        "emoid": this.emono,
        "createdby": record.createdby,
        "createdbyid": record.createdbyid,
        "modifiedby": this.empName,
        "modifiedbyid": this.empId,
      }
    }
    return mappedRecords;
  }

  mapEmoRecordsForSave = (record) => {
    let record_save = this.mappedRecords(record);
    return record_save;
  }

  mapEmoRecordsForUpdate = (record) => {
    let record_update = this.mappedRecords(record, 'update');
    return record_update;
  }

  private saveEmo(payload) {
    if (this.emono) {
      let mappedRecords = this.mapEmoRecordsForUpdate(payload);
      this.store.dispatch(new updateEmo(mappedRecords));
    } else {
      let mappedRecords = this.mapEmoRecordsForSave(payload);
      this.store.dispatch(new GenerateEmoData(mappedRecords));
    }
  }

  private shipEmo(cancelship:boolean) {
    let shipPayload = {
      emoid: this.emono,
      cancelship
    }
    this.store.dispatch(new ShipEmo(shipPayload));
    //this.fetchEmoDetails(this.emono)
  }

  removeEmoDetails(index: number) {
    let remove_details = JSON.parse(JSON.stringify(this.details));
    remove_details.splice(index, 1);
    this.details = remove_details;
    this.updateItemNo();
  }

  getButtonPermission(btnType: string) {
    if ('saveemo' === btnType) {
      return this.permissions.includes(createEMOPermission);
    } else if ('shipemo' === btnType) {
      return this.permissions.includes(shipEMOPermission);
    } else if('cancelship' === btnType){
      return this.permissions.includes(cancelEMOShipPermission);
    }else {
      return true;
    }
  }

  getButtonDisabled(btnType: string) {
    if (['saveemo', 'cancelemo'].includes(btnType)) {
      return this.isShippedEmo ? true : false;
    } else if (btnType === 'shipemo') {
      return !this.isShippedEmo && this.emono ? false : true;
    } else if (btnType === 'printemo') {
      return false;
    } else if(btnType === 'cancelship'){
      return this.isShippedEmo && this.emono ? false :true;
    }
  }

  checkDisable(btnType: string) {
    let actionDisabled = this.getButtonDisabled(btnType);
    let hasPermission = this.getButtonPermission(btnType);
    if (actionDisabled || !hasPermission || this.emoActionDisabled) {
      return true;
    } else {
      return false;
    }
  }

  permissionDisplayCheck = (buttonObject) => {
    const {
      permissionBasedDisplay=false, permission=''
    } = buttonObject;

    if(!permissionBasedDisplay){
      return true;
    }else{
      return this.permissions.includes(permission);
    }
  }

  isDisableField(form_element) {
    if (this.isShippedEmo) {
      return true;
    } else {
      if (form_element.dataKey === "destinationarea") {
        if (this.emoObject['destinationlocation']) {
          return false;
        } else {
          return true;
        }
      } else {
        return false;
      }
    }
  }

  get itemTypeOptions() {
    let itemTypeOption = this.emoDetails.filter(itemType => itemType.dataKey === "itemtype");
    return itemTypeOption[0].options;
  }

  onBlur(index, input) {
    this.editMode = false;
    let emoDetailsRecord = JSON.parse(JSON.stringify(this.emoDetails));
    emoDetailsRecord.forEach(val => {
      if (input === val.dataKey) {
        val['viewMode'] = !val['viewMode'];
      }
    })
    this.emoDetails = emoDetailsRecord;
    this.editindex = index;
    if (!this.showDublError) {
      if (this.editableRecordInput[input]) {
        this.details[index][input] = this.editableRecordInput[input];
        if (this.emono && !this.details[index]['newdetail']) {
          this.details[index]['modified'] = true;
        }
      }
    }
    this.showDublError = false;
  }

  showViewEdit(index, input) {
    if (!input.editable || this.isShippedEmo) {
      return false;
    }
    let allDisableField = this.itemTypeOptions.filter(option => option.value === this.details[index].itemtype);
    let nonEditableField = allDisableField && allDisableField[0] && allDisableField[0].disabledField;
    if (nonEditableField && nonEditableField.length > 0) {
      if (nonEditableField.includes(input.dataKey)) {
        return false;
      }
    }
    return (this.editindex === index) && !input.viewMode
  }

  edit(i, input) {
    if (this.editMode) {
      this.onBlur(this.previousValue.index, this.previousValue.input);
      return;
    }
    this.editableRecordInput[input] = this.details[i][input];
    this.previousValue = { index: i, input: input }
    let emoDetailsRecord = JSON.parse(JSON.stringify(this.emoDetails));
    emoDetailsRecord.forEach(val => {
      if (input === val.dataKey) {
        val['viewMode'] = !val['viewMode'];
      }
    })
    this.emoDetails = emoDetailsRecord;
    this.editindex = i;
    this.editMode = true;
  }

  removeAlertIcon() {
    this.isShowAlert = false;
  }

  preventDublicate(event: Event, input) {
    if (input.uniqueValue) {
      let inputKeyArray = this.details.filter(value => value[input.dataKey]);
      inputKeyArray = inputKeyArray.map(value => value[input.dataKey]);
      if (inputKeyArray.indexOf(event.target['value']) !== -1) {
        this.showDublError = true
      } else {
        this.showDublError = false
      }
    }
  }

  handleAutocompleteInputChange(text, field) {
    this.suggestionList = [];
    if (text.length > 1) {
      if (field === 'projectnumber') {
        this.displayKey = 'PROJECTID';
        let obj = {
          "skip": 0,
          "limit": 10,
          "filter": {}
        }
        obj.filter['PROJECTID'] = text
        this.destroyAutoCompleteList();
        obj.filter["PROJECTSTATUS"] = "A";
        this.store.dispatch(new GetProjectData(obj));
      }else if (field === 'destinationlocation') {
        this.displayKey = 'locationText';
        let obj = {
          field: 'location'
        }
        obj['locationDescription'] = text;
        this.destroyAutoCompleteList();
        this.getCheckoutComplete(obj);
      }else if (field === 'destinationarea') {
        this.displayKey = 'areaText';
        let obj = {
          field: 'area'
        }
        obj['locationCode'] = this.emoObject['destinationlocation'];
        obj['areaDescription'] = text;
        this.destroyAutoCompleteList();
        this.getCheckoutComplete(obj);
      }else if (field === 'origincountry') {
        this.displayKey = 'country';
        let obj = {
          filter:{}
        }
        obj.filter['country'] = text
        this.destroyAutoCompleteList();
        this.getCountries(obj);
      } else if (field === 'uom') {
        this.displayKey = 'uom';
        let obj = {
          filter: {}
        }
        obj.filter['uom'] = text
        this.destroyAutoCompleteList();
        this.getUOM(obj);
      }
    }else{
      if(text == "" && field === 'destinationlocation') {
        this.emoObject['destinationarea'] = '';
        this.emoObject['destinationareadescription'] = '';
      }
    }
  }

  private getCheckoutComplete(obj: { field: string; }) {
    this.store.dispatch(new GetCheckoutAutocomplete(obj));
  }

  private getCountries(queryObj){
    this.store.dispatch(new GetCountriesAutoComplete(queryObj));
  }

  private getUOM(queryObj) {
    this.store.dispatch(new GetUOMAutoComplete(queryObj));
  }

  private destroyAutoCompleteList() {
    this.store.dispatch(new DestroyAutocompleteList());
  }

  suggestionSelected(suggestion, field) {
    if (field === "destinationlocation") {
      this.emoObject['destinationlocationdescription'] = suggestion.locationText;
      this.emoObject['destinationlocation'] = suggestion.locationCode;

      let areaCheckObj = {
        locationId : suggestion.locationCode
      }
      this.isGetAreaCount = true;
      this.store.dispatch(new GetLocationAreasCheck(areaCheckObj));

    } else {
      this.emoObject['destinationareadescription'] = suggestion.areaText;
      this.emoObject['destinationarea'] = suggestion.areaCode
    }
  }

  emoSuggestionSelected(suggestion, state, index, field) {
    if (state === "emodetail") {
      this.editableRecordInput[field] = suggestion[this.displayKey];
      this.onBlur(index, field);
    } else {
      this.emodetailRecord[field] = suggestion[this.displayKey];
    }
  }

  getUniqueCountries(suggested){
    let uniqueCountries = [], refrenceCountryString = [];

    for(let countryObj of suggested){
      if(!refrenceCountryString.includes(countryObj[this.displayKey])){
        refrenceCountryString.push(countryObj[this.displayKey])
        uniqueCountries.push(countryObj)
      }
    }
    return uniqueCountries;
  }

  showMoreOrLessText = (text = '', dataKey, row) => {
    try {
      if (text.length > this.maxLength) {
        if (
          this.textDisplayLengthMap[dataKey] &&
          this.textDisplayLengthMap[dataKey][row] === 1
        ) {
          return 'show less';
        } else {
          return 'show more';
        }
      } else {
        return '';
      }
    } catch (e) {
      console.log('showMoreOrLessText catch block error', e);
      return '';
    }
  }

  showMoreOrLessTextToggle = (text) => {
    try {
      return text && text.toString().length > this.maxLength;
    } catch (e) {
      return false;
    }
  }

  toggleShowLessMoreFunction = (dataKey, row) => {
    try {
      if (
        this.textDisplayLengthMap[dataKey] &&
        this.textDisplayLengthMap[dataKey][row]
      ) {
        this.textDisplayLengthMap[dataKey][row] = 0;
      } else {
        this.textDisplayLengthMap[dataKey] = {}
        this.textDisplayLengthMap[dataKey][row] = 1;
      }
    } catch (e) {
      console.log('toggleShowLessMoreFunction catch block error', e);
    }

  }

  showText = (text = '', dataKey, row) => {
    try {
      if (
        text &&
        text.toString().length < this.maxLength
      ) {
        return text;
      } else {
        if (
          this.textDisplayLengthMap[dataKey] &&
          this.textDisplayLengthMap[dataKey][row] === 1
        ) {
          return text;
        } else {
          return text ? `${text.toString().substring(0, this.maxLength)}...` : ''
        }
      }
    } catch (e) {
      return text;
    }
  }

  downloadcsv = () => {
    let mappedData = this.mappDownloadData(this.emoData);
    downlaodcsv('emoDetail', mappedData);
  }

  mappDownloadData = (downloadData) => {
    let _downloadData = Object.assign(downloadData);
    const { projectsalesno = '', customerponumber = '', shippinginstructions = '',
      specialinstructions = '', oceaneeringponumber = '', shippingvia = '',
      shipmentmustarriveby = '', destinationlocation = '', destinationlocationdescription = '',
      destinationarea = '', destinationareadescription = '', projectarea = '', shippingfrom = '',
      shippingto = '', emodetails = [] } = _downloadData;
    return emodetails.map((record, index) => {
      const {
        itemno = "", itemtype = "", businessunit = "", peoplesoftcheckoutid = "",
        serialid = "", tagnumber = "", partno = "", quantity = "", uom = "", description = "", unitvalue = "", currency = "",
        dimensions = "", uomdimensions = "", weight = "", weightuom = "", projectnumber = "", assetid = "",
        activity = "", htscode = "", eccn = "", origincountry = "", extendedvalue = ""
      } = record;
      let obj = {
        itemno, itemtype, businessunit, peoplesoftcheckoutid,
        serialid, tagnumber, partno, quantity, uom, description, unitvalue, currency,
        dimensions, uomdimensions, weight, weightuom, projectnumber, assetid,
        activity, htscode, eccn, origincountry, extendedvalue
      }
      let detailsobj = {}
      if (index === 0) {
        detailsobj = {
          projectsalesno, customerponumber, shippinginstructions, specialinstructions,
          oceaneeringponumber, shippingvia, shipmentmustarriveby, destinationlocation,
          destinationlocationdescription, destinationarea, destinationareadescription,
          projectarea, shippingfrom, shippingto,
          ...obj
        }
      } else {
        detailsobj = {
          projectsalesno: '', customerponumber: '', shippinginstructions: '', specialinstructions: '',
          oceaneeringponumber: '', shippingvia: '', shipmentmustarriveby: '', destinationlocation: '',
          destinationlocationdescription: '', destinationarea: '', destinationareadescription: '',
          projectarea: '', shippingfrom: '', shippingto: '',
          ...obj
        }
      }
      return detailsobj;
    })
  }
}
