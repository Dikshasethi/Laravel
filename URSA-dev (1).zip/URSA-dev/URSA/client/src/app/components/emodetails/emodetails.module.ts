import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { EmoDetailsRoutes } from './emodetails.routes';
import { EmoDetailsComponent } from '../emodetails/emodetails.component';

@NgModule({
    declarations: [
        EmoDetailsComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(EmoDetailsRoutes)
    ],
    exports: [
        RouterModule
    ]
})

export class EmoDetailsModule { }