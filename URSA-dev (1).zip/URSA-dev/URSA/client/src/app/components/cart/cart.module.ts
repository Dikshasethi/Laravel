import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { CartRoutes } from './cart.routes';
import { CartComponent } from './cart.component';
import { AssetForecastComponent } from '../asset-forecast/asset-forecast.component';

@NgModule({
    declarations: [
        CartComponent,
        AssetForecastComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(CartRoutes)
    ]
})

export class CartModule { }