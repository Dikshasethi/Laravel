import { Component, OnInit, ViewChild } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { GetCartData, SetCartData, DeleteFromCart, GetCalenderForCart } from '../../actions/cart.action';
import { LogoutUser } from '../../actions/userDetail.actions';
import { Router } from '@angular/router';
import { hardReservePermission, checkoutPermission,cartCalenderDataLimit } from '../../utils/config/config';
import { ReSetSorting, SetSorting } from '../../actions/checkInOut.action';
import { Subscription } from 'rxjs/Subscription';
import { ClearDownloadData, GetDownloadData } from '../../actions/download.action';
import downlaodcsv from '../../utils/downloadCSV/downlaodcsv';
import * as _ from 'lodash';
import { config } from 'process';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  
  
  constructor( private store: Store<AppState>,private router :Router) { }
  cartSubscription;
  userDetailSubscription;
  hardReserveSubscription;
  checkedOutSubscription;
  permissions=[]
  cartData=[];
  modalDisplay = "none";
  defaultCustodian;
  defaultCustodianCode;
  empId;
  process;
  isRefreshData=false;
  selectedAssets=[];
  selectedCartItem =[];
  _checkedoutData;
  _hrresponseData;
  recheckoutModalProperties = {
    display: 'none',
    selectedAssets:[],
    custodian:{}
  }
  waitForCalendarMap: boolean = false;
  _calendarMap: any = {};
  calendarDataIsLoading: boolean = false;
  cartCheckboxMap = {};
  allRowsSelected: boolean = false;
  allSelectionCart: boolean = false;
  cartFetchingLoading:boolean = false;
  hardReservePermission:string = hardReservePermission;
  checkoutPermission:string = checkoutPermission;
  sort :any = {};
  sortingIcon :any={};
  downloadSubscription:Subscription;
  checkInOutSortingSubscription : Subscription;
  donwloadDataListIsLoading:boolean;
  selectedAssetsCount : number = 0;
  deletedCartFetchLoading: boolean = false;
  show_errorMessage: boolean = false;
  error_message: string;

  ngOnInit() {
    this.cartSubscription = this.store.pipe(select(state => state.Cart))
      .subscribe(cartObj => {
        const {
          cartData: { cartData, cartFetchIsLoading },
          deletedCartData: { deletedCartData, deletedCartFetchLoading },
          errorState: { error = false, error_message },
          calendarDataIsLoading,
          calenderDataMap
        } = cartObj
        this.cartFetchingLoading = cartFetchIsLoading;
        this.deletedCartFetchLoading = deletedCartFetchLoading;
        
        if (cartData.length){
          this.cartData = cartData && cartData.map(val => {
            val.isCartCheckboxSelected = false;
            return val;
          }) || [];
          
          this.formatCartData(JSON.parse(JSON.stringify(this.cartData)));
          this.calendarDataIsLoading = calendarDataIsLoading;
          if (!calendarDataIsLoading && (this.waitForCalendarMap || this.allSelectionCart)) {
            this.waitForCalendarMap = false;
            this._calendarMap = calenderDataMap ;
          }
        }
        else{
          this.cartData = [];
        }

        if (!_.isEmpty(deletedCartData) && !deletedCartFetchLoading && !cartFetchIsLoading && !deletedCartData['hasError']) {
          this.isRefreshData = true;
          this.fetchCartData();
        }

        if (error) {
          this.showErrorMessage(error_message);
        }
    
      })
  
      this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
      .subscribe(userDetailObj => {
        const {
          details
        } = userDetailObj;
        this.defaultCustodian = details['first_name'] +' '+ details['last_name'];
        this.defaultCustodianCode = details['employee_id'] ;
        this.empId = details['employee_id'] ;
        this.permissions = details['permission'] || [];
        if(this.empId && !this.cartData.length){
          this.fetchCartData();
        }
      })
    
      this.checkedOutSubscription = this.store.pipe(select(state => state.CheckOutPageData.checkedoutData))
      .subscribe(data => {      
        const {
          checkedoutData
        } = data;        
       if(checkedoutData){
        this._checkedoutData = checkedoutData;
       } 
      })
  
      this.hardReserveSubscription = this.store.pipe(select(state => state.ProposalPageData.hrResponseObj))
      .subscribe(data => {
        if(data){
          this._hrresponseData=data;
        }
        
      });

      this.checkInOutSortingSubscription = this.store.pipe(select(state => state.CheckInOut))
      .subscribe(data => {
        const {sort:{cart}}=data;
          let obj={};
          for(let key in cart){
            obj[key] = cart[key] === 1 ? "asc" : "desc";
          }
          this.sort = obj;
      });

      this.downloadSubscription = this.store.pipe(select(state => state.Download))
      .subscribe(data => {
        const { downloadData = [],isLoading} = data;
        this.donwloadDataListIsLoading = isLoading ;
        if(!isLoading && downloadData.length){
          let mappedData = this.mappDownloadData(downloadData);
          downlaodcsv('cart', mappedData);
        }
      });
  }

  ngOnDestroy(){
    this.cartSubscription.unsubscribe();
    this.userDetailSubscription.unsubscribe();
    this.checkedOutSubscription.unsubscribe();
    this.hardReserveSubscription.unsubscribe();
    this.checkInOutSortingSubscription.unsubscribe();
    this.downloadSubscription.unsubscribe();
    this.store.dispatch(new SetCartData([]));
    this.store.dispatch(new ReSetSorting());
  }

  mappDownloadData = (downloadData) => {
    let _downloadData = [...downloadData];
    return _downloadData.map(record => {
      const { data: { serialNumber = '', tagNumber = '', description = '', category = '', subtype2 = '',
        businessunit = '', assetid } } = record;
      let obj = {
        serialNumber, tagNumber, description, category, subtype2,
        businessunit, assetid
      };
      return obj;
    })
  }

  showErrorMessage(errorMsg) {
    this.error_message = errorMsg && errorMsg.error && errorMsg.error.message ? errorMsg.error.message : 'Something went wrong';
    alert(this.error_message);
  }

  fetchCartData(){
    let obj={
      "userId" : this.empId,
      "appId" : "001",
      "limit" : 0,
      "skip" : 0	
    }
    this.selectedAssets= [];
    this.modalDisplay = "block";
    this.store.dispatch(new GetCartData(obj));
    this.cartCheckboxMap = {};
  }

  formatCartData(cartData){
    let newList = [];
    for(let i = 0;i < cartData.length;i++){
      let cartInfo = cartData[i];
      let {data = {}} = cartInfo;
      let newObj = {
        ...cartInfo,
        ...data
      }
      newList.push(newObj);
    }   
    this.cartData = newList;
  }

  removeCartItem(items){
    let obj={
      appId : "001", 
      userId : this.empId, 
      cartItemsIdList : items
    }
    this.store.dispatch(new DeleteFromCart(obj));
  }
  
  onReservationClick(process){
    this.process=process;    
    this.isRefreshData = false;
    this.recheckoutModalProperties = {
      display: 'block',
      selectedAssets:this.selectedAssets,
      custodian:{
        'name':this.defaultCustodian,
        'code':this.defaultCustodianCode
      }
    }
  }

  onRemoveFromCartClick(){
    let selectedIds=[];
    for (let i = 0; i < this.selectedAssets.length; i++) {
      let data = this.selectedAssets[i];
      selectedIds.push(data._id);
    }
    this.removeCartItem(selectedIds);
  }

  removebuttonIsDisabled = () => {
    if(
      this.selectedCartItem.length < 1
    ){
      return true;
    }else{
      return false;
    }
  }

  onAssetSelection(data, i) {
    this.waitForCalendarMap = true;
    if (!this.cartCheckboxMap[i]) {
      this.cartCheckboxMap[i] = {
        selected: false
      }
    }
    if (!this.cartCheckboxMap[i]['selected']) {
      this.modalDisplay = 'block';
      this.cartCheckboxMap[i]['selected'] = true;
      this.selectedAssets.push(data);
      this.addAssetItem(data, i)
    } else {
      this.modalDisplay = 'none';
      this.cartCheckboxMap[i]['selected'] = false;
      this.selectedAssets = this.selectedAssets.filter(function (obj) {
        return obj._id !== data._id;
      });
    }
    this.selectedCartItem = JSON.parse(JSON.stringify(this.selectedAssets));
    this.calculateSelectedAssets();
  }

  isCartItemSelected(i){
    return (this.cartCheckboxMap[i] && this.cartCheckboxMap[i]['selected']) || false;
  }

  assetForecastDisplay = (i) => {
    if (this.isCartItemSelected(i)) {
      return 'table-row';
    }
    else {
      return 'none'
    }
  }

  addAssetItem(data,i){
    let getCalObj = {
      bu: data.businessunit,
      assetid: data.assetid,
      _index: i
    }
    this.store.dispatch(new GetCalenderForCart(getCalObj));
  }

  onLoaderModalStatusChange(status){
    this.modalDisplay = status
  }

  normalizeCheckboxes(length,allRowsSelected){
    for(let i=0;i<length;i++){
      if(!this.cartCheckboxMap[i]){
        this.cartCheckboxMap[i] = {
          selected : false
        }
      }
      this.cartCheckboxMap[i]['selected'] = allRowsSelected;
    }
  }

  onAllAssetSelection() {
    this.allSelectionCart = true;
    this.allRowsSelected = !this.allRowsSelected;
    this.normalizeCheckboxes(this.cartData.length, this.allRowsSelected);
    if (this.allRowsSelected) {
      if(this.cartData.length <= cartCalenderDataLimit) {
        for (let i = 0; i < this.cartData.length; i++) {
          let data = this.cartData[i];
           this.addAssetItem(data, i)
        }
      }
      this.selectedAssets = this.cartData;
    }
    else {
      this.selectedAssets = [];
    }
    this.selectedCartItem = JSON.parse(JSON.stringify(this.selectedAssets));
    this.calculateSelectedAssets();
  }
  
  calculateSelectedAssets = () =>{
    this.selectedAssetsCount = this.selectedAssets.length;
  }

  onReservationModalClose(action){
    if(action != 'destroy'){
      this.navigateToCallOut()
    }
    if(this.isRefreshData){
      this.selectedAssets=[];
    }
  }

  navigateToCallOut(){
    let calloutid;
    let isfail=false;
    if(this._checkedoutData && this._checkedoutData.successList && this._checkedoutData.successList.length){
      calloutid = this._checkedoutData.successList[0].calloutid;
    } 
    if(this._hrresponseData && this._hrresponseData.successList && this._hrresponseData.successList.length){
      calloutid = this._hrresponseData.successList[0].calloutid;
    } 

    if(this._checkedoutData && this._checkedoutData.failList && this._checkedoutData.failList.length){
      isfail=true;
    } 
    if(this._hrresponseData && this._hrresponseData.failList && this._hrresponseData.failList.length){
      isfail=true;
    } 

    if(isfail){
      return ;
    }
    if(this.cartData.length){
      let url=`/calloutinfo/${calloutid}`;
      window.open(url, "_blank");
    }else{
      this.router.navigateByUrl(`/calloutinfo/${calloutid}`);
    }
  }

  buttonIsDisabled = (type) => {
    let hasPermission = this.permissions.includes(type);
    if(
      !hasPermission ||
      this.selectedCartItem.length < 1
    ){
      return true;
    }else{
      return false;
    }
  }

  modalDisplayFunction = () => {
    if (this.cartFetchingLoading || this.deletedCartFetchLoading || this.donwloadDataListIsLoading || this.calendarDataIsLoading) {
      return 'block';
    } else {
      return 'none';
    }
  }

  setSorting = (key) => {
    let sort = {};
    sort['componentType'] = "cart";
    sort['dataKey'] = key;
    this.store.dispatch(new SetSorting(sort))
  }

  sortData = (dataKey) => {
    this.setSorting(dataKey);
    this.sortExistingData();
    this.visualizeSortingIcon();
  }

  sortExistingData = () => {
    let keys: any[] = Object.keys(this.sort);
    let values: any[] = Object.values(this.sort);
    this.cartData = _.orderBy(this.cartData, keys, values);
  }

  visualizeSortingIcon = () => {
    let sortData = JSON.parse(JSON.stringify(this.sort));
    let obj = {}
    for (let key in sortData) {
      if (sortData[key] === "asc") {
        obj[key] = "fa fa-arrow-up"
      } else if (sortData[key] === "desc") {
        obj[key] = "fa fa-arrow-down"
      }
    }
    this.sortingIcon = obj;
  }


  downloadcsv = () => {
    let obj = {
      "userId": this.empId,
      "appId": "001",
      sort: { ...this.sort }
    }
    this.store.dispatch(new ClearDownloadData());
    this.store.dispatch(new GetDownloadData({ urlType: 'cart', payload: obj }))
  }
}
