import { Component, OnInit, Input, SimpleChange, ViewChild, Output, EventEmitter } from '@angular/core';
import { trigger,style,state,transition,animate,group} from '@angular/animations';
import * as _ from 'lodash';
import { IfObservable } from 'rxjs/observable/IfObservable';
import { AppState } from '../../models/appState';
import { Store, select } from '@ngrx/store';
import { SetSummaryScrollTop } from '../../actions/productSummary.actions';
import { SetProductProposalCartData } from '../../actions/proposalData.action';
import { AssetModel } from '../../utils/proposal/assetdetailModel';
import { createProposalPermission } from '../../utils/config/config';

@Component({
  selector: 'app-product-summary',
  templateUrl: './product-summary.component.html',
  styleUrls: ['./product-summary.component.css'],
  animations:[
    trigger('slideInOut', [
      state('in', style({
          'max-height': '100%', 'opacity': '1', 'visibility': 'visible'
      })),
      state('out', style({
        'max-height': '0px', 'opacity': '0', 'visibility': 'hidden'
      })),
      transition('in => out', [group([
          animate('400ms ease-in-out', style({
              'opacity': '0'
          })),
          animate('600ms ease-in-out', style({
              'max-height': '0px'
          })),
          animate('700ms ease-in-out', style({
              'visibility': 'hidden'
          }))
      ]
      )]),
      transition('out => in', [group([
          animate('1ms ease-in-out', style({
              'visibility': 'visible'
          })),
          animate('600ms ease-in-out', style({
              'max-height': '100%'
          })),
          animate('800ms ease-in-out', style({
              'opacity': '1'
          }))
      ]
    )])
  ]),
  ]
})
export class ProductSummaryComponent implements OnInit {
  @Input() data: any;
  @Input() activeIndex: any;
  @Input() activeStatus: any;
  @Input() activeView : any;
  @Input() summaryScrollTop: any;
  @Output() searchDetailsFunction: EventEmitter<any>  = new EventEmitter();
  @Output() summaryProposalEvent = new EventEmitter<any>();
  @Input() searchStartDate: any;
  @Input() searchEndDate: any;
  @Input() proposalCart: any;
  @Input() isProposalMode: any;
  productList = [];
  productCount = 0;
  totalCount = 0;
  userSubscription;
  userDetailSubscription;
  proposalSummaryRecord: AssetModel;
  permissions: any = [];

  constructor( private store: Store<AppState>) { }

  ngOnInit() {
    this.productCount = (this.data && this.data.length) || 0;
    this.totalCount = (this.data && this.data.length) || 0;
    this.productList = this.data || [];

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
      .subscribe(userDetails => {
        const { details } = userDetails;
        this.permissions = details['permission'] || [];
      });

    this.userSubscription = this.store.pipe(select(state => state.User))
    .subscribe(user => {
        this.productList.map(item =>{if(item.animationState=="in"){
            item.animationState="out"
            item.showIcon = false
            return item
        }})
    })
  }

    ngOnChanges(changes: SimpleChange) {
        let dataReference = changes['data'];
        let dataProp = Object.assign({}, dataReference);
        if (dataProp) {
            let currentDataProp = dataProp.currentValue;
            let previousDataProp = dataProp.previousValue;
            if (!_.isEqual(currentDataProp, previousDataProp)) {
                this.productList = currentDataProp;
                this.productCount = (currentDataProp && currentDataProp.length) || 0;
                this.totalCount = (currentDataProp && currentDataProp.length) || 0
            }
        }
    }

  toggleShowDiv(i) {
    if(this.productList[i].proposalList == undefined){
        let obj={
            "index":i,
            "view":"summary",
            "assetidentifier":this.productList[i].key
        }   
        this.summaryProposalEvent.next(obj);
    }else{
        this.productList[i].animationState = this.productList[i].animationState === 'out' ? 'in' : 'out';
        this.productList[i].showIcon=!this.productList[i].showIcon;
    }  
    
  }  

  onSoftReservedClick(i){
      if(this.productList[i].reserved>0)
        this.toggleShowDiv(i);
  }
    

  elementClassFunction = (index) => {
        if(this.activeView !== 'mixed'){
            if(index === this.activeIndex){
                return 'bg-light';
            }else{
                return 'bg-white';
            }
        }else{
            if(index === this.activeIndex){
                return 'p-3 shadow-sm mb-1 bg-light';
            }else{
                return 'p-3 mb-1 bg-white';
            }
        }
    }

    statusClassFunction = (index, status, count) => {
      if(index === this.activeIndex){
        if(status === this.activeStatus){
            return `mb-1 bg-white p-1 ${Number(count) > 0 ? 'cursor' : ''}`
        }
        return `mb-1 ${Number(count) > 0 ? 'cursor' : ''}`
      }
      return `mb-1 ${Number(count) > 0 ? 'cursor' : ''}`;
    }

    

    fetchDetails = (product, status='', i, count) => {
       this.productList.map((val, index) =>{
           if(index == i){
                 val.showIcon = true
           }else{
            val.showIcon = false
           } 
       })
        if(Number(count) > 0){
            this.searchDetailsFunction.emit({...product, status, i});
        }
    }
    
     handleUserScroll = (event) => {
        this.store.dispatch(new SetSummaryScrollTop(event.target.scrollTop));
    }
    

    parseProposal = (proposal) => {
        if(proposal){
            let list, copy;
            let subAccumulator = [];
            let pushedIndex = [];
            if(!Array.isArray(proposal)){
                copy = Object.assign({}, proposal);
                list = [copy];
            }else{
                copy = proposal.slice();
                list = copy
            }

            for (let i = 0; i < list.length; i++){
                let proposal = list[i];
                if(this.isWithinSearchRange(proposal)){
                    subAccumulator.push(proposal);
                    pushedIndex.push(i);
                }
            }

            return subAccumulator;
        }
        return [];
    }

    isWithinSearchRange = (obj) => {
        if(obj){
            let searchStartDate = new Date(this.searchStartDate).getTime();
            let searchEndDate = new Date(this.searchEndDate).getTime();
            let start, end;
            const {startDate='', endDate=''} = obj;
            start = new Date(startDate).getTime();
            end = new Date(endDate).getTime();

            if(((searchStartDate <= start && searchStartDate <= end) && (searchEndDate >= start && searchEndDate <= end)) ||
            ((searchStartDate >= start && searchStartDate <= end) && (searchEndDate >= start && searchEndDate <= end)) || 
            ((searchStartDate >= start && searchStartDate <= end) && (searchEndDate >= start && searchEndDate >= end)) || 
            ((searchStartDate <= start && searchStartDate <= end) && (searchEndDate >= start && searchEndDate >= end))){
                return true;
            }else{
                return false;
            }
 
        }
        return false;
    }

    setProposalCart = (product: any,index: number) => {
        this.proposalSummaryRecord = new AssetModel;
        // not choosen index beacuse data was overriding when navigating between view
        let proposalCartData = {
            ...this.proposalSummaryRecord,
            productcategory:   product.category,
            businessunit: product.bu,
            oiamsubtype2: product.assetsubtype2,
            view:   'productSummaryList',   //keyword view to diiferentiate from which view
            itemtype: 'asset',
            index: index,
            proposalMode: (this.isProposalMode) ? true : false //proposalMode to check if redirected to product view by clicking add asset
            
        }
        this.store.dispatch(new SetProductProposalCartData(proposalCartData));
    }

    checkProposalCart = (product: any, index: number) => {
        if(this.proposalCart && this.proposalCart.length > 0) {
            return this.proposalCart.some(cartValue => {
                return cartValue.view === 'productSummaryList' && cartValue.productcategory === product.category && cartValue.businessunit === product.bu && 
                cartValue.oiamsubtype2 === product.assetsubtype2;
            })
        }
    }

    permissionDisplayCheck = () => {
        return this.permissions.includes(createProposalPermission);
    }
}
