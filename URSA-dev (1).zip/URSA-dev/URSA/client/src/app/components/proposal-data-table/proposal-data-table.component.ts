import { Component, OnInit, Input, SimpleChange, Output, EventEmitter } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { AssetModel } from '../../utils/proposal/assetdetailModel';
import { Router, ActivatedRoute } from '@angular/router';
import { 
  SetHardReserveMode, ResetProposalPageData 
} from '../../actions/proposalPageData.action';
import { SetDateRange } from '../../actions/search.actions';
import {hardReservePermission} from '../../utils/config/config';
import { SetViewPreference } from '../../actions/user.actions';
import { LogoutUser } from '../../actions/userDetail.actions';
import {
  SetAssetDataInProposalDeatil, SetProposalMode, SetProposalCartData
} from '../../actions/proposalData.action'
import { DestroyAutocompleteList, GetProjectData, SetAutoCompleteDisplayKey } from '../../actions/autocomplete.actions';
import isFromPs from '../../utils/proposal/isFromPs';
import chargeUnitType from '../../utils/proposal/chargeUnitType'
import itemTypeList from '../../utils/proposal/itemTypeList'
import localDate from '../../utils/date/localDate';
import { ProposaldetailsModel } from '../../utils/proposal/proposalModel';
import  checkForMinDate from '../../utils/proposal/checkForMinDate'
import * as _ from 'lodash';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
import reformatDate from '../../utils/date/reformatDate';
import localformat from '../../utils/date/dateFormat';
import validateLocaleDate from '../../utils/date/validateLocaleDate';

@Component({
  selector: 'app-proposal-data-table',
  templateUrl: './proposal-data-table.component.html',
  styleUrls: ['./proposal-data-table.component.css']
})
export class ProposalDataTableComponent implements OnInit {

  constructor(
    private store: Store<AppState>, 
    private route:ActivatedRoute, 
    private router:Router
  ) { }

  @Input() proposalDetails: any;
  @Input() hardReservedList: any;
  @Input() checkedOutList: any;
  @Input() checkedInList: any;
  @Input() proposalData: any;
  @Input() userPermissions: any;
  @Input() proposalid: any;
  @Input() height: any;
  @Input() isAddMode: boolean;
  @Input()
  set autoPopulateInEmptyDates(autoPopulateObject: {dataKey: string, date: string}) {
    const dataKey = autoPopulateObject.dataKey || '';
    const date = autoPopulateObject.date || ''
    if(dataKey && date && this.proposalDetails 
      && this.proposalDetails.length > 0) {
      let newProposalDetails = [];
      for (let details of this.proposalDetails) {
        if(!details[dataKey]) {
          details[dataKey]  = date
        }
        newProposalDetails.push(details);
      }
      this.parseProposaltData(newProposalDetails);
    }
  }
  @Output() resetShowModal = new EventEmitter<any>();
  @Output() removeProposal = new EventEmitter<any>();
  @Output() hardReservationAction = new EventEmitter<any>();
  assetDetailsRecord: AssetModel;
  parsedPSData = [];
  filteredPSData = [];
  rowMap={};
  filterByObj:any={};
  hrPermission;
  hardReservedReference = [];
  actionableStatusList = ['committed'];
  modalDisplay='none';
  proposalStatus: string = '';
  chargeUnitType = chargeUnitType;
  itemTypeList = itemTypeList;
  showAddAssetIcon: boolean = false;
  projectAutocompleteSubscription:Subscription;
  suggestionList=[];
  displayKey: string;
  projectNumber: string;
  hrResponseObj={};
  autocompleteSkip: number = 0;
  autocompleteLimit: number = 10;
  recordCount: number = 10;
  autocompleteText: string = '';
  autocompleteField: string = '';
  autocompleteScrolledActive: boolean = false;
  checkIsFromPs = isFromPs;
  checkForMinDate = checkForMinDate;
  localformat = localformat;

  ngOnInit() {
    this.parseProposaltData(
      this.proposalDetails,
      this.hardReservedList,
      this.checkedOutList,
      this.checkedInList
    );
    this.hrPermission = this.userPermissions && 
    this.userPermissions.includes(hardReservePermission);

    this.projectAutocompleteSubscription = this.store.pipe(select(state => state.Autocomplete.projectAutocomplete))
      .subscribe(autocompleteObject => {
        const {
          suggestionList
        } = autocompleteObject;
        if (suggestionList) {
          this.recordCount = suggestionList.length;
          this.suggestionList = suggestionList;
        }
      });
  }

  ngOnChanges(changes: SimpleChange) {
    if(
      changes['proposalDetails'] &&
      changes['hardReservedList'] && 
      changes['checkedOutList'] && 
      changes['checkedInList'] &&
      (
        !_.isEqual(
          changes['proposalDetails']['currentValue'],
          changes['proposalDetails']['previousValue']
        ) || 
        !_.isEqual(
          changes['hardReservedList']['currentValue'],
          changes['hardReservedList']['previousValue']
        ) || 
        !_.isEqual(
          changes['checkedOutList']['currentValue'],
          changes['checkedOutList']['previousValue']
        ) || 
        !_.isEqual(
          changes['checkedInList']['currentValue'],
          changes['checkedInList']['previousValue']
        )
      )
    ){
      this.parseProposaltData(
        changes['proposalDetails']['currentValue'],
        changes['hardReservedList']['currentValue'],
        changes['checkedOutList']['currentValue'],
        changes['checkedInList']['currentValue']
      );
    }

    if(
      changes['proposalDetails'] &&
      !changes['hardReservedList'] && 
      !changes['checkedOutList'] && 
      !changes['checkedInList'] &&
      (
        !_.isEqual(
          changes['proposalDetails']['currentValue'],
          changes['proposalDetails']['previousValue']
        ) 
      )
    ){
      this.parseProposaltData(
        changes['proposalDetails']['currentValue']
      );
    }

    if(
      changes['userPermissions'] &&
      !_.isEqual(
        changes['userPermissions']['currentValue'],
        changes['userPermissions']['previousValue']
      )
    ){
      this.hrPermission = changes['userPermissions']['currentValue'] && 
      changes['userPermissions']['currentValue'].includes(hardReservePermission); 
    }

    if(
      changes['height'] && 
      !_.isEqual(changes['height']['currentValue'], changes['height']['previousValue'])
    ){
      this.height = changes['height']['currentValue'];
    }
  }

  getSectionHeight = () => {
   return `${this.height - 15}vh`;
  }

  getTableWrapperHeight = () => {
   return `${this.height * 0.8}vh`;
  }

  updateFilter = (obj, field, e) => {
    if(!this[obj][field]){
      this[obj][field] = '';
    }
    this[obj][field] = e.target.value;
    this.executeFilter(
      'parsedPSData', 
      'filteredPSData', 
      obj
    );
  }

  executeFilter = (mainList, filterList, filterObj) => {
    let accumulator = [];
    for (let i = 0; i < this[mainList].length; i++) {
      let dataObj = this[mainList][i];
      let counts = 0, match = 0, filterValueCount=0;
      for (let k in this[filterObj]){
        let value = this[filterObj][k];
        if(typeof value === 'string') {
          if(value) {
            value = value.trim();
            filterValueCount++;
            counts++;
          }
          if(isNaN(dataObj[k])) {
            if(dataObj[k] && value && (k === 'begindate' || k === 'enddate')) {
              let dateInRow = dataObj[k];
              let searchedDate = value;
               if(this.isAddMode || this.proposalData?.submitstatus?.toLowerCase() === 'draft') {
                let reformedDate = reformatDate(value,'YYYY-MM-DD'); 
                searchedDate = reformedDate
               }

              if(dateInRow && searchedDate && 
              dateInRow.toLowerCase().includes(searchedDate.toLowerCase())) {
                match++;
              }
            }else if(
              dataObj[k] && value &&
              dataObj[k].toLowerCase().includes(value.toLowerCase())
            ){
              match++;
            }
          }else{
            if(
              value && dataObj[k] == value
            ){
              match++;
            }
          }
        }
      }
      if(filterValueCount){
        if(match === counts){
          accumulator.push(dataObj);
        }
      }else{
        accumulator.push(dataObj);
      }
    }
    this[filterList] = accumulator;
  }

  parseProposaltData = (
    proposaldetails=[],
    hardreservedassets=[],
    checkedoutassets=[],
    checkedinassets=[]
  ) => {
    let proposalDetails = (Array.isArray(proposaldetails) && proposaldetails.slice()) || [];
    let hardReservedAssets = (Array.isArray(hardreservedassets) &&  hardreservedassets) || [];
    let checkedOutAssets = (Array.isArray(checkedoutassets) && checkedoutassets) || [];
    let checkedInAssets = (Array.isArray(checkedinassets) && checkedinassets) || [];
    this.proposalStatus = this.proposalData.hasOwnProperty('submitstatus') && this.proposalData.submitstatus.toLowerCase() || '';
    this.hardReservedReference = hardReservedAssets;
    this.parsedPSData = [];
    proposalDetails.forEach((details, i) => {
      details['hrQty']=0;
      details['coQty']=0;
      for(let j=0;j<hardReservedAssets.length;j++) {
        if(details['pdid']===hardReservedAssets[j].pdid){
          details['hrQty']+=1
        }
      }
      
      for(let j=0;j<checkedOutAssets.length;j++) {
        if(details['pdid'] === checkedOutAssets[j].pdid && !checkedOutAssets[j].checkedin )
          details['coQty']+=1
      }

      for(let j=0;j<checkedInAssets.length;j++) {
        if(details['pdid'] === checkedInAssets[j].pdid)
        details['coQty']+=1
      }
      if(this.proposalData['submitstatus'] && this.proposalData['submitstatus'].toLowerCase() !== 'draft') {
        let begindate = details.begindate ? localDate(details.begindate, 'DD-MMM-YYYY') : "";
        let enddate= details.enddate ? localDate(details.enddate, 'DD-MMM-YYYY') : "";
        details.begindate = validateLocaleDate(begindate) ? begindate : details.begindate || '';
        details.enddate = validateLocaleDate(enddate) ? enddate : details.enddate || '';
      }
      if(this.proposalData['submitstatus'] && this.actionableStatusList.includes(this.proposalData['submitstatus'].toLowerCase())) {
        this.rowMap[i] = details;
        this.rowMap[i]['showCheck'] = true;
        this.rowMap[i]['showAddAsset'] = true;
        this.rowMap[i]['showX'] = true;
        if ('assetid' in details) {
          this.rowMap[i]['hasPill'] = true;
        }
      }
      this.parsedPSData.push(details);
    })
    this.checkRows();
    this.filteredPSData = this.parsedPSData.slice();
  }

  deleteProposal(proposalDetail: any, index: number) {
    this.removeProposal.emit({proposalDetail: proposalDetail, index: index})
  }

  checkRows = async() => {
    let showCheckBox = true;
    let showAddAssetBox = true;
    let showXBox = true;
    
    for (let row in this.rowMap) {
  
      //Partial Check on Check Box : Full Check On AddAsset
      let result = await this.assetPillQuantitiesCheckMap(this.rowMap[row])
      showCheckBox = result.showCheck;
      showAddAssetBox = !result.showAddAsset;
    
      //Partial Check on Check Box
      if (showCheckBox){
        let result2 = await this.assetPillCheckDateMap(this.rowMap[row])
        showCheckBox = result2;
      }
  
      //Full Check on X Box
      let result3 = this.assetPillCheckMap(this.rowMap[row])
      showXBox = result3
      
      this.rowMap[row].showCheck = showCheckBox;
      this.rowMap[row].showAddAsset = showAddAssetBox;
      this.rowMap[row].showX = showXBox;
    }
  }

  assetPillQuantitiesCheckMap(asset) {
    let isWarning : boolean = true;
    let isAddAssetDisable : boolean = false;
    if(asset.coQty >= Number(asset.quantity)){ // Check Out = Needed Amount
      isWarning = false;
      isAddAssetDisable = true;
    }
    else if(asset.hrQty === Number(asset.quantity)){ // Needed Amout = Hard Reserved
        isWarning = false;
        isAddAssetDisable = true;
    }
    else if(
      asset.coQty !== Number(asset.quantity) && asset.hrQty === 0   // Check Out != Needed Amount : Hard Reserved Assets = 0
    ) {
        isWarning = true
    }
    else if(asset.coQty !== Number(asset.quantity) && // Check Out != Needed Amount :  Hard Reserved Assets > 0
      asset.hrQty > 0) {
        for(let i = 0; i < this.hardReservedReference.length; i++) {
          if(this.hardReservedReference[i]['assetId'] === asset.assetid){
            isWarning = false;
            if(asset.hrQty + asset.coQty === Number(asset.quantity)){
              isAddAssetDisable = false
            }
            break;
          }
        }
        if (isWarning && asset.hrQty + asset.coQty === Number(asset.quantity)) {
          isWarning = false;
        }  
    }
    let usageObj = {
      showCheck : isWarning,
      showAddAsset : isAddAssetDisable
    }
    return usageObj
  }
  
  assetPillCheckMap(asset){ //Checks if asset in pill is Hard Reserved
    let pillInHR : boolean = false;
    for(let i =0; i< this.hardReservedReference.length; i++){
      if(this.hardReservedReference[i]['assetId'] == asset.assetid){
        if (this.hardReservedReference[i]['checkedout'] == false && 
            this.hardReservedReference[i].pdid === asset.pdid){
          pillInHR = true
          break;
        }
      }
    }
    return pillInHR
  }
  
  assetPillCheckDateMap(rowData){
    let isCheck = true;
    for (let hrAsset of this.hardReservedReference){
      if (hrAsset.assetId === rowData.assetid && hrAsset.pdid !== rowData.pdid){
        if ((Date.parse(rowData.enddate) < Date.parse(hrAsset.startdate)) || (Date.parse(rowData.begindate) > Date.parse(hrAsset.enddate))){
        }
        else{
          isCheck = false;
          break;
        }
      }
    }
    return isCheck
  }

  initiateHardReserve = (detail, proposalNumber, i) => {
    const {
      proposalid='',
      productcategory='', oiamsubtype2='',
      begindate='', enddate='',
      quantity=0, hrQty=0,
      businessunit='', pdid='',
      pcbusinessunit='', project='',
      custodian='',projectid=''
    } = detail;
    
    const hrObj = {
      proposalNumber : proposalNumber,
      projectNumber : projectid,
      category : productcategory,
      subtype2 : oiamsubtype2,
      startDate : moment(begindate).format('YYYY-MM-DD'),
      endDate : moment(enddate).format('YYYY-MM-DD'),
      businessUnit : businessunit,
      maxHrCount : quantity - hrQty,
      pdid,
      pdidIndex : i,
      pcbusinessunit : businessunit, 
      projectid : projectid, 
      custodian : this.proposalData['proposalplannerid'] || '', 
      customerName : this.proposalData['customername'] || '',
      proposalDescription : this.proposalData['proposaltitle'] || '',
      crmnumber: this.proposalData.oicrmbidnumber || ''
    }
    
    let projectStart = new Date(begindate).getTime();
    let today = new Date().getTime();
    let dateGreater;

    if(projectStart && today) {
      dateGreater = projectStart > today;
    }
    this.store.dispatch(new ResetProposalPageData());
    this.store.dispatch(new SetHardReserveMode(hrObj));
    this.store.dispatch(new SetViewPreference('details'));
    this.store.dispatch(new SetDateRange({
      startDate : dateGreater ? moment(begindate).format('YYYY-MM-DD') : moment().format('YYYY-MM-DD'), 
      endDate : dateGreater ? moment(enddate).format('YYYY-MM-DD') : moment().add(6, 'months').format('YYYY-MM-DD')
    }));
    this.router.navigate(['/product/:']);
  }

  removeReservation = (rowData, proposalNumber) => {
    let obj = {
       assetId : rowData['assetid'] || '',
       subType2 : rowData['oiamsubtype2'] || '',
       assetCategory : rowData['productcategory'] || '',
       hrStartDate : moment(rowData['begindate']).format('YYYY-MM-DD') || '',
       hrEndDate : moment(rowData['enddate']).format('YYYY-MM-DD') || '',
       proposalNumber,
       projectNumber : rowData['projectid'] || '',
       businessUnit : rowData['businessunit'] || '',
       pdid : rowData['pdid'] || ''
    }
     this.hardReservationAction.emit({
      hrObject: obj,
      hrModeltype: 'removeHardReservation'
     });
  }

  createHardReservation = (rowData, proposalNumber, i) => {
  let obj = {
    assetId : rowData['assetid'] || '',
    subType2 : rowData['oiamsubtype2'] || '',
    assetCategory : rowData['productcategory'] || '',
    hrStartDate : moment(rowData['begindate']).format('YYYY-MM-DD') || '',
    hrEndDate : moment(rowData['enddate']).format('YYYY-MM-DD') || '',
    proposalNumber,
    projectNumber : rowData['projectid'] || '',
    businessUnit : rowData['businessunit'] || '',
    pdid : rowData['pdid'] || '',
    pdidIndex : i,
    customerName : this.proposalData['customername'] || '',
    proposalDescription : this.proposalData['proposaltitle'] || '',
    pcbusinessunit : rowData['businessunit'] || '',
    projectid : rowData['projectid'] || '',
    custodian : this.proposalData['proposalplannerid'] || '',
  }
  this.hardReservationAction.emit({
    hrObject: obj,
    hrModeltype: 'createHardReservation'
  });
}

addToProposal = () => {
  let begindate = this.proposalData['begindate'] || '';
  let enddate = this.proposalData['enddate'] || '';
  
  this.assetDetailsRecord = new AssetModel(begindate, enddate);
  const obj = {
    indexToBeSliced: -1,
    detailToBeAdded: [{
      ...this.assetDetailsRecord,
      newdetail: true
    }]
  }
  this.store.dispatch( new SetAssetDataInProposalDeatil(obj));
}

addAssetFromProduct =  (detail: any, index: number) => {
  this.store.dispatch(new SetProposalCartData());
  this.store.dispatch(new SetProposalMode({
    isProposalPageType: (this.isAddMode) ? 'add' : 'edit',
    proposalid: (this.proposalid) ? this.proposalid : '',
    indexToAdd: index,
    detailTobeDeletedFromCart: detail
  }));
  this.router.navigate(['/product/:']);
}

enableAddAsset = (itemType, index: number) => {
  if(itemType === 'asset') {
    this.filteredPSData[index]['showAddAsset'] = true;
  }else{
    this.filteredPSData[index]['showAddAsset'] = false;
  }
}

handleAutocompleteInputChange(text, field, index) {
  this.setAutocompleteDisplayKey('');
  this.suggestionList = [];
  this.resetAutocompletePagination();
  if (text.length > 1 && !this.filteredPSData[index][field]) {
    this.autocompletePayload(text, field)
  }else {
      this.resetProposalData(index,field)
      this.destroyAutoCompleteList();
  }
}

dispatchInitialRequest = (text, field: string, index) =>  {
  this.setAutocompleteDisplayKey(field);
  this.suggestionList = [];
  this.resetAutocompletePagination();
  if(!this.filteredPSData[index][field]) {
    this.autocompletePayload(text, field)
  }
}

onScrollLoad = () => {
  this.autocompleteScrolledActive = true;
  this.autocompleteSkip = this.autocompleteSkip + 10;
  if(this.recordCount % 10 === 0) {
    this.autocompletePayload(this.autocompleteText, this.autocompleteField)
  }
}

private autocompletePayload(text, field) {
  this.autocompleteText = text;
  this.autocompleteField = field;
  if (field === 'projectid') {
    this.displayKey = 'PROJECTID';
    let obj = {
      "skip": this.autocompleteSkip,
      "limit": this.autocompleteLimit,
      "filter": {}
    }
    obj.filter['PROJECTID'] = text
    this.destroyAutoCompleteList();
    obj.filter["PROJECTSTATUS"] = "A";
    this.setAutocompleteDisplayKey(field);
    this.store.dispatch(new GetProjectData(obj));
  }
}

private setAutocompleteDisplayKey = (keyValue: string) => {
  this.store.dispatch(new SetAutoCompleteDisplayKey({identifierKey: keyValue}));
}

private resetProposalData(index,field) {
  this.resetAutocompletePagination();
  if( this.filteredPSData[index][field]) {
    if (field === 'projectid') {
      this.filteredPSData[index][field] =  '';
      this.projectNumber =  '';
    }else {
        this.filteredPSData[index][field] =  '';
    }
  }
}

private resetAutocompletePagination () {
  this.autocompleteSkip = 0;
  this.autocompleteScrolledActive = false;
  this.recordCount = 10;
}

proposalSuggestionSelected(suggestion, state, index, field) {
  if (state === "proposalDetail") {
    this.projectNumber =  suggestion.PROJECTID;
    this.filteredPSData[index][field] =  suggestion.PROJECTID;
  }
}

private destroyAutoCompleteList() {
  if(!this.autocompleteScrolledActive) {
    this.store.dispatch(new DestroyAutocompleteList());
  }
}

showInCommittedMode = () =>  {
  let isVisible = false; 
  if(!this.isAddMode && this.proposalData['submitstatus'] && this.proposalData['submitstatus'].toLowerCase() !== 'draft')
  {
    isVisible = true;
  }
  return isVisible;
}

showInDraftMode = () => {
  let isVisible = false; 
  if(this.isAddMode  ||  (this.proposalData['submitstatus'] && this.proposalData['submitstatus'].toLowerCase() === 'draft'
    && !isFromPs(this.proposalData))
  )
  {
    isVisible = true;
  }
  return  isVisible;
}
}