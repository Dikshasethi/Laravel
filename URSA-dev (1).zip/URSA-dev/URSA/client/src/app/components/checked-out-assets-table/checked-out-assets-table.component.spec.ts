import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckedOutAssetsTableComponent } from './checked-out-assets-table.component';

describe('CheckedOutAssetsTableComponent', () => {
  let component: CheckedOutAssetsTableComponent;
  let fixture: ComponentFixture<CheckedOutAssetsTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckedOutAssetsTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckedOutAssetsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
