import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {checkinPermission,cancelCheckoutPermission} from '../../utils/config/config';

@Component({
  selector: 'app-checked-out-assets-table',
  templateUrl: './checked-out-assets-table.component.html',
  styleUrls: ['./checked-out-assets-table.component.css']
})
export class CheckedOutAssetsTableComponent implements OnInit {

  constructor() { }
  checkedOutList;
  filterByObj : any= {};
  isLoading;
  maxLength = 50;
  isShowStatus = false;
  project_view:boolean;
  checkinPermission:string = checkinPermission;
  cancelCheckoutPermission:string = cancelCheckoutPermission;
  @Output() assetSelected = new EventEmitter<any>();
  @Output() allAssetSelected = new EventEmitter<any>();
  @Input() hrPermission : any;
  @Input() fromProposal : any;

  @Output() confirmCheckIn = new EventEmitter<any>();
  @Output() cancelCheckIn  = new EventEmitter<any>();
  @Output() filter = new EventEmitter<any>();

  @Input() checkInConfirmationModalDisplay :string;

  @Input()
  set checkedOutTableData(val) {
    if (val) {
      this.checkedOutList = val.obj;
      this.project_view =val.readytoCheckin;
      if (this.checkedOutList && this.checkedOutList.length > 0) {
       this.dataFormatter();
        this.arrangeCheckedOutData();
      }
      this.isLoading = val.isLoading;
      this.isShowStatus = val.isShowStatus;
    }

  }

  dataFormatter(){
    this.checkedOutList.forEach((obj) => {
      obj['maxLength'] = this.maxLength;
      obj['projectnumber'] = obj['projectnumber'] || "";
      obj['serialid'] = obj['serialid'] || "";
      obj['tagnumber'] = obj['tagnumber'] || "";
      obj['assetdescription'] = obj['assetdescription'] || "";
      obj['checkoutdate'] = obj['checkoutdate'] || "";
      obj['expectedcheckindate'] =obj['expectedcheckindate'] || "";
      obj['destinationlocation'] = obj['destinationlocation'] || "";
      obj['destinationarea'] = obj['destinationarea'] || "";
      obj['assetcategory'] = obj['assetcategory'] || "";
      obj['subtype2'] = obj['subtype2'] || "";
      obj['peoplesoftcheckoutid'] = obj['peoplesoftcheckoutid'] || "";
      obj['proposalnumber'] = obj['proposalnumber'] || "";
      obj['proposalDescription'] = obj['proposalDescription'] || "";
      obj['crmnumber'] = obj['crmnumber'] || "";
      obj['assetid'] = obj['assetid'] || "";
      obj['customerreferencenumber'] = obj['customerreferencenumber'] || "";
      obj['checkoutcustodianname'] = obj['checkoutcustodianname'] || "";
        if(obj.checkinFail){
          obj['isShowWarning']=true;
        }else{
          obj['isShowWarning']=false;
        }
        if(obj.editcheckinFail){
          obj['isEditShowWarning']=true;
        }else{
          obj['isEditShowWarning']=false;
        }
    });
  }

  arrangeCheckedOutData() {
    const coData = this.checkedOutList.filter(data => !data.checkedin);
    const otherData = this.checkedOutList.filter(data => data.checkedin);
    this.checkedOutList = coData.concat(otherData);
  }

  onAssetSelection(data) {
    this.assetSelected.next(data);
  }

  showMoreLess(i, label) {
    if (label == "more")
      this.checkedOutList[i].maxLength = this.checkedOutList[i].assetdescription.length;
    else if (label == "less")
      this.checkedOutList[i].maxLength = this.maxLength;
  }

  onAllAssetSelection(event) {
    this.allAssetSelected.next(event.target.checked);
  }
  ngOnInit() {
    
  }

  _confirmCheckIn(){
    this.confirmCheckIn.next('confirm');
  }
  _cancelCheckIn(){
     this.cancelCheckIn.next('cancel');
  }

  updateFilter(name:string,event:any){
    this.filter.next({name:name,event:event.target.value});
  }
}
