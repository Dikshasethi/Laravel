import { Routes } from '@angular/router';
import { ProposaldataComponent } from './proposaldata.component';

export const ProposalDataRoutes: Routes = [
    { path: ':id', component: ProposaldataComponent }
];