import { Component, OnInit, HostListener } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { Router, ActivatedRoute } from '@angular/router';
import { 
  GetProposalPageData, ResetProposalPageData 
} from '../../actions/proposalPageData.action';
import { 
  SetSearchKeyword, SetSearchKeywordLocalStorage
} from '../../actions/search.actions';
import * as _ from 'lodash';
import descrBuilder from '../../utils/calloutDetails/descriptionBuilder';
import tabMenuList from '../../utils/proposal/tabMenuList';
import tableStructure from '../../utils/checkInOut/tableStructure';
import * as $ from 'jquery';
import localDate from '../../utils/date/localDate';

@Component({
  selector: 'app-proposaldata',
  templateUrl: './proposaldata.component.html',
  styleUrls: ['./proposaldata.component.css']
})
export class ProposaldataComponent implements OnInit {

  constructor(
    private store: Store<AppState>, 
    private route:ActivatedRoute, 
    private router:Router
  ) { }  
  
  proposalPageSubscription;
  userDetailSubscription;
  userPermissions = [];
  defaultCustodian = '';
  proposalid = '';
  hardReservedAssets = [];
  checkedOutAssets = [];
  checkedInAssets = [];
  proposalData :any= {};
  proposalDetails = [];
  proposalDataLoading = false;
  proposalDataError = false;
  descriptionBuilder = descrBuilder.slice();
  tabMenuBuilder = tabMenuList.slice();
  tableBuilderList = tableStructure.slice();
  tableInFocus='proposal';
  countMap = {
    hardReservedAssets : 0,
    checkedOutAssets : 0,
    checkedInAssets : 0,
    proposalDetails : 0
  }
  modalDisplay = 'none';
  tableViewHeight = 0;
  hrResponseArray = [];
  showHrResponseModal = true;
  showHrResponse = 'none';
  
  public innerHeight: any;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;
    
  }

  ngOnInit() {
    this.innerHeight = window.innerHeight;
    this.extractId();
    this.proposalPageSubscription = this.store.pipe(select(state => state.ProposalPageData))
    .subscribe(proposalPageObject => {
      const {
        proposalData={}, hrResponseObj={}
      } = proposalPageObject;
      this.getTableViewHeight();
      this.modalDisplay = proposalData['proposalDataLoading'] ? 'block' : 'none';
      this.hardReservedAssets = proposalData['hardReservedAssets'] || [];
      this.checkedOutAssets = proposalData['checkedOutAssets'] || [];
      this.checkedInAssets = proposalData['checkedInAssets'] || [];
      this.proposalData = proposalData['proposalPageInfoData'] || {};
      this.proposalDetails = this.proposalData['proposaldetails'] || [];
      this.refineProprsalData(this.proposalData);
      this.countMap = {
        hardReservedAssets : this.hardReservedAssets.length || 0,
        checkedOutAssets : this.checkedOutAssets.length || 0,
        checkedInAssets : this.checkedInAssets.length || 0,
        proposalDetails : this.proposalData['proposaldetails'] && 
        this.proposalData['proposaldetails'].length || 0
      }
      if(
        this.showHrResponseModal && 
        Object.keys(hrResponseObj).length > 0
      ){
        this.parseHrResponse(hrResponseObj);
      }
    })
    
    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(userDetailObj => {
      const {
        details
      } = userDetailObj;
      this.userPermissions = details['permission'];
      this.defaultCustodian = details['first_name'] + ' ' + details['last_name'];
    })

    this.store.dispatch(new GetProposalPageData({"proposalid" : this.proposalid}));
    this.store.dispatch(new SetSearchKeyword(''));
    this.store.dispatch(new SetSearchKeywordLocalStorage(''));
  }

  ngOnDestroy(){
    this.proposalPageSubscription.unsubscribe();
    this.userDetailSubscription.unsubscribe();
  }

  refineProprsalData = (proposalData) => {
    let newArray = {} ;
    let data = proposalData;
    let {
      begindate = '', enddate = '',
    } = data;
    newArray = {
      ...data,
      begindate: begindate ? localDate(begindate, 'DD-MMM-YYYY') : '',
      enddate: enddate ? localDate(enddate, 'DD-MMM-YYYY') : ''
    };
    this.proposalData = newArray;
  }

  extractId = () => {
    this.proposalid = this.route.snapshot.paramMap.get('id');
  }

  tabClass = (tab) => {
    return `d-flex cursor p-1 ${this.tableInFocus === tab['tableInFocus'] ? 'bg-secondary active-tab text-white' : 'bg-white inactive-tab text-secondary'}`;
  }

  hrResponseRowClass = (rowData: any = {}) => {
    const {
      failMessage=''
    } = rowData;
    if(failMessage){
      return 'rowIsUnavailable';
    }else{
      return ''
    }
  }

  getTableViewHeight = () => {
    let windowHeight = $(window).height();
    let proposalHeader = $('#proposalHeaderId').height();
    let proposalDataBox = $('#proposalDataBox').height();
    let tableTabHeaders = $('#tabSelector').height();
    let appHeaderHeight = $('#appHeaderComponent').height();
    let nonTableVH = ((
      proposalDataBox + proposalHeader + 
      tableTabHeaders + appHeaderHeight
      ) / windowHeight) * 100;
    this.tableViewHeight = 100 - nonTableVH;
  }

  refreshParent = () => {
    this.store.dispatch(new GetProposalPageData({"proposalid" : this.proposalid}));
  }

  setTableInFocus = (tab) => {
    this.tableInFocus = tab['tableInFocus'];
  }

  parseHrResponse = (responseData : any={}) => {
    const {
      failList=[], successList=[]
    } = responseData;

    let normalizedList = [...successList, ...failList];
    this.showHrResponse = 'block';
    this.hrResponseArray = normalizedList;
  }

  closeHrResponse = () => {
    this.showHrResponse = 'none';
    this.showHrResponseModal = false;
  }

  resetShowModal = () => {
    this.showHrResponseModal = true;
  }

}


