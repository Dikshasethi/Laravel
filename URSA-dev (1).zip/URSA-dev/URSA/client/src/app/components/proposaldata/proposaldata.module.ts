import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { ProposalDataRoutes } from './proposaldata.routes';
import { ProposaldataComponent } from './proposaldata.component';
import { ProposalTableComponent } from '../proposal-table/proposal-table.component';
@NgModule({
    declarations: [
        ProposaldataComponent,
        ProposalTableComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(ProposalDataRoutes)
    ],
    exports: [
        RouterModule
    ]
})

export class ProposalDataModule { }