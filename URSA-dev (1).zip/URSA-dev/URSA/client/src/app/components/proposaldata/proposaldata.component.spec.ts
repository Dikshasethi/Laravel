import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProposaldataComponent } from './proposaldata.component';

describe('ProposaldataComponent', () => {
  let component: ProposaldataComponent;
  let fixture: ComponentFixture<ProposaldataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProposaldataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposaldataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
