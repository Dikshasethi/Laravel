import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import {AppState} from '../../models/appState';
import { HandleInput, ResetSearch, ManageAdvancedSearchDisplay, SetActiveSearch } from '../../actions/advancedSearch.actions';
import { ResetFilters } from '../../actions/refinedBy.actions';
import { DestroyDataObject, GetProducts } from '../../actions/product.actions';
import { SetSearchKeyword } from '../../actions/search.actions';
import {advancedSearchObjectBuilder} from '../../utils/advancedSearch/queryObjectBuilder';
import { GetProductSummary, DestroyProductSummary } from '../../actions/productSummary.actions';
import { BlockSearchChangeView } from '../../actions/user.actions';
import { DestroyAutocompleteList, GetAutocompleteList } from '../../actions/autocomplete.actions';
import { ResetProductProposalCartData } from '../../actions/proposalData.action';

@Component({
  selector: 'app-advanced-search',
  templateUrl: './advanced-search.component.html',
  styleUrls: ['./advanced-search.component.css']
})
export class AdvancedSearchComponent implements OnInit {
  categoryString;
  manufacturerString;
  modelString;
  locationString;
  subtype2String;
  startDate;
  descriptionString;
  endDate;
  refinedByFilterKey = 'productFilterObject';
  userView;
  autocompleteSubscription;
  suggestionList =[];
  categoryStringSuggestionList=[];
  manufacturerStringSuggestionList = [];
  modelStringSuggestionList=[];
  locationStringSuggestionList=[];
  subtype2StringSuggestionList=[];
  descriptionStringSuggestionList=[];


  constructor(
    private router:Router,
    private store: Store<AppState>
  ) { }

  ngOnInit() {
    this.store.pipe(select(state => state.AdvancedSearch))
    .subscribe(advancedSearch => {
      let advancedSearchCopy = Object.assign({}, advancedSearch);
      const {
        categoryString, manufacturerString,
        modelString, locationString,
        subtype2String, descriptionString
      } = advancedSearchCopy;

      this.categoryString = categoryString;
      this.manufacturerString = manufacturerString;
      this.modelString = modelString;
      this.locationString = locationString;
      this.subtype2String = subtype2String;
      this.descriptionString = descriptionString
    });

    this.store.pipe(select(state => state.Search))
    .subscribe(searchObject => {
      const {startDate, endDate} = searchObject;
      this.startDate = startDate;
      this.endDate = endDate;
    });

    this.store.pipe(select(state => state.User))
    .subscribe(user => {
      const {userViewPreference=''} = user;
      this.userView = userViewPreference;
    })

    this.autocompleteSubscription = this.store.pipe(select(state => state.Autocomplete))
    .subscribe(autocompleteObject => {
      const {categoryStringSuggestionList,manufacturerStringSuggestionList,modelStringSuggestionList,
        locationStringSuggestionList,subtype2StringSuggestionList,descriptionStringSuggestionList} = autocompleteObject;
      this.manufacturerStringSuggestionList = manufacturerStringSuggestionList;
      this.categoryStringSuggestionList = categoryStringSuggestionList;
      this.modelStringSuggestionList=modelStringSuggestionList;
      this.locationStringSuggestionList = locationStringSuggestionList;
      this.subtype2StringSuggestionList=subtype2StringSuggestionList;
      this.descriptionStringSuggestionList=descriptionStringSuggestionList;
    });
  }

  suggestionSelected = (selectedValue, field) => {
    let value=this[field];
    let tempValue = this[field].split(',')
    if(tempValue.length>1){
      value=value.substr(0,value.lastIndexOf(",")+1)
      if(selectedValue.slice(-1)!=',')
        value+=selectedValue+",";  
    }
    else{
      value=selectedValue+",";

    }
    let payload = {field, value}
    this.store.dispatch(new HandleInput(payload));
    }

  handleInputChange = (value, field,autocompleteField) => {
    let tempArray=value.split(',');
    let autocompleteString=tempArray[tempArray.length-1];
    
    
    let payload = {field, value}
    let obj={
      "autoCompleteLetter":autocompleteString,
      "field":autocompleteField,
      "suggestionField":field+"SuggestionList"
    }
    this.store.dispatch(new DestroyAutocompleteList());
    this.store.dispatch(new HandleInput(payload));
    this.store.dispatch(new GetAutocompleteList(obj));
  }

  resetSearch = () => {
    this.store.dispatch(new ResetSearch());
  }

  CloseAdvanceSearch = () => {
    this.store.dispatch(new ManageAdvancedSearchDisplay('none'));
  }

  submitSearch = () => {
    let list = {
      category : this.categoryString && this.categoryString.match(/^[,]+$/)!=null ? new Array(this.categoryString) : this.categoryString.split(',').filter(x => x) || ([]), 
      manufacturer : this.manufacturerString && this.manufacturerString.match(/^[,]+$/)!=null ? new Array(this.manufacturerString) : this.manufacturerString.split(',').filter(x => x) || ([]),
      model : this.modelString && this.modelString.match(/^[,]+$/)!=null ? new Array(this.modelString) : this.modelString.split(',').filter(x => x)  || ([]), 
      currentLocationFilterList : this.locationString && this.locationString.match(/^[,]+$/)!=null ? new Array(this.locationString) : this.locationString.split(',').filter(x => x)  || ([]),
      subtype : this.subtype2String && this.subtype2String.match(/^[,]+$/)!=null ? new Array(this.subtype2String) : this.subtype2String.split(',').filter(x => x)  || ([]),
      detailDescription : this.descriptionString && this.descriptionString.match(/^[,]+$/)!=null ? new Array(this.descriptionString) : this.descriptionString.split(',').filter(x => x) || ([]) 
    };
    for (let k in list){
      let fieldList = list[k]
      if(!fieldList || !(fieldList && fieldList.length > 0)){
        delete list[k];
      }
    }    
    let searchObject = {
      startDate : this.startDate,
      endDate : this.endDate,
      advancedSearch : advancedSearchObjectBuilder(list)
    };

    this.store.dispatch(new SetActiveSearch(true));
    this.store.dispatch(new SetSearchKeyword(''));
    this.store.dispatch(new ResetFilters());
    this.store.dispatch(new DestroyDataObject());
    this.store.dispatch(new DestroyProductSummary());
    this.store.dispatch(new ManageAdvancedSearchDisplay('none'));
    this.store.dispatch(new ResetProductProposalCartData());

    if(this.userView === 'mixed'){
      this.store.dispatch(new GetProducts(JSON.stringify(searchObject)));
      this.store.dispatch(new GetProductSummary(JSON.stringify({...searchObject, summary : true})));
    }else if(this.userView === 'summary'){
      this.store.dispatch(new BlockSearchChangeView('summary'));
      this.store.dispatch(new GetProductSummary(JSON.stringify({...searchObject, summary : true})));
    }else if(this.userView === 'details'){
      this.store.dispatch(new BlockSearchChangeView('details'));
      this.store.dispatch(new GetProducts(JSON.stringify(searchObject)));
    }
    
    if(this.router.url === '/landing'){
      this.router.navigate(['/product/:']);
    }
  }

}
