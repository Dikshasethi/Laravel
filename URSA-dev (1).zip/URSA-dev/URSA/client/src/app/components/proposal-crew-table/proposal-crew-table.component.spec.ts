import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProposalCrewTableComponent } from './proposal-crew-table.component';

describe('ProposalCrewTableComponent', () => {
  let component: ProposalCrewTableComponent;
  let fixture: ComponentFixture<ProposalCrewTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProposalCrewTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposalCrewTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
