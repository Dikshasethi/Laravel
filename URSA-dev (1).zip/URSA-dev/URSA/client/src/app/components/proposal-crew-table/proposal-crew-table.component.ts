import { Component, OnInit, Input, SimpleChange, Output, EventEmitter } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { Router, ActivatedRoute } from '@angular/router';
import crewTypeList from '../../utils/proposal/crewTypeList'
import localDate from '../../utils/date/localDate';
import * as _ from 'lodash';
import * as moment from 'moment';
import { CrewModel } from '../../utils/proposal/crewdetailModel';
import update from 'immutability-helper';
import chargeUnitType from '../../utils/proposal/chargeUnitType';
import { 
  GetJobTitles, RemoveJobTitlesInProposalDetail
} from '../../actions/proposalData.action';
import isFromPs from '../../utils/proposal/isFromPs';
import {
  SetAssetDataInProposalDeatil,
  DeleteProposalData
} from '../../actions/proposalData.action'
import  checkForMinDate from '../../utils/proposal/checkForMinDate'
import { DestroyAutocompleteList, GetCrewPositions, SetAutoCompleteDisplayKey } from '../../actions/autocomplete.actions';
import reformatDate from '../../utils/date/reformatDate';
import localformat from '../../utils/date/dateFormat';
import validateLocaleDate from '../../utils/date/validateLocaleDate';

@Component({
  selector: 'app-proposal-crew-table',
  templateUrl: './proposal-crew-table.component.html',
  styleUrls: ['./proposal-crew-table.component.css']
})
export class ProposalCrewTableComponent implements OnInit {

  constructor(
    private store: Store<AppState>, 
    private route:ActivatedRoute, 
    private router:Router
  ) { }

  @Input() proposalDetails:any;
  @Input() proposalData: any;
  @Input() userPermissions: any;
  @Input() proposalid: any;
  @Input() height: any;
  @Input() isAddMode: boolean;
  @Input() crewPostitions: any;
  @Input() hardReservedList: any;
  @Input() checkedOutList: any;
  @Input() checkedInList: any;
  @Input()
  set autoPopulateInEmptyDates(autoPopulateObject: {dataKey: string, date: string}) {
    const dataKey = autoPopulateObject.dataKey || '';
    const date = autoPopulateObject.date || ''
    if(dataKey && date && this.proposalDetails 
      && this.proposalDetails.length > 0) {
      let newProposalDetails = [];
      for (let details of this.proposalDetails) {
        if(!details[dataKey]) {
          details[dataKey]  = date
        }
        newProposalDetails.push(details);
      }
      this.parseProposaltData(newProposalDetails);
    }
  }
  @Output() setEditableSaveButton = new EventEmitter<any>();
  crewTypeActions = [] = crewTypeList;
  parsedPSData = [];
  filteredPSData = [];
  rowMap={};
  filterByObj:any={};
  deletedProposalDetail = [];
  hardReservedReference = [];
  actionableStatusList = ['committed','Committed'];
  crewDetails:  CrewModel;
  modalDisplay='none';
  proposalStatus: '';
  chargeUnitType = chargeUnitType;
  suggestionList=[];
  displayKey: string;
  autocompleteProposalSubscription;
  autocompleteSkip: number = 0;
  autocompleteLimit: number = 10;
  recordCount: number = 10;
  autocompleteText: string = '';
  autocompleteField: string = '';
  autocompleteScrolledActive: boolean = false;
  checkForMinDate = checkForMinDate;
  localformat = localformat;

  ngOnInit() {
    this.parseProposaltData(
      this.proposalDetails
    );

    this.autocompleteProposalSubscription = this.store.pipe(select(state => state.Autocomplete))
    .subscribe(autocompleteObject => {
      const {
        proposalAutoComplete: { suggestionList=[]},
      } = autocompleteObject;
      if (suggestionList.length > 0) {
        this.recordCount = suggestionList.length;
        this.suggestionList = [...suggestionList];
      }
    });
  }

  ngOnChanges(changes: SimpleChange) {
    if(
      changes['proposalDetails'] &&
      (
        !_.isEqual(
          changes['proposalDetails']['currentValue'],
          changes['proposalDetails']['previousValue']
        ) 
      )
    ){
      this.proposalDetails = changes['proposalDetails']['currentValue'];
      this.parseProposaltData(
        changes['proposalDetails']['currentValue']
      );
    }

    if(
      changes['height'] && 
      !_.isEqual(changes['height']['currentValue'], changes['height']['previousValue'])
    ){
      this.height = changes['height']['currentValue'];
    }
  }

  getSectionHeight = () => {
    return `${this.height - 15}vh`;
   }
 
   getTableWrapperHeight = () => {
    return `${this.height * 0.8}vh`;
   }

  updateFilter = (obj, field, e) => {
    if(!this[obj][field]){
      this[obj][field] = '';
    }
    this[obj][field] = e.target.value;
    this.executeFilter(
      'parsedPSData', 
      'filteredPSData', 
      obj
    );
  }

  executeFilter = (mainList, filterList, filterObj) => {
    let accumulator = [];
    for (let i = 0; i < this[mainList].length; i++){
      let dataObj = this[mainList][i];
      let counts = 0, match = 0, filterValueCount=0;
      for (let k in this[filterObj]){
        let value = this[filterObj][k];
        if(typeof value === 'string'){
          if(value){
            value = value.trim();
            filterValueCount++;
            counts++;
          }
          if(isNaN(dataObj[k])){
            if(
              dataObj[k] && value &&
              k === 'crewtype'
            ){
              // filter for crew types
              let crewTypeValue = this.crewTypeActions.find(crewTypeElem => crewTypeElem.name.toLowerCase().includes(value.toLowerCase()));
              if(crewTypeValue  && dataObj[k] === crewTypeValue.value) {
                match++;
              }
            }else if(dataObj[k] && value && k === 'crewjobtitles'){
              // filter for crew job titles
             let filterSearchExists = dataObj[k].some(filterElement => filterElement.jobTitle.toLowerCase().includes(value.toLowerCase()));
             if(filterSearchExists) {
              match++;
             }
            }else if(dataObj[k] && value && (k === 'begindate' ||
             k === 'enddate' || k === 'crewrequiredbydate')) {
              let dateInRow = dataObj[k];
              let searchedDate = value;
               if(this.isAddMode || this.proposalData?.submitstatus?.toLowerCase() === 'draft') {
                let reformedDate = reformatDate(value,'YYYY-MM-DD'); 
                searchedDate = reformedDate
               }

              if(dateInRow && searchedDate && 
              dateInRow.toLowerCase().includes(searchedDate.toLowerCase())) {
                match++;
              }
            }else if(
              dataObj[k] && value &&
              dataObj[k].toLowerCase().includes(value.toLowerCase())
            ){
              //filter for rest in crew table
              match++;
            }
          }else{
            if(
              value && dataObj[k] == value
            ){
              match++;
            }
          }
          
        }
      }
      if(filterValueCount){
        if(match === counts){
          accumulator.push(dataObj);
        }
      }else{
        accumulator.push(dataObj);
      }
    }
    this[filterList] = accumulator;
  }

  parseProposaltData = (
    proposaldetails=[]
  ) => {
    let proposalDetails = (Array.isArray(proposaldetails) && proposaldetails.slice()) || [];
    this.proposalStatus = this.proposalData.hasOwnProperty('submitstatus') && 
    this.proposalData.submitstatus.toLowerCase() || '';
    this.parsedPSData = [];
    proposalDetails.forEach((details, i) => {
      if(this.proposalData['submitstatus'] && this.proposalData['submitstatus'].toLowerCase() !== 'draft') {
        let begindate= details.begindate ? localDate(details.begindate, 'DD-MMM-YYYY') : "";
        let enddate= details.enddate ? localDate(details.enddate, 'DD-MMM-YYYY') : "";
        let crewrequiredbydate = details.crewrequiredbydate ? localDate(details.crewrequiredbydate, 'DD-MMM-YYYY') : "";

        details.begindate = validateLocaleDate(begindate) ? begindate : details.begindate || '';
        details.enddate = validateLocaleDate(enddate) ? enddate : details.enddate || '';
        details.crewrequiredbydate  =  validateLocaleDate(crewrequiredbydate) ? crewrequiredbydate : details.crewrequiredbydate || '';
      }
      this.parsedPSData.push(details);
    })
    this.filteredPSData = this.parsedPSData.slice();
  }

  addToProposal() {
    let begindate = this.proposalData['begindate'] || '';
    let enddate = this.proposalData['enddate'] || '';
    this.crewDetails = new CrewModel(begindate, enddate);
    const obj = {
      indexToBeSliced: -1,
      detailToBeAdded: [{
        ...this.crewDetails,
        newdetail: true
      }],
      isAddCrew: true
    }
    this.store.dispatch( new SetAssetDataInProposalDeatil(obj));
  }

 removejobTitleItem(index: number, jobtitleaction: string) {
  this.store.dispatch(new RemoveJobTitlesInProposalDetail({
    index: index,
    jobtitleaction : jobtitleaction
  }));
 }

deleteProposal(index: number) {
  this.setSaveButton();
  this.store.dispatch(new DeleteProposalData({
    index: index,
    isDeleteCrew: true
  }));
}

fetchJobTitles(crewPositionId,crewJobtitleAppendIndex) {
  this.setSaveButton();
  let obj = {
    crewPositionId : crewPositionId,
    crewJobtitleAppendIndex: crewJobtitleAppendIndex
  }
  this.store.dispatch( new GetJobTitles(obj));
}

setSaveButton = () => {
  if(!this.isAddMode) {
    this.setEditableSaveButton.emit();
  }
}

showInCommittedMode = () =>  {
  let isVisible = false; 
  if((!this.isAddMode && this.proposalData['submitstatus'] && this.proposalData['submitstatus'].toLowerCase() !== 'draft') ||
    this.proposalData.hasOwnProperty('crewrequirementid') && 
    this.proposalData['crewrequirementid'].length > 0
  )
  {
    isVisible = true;
  }
  return isVisible;
}

showInDraftMode = () => {
  let isVisible = false; 
  if((this.proposalData['submitstatus'] && this.proposalData['submitstatus'].toLowerCase() === 'draft'
    && (!this.proposalData.hasOwnProperty('crewrequirementid') ||
    this.proposalData.hasOwnProperty('crewrequirementid') &&
    this.proposalData['crewrequirementid'].length === 0) &&  !isFromPs(this.proposalData)) 
    || this.isAddMode
  )
  {
    isVisible = true;
  }
  return  isVisible;
}

handleAutocompleteInputChange(text, field, index) {
  this.suggestionList = [];
  this.setAutocompleteDisplayKey('');
  this.resetAutocompletePagination();
  if (text.length > 1 && !this.filteredPSData[index][field]) {
   this.autocompletePayload(text, field);
  }else {
      this.resetProposalData(index,field)
      this.destroyAutoCompleteList();
  }
}

dispatchInitialRequest = (text, field: string, index) =>  {
  this.setAutocompleteDisplayKey(field);
  this.suggestionList = [];
  this.resetAutocompletePagination();
  if(!this.filteredPSData[index][field]){
    this.autocompletePayload(text, field)
  }
}

onScrollLoad = () => {
  this.autocompleteScrolledActive = true;
  this.autocompleteSkip = this.autocompleteSkip + 10;
  if(this.recordCount % 10 === 0) {
    this.autocompletePayload(this.autocompleteText, this.autocompleteField)
  }
}

private resetAutocompletePagination () {
  this.autocompleteSkip = 0;
  this.autocompleteScrolledActive = false;
  this.recordCount = 10;
}

private autocompletePayload(text, field) {
  this.autocompleteText = text;
  this.autocompleteField = field;
  if (field === 'crewpositionname') {
    this.displayKey = 'name';
    let crewPostionRequestObj = {
      "searchKeyword":text,
      "skip": this.autocompleteSkip,
      "limit": this.autocompleteLimit
    }
    this.destroyAutoCompleteList();
    this.setAutocompleteDisplayKey(field);
    this.store.dispatch(new GetCrewPositions(crewPostionRequestObj));
  }
}

private setAutocompleteDisplayKey = (keyValue: string) => {
  this.store.dispatch(new SetAutoCompleteDisplayKey({identifierKey: keyValue}));
}

private resetProposalData(index,field) {
  this.resetAutocompletePagination();
  if( this.filteredPSData[index][field]) {
    if (field === 'crewpositionname') {
      this.filteredPSData[index][field] =  '';
      this.filteredPSData[index]['crewpositionid'] =  '';
      this.filteredPSData[index]['crewjobtitles'] =  [];
    }else {
        this.filteredPSData[index][field] =  '';
    }
  }
    this.suggestionList = [];
}

proposalSuggestionSelected(suggestion, field, index) {
  if (field === "crewpositionname") {
    this.filteredPSData[index][field] =  suggestion.name;
    this.filteredPSData[index]['crewpositionid'] =  suggestion.id;
    this.fetchJobTitles(suggestion.id,index);
  }
}

private destroyAutoCompleteList() {
  if(!this.autocompleteScrolledActive) {
    this.store.dispatch(new DestroyAutocompleteList());
  }
}

}