import { Component, OnInit, Input, Output, SimpleChange, EventEmitter } from '@angular/core';
import * as _ from 'lodash';

@Component({
  selector: 'app-flash-error',
  templateUrl: './flash-error.component.html',
  styleUrls: ['./flash-error.component.css']
})
export class FlashErrorComponent implements OnInit {
  state = ""
  message = ""
  @Input() alertState: string = '';
  @Input() alertMessage: string = '';
  @Output() resetErrorMessages = new EventEmitter<any>();
  isShowAlert: boolean = false;
  constructor() { }

  ngOnInit() {
    this.showAlertMessage(
      this.state, this.message
    );
  }

  ngOnChanges(changes: SimpleChange) {
    if(
      changes['alertMessage'] &&
      (
        !_.isEqual(
          changes['alertMessage']['currentValue'],
          changes['alertMessage']['previousValue']
        ) 
      )
    ){
      this.showAlertMessage(
        this.alertState, this.alertMessage
      );
    }
  }


  private showAlertMessage(state, message) {
    if(message && state){
      if (state === "error") {
        this.state = "alert-danger";
      } else {
        this.state = "alert-success";
      }
      this.message = message
      this.isShowAlert = true;
    }
  }

  removeAlertIcon() {
    this.resetErrorMessages.emit();
    this.isShowAlert = false;
  }

}
