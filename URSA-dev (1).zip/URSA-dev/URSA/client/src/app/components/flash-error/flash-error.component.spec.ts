import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlashErrorComponent } from './flash-error.component';

describe('FlashErrorComponent', () => {
  let component: FlashErrorComponent;
  let fixture: ComponentFixture<FlashErrorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlashErrorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlashErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
