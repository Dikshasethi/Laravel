import { Component, OnInit } from '@angular/core';
import { trigger,style,state,transition,animate} from '@angular/animations';
import { Store,select } from '@ngrx/store';
import {AppState} from '../../models/appState';
import { ManageAdvancedSearchDisplay } from '../../actions/advancedSearch.actions';


@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css'],
  animations:[
    trigger('ExpandCollapse',[
      state('hide',style({display:'none',transform:'translateY(0)'})),
      state('show',style({display:'block',transform:'translateY(0)'})),
      transition('hide => show', [
        style({transform: 'translateY(-5%)'}),
        animate(400)
      ]),
      transition('show => hide', [
        style({transform: 'translateY(0%)'}),
        animate(100)
      ])
    ]),
    
    trigger('display',[
      state('hide',style({display:'none'})),
      state('show',style({display:'block'})),      
    ]),
    
    trigger('show1',[
      state('hide',style({display:'none'})),
      state('show',style({display:'block'})),      
    ])
  ]
})
export class LandingComponent implements OnInit {

  constructor(
    private store: Store<AppState>
  ) { }
  public dispblock :string = 'hide';
  userDetailSubscription : any;
  userDetailsLoading: boolean = false;

  ngOnInit() {
    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(userDetailObj => {
      const {
        isfetch
      } = userDetailObj;
      this.userDetailsLoading = isfetch;
    })
  }

  ngOnDestroy(){
    this.store.dispatch(new ManageAdvancedSearchDisplay('none'));
  }

  modalDisplayFunction = () => {
    let defaultRefiendByPersonalization=sessionStorage.getItem('defaultRefiendByPersonalization');
    if(!defaultRefiendByPersonalization && this.userDetailsLoading && JSON.parse(sessionStorage.getItem('defaultRefiendByExists'))){
      return 'block';
    }else{
      return 'none';
    }
  }
}
