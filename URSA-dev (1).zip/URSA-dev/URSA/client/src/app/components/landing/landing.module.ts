import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { LandingRoutes } from './landing.routes';
import { LandingComponent } from './landing.component';
import { ReceivingDetailsCardComponent } from '../information-card/receivingdetails-card/receivingdetails-card.component';
import { EmoDetailsCardComponent } from '../information-card/emodetails-card/emodetails-card.component';
import { AssetsTransactionsLogCardComponent } from '../information-card/assettransactionslog-card/assettransactionslog-card.component';

@NgModule({
    declarations: [
        LandingComponent,
        ReceivingDetailsCardComponent,
        EmoDetailsCardComponent,
        AssetsTransactionsLogCardComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(LandingRoutes)
    ],
    exports: [
        RouterModule
    ]
})

export class LandingModule { }