import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceRequestNotesComponent } from './service-request-notes.component';

describe('ServiceRequestNotesComponent', () => {
  let component: ServiceRequestNotesComponent;
  let fixture: ComponentFixture<ServiceRequestNotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceRequestNotesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceRequestNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
