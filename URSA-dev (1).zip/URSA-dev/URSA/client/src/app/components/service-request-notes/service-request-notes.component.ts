import { Component, OnInit, Input, SimpleChange, Output, EventEmitter } from '@angular/core';
import * as _ from 'lodash';

@Component({
  selector: 'app-service-request-notes',
  templateUrl: './service-request-notes.component.html',
  styleUrls: ['./service-request-notes.component.css']
})
export class ServiceRequestNotesComponent implements OnInit {
  notes: string = ''
  @Input() serviceRequestNotes: string  = '';
  @Output() setServiceRequestNotes = new EventEmitter<any>();
  constructor() { }

  ngOnInit() {
    this.notes = this.serviceRequestNotes;
  }

  ngOnChanges(changes: SimpleChange) {
    if(
      changes['serviceRequestNotes'] &&
      (
        !_.isEqual(
          changes['serviceRequestNotes']['currentValue'],
          changes['serviceRequestNotes']['previousValue']
        ) 
      )
    ){
      this.notes = changes['serviceRequestNotes']['currentValue'];
    }
  }

  handleInputChange = (text) => {
    this.setServiceRequestNotes.emit(text);
  }

}
