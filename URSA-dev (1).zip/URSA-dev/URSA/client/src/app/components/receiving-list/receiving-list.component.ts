import { Component, OnInit, HostListener, ViewChild, Input } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { GetReceivingList, SetReceivingList, ResetReceivingMode, ResetReceivingList } from '../../actions/receiving.actons';
import * as moment from 'moment';
import * as _ from 'lodash';
import localDate from '../../utils/date/localDate';
import receivingFilterMap from '../../utils/receiving/receivingFilterMap';
import filterObjectEmoDateFormat from '../../utils/checkInOut/filterObjectDateFormat';
import { ReceivingPrintReportComponent } from '../receiving-print-report/receiving-print-report.component';
import { ReSetSorting, SetSorting } from '../../actions/checkInOut.action';
import { Subscription } from 'rxjs/Subscription';
import { ClearDownloadData, GetDownloadData } from '../../actions/download.action';
import downlaodcsv from '../../utils/downloadCSV/downlaodcsv';

@Component({
  selector: 'app-receiving-list',
  templateUrl: './receiving-list.component.html',
  styleUrls: ['./receiving-list.component.css']
})
export class ReceivingListComponent implements OnInit {

  @Input() assetId;
  @Input() businessunit;
  @Input() receivingdetailsFlag;

  receivingSubscription;
  receivingList = [];
  refinedListCopy = [];
  receivingListIsLoading = false;
  receivingListError = false;
  filters: any = {
    receivingid: '',
    receivingdate: '',
    projectnumber: '',
    receivinglocation: '',
    receivingarea: '',
    received: '',
    createdby: '',
    createdAt: '',
    modifiedby: '',
    updatedAt: '',
    createddate: '',
    updateddate: '',
    assetid: '',
    businessunit: ''
  };
  skip: number = 0;
  limit: number = 50;
  recordCount: number = 0;
  timeout = null;
  filterObj = {
  };
  sort : any = { "createdAt": -1, "updatedAt": -1 };
  receivingCount: number = 0;
  refinedList: any[];
  onScrollLoading: boolean = false;
  selectedData:any = [];
  printModal = 'none';
  checkInOutSortingSubscription : Subscription;
  sortingIcon :any={};
  downloadSubscription:Subscription;
  donwloadDataListIsLoading:boolean;
  selectedAssetsCount : number = 0;
  headingLabel = 'Receiving List';
  constructor(
    private store: Store<AppState>
  ) { }

  public innerHeight: any;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;
  }
  @ViewChild (ReceivingPrintReportComponent) receivingPrintReportComponent : ReceivingPrintReportComponent;
  ngOnInit() {
    this.innerHeight = window.innerHeight;
    if(this.receivingdetailsFlag){
      this.filters = {
          assetid: this.assetId,
          businessunit: this.businessunit
      }
      this.headingLabel = this.receivingdetailsFlag ? 'Receiving Inspection Reports' : 'Receiving List';
    }
    this.fetchData();
    this.receivingSubscription = this.store.pipe(select(state => state.Receiving))
      .subscribe(receivingData => {
        const {
          receivingList = [],
          receivingListError = false,
          receivingListIsLoading = false,
          onScrollLoading = false,
          receivingCount = 0
        } = receivingData;

        this.receivingList = receivingList;
        this.recordCount = this.receivingList.length
        this.receivingListError = receivingListError;
        this.receivingListIsLoading = receivingListIsLoading;
        this.onScrollLoading = onScrollLoading;
        this.receivingCount = receivingCount;
        this.refinedList = this.refineList(this.receivingList.slice());
        this.refinedList = this.refinedList.map(val => {
          val.isSelected = false;
          return val;
        });
        this.refinedListCopy = this.refinedList;
      })

      this.checkInOutSortingSubscription = this.store.pipe(select(state => state.CheckInOut))
      .subscribe(data => {
        const {sort:{receiving}}=data;
          let obj={};
          for(let key in receiving){
            obj[key] = receiving[key];
          }
          this.sort = obj;
      });

      this.downloadSubscription = this.store.pipe(select(state => state.Download))
      .subscribe(data => {
        const { downloadData = [],isLoading} = data;
        this.donwloadDataListIsLoading = isLoading ;
        if(!isLoading && downloadData.length){
          let mappedData = this.mappDownloadData(downloadData);
          downlaodcsv('receivinglist', mappedData);
        }
      });
  }
  ngOnDestroy() {
    this.receivingSubscription.unsubscribe();
    this.checkInOutSortingSubscription.unsubscribe();
    this.downloadSubscription.unsubscribe();
    this.store.dispatch(new ResetReceivingList());
    this.store.dispatch(new ReSetSorting());
  }

  mappDownloadData(downloadData) {
    let _downloadData = [...downloadData];
    return _downloadData.map(record => {
      const { receivingid = '', receivingdate = '', projectnumber = '', receivinglocation = '',
        receivingarea = '', received = '', createdby = '', createddate = '', modifiedby = '',
        updateddate = '' } = record;
      let obj = {
        receivingid, receivingdate, projectnumber, receivinglocation, receivingarea,
        received, createdby, createddate, modifiedby, updateddate
      };
      return obj;
    })
  }

  refineList = (receivingList = []) => {
    let newArray = [];
    for (let i = 0; i < receivingList.length; i++) {
      let receivingData = receivingList[i];
      let {
        receivingdate = '', createddate = '', updateddate = '', received
      } = receivingData;
      newArray.push({
        ...receivingData,
        receivingdate: receivingdate ? localDate(receivingdate, 'DD-MMM-YYYY') : '',
        received: received ? 'Yes' : 'No',
        createddate: createddate ? localDate(createddate, 'DD-MMM-YYYY') : '',
        updateddate: updateddate ? localDate(updateddate, 'DD-MMM-YYYY') : ''
      });
    }

    return newArray;
  }

  updateFilter(map: string, text) {
    this.filters[map] = text.target.value;
    this.resetSearchMeta();
    this.fetchData();

  }

  resetSearchMeta = () => {
    this.skip = 0;
    this.store.dispatch(new ResetReceivingMode());
    this.filterObj = {
    }
  }

  fetchData() {
    for (let k in this.filters) {
      let value = this.filters[k];
      if (value) {
        this.filterObj[receivingFilterMap[k]] = value
      }
    }
  this.fetchReceivingDetails();
  }

  fetchReceivingDetails = ()=>{
    let filterObjectWithNormalizedDate = filterObjectEmoDateFormat(this.filterObj);
    let obj = {
      "skip": this.skip,
      "limit": this.limit,
      "filter": filterObjectWithNormalizedDate,
      "sort": this.sort
    }
   this.store.dispatch(new GetReceivingList(obj));
   
  }
  errorDisplayFunction = () => {
    if (this.receivingListError) {
      return 'block';
    } else {
      return 'none';
    }
  }

  modalDisplayFunction = () => {
    if (this.donwloadDataListIsLoading) {
      return 'block';
    }
    if (this.receivingListIsLoading && !this.onScrollLoading) {
      return 'block';
    }
    return 'none';
  }

  onScroll() {
    if (
      this.skip <= this.recordCount
    ) {
      this.skip = this.recordCount;
      this.fetchData();
    }
  }

  selectRecords(data, i) {
    if (data.isSelected) {
      this.selectedData.push(data);
    }
    else {
      this.selectedData = this.selectedData.filter(function (obj) {
        return obj._id !== data._id;
      });
    }
    this.selectedAssetsCount = this.selectedData.length;
  }

  buttonIsDisabled = () => {
    if(
      this.selectedData.length < 1
    ){
      return true;
    }else{
      return false;
    }
  }

  print(){
    this.receivingPrintReportComponent.printReceivingReport();
  }

  setSorting=(key)=>{
    let sort = {};
    sort['componentType'] = "receiving";
    sort['dataKey'] = key;
    this.store.dispatch(new SetSorting(sort))
  }
  
  sortData = (dataKey) => {
    this.setSorting(dataKey);
    this.skip = 0;
    this.store.dispatch(new ResetReceivingMode());
    
    this.fetchReceivingDetails();
    this.visualizeSortingIcon();
  }

  visualizeSortingIcon = () => {
    let sortData = JSON.parse(JSON.stringify(this.sort));
    let obj={}
    for(let key in sortData){
       if(sortData[key] === 1){
        obj[key] = "fa fa-arrow-up"
       }else if(sortData[key] === -1){
        obj[key] = "fa fa-arrow-down"
       }
    }
    this.sortingIcon = obj;  
  }

  downloadcsv = () => {
    let filterObjectWithNormalizedDate = filterObjectEmoDateFormat(this.filterObj);
    let obj = {
      "filter": filterObjectWithNormalizedDate,
      "sort": this.sort
    }
    this.store.dispatch(new ClearDownloadData());
    this.store.dispatch(new GetDownloadData({ urlType: 'receivinglist', payload: obj }))
  }

}

