import { Component, OnInit, ViewChild, Input, SimpleChange } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { Router } from '@angular/router';
import { detailsRefinedBy } from '../../utils/refinedBy/refinedByConstants';
import * as _ from 'lodash';
import { productRefinedByList } from '../../utils/product/refinedByList';
import * as moment from 'moment';
import { Chart } from 'chart.js';
import { Subscription } from 'rxjs';
import localDate from '../../utils/date/localDate';
import {
  GetHardReservationChart,
  GetShippedChart, GetSoftReservationChart, ResetChartCounts ,GetCheckoutmetrics ,Getonhiremetrics, Getreceivecount
} from '../../actions/dashbord.action';
import { DaterangepickerConfig, DaterangePickerComponent } from 'ng2-daterangepicker';
import * as Highcharts from 'highcharts';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent implements OnInit {
  @Input() queryChangeIndicator;
  refinedByNgrxKey = detailsRefinedBy;
  refinedBySubscription: Subscription;
  dashboardSubScription: Subscription;
  utilizationSubscription: Subscription;
  checkoutSubscription: Subscription;
  onhireSubscription: Subscription;
  shippedSubscription: Subscription;
  hardReservationSubscription: Subscription;
  receivedSubscription: Subscription;
  refinedByList = productRefinedByList || [];
  detailsRefinedByObj = {};
  totalAssetCount: number = 0;
  checkedOutAssetsCount: number = 0;
  pastDueCount: number = 0;
  hardReservedAssetsCount: number = 0;
  SoftReservedAssetsCount: number = 0;
  @ViewChild('utilizationCanvas') utilizationCanvas;
  @ViewChild('shippedReceivedCanvas') shippedReceivedCanvas;
  @ViewChild('utilization', { read: DaterangePickerComponent })
  utilizationDateRange: DaterangePickerComponent;
  @ViewChild('softReservation', { read: DaterangePickerComponent })
  softReservationDateRange: DaterangePickerComponent;
  @ViewChild('hardReservation', { read: DaterangePickerComponent })
  hardReservationDateRange: DaterangePickerComponent;
  @ViewChild('shippedReceived', { read: DaterangePickerComponent })
  shippedReceivedDateRange: DaterangePickerComponent;
  softReservationChart:Chart;
  chartOptions: any = {
    responsive: true,
    elements: {
      point: {
        radius: 0,
      }
    }
  };
  displayFormat: any = {
    'week': 'DD MMM YYYY',
    'day': 'DD MMM',
    'quarter': 'MMM YYYY',
    'month': 'DD MMM YYYY',
  };
  chartProperty: any = {
    lineTension: 0.1,
    pointBorderColor: 'rgba(75,192,192,1)',
    pointBorderWidth: 1,
    pointHoverRadius: 5,
    pointHoverBackgroundColor: 'rgba(75,192,192,1)',
    pointHoverBorderColor: 'rgba(220,220,220,1)',
    pointHoverBorderWidth: 2,
    pointRadius: 5,
    pointHitRadius: 10,
    borderCapStyle: 'butt',
    borderDashOffset: 0.0,
    borderJoinStyle: 'miter',
    spanGaps: false,
  };

  daterange: any = {
    startDate: moment().subtract(1, 'months').format('YYYY-MM-DD'),
    endDate: moment().format('YYYY-MM-DD'),
  };

  options: any = {
    locale: localDate(moment(), { format: 'YYYY-MM-DD' }),
    alwaysShowCalendars: false,
    maxDate: localDate(this.daterange['endDate'], { format: 'YYYY-MM-DD' })
  };
  mappPayload: any = {
    "buList": "businessunit",
    "subtype": "subtype2"
  }

  onhireutilizationChartData:any[];
  checkoututilizationChartData:any[];
  softReservationChartData: any[];
  hardReservationChartData: any[];
  receivecountChartData: any[];
  shippedChartData: any[];
  hardReservationChartLoading: boolean = false;
  receivecountChartLoading: boolean = false;
  onhireutilizationChartLoading: boolean = false;
  checkoututilizationChartLoading: boolean = false;
  utilizationChartLoading: boolean = false;
  shippedChartLoading: boolean = false;
  selectedUtilizationDateRange: string = 'month';
  selectedSoftReservationDateRange: string = 'month';
  selectedHardReservationDateRange: string = 'month';
  selectedShippedReceivedDateRange: string = 'month';
  hardReservationChart: Highcharts.Chart;
  utilizationChart: Highcharts.Chart;
  shippedReceivedChart: Highcharts.Chart;
  constructor(
    private store: Store<AppState>,
    private router: Router,
    private daterangepickerOptions: DaterangepickerConfig
  ) {
    this.daterangepickerOptions.settings = {
      locale: { format: 'YYYY-MM-DD' },
      alwaysShowCalendars: false
    };
  }

  ngOnInit() {

      this.onhireSubscription = this.store.pipe(select(state => state.Dashboard.onhireutilizationChart))
      .subscribe(data => {
        if (data) {
          const { onhireutilizationChartData, onhireutilizationChartLoading } = data;
          this.onhireutilizationChartData = onhireutilizationChartData;
          this.onhireutilizationChartLoading = onhireutilizationChartLoading;
        }
      });


      this.checkoutSubscription = this.store.pipe(select(state => state.Dashboard.checkoututilizationChart))
      .subscribe(data => {
        if (data) {
          const { checkoututilizationChartData, checkoututilizationChartLoading } = data;
          this.checkoututilizationChartData = checkoututilizationChartData;
          this.checkoututilizationChartLoading = checkoututilizationChartLoading;
          if (!this.checkoututilizationChartLoading && !this.onhireutilizationChartLoading) {
            this.utilizationGraph();
          }
        }
      });

      this.hardReservationSubscription = this.store.pipe(select(state => state.Dashboard.hardReservationChart))
      .subscribe(data => {
        if (data) {
          const { hardReservationChartData, hardReservationChartLoading } = data;
          this.hardReservationChartData = hardReservationChartData;
          this.hardReservationChartLoading = hardReservationChartLoading;
          if (!hardReservationChartLoading) {
            this.hardReservationGraph();
          }
        }
      });


    this.dashboardSubScription = this.store.pipe(select(state => state.Dashboard))
      .subscribe(data => {
        if (data) {
          const {
            assetCount: { assetCountData },
            pastDueCount: { pastDueCountData },
            hardReservationCount: { hardReservationCountData },
            softReservationCount: { softReservationCountData },
            checkoutCount: { checkoutCountData }
          } = data;
          this.totalAssetCount = assetCountData;
          this.pastDueCount = pastDueCountData;
          this.checkedOutAssetsCount = checkoutCountData;
          this.hardReservedAssetsCount = hardReservationCountData;
          this.SoftReservedAssetsCount = softReservationCountData;
        }
      });

      

      this.receivedSubscription = this.store.pipe(select(state => state.Dashboard.receivecountChart))
      .subscribe(data => {
        if (data) {
          const { receivecountChartData, receivecountChartLoading } = data;
          this.receivecountChartData = receivecountChartData;
          this.receivecountChartLoading = receivecountChartLoading;
         
        }
      });


      this.shippedSubscription = this.store.pipe(select(state => state.Dashboard.shippedChart))
      .subscribe(data => {
        if (data) {
          const { shippedChartData, shippedChartLoading } = data;
          this.shippedChartData = shippedChartData;
          this.shippedChartLoading = shippedChartLoading;
          if (!this.receivecountChartLoading && !this.shippedChartLoading) {
             this.shippedReceivedGraph();
           }
        }
      });



    this.refinedBySubscription = this.store.pipe(select(state => state.RefinedBy))
      .subscribe(refinedByObj => {
        const {
          detailsRefinedBy = {}
        } = refinedByObj;
        this.detailsRefinedByObj = Object.assign({}, detailsRefinedBy);
      })
  }

  ngOnDestroy() {
    this.onhireSubscription.unsubscribe();
    this.checkoutSubscription.unsubscribe();
    this.hardReservationSubscription.unsubscribe();
    this.receivedSubscription.unsubscribe();
    this.dashboardSubScription.unsubscribe();
    this.refinedBySubscription.unsubscribe();
    this.store.dispatch(new ResetChartCounts({}));
  }

  ngOnChanges(changes: SimpleChange){
    let changeIndicator = changes['queryChangeIndicator'];
    if(changeIndicator){
      if(
        !_.isEqual(changeIndicator.currentValue, changeIndicator.previousValue)
      ){
        this.resetAllCharts();
      }
    }
  }

  ngAfterViewInit() {
    const { startDate, endDate } = this.daterange;
    this.setUtilizationDateRange(startDate, endDate);
    this.setHardReservationDateRange(startDate, endDate);
    this.setShippedReceivedDateRange(startDate, endDate);
  }

  setUtilizationDateRange(startDate, endDate) {
    this.utilizationDateRange.datePicker.setStartDate(localDate(startDate, 'YYYY-MM-DD'));
    this.utilizationDateRange.datePicker.setEndDate(localDate(endDate, 'YYYY-MM-DD'));

  }

  setHardReservationDateRange(startDate, endDate) {
    this.hardReservationDateRange.datePicker.setStartDate(localDate(startDate, 'YYYY-MM-DD'));
    this.hardReservationDateRange.datePicker.setEndDate(localDate(endDate, 'YYYY-MM-DD'));
  }

  setShippedReceivedDateRange(startDate, endDate) {
    this.shippedReceivedDateRange.datePicker.setStartDate(localDate(startDate, 'YYYY-MM-DD'));
    this.shippedReceivedDateRange.datePicker.setEndDate(localDate(endDate, 'YYYY-MM-DD'));
  }

  getActiveTabClass(chart, state) {
    if (chart === 'utilization') {
      return state === this.selectedUtilizationDateRange ? 'chartActiveTab' : 'chartInactiveTabs'
    } else if (chart === 'softReservation') {
      return state === this.selectedSoftReservationDateRange ? 'chartActiveTab' : 'chartInactiveTabs'
    } else if (chart === 'hardReservation') {
      return state === this.selectedHardReservationDateRange ? 'chartActiveTab' : 'chartInactiveTabs'
    } else if (chart === 'shippedReceived') {
      return state === this.selectedShippedReceivedDateRange ? 'chartActiveTab' : 'chartInactiveTabs'
    } else {
      return 'chartInactiveTabs';
    }
  }

  resetAllCharts = () => {
    if(this.utilizationChart){
      this.utilizationChart.destroy();
    }
    if(this.softReservationChart){
      this.softReservationChart.destroy();
    }
    if(this.hardReservationChart){
      this.hardReservationChart.destroy();
    }
    if(this.shippedReceivedChart){
      this.shippedReceivedChart.destroy();
    }
  }


  utilizationGraph() {
    let checkedoutArray = [];
    let onHireArray = [];
    let tickInterval;
    for (let i = 0; i < this.checkoututilizationChartData.length; i++) {
      let { checkedout, datestamp } = this.checkoututilizationChartData[i];
      let tempcheckedarr={};
      tempcheckedarr['x']=datestamp
      tempcheckedarr['y']=checkedout;
      checkedoutArray.push(tempcheckedarr);
    }

    for (let i = 0; i < this.onhireutilizationChartData.length; i++) {
      let { onhire, datestamp } = this.onhireutilizationChartData[i];
      let temponhirearr={};
      temponhirearr['x']=datestamp;
      temponhirearr['y']=onhire;
      onHireArray.push(temponhirearr);
    }
    if(this.selectedUtilizationDateRange === 'month') {
      tickInterval= 24 * 3600 * 1000
    }
    else if(this.selectedUtilizationDateRange === 'quarter'){
      tickInterval=3* 24 * 3600 * 1000;
    } 
    else if(this.selectedUtilizationDateRange === 'halfYear'){
      tickInterval=6 * 24 * 3600 * 1000;
    }
   

    this.utilizationChart = Highcharts.chart('utilizationChartcontainer', {
      title: {
        text: ""
      },
      xAxis: {
        title: {
          text: 'Date'
        },
        tickInterval: parseInt(tickInterval),
        minPadding: 0,
        maxPadding: 0,
        type:'datetime',
        gridLineWidth: 0,
        dateTimeLabelFormats: {
          day: '%e %b',
          month: '%b %y'
        },
       },
       yAxis: {
        title: {
          text: "Utilization %"
        },
        max: 100,
        tickInterval:10,
        tickWidth:1,
        lineWidth:1,
        gridLineWidth: 0
      },
      tooltip: {
        formatter: function() {
          return  '<b>' + this.series.name +':</b>' + this.y + ' <br/>'+
             Highcharts.dateFormat('%e %b %Y', this.x);    
          }
      },
      credits: {
        enabled: false
      },
      plotOptions: {
        series: {
            marker: {
                enabled: true
            }
        }
     },
      series: [{
         data: checkedoutArray,
        type: 'line',
        color: 'rgb(23, 118, 182)',
        name: 'Checkout',
        lineWidth:3
      },
      {
        data: onHireArray,
        type: 'line',
        color: 'rgb(144, 237, 125)',
        name: 'OnHire',
        lineWidth:3
      }]
      }, null);

  }

  utilizationGraphChart(unit) {
    this.selectedUtilizationDateRange = unit;
    let startdate = '';
    let enddate = moment().format('YYYY-MM-DD');
    let filterObj = this.getFilter();
    if (unit === 'week') {
      startdate = moment().subtract(7, 'day').format('YYYY-MM-DD');
      this.utilizationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'month') {
      startdate = moment().subtract(1, 'months').format('YYYY-MM-DD');
      this.utilizationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'quarter') {
      startdate = moment().subtract(3, 'months').format('YYYY-MM-DD');
      this.utilizationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'halfYear') {
      startdate = moment().subtract(6, 'months').format('YYYY-MM-DD');
      this.utilizationAction({ startdate, enddate, filter: filterObj })
    }
    this.setUtilizationDateRange(startdate, enddate);
  }

  utilizationAction(query) {
    this.utilizationChart.destroy();
    this.store.dispatch(new Getonhiremetrics(query));
    this.store.dispatch(new GetCheckoutmetrics(query));
  }

  softReservationAction(query) {
    this.softReservationChart.destroy();
    this.store.dispatch(new GetSoftReservationChart(query));
  }

  hardReservationGraph() {
    let hardReservationArray = [];
    let tickInterval;
    for (let i = 0; i < this.hardReservationChartData.length; i++) {
      let { hardreserved, datestamp } = this.hardReservationChartData[i];
      let temphardReservationarr={};
      temphardReservationarr['x']=datestamp
      temphardReservationarr['y']=hardreserved;
      hardReservationArray.push(temphardReservationarr);
    }
    if(this.selectedHardReservationDateRange === 'month') {
      tickInterval= 24 * 3600 * 1000 
    }
    else if(this.selectedHardReservationDateRange === 'quarter'){
      tickInterval=3* 24 * 3600 * 1000;
    } 
    else if(this.selectedHardReservationDateRange === 'halfYear'){
      tickInterval=6 * 24 * 3600 * 1000;
    }

    this.hardReservationChart = Highcharts.chart('hardReservationcontainer', {
      title: {
        text: ""
      },
      xAxis: {
        title: {
          text: 'Date'
        },
        tickInterval: parseInt(tickInterval),
        minPadding: 0,
        maxPadding: 0,
        type:'datetime',
        gridLineWidth: 0,
        dateTimeLabelFormats: {
          day: '%e %b',
          month: '%b %y'
        },
      },
      yAxis: {
        title: {
          text: "Hard Reservation %"
        },
        max: 100,
        min:0,
        tickInterval:10,
        tickWidth:1,
        lineWidth:1,
        gridLineWidth: 0
      },
      plotOptions: {
        series: {
            marker: {
                enabled: true
            }
        }
      },
      tooltip: {
        formatter: function() {
          return  '<b>' + this.series.name +':</b>' + this.y + ' <br/>'+
             Highcharts.dateFormat('%e %b %Y', this.x);
          }
      },
      credits: {
        enabled: false
      },
      series: [{
        data: hardReservationArray,
        type: 'spline',
        color: 'rgb(23, 118, 182)',
        name: 'Hard Reservation',
        lineWidth:3
      }]
      }, null);
  }

  hardReservationGraphChart(unit) {
    this.selectedHardReservationDateRange = unit;
    let startdate = '';
    let enddate = moment().format('YYYY-MM-DD');
    let filterObj = this.getFilter();
    if (unit === 'week') {
      startdate = moment().subtract(7, 'day').format('YYYY-MM-DD');
      this.hardReservationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'month') {
      startdate = moment().subtract(1, 'months').format('YYYY-MM-DD');
      this.hardReservationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'quarter') {
      startdate = moment().subtract(3, 'months').format('YYYY-MM-DD');
      this.hardReservationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'halfYear') {
      startdate = moment().subtract(6, 'months').format('YYYY-MM-DD');
      this.hardReservationAction({ startdate, enddate, filter: filterObj })
    }
    this.setHardReservationDateRange(startdate, enddate);
  }

  hardReservationAction(query) {
    this.hardReservationChart.destroy();
    this.store.dispatch(new GetHardReservationChart(query));
  }

  shippedReceivedGraph() {
    let receiveArray = [];
    let shipArray = [];
    let tickInterval;
    for (let i = 0; i < this.receivecountChartData.length; i++) {
      let { receivecount, datestamp } = this.receivecountChartData[i];
      let tempreceivecount={};
      tempreceivecount['x']=datestamp
      tempreceivecount['y']=receivecount;
      receiveArray.push(tempreceivecount);
    }

    for (let i = 0; i < this.shippedChartData.length; i++) {
      let { shipcount, datestamp } = this.shippedChartData[i];
      let tempshipArray={};
      tempshipArray['x']=datestamp
      tempshipArray['y']=shipcount;
      shipArray.push(tempshipArray);
    }
    
    if(this.selectedShippedReceivedDateRange === 'month') {
      tickInterval= 24 * 3600 * 1000 
    }
    else if(this.selectedShippedReceivedDateRange === 'quarter'){
      tickInterval=3* 24 * 3600 * 1000;
    } 
    else if(this.selectedShippedReceivedDateRange === 'halfYear'){
      tickInterval=6 * 24 * 3600 * 1000;
    }

    this.shippedReceivedChart = Highcharts.chart('shippedReceivedcontainer', {
      title: {
        text: ""
      },
      xAxis: {
        title: {
          text: 'Date'
        },
        tickInterval: parseInt(tickInterval),
        minPadding: 0,
        maxPadding: 0,
        type:'datetime',
        gridLineWidth: 0,
        dateTimeLabelFormats: {
          day: '%e %b',
          month: '%b %y'
        },
       },
       yAxis: {
        title: {
          text: "Shipped & Received Count"
        },
        max: 100,
        tickInterval:10,
        tickWidth:1,
        lineWidth:1,
        gridLineWidth: 0
      },
      tooltip: {
        formatter: function() {
          return  '<b>' + this.series.name +':</b>' + this.y + ' <br/>'+
             Highcharts.dateFormat('%e %b %Y', this.x);    
          }
      },
      credits: {
        enabled: false
      },
      series: [
      {
        data: shipArray,
        type: 'line',
        color: 'rgb(23, 118, 182)',
        name: 'Shipped',
        lineWidth:3
      },
      {
        data: receiveArray,
        type: 'line',
        color: 'rgb(244, 121, 121)',
        name: 'Received',
        lineWidth:3
      }]
      }, null);

  }

  shippedReceivedGraphChart(unit) {
    this.selectedShippedReceivedDateRange = unit;
    let startdate = '';
    let enddate = moment().format('YYYY-MM-DD');
    let filterObj = this.getFilter();
    if (unit === 'week') {
      startdate = moment().subtract(7, 'day').format('YYYY-MM-DD');
      this.shippedReceivedAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'month') {
      startdate = moment().subtract(1, 'months').format('YYYY-MM-DD');
      this.shippedReceivedAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'quarter') {
      startdate = moment().subtract(3, 'months').format('YYYY-MM-DD');
      this.shippedReceivedAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'halfYear') {
      startdate = moment().subtract(6, 'months').format('YYYY-MM-DD');
      this.shippedReceivedAction({ startdate, enddate, filter: filterObj })
    }
    this.setShippedReceivedDateRange(startdate, enddate);
  }

  shippedReceivedAction(query) {
    this.shippedReceivedChart.destroy();
    this.store.dispatch(new GetShippedChart(query));
    this.store.dispatch(new Getreceivecount(query));
  }

  getFilter() {
    let filter = this.detailsRefinedByObj['clickTracker'] || {};
    let filterObj = {};
    for (let key in filter) {
      if (this.mappPayload.hasOwnProperty(key)) {
        filterObj[this.mappPayload[key]] = filter[key]
      } else {
        filterObj[key] = filter[key]
      }
    }
    return filterObj
  }

  getChartQuery(e) {
    let startdate = moment(e.picker.startDate).format('YYYY-MM-DD');
    let enddate = moment(e.picker.endDate).format('YYYY-MM-DD');
    let filterObj = this.getFilter();
    return { startdate, enddate, filter: filterObj }
  }

  onUtilizationDateChange(e: any) {
    this.selectedUtilizationDateRange = '';
    let query = this.getChartQuery(e);
    this.utilizationAction(query);
  }

  onSoftReservationDateChange(e: any) {
    this.selectedSoftReservationDateRange = '';
    let query = this.getChartQuery(e);
    this.softReservationAction(query);
  }

  onhardReservationDateChange(e: any) {
    this.selectedHardReservationDateRange = '';
    let query = this.getChartQuery(e);
    this.hardReservationAction(query);
  }

  onShipReceivedDateChange(e: any) {
    this.selectedShippedReceivedDateRange = '';
    let query = this.getChartQuery(escape);
    this.shippedReceivedAction(query)
  }
}