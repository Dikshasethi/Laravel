import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceRequestSelectedAssetsComponent } from './service-request-selected-assets.component';

describe('ServiceRequestSelectedAssetsComponent', () => {
  let component: ServiceRequestSelectedAssetsComponent;
  let fixture: ComponentFixture<ServiceRequestSelectedAssetsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceRequestSelectedAssetsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceRequestSelectedAssetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
