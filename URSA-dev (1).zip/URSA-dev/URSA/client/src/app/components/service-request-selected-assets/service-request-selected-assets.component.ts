import { Component, OnInit, Input, SimpleChange, Output, EventEmitter } from '@angular/core';

import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { Router, ActivatedRoute } from '@angular/router';
import localformat from '../../utils/date/dateFormat';
import localDate from '../../utils/date/localDate';
import validateLocaleDate from '../../utils/date/validateLocaleDate';
import { ServiceRequestAssetsModel } from '../../utils/serviceRequest/serviceRequestModel';
import tableStructure from '../../utils/serviceRequest/additionalAssetTableStructure';
import actionButtonsList from '../../utils/serviceRequest/popUpActionButtonsList';
import { ServiceRequestModel } from '../../utils/serviceRequest/serviceRequestModel';
import * as _ from 'lodash';
import { ClearCheckInOutAssets, ClearCheckoutData } from '../../actions/checkout.action';
import { Subscription } from 'rxjs';
import { DeleteSelectedAsset } from '../../actions/serviceRequest.actions';
@Component({
  selector: 'app-service-request-selected-assets',
  templateUrl: './service-request-selected-assets.component.html',
  styleUrls: ['./service-request-selected-assets.component.css']
})
export class ServiceRequestSelectedAssetsComponent implements OnInit {
  parsedSAData: ServiceRequestAssetsModel[] = [];
  tableBuilderList = tableStructure;
  actionButtonsList = actionButtonsList;
  showSelectedAssetsModal: boolean = false;
  requestObject: object = {};
  hardreservedassets = [];
  checkInOutRecords = [];
  readyToCheckOutSubscription: Subscription;
  checkInOutSubscription: Subscription;
  tablePopUPData = [];
  assetsBuListToParse = [];
  @Input() originmodule: string = '';
  @Input() projectNumber: string = '';
  @Input() selectedAssetDetails: ServiceRequestAssetsModel[] = [];
  @Input() serviceRequestObject: ServiceRequestModel = <ServiceRequestModel>[];
  @Input() isAddMode: boolean;
  @Output() triggerAlertMessage = new EventEmitter<any>();
  constructor(
    private store: Store<AppState>, 
    private route:ActivatedRoute, 
    private router:Router
  ) { }

  ngOnInit() {
    if(this.serviceRequestObject.originmodule){
      this.originmodule = this.serviceRequestObject.originmodule;
    }
    this.parseSelectedAssetsDetailData(
      this.selectedAssetDetails
    );
     this.readyToCheckOutSubscription = this.store.pipe(select(state => state.CheckOutPageData))
    .subscribe(data => {
      const {
        readyToCheckOutData={},checkInOutData={}
      } = data;
      this.hardreservedassets = readyToCheckOutData['hardReservedAssets'];
      this.checkInOutRecords = checkInOutData['checkInOutRecords'];
      let modalPopUpData = [];
      if(this.originmodule === 'hard_reserve_table') {
        modalPopUpData = this.initHardReservedData(this.hardreservedassets) || [];
      }else {
        modalPopUpData = this.initCheckedOutCheckedInData(this.checkInOutRecords) || []
      }
      if(!_.isEmpty(modalPopUpData)) {
       this.tablePopUPData = this.parseModalPopUpData(modalPopUpData);;
      }
    });  
  }

  ngOnChanges(changes: SimpleChange) {
    if(
      changes['selectedAssetDetails'] &&
      (
        !_.isEqual(
          changes['selectedAssetDetails']['currentValue'],
          changes['selectedAssetDetails']['previousValue']
        ) 
      )
    ){
      this.selectedAssetDetails = changes['selectedAssetDetails']['currentValue'];
      this.parseSelectedAssetsDetailData(
        changes['selectedAssetDetails']['currentValue']
      );
    }
  }

  ngOnDestroy() {
    this.readyToCheckOutSubscription.unsubscribe();
  }

  parseSelectedAssetsDetailData = (selectedAssetDetails) => {
    let selectedAssetDeatils = (Array.isArray(selectedAssetDetails) && selectedAssetDetails.slice()) || [];
    this.parsedSAData = [];
    this.assetsBuListToParse = [];
    selectedAssetDeatils.forEach((details, i) => {
        this.assetsBuListToParse.push(details.assetid+details.businessunit)
        this.parsedSAData.push(details);
    })
  }

    showAssetModal = async () => {
     if(this.originmodule && this.projectNumber) {
     this.requestObject = await this.getAssetModelObject();
     this.showSelectedAssetsModal = true;
     }else{
       this.triggerErrorMessage();
     }
    }

    deleteSelectedAsset = (index) => {
      let reqObj = {
        indexToDelete: index
      }
      this.store.dispatch(new DeleteSelectedAsset(reqObj));
    }

    private getAssetModelObject = () => {
      let obj: any = {
        sort: {},
        filter: {},
      }
      if(this.originmodule === 'hard_reserve_table') {
        obj = {
         ...obj,
         hardReserverList: true,
          filter: {
           ...obj.filter,
           "checkedout":false,
           "checkedin":false,
           "projectnumber": this.projectNumber
          },
         sort: {updatedAt: -1}
        }
      }else if(this.originmodule === 'checkin_table') {
        obj = {
         ...obj,
          checkinList: true,
          filter: {
           ...obj.filter,
           "checkInOutRecords.checkedin": false,
           "checkInOutRecords.cancelled": false,
           "checkInOutRecords.projectnumber": this.projectNumber,
          },
          sort: {checkoutdatems: -1}
        }

      }else if(this.originmodule === 'checkedin_table') {
        obj = {
          ...obj,
           checkinList: true,
           filter: {
            ...obj.filter,
            "checkInOutRecords.cancelled": false,
            'checkInOutRecords.checkedin': true,
            'checkInOutRecords.projectnumber': this.projectNumber,
           },
          sort: {checkoutdatems: -1}
         }
      }
      return obj;
    }

    parseModalPopUpData (modalData) {
      return modalData.filter(modalPopUpData =>  !this.assetsBuListToParse.includes(modalPopUpData.assetid+modalPopUpData.businessunit));
    } 

    initHardReservedData = (hardReserveList=[]) => {
      let list = [];
      for (let i = 0; i < hardReserveList.length; i++){
        const record = hardReserveList[i];
        const {reservation={}} = record;
        let obj = {
          ...record,
          ...reservation
        };
        obj = {
          ...obj,
          assetid: obj.assetId,
          businessunit: obj.businessUnit,
          assetdescription: obj.assetDescription,
          status: this.originmodule,
        }
        delete obj['reservation'];
        list.push(obj);
      }
       return list;
    }

    initCheckedOutCheckedInData = (checkOutChekcedInList=[]) =>{
      let list = [];
      for (let i = 0; i < checkOutChekcedInList.length; i++){
        const record = checkOutChekcedInList[i];
        let obj = {
          ...record,
          startdate: record.projectstartdate,
          enddate: record.projectenddate,
          status: this.originmodule,
        }
        list.push(obj);
      }
       return list;
    }

    resetPopUpModal = () => {
      this.requestObject = {}
      this.showSelectedAssetsModal = false;
      this.store.dispatch(new ClearCheckInOutAssets());
      this.store.dispatch(new ClearCheckoutData());
      this.tablePopUPData = [];
    }

    triggerErrorMessage(){
      this.triggerAlertMessage.emit({
        alertState: 'error',
        alertMessage: 'Please select project number to select assets' }
      )
    }

}
