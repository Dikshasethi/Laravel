import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { NotificationsRoutes } from './notificaitons.routes';
import { NotificationsComponent } from './notifications.component';
import { NotificationUnitComponent } from '../notification-unit/notification-unit.component';

@NgModule({
    declarations: [
        NotificationsComponent,
        NotificationUnitComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(NotificationsRoutes)
    ],
    exports: [
        RouterModule
    ]
})

export class NotificationsModule { }