import { Component, OnInit, Input } from '@angular/core';
import { trigger, style, state, transition, animate } from '@angular/animations';
import { Router } from "@angular/router";
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { UpdateNotification, SetNotificationReducer } from '../../actions/notifications.actions';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css'],
  animations: [
    trigger('ExpandCollapse', [
      state('hide', style({ display: 'none', transform: 'translateY(0)' })),
      state('show', style({ display: 'block', transform: 'translateY(0)' })),
      transition('hide => show', [
        style({ transform: 'translateY(-5%)' }),
        animate(400)
      ]),
      transition('show => hide', [
        style({ transform: 'translateY(0%)' }),
        animate(100)
      ])
    ]),

    trigger('display', [
      state('hide', style({ display: 'none' })),
      state('show', style({ display: 'block' })),
    ]),

    trigger('show1', [
      state('hide', style({ display: 'none' })),
      state('show', style({ display: 'block' })),
    ])
  ]
})
export class NotificationsComponent implements OnInit {
  constructor(
    private router: Router,
    private store: Store<AppState>,
  ) { }

  @Input() inHeader: boolean;
  @Input() display: string;
  notificationSubscription;
  clientNotifications = [];
  clientNotificationCount = 0;
  updateError=false

  ngOnInit() {
    this.notificationSubscription = this.store.pipe(select(state => state.Notification))
    .subscribe(obj => {
      const {
        usersNotifications=[], updateNotificationError=false
      } = obj;
      this.clientNotifications = this.inHeader ? usersNotifications.slice(0, 5) : usersNotifications;
      this.clientNotificationCount = Array.isArray(usersNotifications) ? 
      usersNotifications.length : 0;
      this.updateError = updateNotificationError
    });
  }

  ngOnDestroy(){
    this.notificationSubscription.unsubscribe();
    this.store.dispatch(new SetNotificationReducer({
      notificationError : false,
      updateNotificationError : false
    }));
  }

  markAsRead = (notification:any) => {
    const {
      notificationId='', userId='', appId=''
    } = notification;
    this.store.dispatch(new UpdateNotification({
      notificationId,
      userId,
      appId,
      markAsRead : true
    }));
  }

  navigateToAllNotifications = () => {
    this.router.navigate(['/notifications']);
  }

}
