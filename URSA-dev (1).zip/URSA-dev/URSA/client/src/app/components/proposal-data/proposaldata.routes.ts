import { Routes } from '@angular/router';
import { ProposalDataComponent } from './proposal-data.component';

export const ProposalDataRoutes: Routes = [
    { path: '', component: ProposalDataComponent },
    { path: ':proposalid', component: ProposalDataComponent }
];