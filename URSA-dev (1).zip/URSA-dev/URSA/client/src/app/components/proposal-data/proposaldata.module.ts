import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { ProposalDataRoutes } from './proposaldata.routes';
import { ProposalDataComponent } from './proposal-data.component';
import { ProposalDataTableComponent } from '../proposal-data-table/proposal-data-table.component';
import { ProposalCrewTableComponent } from '../proposal-crew-table/proposal-crew-table.component';

@NgModule({
    declarations: [
        ProposalDataComponent,
        ProposalDataTableComponent,
        ProposalCrewTableComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(ProposalDataRoutes)
    ],
    exports: [
        RouterModule
    ]
})

export class ProposalDataModule { }