import { Component, OnInit, HostListener, ViewChild, ChangeDetectorRef, Output  } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { Router, ActivatedRoute } from '@angular/router';
import { form_template } from '../../utils/proposal/form_template';
import { crew_form_template } from '../../utils/proposal/crewFormTemplate';
import { ProposalModel, ProposaldetailsModel, ProposalCrewModel } from '../../utils/proposal/proposalModel';
import localDate from '../../utils/date/localDate';
import { 
  CreateReservation, CancelReservation 
} from '../../actions/proposalPageData.action';
import { 
  GetProposalData, DeleteProposalData, DeleteProductProposalCartData,
  CreateProposal, EditProposal, UpdateProposalStatus, GetCrewRequirementType,
  CreateCrewDraft, GetProposalVersions, ChangeProposalVersion, ResetProductProposalCartData,
  CancelProposal, SetPermanentProjectId
} from '../../actions/proposalData.action';
import { DestroyAutocompleteList, GetProjectData, GetCrmData, 
  GetBillingBusinessUnitData, GetBillingGroupData, GetCustodianAutocompleteList,
  GetServiceLineData, GetScopeOfWorkData, GetResponsibilityCodeData, GetBusinessUnitMasterData, GetCustomersData,
  SetAutoCompleteDisplayKey
} from '../../actions/autocomplete.actions';
import * as _ from 'lodash';
import descrBuilder from '../../utils/calloutDetails/descriptionBuilder';
import tabMenuList from '../../utils/proposal/tabMenuList';
import tableStructure from '../../utils/checkInOut/tableStructure';
import crewAssignmentTypeList from '../../utils/proposal/crewAssignmentTypeList'
import * as $ from 'jquery';
import * as moment from 'moment';
import { empty } from 'rxjs/Observer';
import isFromPs from '../../utils/proposal/isFromPs';
import { detailsRefinedBy } from '../../utils/refinedBy/refinedByConstants';
import { ProposalDataTableComponent } from '../proposal-data-table/proposal-data-table.component';
import { ProposalCrewTableComponent } from '../proposal-crew-table/proposal-crew-table.component';
import  checkForMinDate from '../../utils/proposal/checkForMinDate'
import actionButtonsList from '../../utils/proposal/actionButtonsList';
import dateValidation from '../../utils/date/dateValidator';

@Component({
  selector: 'app-proposal-data',
  templateUrl: './proposal-data.component.html',
  styleUrls: ['./proposal-data.component.css']
})
export class ProposalDataComponent implements OnInit {
  
  constructor(
    private store: Store<AppState>, 
    private route:ActivatedRoute, 
    private router:Router,
    private cdref: ChangeDetectorRef 
  ) { }
  
  @ViewChild(ProposalDataTableComponent) assetTable: ProposalDataTableComponent;
  @ViewChild(ProposalCrewTableComponent) crewTable: ProposalCrewTableComponent;
  formTemplate: any = form_template;
  crewFormTemplate: any = crew_form_template;
  proposalObject: ProposalModel;
  proposalDetails: ProposaldetailsModel[] = [];
  proposalCrewDetails : ProposalCrewModel[] = []
  actionButtonElements = actionButtonsList
  isAddMode: boolean;
  proposalPageSubscription;
  proposalDataSubscription
  proposalDetailsOriginalCopy = [];
  optionlist = {
    crewassignmenttype:  crewAssignmentTypeList
  }
  crewassignmenttype =  crewAssignmentTypeList
  empId: string;
  userDetailSubscription;
  userPermissions = [];
  defaultCustodian = '';
  proposalid: string;
  hardReservedAssets = [];
  checkedOutAssets = [];
  checkedInAssets = [];
  proposalDataLoading:boolean = false;
  deleteProposalDataLoading: boolean = false;
  proposalDataError = false;
  descriptionBuilder = descrBuilder.slice();
  tabMenuBuilder = tabMenuList.slice();
  tableBuilderList = tableStructure.slice();
  tableInFocus='proposal';
  countMap = {
    hardReservedAssets : 0,
    checkedOutAssets : 0,
    checkedInAssets : 0,
    proposalDetails : 0,
    proposalCrewDetails: 0
  }
  tableViewHeight = 0;
  productProposalCartData = [];
  hrResponseArray = [];
  showHrResponseModal:boolean = true;
  showHrResponse = 'none';
  isProposalMode: boolean = false;
  isProposalPageType: string = '';
  version:number = 0;
  addProposalLoading: boolean = false;
  public innerHeight: any;
  actionableStatusList = ['committed', 'Committed'];
  alertState: string;
  alertMessage: string;
  showConfirmationDisplay: string = 'none';
  confirmationMessage: string = '';
  confirmationModalType: string = '';
  assetTableDataState = [];
  crewTableDataState = [];
  crewrequirementtype = {}
  crewRequirementTypesLoading: boolean = false;
  crewPostitions = []
  crewPositionsLoading: boolean = false;
  crewJobTitles = [];
  crewjobtitlesLoading: boolean = false;
  projectAutocompleteSubscription;
  autocompleteProposalSubscription;
  autocompleteCheckoutSubscription;
  suggestionList=[];
  displayKey: string;
  proposalObjectOld: ProposalModel;
  editable: boolean = false;
  proposalVersionsData: any = [];
  proposalVersionLoading: boolean = false;
  checkForVersionRequest: boolean = false;
  showtempProjectIdOverwriteModal: string = 'none';;
  tempProjectId: string = '';
  newProjectId: string = '';
  searchScopeOfWork : string = '';
  searchForResponsibilityCode: boolean = false;
  checkForMinDate = checkForMinDate;
  showButtonsInTableFocusList = ['proposal', 'crew'];
  hrIsLoading: boolean = false;
  hardReservedRequestObj = {};
  enableSaveButton: boolean = false;
  autocompleteSkip: number = 0;
  autocompleteLimit: number = 10;
  recordCount: number = 10;
  autocompleteText: string = '';
  autocompleteField: string = '';
  autocompleteScrolledActive: boolean = false;

  @Output()
  setDatesInProposalDeatils =  {
    dataKey:  '',
    date: ''
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;
  }

  ngOnInit() {
    this.innerHeight = window.innerHeight;
    this.proposalid = this.route.snapshot.paramMap.get('proposalid');
    this.isAddMode = !this.proposalid;
    this.fetchCrewRequirementType();
    if(!this.isAddMode) {
      this.fetchProposalVersions();
    }
    this.proposalDataSubscription = this.store.pipe(select(state => state.ProposalNewData))
    .subscribe(proposalPageObject => {
      const {
        proposalNewData: { 
          proposalData = {},hardReservedAssets=[],
        checkedOutAssets=[],checkedInAssets=[],proposalDataLoading=false
        },
        createdProposalData: { addProposalData={}, addProposalLoading=false},
        crewRequirementType: {crewRequirementTypes={}, crewRequirementTypesLoading=false},
        crewPostition: {crewPostitions={}, crewpositionsLoading=false},
        crewJobTitle: {crewjobtitlesLoading=false}, 
        productProposalCartData=[],
        proposalModeObj: { isProposalPageType='', isProposalMode=false, proposalid= '' },
        proposalVersion: { proposalVersionsData = {}, proposalVersionLoading = false },
        errorState: { error = false, error_message },
      } = proposalPageObject;
      this.getTableViewHeight();
      this.crewrequirementtype = crewRequirementTypes['data'] || {};
      this.crewRequirementTypesLoading = crewRequirementTypesLoading;
      this.crewPositionsLoading = crewpositionsLoading;
      this.crewPostitions = crewPostitions['data'] || [];
      this.hardReservedAssets = hardReservedAssets;
      this.checkedOutAssets = checkedOutAssets;
      this.checkedInAssets = checkedInAssets;
      this.proposalObject =  proposalData || {};
      
      this.proposalObjectOld =  JSON.parse(JSON.stringify(this.proposalObject));
      this.proposalDataLoading = proposalDataLoading;
      this.isProposalPageType = isProposalPageType;
      this.isProposalMode =  isProposalMode;
      this.crewjobtitlesLoading = crewjobtitlesLoading 
      this.addProposalLoading = addProposalLoading;
      if(this.proposalObject['createdprojectid']){
        this.tempProjectId = this.proposalObject['createdprojectid'];
      }
      this.proposalVersionsData =  proposalVersionsData['versions'] ?
      _.orderBy(proposalVersionsData['versions'], 'version', 'desc') : [];
      if(this.proposalObject['version']) {
        this.version = this.proposalObject['version'];
      }
      this.proposalVersionLoading = proposalVersionLoading;
      if (error) {
        this.alertState = 'error';
        this.alertMessage = error_message;
          if(this.checkForVersionRequest) {
            this.checkForVersionRequest = false;
          }
          this.searchForResponsibilityCode = false;
      }
      if(this.isAddMode && !_.isEmpty(addProposalData) 
      && !_.isEmpty(addProposalData) && addProposalData['proposalid']) {
        this.router.navigate([`./proposal/${addProposalData['proposalid']}`]);
        this.proposalid = addProposalData['proposalid'];
        this.fetchProposalDetails();
      }

      if(!this.isAddMode && !_.isEmpty(addProposalData) && !addProposalLoading) {
         if(this.checkForVersionRequest) {
          this.fetchProposalVersions();          
        }
        if(!addProposalData['isCancelled']) {
          this.fetchProposalDetails();
        }

        if(addProposalData['editProposal']){
          this.enableSaveButton = false;
        }
        this.checkForVersionRequest = false;
      }
      if(this.proposalObject['submitstatus'] && this.proposalObject['submitstatus'].toLowerCase() !== 'draft'){
        this.refineProposalData(this.proposalObject)
      }
      if(this.proposalObject['proposaldetails']) {
        const assetDetails = this.filterProposalDetails('asset') || [];
        this.proposalDetailsOriginalCopy = assetDetails;
        this.proposalDetails = assetDetails;
        this.proposalCrewDetails = this.filterProposalDetails('crew') || [];
        this.crewTableDataState = this.proposalCrewDetails;
       }
      this.productProposalCartData = productProposalCartData
      this.countMap = {
        hardReservedAssets : this.hardReservedAssets.length || 0,
        checkedOutAssets : this.checkedOutAssets.length || 0,
        checkedInAssets : this.checkedInAssets.length || 0,
        proposalDetails : this.proposalDetails && 
        this.proposalDetails.length || 0,
        proposalCrewDetails:  this.proposalCrewDetails && 
        this.proposalCrewDetails.length || 0
      }
      if(this.isAddMode) {
        this.countMap = {
          ...this.countMap,
          proposalDetails: this.proposalDetails.length || 0
        }
      }
    })

    this.proposalPageSubscription = this.store.pipe(select(state => state.ProposalPageData))
    .subscribe(proposalPageObject => {
      const {
        proposalData={}, hrResponseObj={}, hrIsLoading=false
      } = proposalPageObject;
      this.hrIsLoading = hrIsLoading;
      if(
        this.showHrResponseModal && 
        Object.keys(hrResponseObj).length > 0
      ){
        this.parseHrResponse(hrResponseObj);
      }
    })

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(userDetailObj => {
      const {
        details
      } = userDetailObj;
      this.defaultCustodian = `${details['first_name']} ${details['last_name']}`;
      this.empId = details['employee_id'];
      this.userPermissions = details['permission'] || [];

      if(this.isAddMode && this.empId && !this.proposalObject['proposalplannername']) {
        this.proposalObject['proposalplannername'] =  this.defaultCustodian;
        this.proposalObject['proposalplannerid'] =   this.empId
      }

      if(this.empId && this.proposalDetails.length === 0 && !this.isAddMode 
      && !this.isProposalMode) {
        this.fetchProposalDetails();
      }

    })

    this.projectAutocompleteSubscription = this.store.pipe(select(state => state.Autocomplete.projectAutocomplete))
      .subscribe(autocompleteObject => {
        const {
          suggestionList
        } = autocompleteObject;
        if (suggestionList) {
          this.recordCount = suggestionList.length;
          this.suggestionList = suggestionList;
        }
      });
    
      this.autocompleteProposalSubscription = this.store.pipe(select(state => state.Autocomplete))
      .subscribe(autocompleteObject => {
        const {
          proposalAutoComplete: { suggestionList=[], isResponsibilityCode },
        } = autocompleteObject;
        this.recordCount = suggestionList.length;
        if (suggestionList.length > 0) {
            this.suggestionList = [...suggestionList];
            if(isResponsibilityCode && this.searchForResponsibilityCode) {
              this.setResponsibilityCodes(this.suggestionList);
            }
        }
        if(isResponsibilityCode) {
          this.searchForResponsibilityCode = false;
        }
      });

      this.autocompleteCheckoutSubscription = this.store.pipe(select(state => state.Autocomplete.checkoutAutocomplete))
      .subscribe(autocompleteObject => {
        const {
          suggestionList,isFetchingAutocompleteList, field
        } = autocompleteObject;
        if(suggestionList && field=="custodian") {
          this.recordCount = suggestionList.length;
          this.suggestionList = suggestionList;
        }
      });
  }

  ngAfterContentChecked() {
    this.editable = this.isEditable();
    this.cdref.detectChanges();
  }

  ngOnDestroy(){
    this.proposalDataSubscription.unsubscribe();
    this.proposalPageSubscription.unsubscribe();
    this.userDetailSubscription.unsubscribe();
    this.projectAutocompleteSubscription.unsubscribe();
    this.autocompleteProposalSubscription.unsubscribe();
    this.autocompleteCheckoutSubscription.unsubscribe();
  }

  filterProposalDetails(itemType: string ='asset') {
    return  this.proposalObject['proposaldetails'].filter((detailObj) => {
       return  (itemType === 'crew') ? 
       detailObj.itemtype == 'crew' :  detailObj.itemtype !== 'crew';
    })
  }

  refreshParent = (fiters) => {
    this.fetchProposalDetails();
  }
  
  getTableViewHeight = () => {
    let windowHeight = $(window).height();
    let proposalHeading = $('#proposalHeaderh').height();
    let proposalHeader = $('#proposalHeader').height();
    let proposalHeadercrew =  $('#proposalHeadercrew').height();

    let nonTableVH = ((
       proposalHeader     
        + proposalHeading
        + proposalHeadercrew
    ) / windowHeight) * 100;
    this.tableViewHeight = 130 - nonTableVH;
  }

  resetShowModal = () => {
    this.showHrResponseModal = true;
  }

  setEditableSaveButton = () => {
    this.enableSaveButton = true;
  }

  refineProposalData = (proposalData) => {
    let newArray = {} ;
    let data = proposalData;
    let {
      begindate = '', enddate = '',
    } = data;
    newArray = {
      ...data,
      begindate: begindate ? localDate(begindate, 'DD-MMM-YYYY') : '',
      enddate: enddate ? localDate(enddate, 'DD-MMM-YYYY') : ''
    };
    this.proposalObject = newArray;
  }

  fetchProposalVersions = () => {
    const obj={
      "proposalid": this.proposalid,
    }
    this.store.dispatch(new GetProposalVersions(obj));
  }

  setVersion = (selectedVersion) => {
    this.version = Number(selectedVersion);
    this.fetchProposalDetails();
  }

  fetchProposalDetails = () => {
    let obj={
        "proposalid": this.proposalid,
        "getReservations": true
    }
    if(this.version > 0 && !this.checkForVersionRequest) {
      obj['version'] = this.version;
    }
    this.store.dispatch(new GetProposalData(obj));
  }

  fetchCrewRequirementType = () => {
    this.store.dispatch(new GetCrewRequirementType());
  }

  setTableInFocus = (tab) => {
    if( this.assetTable){
      this.assetTableDataState = this.assetTable.parsedPSData
    }
    if(this.crewTable) {
      this.crewTableDataState = this.crewTable.parsedPSData
    }
    this.tableInFocus = tab['tableInFocus'];
  }

  removeProposal = (removalObj) => {
    if(!this.isAddMode) {
      this.enableSaveButton = true;
    }
    this.store.dispatch(new DeleteProposalData({index: removalObj.index}));
    if(removalObj.proposalDetail.hasOwnProperty('view'))  {
      //to remove from cart comparing product view or summary view
      const obj = {
        assetid: removalObj.proposalDetail.assetid || '',
        businessunit: removalObj.proposalDetail.businessunit || '',
        oiamsubtype2:  removalObj.proposalDetail.oiamsubtype2 || '',
        productcategory: removalObj.proposalDetail.productcategory || '',
        view:  removalObj.proposalDetail.view || ''
      };
      this.store.dispatch(new DeleteProductProposalCartData(obj));
    }
  }

  autoPopulateInEmptyDates = (datakey: string) => {
    this.setDatesInProposalDeatils = {
      dataKey: datakey,
      date: this.proposalObject[datakey]
    }
  }

  modalDisplayFunction() {
    if(this.proposalDataLoading || this.deleteProposalDataLoading 
      || this.addProposalLoading || this.crewRequirementTypesLoading || this.crewPositionsLoading ||
      this.crewjobtitlesLoading || this.searchForResponsibilityCode || this.hrIsLoading) {
      return 'block';
    } else {
      return 'none';
    }
  }

  parseHrResponse = (responseData : any={}) => {
    const {
      failList=[], successList=[]
    } = responseData;

    if(successList.length > 0){
      this.fetchProposalDetails();
    }
    let normalizedList = [...successList, ...failList];
    this.showHrResponse = 'block';
    this.hrResponseArray = normalizedList;
  }

  closeHrResponse = () => {
    this.showHrResponse = 'none';
    this.showHrResponseModal = false;
  }

  permissionDisplayCheck = (buttonObject) => {
    const {
      permissionBasedDisplay=false, permission='',type='', 
    } = buttonObject;

    switch(true) {
      case  this.isAddMode && type === 'createProposal' && (!permissionBasedDisplay || 
            this.userPermissions.includes(permission)):
        return true;
      case  !this.isAddMode && type === 'save' && this.proposalObject['submitstatus'] &&
            this.proposalObject.submitstatus.toLowerCase() === 'draft' && (!permissionBasedDisplay || 
            this.userPermissions.includes(permission)) && !isFromPs(this.proposalObject) && 
            !this.proposalObject['cancelled'] && (this.isEditable() || this.enableSaveButton):  
        return true;
      case  !this.isAddMode && type === 'readyproposal' &&  this.proposalObject['submitstatus'] &&
            this.proposalObject.submitstatus.toLowerCase() === 'draft' && (!permissionBasedDisplay || 
            this.userPermissions.includes(permission)) && !isFromPs(this.proposalObject) && 
            !this.proposalObject['cancelled']:
            return true;
      case  !this.isAddMode && type === 'returntodraft' &&  this.proposalObject['submitstatus'] &&
            this.proposalObject.submitstatus.toLowerCase() === 'ready' && !isFromPs(this.proposalObject) && 
            !this.proposalObject['cancelled']:
            return true;
      case  !this.isAddMode && type === 'overwritetempprojectid' &&  this.proposalObject['submitstatus'] &&
            this.actionableStatusList.includes(this.proposalObject.submitstatus.toLowerCase()) && this.proposalObject['projectcreated'] &&
            this.showButtonsInTableFocusList.includes(this.tableInFocus) && !this.proposalObject['finalprojectset'] && 
            (!permissionBasedDisplay || this.userPermissions.includes(permission)) 
            && !isFromPs(this.proposalObject) && !this.proposalObject['cancelled']:
            return true;
      case  !this.isAddMode && type === 'commitproposal' &&  this.proposalObject['submitstatus'] &&
            this.proposalObject.submitstatus.toLowerCase() === 'ready' && (!permissionBasedDisplay || 
            this.userPermissions.includes(permission)) && !isFromPs(this.proposalObject) && 
            !this.proposalObject['cancelled']:
            return true;
      case  !this.isAddMode && type === 'cancelproposal' && this.proposalObject['submitstatus'] &&
            !this.actionableStatusList.includes(this.proposalObject.submitstatus.toLowerCase()) &&  
            (!permissionBasedDisplay || this.userPermissions.includes(permission)) 
            && !isFromPs(this.proposalObject) && !this.proposalObject['cancelled']:
        return true;
      case  !this.isAddMode && type === 'activeversion' && this.proposalObject['submitstatus'] &&
            this.proposalObject.submitstatus.toLowerCase() === 'draft' &&  
            this.proposalObject['activeversion'] === false && !isFromPs(this.proposalObject) && 
            !this.proposalObject['cancelled']:
        return true;
      case  !this.isAddMode && type === 'createCrewDraft' && this.proposalObject['submitstatus']  &&
            !this.actionableStatusList.includes(this.proposalObject.submitstatus.toLowerCase()) &&
            this.tableInFocus === 'crew' && 
            (!this.proposalObject.hasOwnProperty('crewrequirementid') ||
            this.proposalObject.hasOwnProperty('crewrequirementid') &&
            this.proposalObject['crewrequirementid'].length === 0) && !isFromPs(this.proposalObject) :
        return true;
      case !this.isAddMode && this.proposalObject['submitstatus'] && type === 'decommitproposal' &&
            this.actionableStatusList.includes(this.proposalObject.submitstatus.toLowerCase()) &&
            this.showButtonsInTableFocusList.includes(this.tableInFocus) && _.isEmpty(this.hardReservedAssets) &&
            _.isEmpty(this.checkedInAssets) && _.isEmpty(this.checkedOutAssets) && (!permissionBasedDisplay || 
            this.userPermissions.includes(permission)) && !isFromPs(this.proposalObject) :
        return true;
      default:
        return false;
    }
  }

  private CreatePayload() {
    let mergedProposalDetails = [];
    if(this.tableInFocus === 'crew') {
      let filteredPsdata =   (this.crewTable) ? this.crewTable.filteredPSData : [];  
      mergedProposalDetails =  [
        ...this.assetTableDataState,
        ...filteredPsdata
      ]
    }

    if(this.tableInFocus === 'proposal') {
      let filteredPsdata =   (this.assetTable) ? this.assetTable.filteredPSData : [];  
      mergedProposalDetails =  [
        ...filteredPsdata,
        ...this.crewTableDataState
      ]
    }
    let payload = this.proposalObject;
    payload.proposaldetails = mergedProposalDetails;
    return payload;
  }

  private mappeddata() {
    let payload = this.CreatePayload();
    let proposalDetail_record =  payload.proposaldetails;
    let detail_record = [];
    for (let i = 0; i < proposalDetail_record.length; i++) {
      let record = proposalDetail_record[i];
      let newRecord = {
        itemtype: record.itemtype,
        quantity: record.quantity || 0,
        chargerate:  record.chargerate || 0,
        chargeunit:   record.chargeunit || 0,
        chargeunittype:  record.chargeunittype,
        begindate : dateValidation(record.begindate) ? moment(record.begindate).format('YYYY-MM-DD') : '',
        enddate : dateValidation(record.enddate) ? moment(record.enddate).format('YYYY-MM-DD') : '',
        businessunit: record.businessunit || '',
        productcategory: record.productcategory || '',
        pdid: record.pdid || '',
        assetid: record.assetid || '',
        projectid : record.projectid || '',
        oiamsubtype2 : record.oiamsubtype2 || '',
        crewpositionid : record.crewpositionid  || '',
        crewpositionname : record.crewpositionname  || '',
        crewjobtitles  : record.crewjobtitles || [],
        crewtype  : record.crewtype  || '',
        softreservecount: record.softreservecount  || 0,
        crewrequiredbydate : dateValidation(record.crewrequiredbydate) ? moment(record.crewrequiredbydate).format('YYYY-MM-DD') : '',
      }
      detail_record.push(newRecord);
    }

    let mappedRecords: any = {
      ...payload,
      begindate: dateValidation(payload.begindate) ? moment(payload.begindate).format('YYYY-MM-DD') : '',
      enddate: dateValidation(payload.enddate) ? moment(payload.enddate).format('YYYY-MM-DD') : '',
      proposaldetails: detail_record
    }
    return mappedRecords;
  }

  private createProposal() {
   let payload = this.mappeddata()
   this.store.dispatch(new CreateProposal(payload));
  }

  closeConfirmationModal() {
    this.resetConfirmationModal();
  }

  createHardReservation = () => {
    this.store.dispatch(new CreateReservation({
      assetList : [this.hardReservedRequestObj],
      proposalid : this.proposalid
    }));
    this.resetShowModal();
  }

  removeHardReservation = () => {
    this.store.dispatch(new CancelReservation({
      assetList : [this.hardReservedRequestObj],
    }));
    this.resetShowModal();
  }

  saveConfirmationModal = () => {
    if(this.confirmationModalType === 'cancelproposal'){
      this.confirmCancelProposal()
    }else if(this.confirmationModalType === 'createHardReservation') {
      this.createHardReservation()
    }else if(this.confirmationModalType === 'removeHardReservation') {
      this.removeHardReservation()
    }
    this.resetConfirmationModal();
  }

  resetConfirmationModal = () => {
    this.showConfirmationDisplay =  'none';
    this.confirmationModalType = '';
    this.hardReservedRequestObj = {};
  }
  
  confirmVersionAction(checkVersionchange: string = 'oldVersion') {
    let payload = this.mappeddata();
    let  mappedNewRecord = {
        proposal: payload
    }

      if(checkVersionchange === 'newVersion') {
        mappedNewRecord['newVersion'] = true
        this.checkForVersionRequest = true;
      }
    this.store.dispatch(new EditProposal(mappedNewRecord));
    this.showConfirmationDisplay =  'none';
  }



  confirmCancelProposal() {
    let payload = {
      proposalid: this.proposalid
    }
    this.store.dispatch(new CancelProposal(payload));
  }
  
  private showVersionModal(modeltype='save') {
    this.confirmationMessage = 'Please click confirm if you want to change current draft to new version?'
    this.confirmationModalType = 'save'
    if(modeltype === 'cancelproposal') {
      this.confirmationMessage = 'Please click confirm if you want to cancel all versions of current proposal?' 
      this.confirmationModalType = 'cancelproposal'
    }
    this.showConfirmationDisplay =  'block';
  }

  private updateStatus(status='committed') {
    let payload = {
      proposalid: this.proposalid,
      newStatus: 'Committed'
    }

    if(status === 'ready') {
       payload = {
        ...payload,
        newStatus: 'Ready'
       }
    }

    if(status === 'draft') {
      payload = {
       ...payload,
       newStatus: 'Draft'
      }
   }
    this.store.dispatch(new UpdateProposalStatus(payload));
  }

  private createDraft() {
    let payload = this.mappeddata();
    this.store.dispatch(new CreateCrewDraft(payload));
    this.showConfirmationDisplay =  'none';
  }

  private changeVersion() {
    let obj = {
      proposalid : this.proposalid,
      updateVersion: Number(this.version)
    }
    this.store.dispatch(new ChangeProposalVersion(obj));
  }

  triggerSubmit = (btnType) => {
    if(btnType === 'createProposal'){
      this.createProposal();
    }else if(btnType === 'save') {
      this.showVersionModal();
    }else if(btnType === 'cancelproposal') {
      this.showVersionModal('cancelproposal');
    }else if(btnType === 'activeversion') {
      this.changeVersion();
    }else if(btnType === 'readyproposal') {
      this.updateStatus('ready');
    }else if(btnType === 'returntodraft') {
      this.updateStatus('draft');
    }else if(btnType === 'commitproposal') {
      this.updateStatus();
    }else if(btnType === 'decommitproposal') {
      this.updateStatus('ready');
    }else if(btnType === 'createCrewDraft') {
      this.createDraft();
    }else if(btnType === 'overwritetempprojectid') {
      this.resetTempProjectIdShowModal();
    }
  }

  triggerAlertMessage = (alertObject) => {
    this.alertMessage = alertObject.message;
    this.alertState = alertObject.state
  }

  resetErrorMessages() {
    this.alertMessage = '';
    this.alertState = ''
  }

  checkFormType(type: string) {
    if(type === 'date' && 
    this.proposalObject.hasOwnProperty('submitstatus') &&
    this.proposalObject['submitstatus'].toLowerCase() !== 'draft') {
      type = 'text'
    }
    return type;
  }

  checkDisable(buttonType: string) {
    this.editable = this.isEditable();
    if(buttonType == 'createProposal') {
     return this.verifyButtonAccess(this.formTemplate)
    }
    if(buttonType == 'createCrewDraft') {
      let checkforCrewDisable = this.verifyButtonAccess(this.crewFormTemplate);
      if(checkforCrewDisable || this.crewTableDataState.length === 0 || this.editable) {
        return true
      }
      return false;
    }
    if(buttonType == 'readyproposal') {
      if(this.editable || this.enableSaveButton) {
        return true
      }
      return false;
    }
    if(buttonType == 'cancelproposal' && 
      this.proposalObject['submitstatus'] &&
      this.proposalObject.submitstatus.toLowerCase() === 'draft'
    ) {
      if(this.editable || this.enableSaveButton) {
        return true
      }
      return false;
    }
  }

  isEditable() {
    if(!this.isAddMode && this.assetTable || this.crewTable) {
      let payload = this.mappeddata();
      let propObjCopy =   JSON.parse(JSON.stringify(this.proposalObjectOld)) || {};
      if(propObjCopy['proposaldetails'] && propObjCopy['proposaldetails'].length > 0 ) {
        let filteredDetailsAccordingToPayload = [];
        for(let detail of propObjCopy['proposaldetails']) {
          if(detail.hasOwnProperty('_id')) {
            delete detail['_id']
          }
          if(detail.hasOwnProperty('coQty')) {
            delete detail['coQty']
          }
          if(detail.hasOwnProperty('hrQty')) {
            delete detail['hrQty']
          }
          filteredDetailsAccordingToPayload.push(detail);
        }
        propObjCopy = {
          ...propObjCopy,
          proposaldetails: filteredDetailsAccordingToPayload
        }
      }
      
      if(!_.isEqual(payload,propObjCopy)){
        return true;
      }
    }
    return false;
  }

  verifyButtonAccess(formTemplateType) {
    for(let value of formTemplateType) {
      if(!value.hasOwnProperty('required') || (value.required && 
        this.proposalObject.hasOwnProperty(value.dataKey) &&
        this.proposalObject[value.dataKey] !== '')
        ){
          continue;
      }else{
        return true
      }
    }
    return false;
  }


  handleAutocompleteInputChange(text, field) {
    this.setAutocompleteDisplayKey('');
    this.suggestionList = [];
    this.resetAutocompletePagination();
    if (text.length > 1 &&  !this.proposalObject[field] 
      && !this.newProjectId) {
      this.autocompletePayload(text, field)
    }else if ((text.length > 1 &&  field === 'scopeofwork')) {
       this.fetchScopeOfWork(text, field)
    }else {
        this.resetProposalData(field)
        this.destroyAutoCompleteList()
    }
  }

  private autocompletePayload (text, field) {
    this.autocompleteText = text;
    this.autocompleteField = field;
    if (field === 'crewrequirementprojectnumber' || 
      field === 'newProjectId' || field === 'projectid') {
        this.displayKey = 'PROJECTID';
        let obj = {
          "skip": this.autocompleteSkip,
          "limit": this.autocompleteLimit,
          "filter": {}
        }
        obj.filter['PROJECTID'] = text
        this.destroyAutoCompleteList();
        this.setAutocompleteDisplayKey(field);
        obj.filter["PROJECTSTATUS"] = "A";
        this.store.dispatch(new GetProjectData(obj));
      }else if(field === 'group') {
        this.displayKey = 'Billing_Group';
        this.destroyAutoCompleteList();
        let obj = {
          "billinggroup": text,
          "limit":this.autocompleteLimit,
          "skip":this.autocompleteSkip,
        }
        this.setAutocompleteDisplayKey(field);
        this.getBillingGroupData(obj);
      }else if(field === 'businessunit') {
        this.displayKey = 'id';
        this.destroyAutoCompleteList();
        this.setAutocompleteDisplayKey(field);
        let obj={
          "searchKeyword": text,
          "skip": this.autocompleteSkip,
          "limit": this.autocompleteLimit
         }
        this.getBusinessUnitMasterData(obj);
      }else if(field === 'oicrmbidnumber') {
        this.displayKey = 'CRM_Number';
        this.destroyAutoCompleteList();
        this.setAutocompleteDisplayKey(field);
        let obj = {
          "crmnumber": text,
          "skip": this.autocompleteSkip,
          "limit": this.autocompleteLimit
        }
        this.getCrmData(obj);
      }else if (field === 'proposalplannername') {
         this.displayKey = 'empName';
         this.destroyAutoCompleteList();
         this.setAutocompleteDisplayKey(field);
         let obj={
          "index":"employeesearch",
          "search_keyword":text,
          "field":"custodian"
        }
        this.store.dispatch(new GetCustodianAutocompleteList(obj));
      } else if (field === 'servicelinename') {
        this.displayKey = 'name';
        this.destroyAutoCompleteList();
        this.setAutocompleteDisplayKey(field);
        let obj={
         "searchKeyword": text,
         "skip": this.autocompleteSkip,
         "limit": this.autocompleteLimit
        }
       this.store.dispatch(new GetServiceLineData(obj));
      }else if (field === 'scopeofwork') {
        this.fetchScopeOfWork(text, field);
      }else if (field === 'responsibilityname') {
        this.searchForResponsibilityCode = false;
        this.getResponsibilityCodes(text);
      }else if (field === 'customername') {
       this.displayKey = 'clientName';
       this.destroyAutoCompleteList();
       this.setAutocompleteDisplayKey(field);
       let obj={
          "searchKeyword": text,
          "skip": this.autocompleteSkip,
          "limit": this.autocompleteLimit,
       }
       this.store.dispatch(new GetCustomersData(obj));
     }
  }

  dispatchInitialRequest = (text, field: string) =>  {
    this.setAutocompleteDisplayKey(field);
    this.suggestionList = [];
    this.resetAutocompletePagination();
    if (!this.proposalObject[field] 
      && !this.newProjectId) {
        this.autocompletePayload(text, field)
      }else if(field === 'scopeofwork') {
        this.fetchScopeOfWork(text, field);
      }
  }

  onScrollLoad = () => {
    this.autocompleteScrolledActive = true;
    this.autocompleteSkip = this.autocompleteSkip + 10;
    if(this.recordCount % 10 === 0) {
      this.autocompletePayload(this.autocompleteText, this.autocompleteField)
    }
  }

  private resetAutocompletePagination () {
    this.autocompleteSkip = 0;
    this.autocompleteScrolledActive = false;
    this.recordCount = 10;
  }

  private setAutocompleteDisplayKey = (keyValue: string) => {
    this.store.dispatch(new SetAutoCompleteDisplayKey({identifierKey: keyValue}));
  }

  private fetchScopeOfWork(text, field) {
    this.displayKey = 'name';
    this.destroyAutoCompleteList();
    this.setAutocompleteDisplayKey(field);
    let obj={
    "searchKeyword": text,
    "serviceline": this.proposalObject['serviceline'],
    "skip": this.autocompleteSkip,
    "limit": this.autocompleteLimit
    }
    this.searchScopeOfWork = '';
    this.store.dispatch(new GetScopeOfWorkData(obj));
  }

  private resetProposalData(field) {
    this.resetAutocompletePagination();
    if (field === 'responsibilityname' && 
    this.proposalObject['responsibilityname']) {
      this.proposalObject['responsibilityname'] = '';
      this.proposalObject['servicelinename'] = '';
      this.proposalObject['serviceline'] = '';
      this.proposalObject['scopeofwork'] = [];
      this.proposalObject['subscopeofwork'] = [];
      this.proposalObject['regioncode'] = '';
      this.proposalObject['regionname'] = '';
      this.proposalObject['responsibilitycode'] = '';
      this.searchForResponsibilityCode = false;
    }else if (field === 'customername' 
    && this.proposalObject['customername']) {
      this.proposalObject['customername'] = '';
      this.proposalObject['customerid'] = '';
    }else if (field === 'proposalplannername' &&
    this.proposalObject['proposalplannername']) {
      this.proposalObject['proposalplannerid'] = '';
      this.proposalObject['proposalplannername'] = '';
    }else if (field === 'oicrmbidnumber' && 
    this.proposalObject['oicrmbidnumber']) {
      this.proposalObject['crmcustomerid'] = '';
      this.proposalObject['proposaltitle'] = '';
      this.proposalObject['crmcustomername'] = '';
      this.proposalObject['crmprobability'] = '';
      this.proposalObject['crmstatus'] = '';
      this.proposalObject['oicrmbidnumber'] = '';
    }else if (field === 'businessunit' &&  
      this.proposalObject['businessunit']) {
      this.proposalObject['businessunit'] = '';
      this.proposalObject['businessunitname'] = '';
    }else {
      if(field === 'newProjectId') {
        this.newProjectId = '';
      }else{
        if(field !== 'scopeofwork' && this.proposalObject[field]) {
          this.proposalObject[field] = '';
        }
      }
    }
  }

  private getResponsibilityCodes(searchText) {
      this.displayKey = 'responsibilityName';
      this.destroyAutoCompleteList();
      this.setAutocompleteDisplayKey('responsibilityname');
      let obj={
          "searchKeyword": searchText,
          "skip": this.autocompleteSkip,
          "limit": this.autocompleteLimit
      }
      this.store.dispatch(new GetResponsibilityCodeData(obj));
  }

  private setResponsibilityCodes(responsibilitycodesData) {
    if(responsibilitycodesData.length > 0) {
     let  suggestedvalue = responsibilitycodesData[0];
     this.proposalObject['serviceline'] = suggestedvalue.serviceLineCode;
     this.proposalObject['servicelinename'] = suggestedvalue.serviceLineName;
     this.proposalObject['regioncode'] = suggestedvalue.regionCode;
     this.proposalObject['regionname'] = suggestedvalue.regionName;
     this.proposalObject['responsibilitycode'] = suggestedvalue.responsibilityCode;
     this.proposalObject['responsibilityname'] = suggestedvalue.responsibilityName;
     this.searchForResponsibilityCode = false;
    }
  }
  
  private getCrmData(queryObj) {
    this.store.dispatch(new GetCrmData(queryObj));
  }

  private getBillingGroupData(queryObj) {
    this.store.dispatch(new GetBillingGroupData(queryObj));
  }

  private getBusinessUnitMasterData(queryObj) {
    this.store.dispatch(new GetBusinessUnitMasterData(queryObj));
  }

  private destroyAutoCompleteList() {
    if(!this.autocompleteScrolledActive) {
      this.store.dispatch(new DestroyAutocompleteList());
    }
  }

  proposalSuggestionSelected(suggestion, field) {
      if(field === 'newProjectId') {
        this.newProjectId = suggestion[this.displayKey];
      }else{
        if(field !== 'scopeofwork') {
          this.proposalObject[field] = suggestion[this.displayKey];
        }
      }
      if(field === 'oicrmbidnumber') {
        this.proposalObject['crmcustomerid'] = suggestion['CustomerID'];
        this.proposalObject['proposaltitle'] = !suggestion['Description'] || 
        suggestion['Description'] === ''? 'N/A' : suggestion['Description'];
        this.proposalObject['crmcustomername'] =  !suggestion['CustomerName'] || 
        suggestion['CustomerName'] === ''? 'N/A' : suggestion['CustomerName'];

        this.proposalObject['crmprobability'] =  !suggestion['Probability'] || 
        suggestion['Probability'] === ''? 'N/A' : suggestion['Probability'];

        this.proposalObject['crmstatus'] =  !suggestion['Status'] || 
        suggestion['Status'] === ''? 'N/A' : suggestion['Status'];
      }
      if(field === 'businessunit') {
        this.proposalObject['businessunitname'] = suggestion['desc'];
      }
      if(field==='proposalplannername'){
        this.proposalObject['proposalplannerid'] = suggestion.empId;
        this.proposalObject['proposalplannername'] = suggestion.empName;
      }
      if(field==='servicelinename'){
        this.proposalObject['servicelinename'] = suggestion.name;
        this.proposalObject['serviceline'] = suggestion.id;
      }
      if(field==='scopeofwork'){
        this.setScopeOfWork(suggestion);
        this.searchScopeOfWork = '';
      }
      if(field==='responsibilityname'){
        this.proposalObject['serviceline'] = suggestion.serviceLineCode;
        this.proposalObject['servicelinename'] = suggestion.serviceLineName;
        this.proposalObject['regioncode'] = suggestion.regionCode;
        this.proposalObject['regionname'] = suggestion.regionName;
        this.proposalObject['responsibilitycode'] = suggestion.responsibilityCode;
        this.proposalObject['responsibilityname'] = suggestion.responsibilityName;
      }
      if(field==='customername'){
        this.proposalObject['customername'] = suggestion.clientName;
        this.proposalObject['customerid'] = suggestion.clientId;
      }
      if(field==='projectid'){
       this.searchForResponsibilityCode = true;
       this.getResponsibilityCodes(suggestion.RESPONSIBILITYCODE);
      }
  }

  setScopeOfWork = (selectedScopeOfWork) =>  {
    if(selectedScopeOfWork && selectedScopeOfWork['name']) {
      const scopeOfWorkArray: any =  this.proposalObject['scopeofwork'] || [];
      if(!scopeOfWorkArray.includes(selectedScopeOfWork['name'])){
        scopeOfWorkArray.push(selectedScopeOfWork['name']);
        this.setSubScopeOfWork(selectedScopeOfWork);
      }
      this.proposalObject['scopeofwork'] = scopeOfWorkArray
      this.searchScopeOfWork = '';
    }
    
  }

  setSubScopeOfWork = (selectedScopeOfWork) =>  {
    const subtTypesObj =  selectedScopeOfWork.subTypes;
    if(subtTypesObj && subtTypesObj.length > 0) {
      const subScopeOfWorkArray: any =  this.proposalObject['subscopeofwork'] || [];
      const subScopeOfWorkArrayWithSow =  subtTypesObj.map((data) => {
        return {
              ...data,
              sow: selectedScopeOfWork.name
        }
      })
      subScopeOfWorkArray.push(...subScopeOfWorkArrayWithSow);
      this.proposalObject['subscopeofwork'] = subScopeOfWorkArray;
    }
  }

  removeSelectedInput = (input: string) => {
    let scopeOfWorkArray: any =  this.proposalObject['scopeofwork'] || [];
    scopeOfWorkArray = scopeOfWorkArray.filter((scopeOfWorkData) => {
      return scopeOfWorkData !== input
    })
    this.filterSubScopeOfWork(input);
    this.proposalObject['scopeofwork'] = scopeOfWorkArray;
  }

  filterSubScopeOfWork = (input) => {
    let subScopeOfWorkArray: any =  this.proposalObject['subscopeofwork'] || [];
    if(subScopeOfWorkArray.length > 0) {
      subScopeOfWorkArray = subScopeOfWorkArray.filter((subScopeOfWorkData) => {
        return subScopeOfWorkData.sow !== input
      })
      this.proposalObject['subscopeofwork'] = subScopeOfWorkArray;
    }
  }

  hrResponseRowClass = (rowData: any = {}) => {
    const {
      failMessage=''
    } = rowData;
    if(failMessage){
      return 'rowIsUnavailable';
    }else{
      return ''
    }
  }

  removeSubScopeOfWork = (index: number, deleteSubscopeofwork) => {
     const filtereSubScopeArrayObj: any = this.proposalObject['subscopeofwork'].filter((subScopeObj: any) => {
       if(subScopeObj._id) {
        return subScopeObj._id  !== deleteSubscopeofwork._id;
       }else{
        return subScopeObj.name  !== deleteSubscopeofwork.name;
       }
    });
    this.proposalObject['subscopeofwork'] = filtereSubScopeArrayObj;
  }

  resetTempProjectIdShowModal = () => {
    this.showtempProjectIdOverwriteModal = 'block';
  }

  closeOverwriteModal = () => {
    this.newProjectId = '';
    this.showtempProjectIdOverwriteModal = 'none';
  }

  updateTempProjectId = () => {
    let obj = {
      proposalid: this.proposalid,
      temporaryprojectid : this.tempProjectId,
      projectid: this.newProjectId
    }
    this.store.dispatch(new SetPermanentProjectId(obj));
    this.showtempProjectIdOverwriteModal = 'none';
    this.newProjectId = '';
  }
  
  hardReservationAction = (hardReserveObject) => {
    const {hrObject={}, hrModeltype='createHardReservation'} = hardReserveObject;
    this.confirmationMessage = 'Are you sure you want to create Hard Reservation ?'
    this.confirmationModalType = 'createHardReservation';
    this.hardReservedRequestObj = hrObject;
    if(hrModeltype === 'removeHardReservation') {
      this.confirmationMessage = 'Are you sure you want to cancel Hard Reservation?'
      this.confirmationModalType = 'removeHardReservation'
    }
    this.showConfirmationDisplay =  'block';
  }
}