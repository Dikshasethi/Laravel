import { Component, OnInit, Input, Output, EventEmitter, SimpleChange } from '@angular/core';
import {
    DestroyAutocompleteList,
    GetCheckoutAutocomplete, GetLocationAreasCheck
} from '../../actions/autocomplete.actions';

import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import * as _ from 'lodash';
import dateValidation from '../../utils/date/dateValidator';
import { Subscription } from 'rxjs';
import defaultValues from '../../utils/autoComplete/defaultValues'

@Component({
    selector: 'app-edit-hardreserve-modal',
    templateUrl: './edit-hardreserve-modal.component.html'
})

export class EditHardReserveModalComponent implements OnInit {

    constructor(
        private store: Store<AppState>
    ) { }

    dateRange = {
        hardReserveStartDate: '',
        hardReserveEndDate: '',
        startDateFlag: false,
        endDateFlag: false,
    }

    @Input() hardreserveModalDisplay: any;
    @Output() closeModal: EventEmitter<any> = new EventEmitter();
    @Output() submitForm: EventEmitter<any> = new EventEmitter();

    ngOnInit() {
    }


    ngOnChanges(changes: SimpleChange) {
        if (
            changes['hardreserveModalDisplay'] &&
            !_.isEqual(
                changes['hardreserveModalDisplay']['currentValue'],
                changes['hardreserveModalDisplay']['previousValue']
            )
        ) {
            this.hardreserveModalDisplay = changes['hardreserveModalDisplay']['currentValue'];
        }
    }


    onDateChange(event, field) {
        if (field == 'start') {
            this.dateRange.startDateFlag = false;
            this.dateRange.hardReserveStartDate = event;
            if (!dateValidation(event)) {
                this.dateRange.startDateFlag = true;
            }
            else {
                this.dateRange.hardReserveEndDate = "";
            }

        }
        else if (field == 'end') {
            this.dateRange.endDateFlag = false;
            this.dateRange.hardReserveEndDate = event;
            if (!dateValidation(event)) {
                this.dateRange.endDateFlag = true;
            }
        }
    }

    resetFormMap() {
        this.dateRange = {
            hardReserveStartDate: '',
            hardReserveEndDate: '',
            startDateFlag: false,
            endDateFlag: false,
        }
    }


    isSubmitButtonDisabled = () => {
        const { hardReserveStartDate, hardReserveEndDate,
            startDateFlag, endDateFlag } = this.dateRange;
        let disabled = true;
        if (!hardReserveStartDate || !hardReserveEndDate) {
            if (hardReserveStartDate && hardReserveEndDate) {
                disabled = false;
            } else {
                return true;
            }
        }
        if (startDateFlag || endDateFlag) {
            return true;
        } else {
            disabled = false;
        }


        return disabled;
    }

    closeModalFunction = () => {
        this.resetFormMap();
        this.closeModal.emit()
    }

    submitFormFunction() {
        const { hardReserveStartDate, hardReserveEndDate } = this.dateRange;
        this.submitForm.emit({ hardReserveStartDate, hardReserveEndDate });
        this.closeModalFunction();
    }

}
