import { Component, OnInit, Input, Output, EventEmitter, SimpleChange } from '@angular/core';
import * as _ from 'lodash';
import panelFormHeaderMap from '../../utils/checkInOutClientDetails/panelFormHeaderMap';

@Component({
  selector: 'app-check-in-out-client-panel-modal',
  templateUrl: './check-in-out-client-panel-modal.component.html',
  styleUrls: ['./check-in-out-client-panel-modal.component.css']
})
export class CheckInOutClientPanelModalComponent implements OnInit {

  constructor() { }

  @Input() isSubmitButtonDisabled: any;
  @Input() displayClientPanelModal: any;
  @Input() panelStructureList: any;
  @Input() panelData: any;
  @Input() currentAction: any;
  @Output() integratePanel: EventEmitter<any>  = new EventEmitter();
  @Output() closeModal: EventEmitter<any>  = new EventEmitter(); 
  @Output() dynamicSubmitAction: EventEmitter<any>  = new EventEmitter(); 
  formHeaderText='';
  isSubmitBtn : boolean = true;
  ngOnInit() {
    this.updateFormHeaderText(this.currentAction);
  }

  ngOnChanges(changes: SimpleChange){
    if(
      changes['currentAction'] &&
      !_.isEqual(
        changes['currentAction']['currentValue'],
        changes['currentAction']['previousValue']
      )
    ){
      this.updateFormHeaderText(changes['currentAction']['currentValue']);
    }
  }

  mergeIntegrationFunction = (data) => {
    this.isSubmitBtn = data.isdateValid;
    this.integratePanel.emit(data)
  }

  closeModalFunction = () => {
    this.closeModal.emit();
  }

  submitFormFunction = () => {
    this.dynamicSubmitAction.emit();
  }

  updateFormHeaderText = (action) => {
    if(action){
      this.formHeaderText = panelFormHeaderMap[action] && panelFormHeaderMap[action]['headerText'];
    }
  }

  isSubmitButton(){
    return !this.isSubmitBtn ? true : this.isSubmitButtonDisabled;
  }


}
