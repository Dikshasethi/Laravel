import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckInOutClientPanelModalComponent } from './check-in-out-client-panel-modal.component';

describe('CheckInOutClientPanelModalComponent', () => {
  let component: CheckInOutClientPanelModalComponent;
  let fixture: ComponentFixture<CheckInOutClientPanelModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckInOutClientPanelModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckInOutClientPanelModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
