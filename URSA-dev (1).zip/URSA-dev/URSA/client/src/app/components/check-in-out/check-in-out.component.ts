import { Component, OnInit, Input, Output, EventEmitter, SimpleChange } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import * as moment from 'moment';
import * as _ from 'lodash';
import * as $ from 'jquery';
import { 
  SetCheckInOutReducer, SetCheckoutDateValidations, 
  GetCheckoutDateValidations, CheckoutAssets, 
  SetCheckoutResults, CheckinAssets, 
  SetCheckinResults, CancelCheckout, CancelHardReservations, EditCheckout, SetSorting 
} from '../../actions/checkInOut.action';
import clientPanelStructure from '../../utils/checkInOutClientDetails/panelStructure';
import actionButtonList from '../../utils/checkInOut/actionButtonsList';
import editCheckoutBuilderList from '../../utils/editCheckoutModal/formBuilderList';
import localDate from '../../utils/date/localDate';
import {setEmoMode, resetEmoMode } from '../../actions/emo.actions';
import {SetReceivingMode,ResetReceivingMode } from '../../actions/receiving.actons';
import { Router} from '@angular/router';
import { Subscription } from 'rxjs';
import { EmodetailsModel } from '../../utils/emo/emoModel';
import { ReceivingDetailsModel } from '../../utils/receiving/receivingModel';
import { SelectedAssetsdetailsModel } from '../../utils/serviceRequest/SelectedAssetsDetailsModel'; 
import reformatDate from '../../utils/date/reformatDate';
import {
  checkoutPermission, checkinPermission, hardReservePermission,editHardReservePermissions,
  createEMOPermission,createReceivingPermission, cancelHardReservePermission, cancelCheckoutPermission
} from '../../utils/config/config';
import { GetEditHardReserve } from '../../actions/checkInOut.action';
import { SetAssetDataInServiceRequest } from '../../actions/serviceRequest.actions';


@Component({
  selector: 'app-check-in-out',
  templateUrl: './check-in-out.component.html',
  styleUrls: ['./check-in-out.component.css']
})


export class CheckInOutComponent implements OnInit {
  
  constructor(
    private store: Store<AppState>,
    private router: Router
  ) { }
  @Input() showPersonalization:boolean=true
  @Input() tableBuilderList: any;
  @Input() componentType : any;
  @Input() componentTypePrefix : any='';
  @Input() tableData: any;
  @Input() sortField: any;
  @Input() dateFields: any;
  @Input() height: any;
  @Input() scrollable: boolean;
  @Output() refreshData = new EventEmitter<any>();
  @Output() scrollFunction = new EventEmitter<any>();
  @Output() filterFunction = new EventEmitter<any>();
  @Output() sortingFunction = new EventEmitter<any>();
  @Output() triggerAlertMessage = new EventEmitter<any>();
  @Input() enableRefreshButton: any;
  parsedTableBuilder=[];
  filteredTableData = [];
  parsedTableData=[];
  filters={};
  sort:{};
  editCheckoutModalDisplay = false;
  displayClientPanelModal = false;
  functionMap = {}
  reducerObject = {};
  checkInOutReducerSubscription;
  userDetailSubscription;
  splitView = false;
  panelStructureList=[];
  panelStructureArrayList=[];
  clientPanel = {};
  dateRangeResults = [];
  projectStatusMap = {};
  disableHeaderCheckbox = false;
  tableBodyHeight='';
  actionType=''
  actionButtonElements=[];
  submitResultsMap = {};
  recheckoutModalProperties = {
    display : 'none',
    selectedAssets : [],
    custodian : {
      name : '',
      code : ''
    }
  }
  permissions = [];
  editCheckoutFormBuilderList = editCheckoutBuilderList.slice();
  failListCount = 0;
  successListCount = 0;
  transactionSize = 0;
  textDisplayLengthMap = {};
  tableMaxLength = 30;
  currentAction = '';
  cancelHrModalDisplay='none';
  transactionSystemError=false;
  selectedRecordsCache=[];
  clickMode = false;
  actionMode = false;
  refreshMode = false;
  detectChange = true;
  emoSubscription: Subscription;
  receivingSubscription : Subscription;
  emoMode: boolean;
  emoPath:string;
  addedEmo : any;
  receivingMode : boolean;
  receivingPath :string;
  addedReceivingData :any;
  previousUrl :string;
  emoorreceivingMode : string;
  sortObj :any = {};
  checkoutActionDisabled: boolean;
  checkinActionDisabled: boolean;
  sortingIcon :any={};
  selectedAssetsCount : number = 0;
  editHardReserveModalDisplay = false;
  tableColumnPersonalizationModalDisplay: boolean = false;
  PersonalizationSubscription;
  addedPersonalizationTableColumnLoading: boolean = false;
  updatePersonalizationTableColumnDataLoading: boolean = false;
  personalizationTableColumnLoading: boolean = false;
  personalizationTableColumnData=[];
  addActionInArray=[];
  originModule = {
    checkout: 'hard_reserve_table',
    checkin: 'checkin_table',
    checkedin: 'checkedin_table'
  }
  @Input() checkoutid;
  ngOnInit() {
    this.previousUrl = this.router.url;
    this.getBodyHeight();
    this.initUiBuilder(this.tableBuilderList, 'parsedTableBuilder');
    this.initUiBuilder(clientPanelStructure.slice(), 'panelStructureList');
    this.initUiBuilder(actionButtonList.slice(), 'actionButtonElements');
    this.initTableData(this.tableData);

    this.emoSubscription = this.store.pipe(select(state => state.Emo.addedEmo))
      .subscribe(data => {
        if (data) {
          const {
            emoPath,
            emoMode,
            addedEmo
          } = data;
          this.emoMode = emoMode;
          this.emoPath = emoPath;
          this.addedEmo = addedEmo;
          if (emoMode) {
            this.emoorreceivingMode = 'emoMode';
            this.initUiBuilder(actionButtonList.slice(), 'actionButtonElements',this.emoMode);
          }        
        }
      });

      this.receivingSubscription = this.store.pipe(select(state => state.Receiving.addedReceivingData))
      .subscribe(data => {
        if (data) {
          const {
            receivingPath,
            receivingMode,
            addedReceivingData
          } = data;
          this.receivingMode = receivingMode;
          this.receivingPath = receivingPath;
          this.addedReceivingData = addedReceivingData;
          if (receivingMode) {
            this.emoorreceivingMode = 'receivingMode';
            this.initUiBuilder(actionButtonList.slice(), 'actionButtonElements',this.receivingMode);
          }
        }
      });
    this.checkInOutReducerSubscription = this.store.pipe(select(state => state.CheckInOut))
    .subscribe(data => {
      this.checkoutActionDisabled = data.checkout.isLoading;
      this.checkinActionDisabled = data.checkin.isLoading;
      this.sortObj = data['sort'][this.componentType];
      this.reducerObject = JSON.parse(JSON.stringify(data[this.componentType])) || {};
      this.clientPanel = this.reducerObject['clientPanel'];
      this.projectStatusMap = data['projectStatusMap'];
      this.transactionSystemError = this.reducerObject['hasError'] ? true : false;
      if(
        data['dateValidationResults'].length > 0 && 
        !_.isEqual(data['dateValidationResults'], this.dateRangeResults)
      ){
        this.dateRangeResults = data['dateValidationResults'];
        this.mapAvailabilityCheck(data['dateValidationResults']);
      }
      this.parseSubmitResults(this.reducerObject['submitResults']);
    });

    
    this.PersonalizationSubscription = this.store.pipe(select(state => state.TableColumnPersonalization))
    .subscribe(personalizationData => {
      const {
        personalizationTableColumnData:  {  personalizationTableColumnData,personalizationTableColumnLoading },
        addedPersonalizationTableColumnData:{ addedPersonalizationTableColumnLoading },
        updatePersonalizationTableColumnData:{  updatePersonalizationTableColumnDataLoading} ,
        deletedPersonalizationTableColumnData: {  deletedPersonalizationTableColumnLoading  }

      }  = personalizationData
        this.personalizationTableColumnLoading = personalizationTableColumnLoading;
        this.addedPersonalizationTableColumnLoading = addedPersonalizationTableColumnLoading;
        this.updatePersonalizationTableColumnDataLoading=updatePersonalizationTableColumnDataLoading;

      if(personalizationTableColumnData && !personalizationTableColumnLoading){
          this.personalizationTableColumnData = personalizationTableColumnData;
       }
       
      if(!_.isEmpty(this.personalizationTableColumnData) && !personalizationTableColumnLoading &&  !addedPersonalizationTableColumnLoading && !updatePersonalizationTableColumnDataLoading && !deletedPersonalizationTableColumnLoading && this.showPersonalization) {
      
        for(let i = 0; i < this.personalizationTableColumnData.length; i++) {
          let personalizationType=this.componentType+this.componentTypePrefix+'TableColumn';
         
          if((this.personalizationTableColumnData[i]['personalizationType']) && (this.personalizationTableColumnData[i]['personalizationType']==personalizationType)) {
              let personlizationArr=this.personalizationTableColumnData[i];

              if((personlizationArr['data']) && !_.isEmpty(personlizationArr['data']) && (personlizationArr['data']['visibleColumn'])){
                let newTableColumnOrderData=this.getFilterData(personlizationArr['data']['visibleColumn']);
                this.setDefaultTableColumnOrder(newTableColumnOrderData);   
                break;  
              }

          }
        } 
      }
    })

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(user => {
      const {details={}} = user;
      this.recheckoutModalProperties['custodian']['name'] = details['first_name'] +  ' ' + details['last_name'];
      this.recheckoutModalProperties['custodian']['code'] = details['employee_id'];
      this.permissions = details['permission'] || [];

    });

    if(this.checkoutid){
      this.filters['peoplesoftcheckoutid'] = this.checkoutid;
    }
  }

  getFilterData(data) {
    let newDataArray=[],tmpArray=[];
    if(data){
      for(let j = 0; j < this.tableBuilderList.length; j++) {
        if(this.tableBuilderList[j]['dataKey'] && data.includes(this.tableBuilderList[j]['dataKey'])){  
          newDataArray.push(this.tableBuilderList[j]); 
        }
        if(this.tableBuilderList[j].headerType==="action"){ 
          tmpArray.push(this.tableBuilderList[j]);  
        }
        this.addActionInArray=tmpArray
      }

      const visibleArrsorter = (a, b) => {
        return data.indexOf(a.dataKey) - data.indexOf(b.dataKey);
      };
      newDataArray.sort(visibleArrsorter);
    }
    return newDataArray;
  }

  
  addActionsInPersonlizationTableColumnData(newTableColumnOrderData)
  {
    return this.addActionInArray.concat(newTableColumnOrderData);
  }

  setDefaultTableColumnOrder(newTableColumnOrderData)
  {
    let newtableBuilderList =this.addActionsInPersonlizationTableColumnData(newTableColumnOrderData);
    this.initUiBuilder(newtableBuilderList, 'parsedTableBuilder');
  }

  ngOnDestroy(){
    this.checkInOutReducerSubscription.unsubscribe();
    this.userDetailSubscription.unsubscribe();
    this.emoSubscription.unsubscribe();
    this.PersonalizationSubscription.unsubscribe();
    this.receivingSubscription.unsubscribe();
    this.store.dispatch(new SetCheckoutDateValidations([]));
    if(!_.isEmpty(this.submitResultsMap)){
      if(this.componentType === 'checkout'){
        this.store.dispatch(new SetCheckoutResults({}));
      }else if(this.componentType === 'checkin'){
        this.store.dispatch(new SetCheckinResults({}));
      }
      this.refreshDataFunction();
    }
  }

  ngOnChanges(changes: SimpleChange){
    if(
      changes['tableBuilderList'] && 
      !_.isEqual(
        changes['tableBuilderList']['currentValue'],
        changes['tableBuilderList']['previousValue']
      )
    ){
      this.initUiBuilder(changes['tableBuilderList']['currentValue'], 'parsedTableBuilder');
    }

    if(
      changes['tableData'] && 
      !_.isEqual(
        changes['tableData']['currentValue'],
        changes['tableData']['previousValue']
      )
    ){
      this.initTableData(changes['tableData']['currentValue']);
    }

    if(
      changes['height'] && 
      !_.isEqual(changes['height']['currentValue'], changes['height']['previousValue'])
    ){
      this.height = changes['height']['currentValue'];
      this.getBodyHeight();
    }

    if(
      changes['checkoutid'] && 
      !_.isEqual(changes['checkoutid']['currentValue'], changes['checkoutid']['previousValue'])
    ){
      if(this.checkoutid){
        this.filters['peoplesoftcheckoutid'] = this.checkoutid;
      }
    }
  }

  showText = (text='', dataKey, row) => {
    try{
      if(
        text &&
        text.toString().length < this.tableMaxLength
      ){
        return text;
      }else{
        if(
          this.textDisplayLengthMap[dataKey] &&
          this.textDisplayLengthMap[dataKey][row] === 1
        ){
          return text;
        }else{
          return text ? `${text.toString().substring(0, this.tableMaxLength)}...` : ''
        }
      }
    }catch(e){
      console.log('showText catch block error', e);
      return text;
    }
  }

  showMoreOrLessText = (text='', dataKey, row) => {
    try{
      if(text.length > this.tableMaxLength){
        if(
          this.textDisplayLengthMap[dataKey] &&
          this.textDisplayLengthMap[dataKey][row] === 1
        ){
          return 'show less';
        }else{
          return 'show more';
        }
      }else{
        return '';
      }
    }catch(e){
      console.log('showMoreOrLessText catch block error', e);
      return '';
    }
  }

  showMoreOrLessTextToggle = (text) => {
    try{
      return text && text.toString().length > this.tableMaxLength;
    }catch(e){
      console.log('showMoreOrLessTextToggle catch block error', e);
      return false;
    }
  }

  toggleShowLessMoreFunction = (dataKey, row) => {
    try{
      if(
        this.textDisplayLengthMap[dataKey] &&
        this.textDisplayLengthMap[dataKey][row]
      ){
        this.textDisplayLengthMap[dataKey][row] = 0;
      }else{
        this.textDisplayLengthMap[dataKey] = {}
        this.textDisplayLengthMap[dataKey][row] = 1;
      }
    }catch(e){
      console.log('toggleShowLessMoreFunction catch block error', e);
    }
  }

  resetTransactionSummary = () => {
    this.transactionSize = 0;
    this.failListCount = 0;
    this.successListCount = 0;
  }

  setReducerObject = () => {
    this.store.dispatch(new SetCheckInOutReducer(
      {
        field : this.componentType,
        value : this.reducerObject
      }
    ));
  }

  refreshDataFunction = () => {
    this.clickMode = false;
    this.actionMode = false;
    this.refreshMode = true;
    this.store.dispatch(new SetCheckoutResults({}));
    this.store.dispatch(new SetCheckinResults({}));
    this.store.dispatch(new SetCheckoutDateValidations([]));
    this.submitResultsMap = {};
    this.unselectAllAndCache();
    this.selectedRecordsCache = [];
    this.refreshData.emit(this.filters);
    this.refreshMode = false;
  }

  initTableData = (tableData) => {
    let accumulator = [];
    let invalidAccumulator = [];
    let validCount = 0;
    for (let i = 0; i < tableData.length; i++){
      const row = tableData[i];
      const newRow = {};
      let isValid = false;
      if(this.componentType === 'checkout'){
        if(
          row['projectstatus'] === 'A' && 
          !row['checkedout']
        ){
          validCount++;
          isValid = true;
        }else{
          this.uncheck(row);
        }
      }else if(this.componentType === 'checkin'){
        if(!row['checkedin']){
          validCount++
          isValid = true;
        }else{
          this.uncheck(row);
        }
      }else if(this.componentType === 'checkedin'){
          validCount++
          isValid = true;
      }
      for (let k in row){
        let value = row[k];
        newRow[k.toLowerCase()] = this.dateFields.includes(k) && value ? 
        localDate(value, 'DD-MMM-YYYY') : 
        value;
      }
      if(this.sortField){
        newRow['sortDateMs'] = new Date(newRow[this.sortField]).getTime();
      }
      if(isValid){
        accumulator.push(newRow);
      }else{
        invalidAccumulator.push(newRow);
      }
    }
    let cleanArray = [...accumulator];
    this.disableHeaderCheckbox = validCount ? false : true;
    let cleanSort = this.sortField ? 
    _.orderBy(cleanArray, 'sortDateMs', 'desc') : 
    cleanArray;
    this.parsedTableData = [...cleanSort, ...invalidAccumulator];
    this.filteredTableData = [...cleanSort, ...invalidAccumulator];
    if(accumulator.length === 0){
      this.reducerObject['allRecordSelected'] = false;
      this.reducerObject['splitView'] = false;
    }
  }

  checkboxPermission = () => {
    if(this.componentType === 'checkout'){
      return this.permissions.includes(checkoutPermission) || this.permissions.includes(cancelHardReservePermission);
    }else if(this.componentType === 'checkin'){
      return this.permissions.includes(checkinPermission) || this.permissions.includes(cancelCheckoutPermission);
    }else if(this.componentType === 'checkedin'){
      return true
    }else{
      return false;
    }
  }

  getButtonPermissions = (button) => {
    if(['cancelCheckout'].includes(button['type'])){
      return this.permissions.includes(checkoutPermission) || this.permissions.includes(cancelCheckoutPermission);
    }else if(['checkout'].includes(button['type'])){
      return this.permissions.includes(checkoutPermission);
    }else if(button['type'] === 'checkin'){
      return this.permissions.includes(checkinPermission);
    }else if(['reCheckout', 'editCheckout'].includes(button['type'])){
      return this.permissions.includes(checkinPermission) && 
      this.permissions.includes(checkoutPermission)
    }else if(button['type'] === 'cancelHardReserve'){
      return this.permissions.includes(hardReservePermission) || this.permissions.includes(cancelHardReservePermission);
    } else if (button['type'] === 'emo') {
      return this.permissions.includes(createEMOPermission);
    } else if(button['type'] === 'receiving'){
      return this.permissions.includes(createReceivingPermission);
    } else if(button['type'] === 'editHardReserve'){
      return this.permissions.includes(editHardReservePermissions);
    }else if(button['type'] === 'createServiceRequest'){
      return true;
    }
  }
  initUiBuilder = (tableBuilderList, variableName,emoMode = false) => {
    let array = [];
    for(let i = 0; i < tableBuilderList.length; i++){
      let column = tableBuilderList[i];
      let {useIn=[]} = column;
      if(emoMode){
        if (useIn.includes(this.componentType) && useIn.includes(this.emoorreceivingMode)) {
          array.push(column);
        }
      }else{
        if (useIn.includes(this.componentType)) {
          array.push(column);
        }
      }
    }
    this[variableName] = array;
  }

  modalDisplayFunction = () => {
    if(this.addedPersonalizationTableColumnLoading || this.updatePersonalizationTableColumnDataLoading){
      return 'block';
    }
    if (
      this.reducerObject['isLoading'] && 
      !this.scrollable 
    ) {
      return 'block';
    } else {
      return 'none';
    }
  }

  onLoaderModalStatusChange = (status) => {}

  checkFilter(filter){
    for(let key in filter){
       if(filter[key]){
         return true;
       }
  }
  return false;
  }
  updateFilter(map: string, text) {
    this.filters[map] = text.target.value;
    if(!this.checkFilter(this.filters)){
      this.detectChange = true;
    }else{
      this.detectChange = false;
    }
    this.executeFilter();
    this.unselectAllAndCache();
  }

  executeFilter = () => {
    let accumulator = [];
    if(
      this.scrollable && !this.clickMode &&
      !this.actionMode && !this.refreshMode
    ){
      this.filterFunction.emit(this.filters);
    }else{
      for (let i = 0; i < this.parsedTableData.length; i++){
        let dataObj = this.parsedTableData[i];
        let counts = 0, match = 0, filterValueCount=0;
        for (let k in this.filters){
          let value = this.filters[k];
          if(typeof value === 'string'){
            counts++;
            if(value){
              filterValueCount++;
            }
            if(
              dataObj[k] &&
              dataObj[k].toLowerCase().includes(value.toLowerCase())
            ){
              match++;
            }
          }
        }
        if(filterValueCount){
          if(match === counts){
            accumulator.push(dataObj);
          }
        }else{
          accumulator.push(dataObj);
        }
      }
      this.filteredTableData = accumulator;
    }
  }

  parseSubmitResults = (submitResults: any = {}) => {
    this.resetTransactionSummary();
    if(submitResults['successList'] && !this.transactionSystemError){
      this.mapToSubmitResults(submitResults['successList'], true);
      this.successListCount = submitResults['successList'].length;
    }
    if(submitResults['failList'] && !this.transactionSystemError){
      this.mapToSubmitResults(submitResults['failList'], false);
      this.failListCount = submitResults['failList'].length;
    }
    if(this.transactionSystemError){
      let adjustedList=[];
      for (let i = 0; i < this.selectedRecordsCache.length; i++){
        let record = this.selectedRecordsCache[i];
        adjustedList.push({
          ...record,
          message : 'A catch block error occured while consuming an API. Transaction failed.'
        })
      }
      this.mapToSubmitResults(adjustedList, false);
      this.failListCount = adjustedList.length;
    }
    this.transactionSize = this.successListCount + this.failListCount;
    if(!_.isEmpty(this.submitResultsMap)){
      this.mapMessageToRow();
    }
  }

  mapToSubmitResults = (
    list:any = [], success: boolean = false
  ) => {
    for (let i = 0; i < list.length; i++){
      let record = list[i];
      this.submitResultsMap[record['_id']] = {};
      this.submitResultsMap[record['_id']]['success'] = success;
      this.submitResultsMap[record['_id']]['message'] = success ? 'Successful' : (record['failMessage'] || record['message']);
    }
  }

  mapMessageToRow = () => {
    let newArray = [], validCount = 0;
    for (let i = 0; i < this.parsedTableData.length; i++){
      let record: any = this.parsedTableData[i];
      let {_id} = record;
      let newRecord;
      if(this.submitResultsMap[_id]){
        newRecord = {
          ...record,
          submitmessage : this.submitResultsMap[_id]['message']
        }
        if(
          this.submitResultsMap[_id]['message'] === 'Successful'
        ){
          if(this.componentType === 'checkout'){
            if(this.actionType === 'cancelHardReserve'){
              newRecord['checkedout'] = true;
            }else if(this.actionType === 'checkout'){
              newRecord['checkedout'] = true;
            }           
          }else if(this.componentType === 'checkin'){
            if(this.actionType === 'cancelCheckout'){
              newRecord['checkedin'] = true;
            }else if(this.actionType === 'checkin'){
              newRecord['checkedin'] = true;
            }
          }
        }
        newArray.push(newRecord)
      }else{
        newRecord = {...record};
        newArray.push(newRecord);
      }

      if(this.componentType === 'checkout'){
        if(
          newRecord['projectstatus'] === 'A' && 
          !newRecord['checkedout']
        ){
          validCount++;
        }
      }else if(this.componentType === 'checkin'){
        if(!newRecord['checkedin']){
          validCount++
        }
      }
    }
    this.disableHeaderCheckbox = validCount ? false : true;
    if(!validCount){
      this.reducerObject['allRecordSelected'] = false;
    }
    this.parsedTableData = newArray;
    this.executeFilter();
  }

  unselectAll = () => {
    let accumulator={};
    for(let k in this.reducerObject['rows']){
      accumulator[k] = {
        ...this.reducerObject[k],
        selected : false
      }
    }
    this.reducerObject = {
      ...this.reducerObject,
      rows : accumulator
    };
  }

  unselectAllAndCache = () => {
    this.unselectAll();
    this.reducerObject['allRecordSelected'] = false;
    this.setReducerObject();
    this.resetTransactionSummary();
  }

  selectRecord = (data) => {
    const {_id} = data;
    this.clickMode = true;
    if(
      (this.componentType === 'checkout' && !data['checkedout']) ||
      (this.componentType === 'checkin' && !data['checkedin']) ||
      (this.componentType === 'checkedin')
    ){
      if(!this.reducerObject['rows'][_id]){
        this.reducerObject['rows'][_id] = {}
      }
      this.reducerObject['rows'][_id]['selected'] = this.reducerObject['rows'][_id]['selected'] ?
      false : true;
    }
    this.resetTransactionSummary()
    this.setReducerObject();
    this.calculateSelectedAssets();
  }

  calculateSelectedAssets = () => {
    let count = 0;
    let allRows = this.reducerObject["rows"];
    Object.keys(allRows).forEach(record => {
      if (allRows[record].selected === true) {
        count++;
      }
    })
    this.selectedAssetsCount = count;
  }

  selectAllRecords = () => {
    this.clickMode = true;
    this.unselectAll()
    this.reducerObject['allRecordSelected'] = !this.reducerObject['allRecordSelected'];
    for (let i = 0; i < this.filteredTableData.length; i++){
      const data = this.filteredTableData[i];
      const {_id=''} = data;
      if(
        (
          this.componentType === 'checkout' && 
          !data['checkedout'] && 
          data['projectstatus'] === 'A'
        ) ||
        (
          this.componentType === 'checkin' && 
          !data['checkedin']
        ) ||
        (
          this.componentType === 'checkedin'
        )
      ){
        if(!this.reducerObject['rows'][_id]){
          this.reducerObject['rows'][_id] = {}
        }
        this.reducerObject['rows'][_id]['selected'] = this.reducerObject['allRecordSelected'] ? 
        true : false;
      }
    }
    this.resetTransactionSummary();
    this.setReducerObject();
    this.setSplitView();
  }

  uncheck = (record) => {
    if(
      this.reducerObject['rows'] && 
      this.reducerObject['rows'][record['_id']]
    ){
      this.reducerObject['rows'][record['_id']]['selected'] = false;
      this.setReducerObject();
    }
  }

  getSelectedRecords = () => {
    let selectedRecords = []
    let rows = this.reducerObject['rows'];
    for (let k in rows){
      let rowObj = rows[k];
      let {
        selected=false
      } = rowObj;
      if(selected){
        let assetRecord = this.getAssetRecord(k, 'parsedTableData');
        if(!_.isEmpty(assetRecord)){
          selectedRecords.push(assetRecord)
        }
      }
    }
    return selectedRecords;
  }

  editTableData = (data: any={}) => {
    let idList = [], rows = this.reducerObject['rows'];
    for (let k in rows){
      let rowObj = rows[k];
      let {
        selected=false
      } = rowObj;
      if(selected){
        idList.push(k);
      }
    }
    let updatedTableData = [];
    for (let i = 0; i < this.tableData.length; i++){
      let row = this.tableData[i];
      let {
        _id='', checkoutcustodianid='',
        checkoutcustodianname='', destinationarea='',
        destinationareadescription='', destinationlocation='',
        destinationlocationdescription='', expectedcheckindate=''
      } = row;
      if(idList.includes(_id)){
        updatedTableData.push({
          ...row,
          checkoutcustodianid : data['custodian'] ? data['custodian'] : 
          checkoutcustodianid,
          checkoutcustodianname : data['custodianname'] ? data['custodianname'] :
          checkoutcustodianname,
          destinationarea : data['areacode'] ? data['areacode'] : destinationarea,
          destinationareadescription : data['areadescription'] ? data['areadescription'] : 
          destinationareadescription,
          destinationlocation : data['locationcode'] ? data['locationcode'] :
          destinationlocation,
          destinationlocationdescription : data['locationdescription'] ? data['locationdescription'] :
          destinationlocationdescription,
          expectedcheckindate : moment(data['checkindate']).isValid() ? 
          moment(data['checkindate']).format('YYYY-MM-DD') : 
          expectedcheckindate
        })
      }else{
        updatedTableData.push(row);
      }
    }
    this.tableData = updatedTableData;
    this.initTableData(this.tableData);
  }

  getAssetRecord = (id, arrayMap) => {
    let array = this[arrayMap];
    let record = array.filter(record => record._id === id)[0] || {};
    return record;
  }

  setSplitView = () => {
    let count = 0;
    for (let k in this.reducerObject['rows']){
      let value = this.reducerObject['rows'][k];
      if(value['selected']){
        count++;
        break;
      }
    }
    this.reducerObject['splitView'] = count ? true : false;
    this.setReducerObject();
  }

  prepareRecordsForDateValidation = (records: any = []) => {
    let preparedRecords = [];
    for (let i = 0; i < records.length; i++){
      let record = records[i];
      let newObj = {
        ...record,
        checkoutdate : this.clientPanel['startdate'] ? this.clientPanel['startdate'] : 
        reformatDate(record['checkoutdate'], 'YYYY-MM-DD'),
        expectedcheckindate : this.clientPanel['enddate'] ? this.clientPanel['enddate'] :
        reformatDate(record['expectedcheckindate'], 'YYYY-MM-DD')
      }
      preparedRecords.push(newObj);
    }
    return preparedRecords;
  }

  integratePanel = (panelData: any = {}) => {
    const {startdate='', enddate=''} = panelData;
    this.reducerObject['clientPanel'] = panelData;
    this.setReducerObject();
    if(
      (startdate && enddate) && 
      this.componentType === 'checkout'
    ){
      let selectedRecords = this.getSelectedRecords();
      let preparedRecords = this.prepareRecordsForDateValidation(selectedRecords);
      this.store.dispatch(new GetCheckoutDateValidations({assetList : preparedRecords}));
    }
  }

  mapAvailabilityCheck = (results: any = []) => {
    for (let i = 0; i < results.length; i++){
      let record = results[i];
      const {_id='', isAvailable=false} = record;
      this.reducerObject['rows'][_id]['isAvailable'] = isAvailable;
    }
    this.setReducerObject();
  }

  getRowClassAndTitle = (record: any = {}) => {
    const {
      _id='', checkedout=false, checkedin=false
    } = record;
    let rowReducerObj = this.reducerObject['rows'][_id] || {};
    let obj = {
      className : '',
      title : ''
    }
    let submitResultMap = this.submitResultsMap[_id];

    if(this.componentType === 'checkout'){
      if(
        rowReducerObj['selected'] && 
        rowReducerObj['isAvailable'] && 
        !submitResultMap
      ){
        obj['className'] += 'bg-white';
      }else if(
        rowReducerObj['selected'] && 
        (
          typeof rowReducerObj['isAvailable'] === 'boolean' && 
          !rowReducerObj['isAvailable']
        ) && 
        !submitResultMap
      ){
        obj['className'] += 'cursor rowIsUnavailable';
        obj['title'] = "Asset is unavailable for the selected date range."
      }else if(
        record['projectstatus'] !== 'A' ||
        checkedout && 
        !submitResultMap
      ){
        obj['className'] += 'bg-light cursor';
        obj['title'] = checkedout ? 'Asset is checked out.' : 
        'The project is not available for use.'
      }else if(
        submitResultMap
      ){
        obj['className'] += submitResultMap['success'] ? 'cursor rowSuccess' : 
        'cursor rowIsUnavailable';
        obj['title'] += submitResultMap['message'];
      }
    }else if(this.componentType === 'checkin'){
      if(checkedin && !submitResultMap){
        obj['className'] += 'bg-light cursor';
        obj['title'] = "Asset is checked in."
      }else if(submitResultMap){
        obj['className'] += submitResultMap['success'] ? 'cursor rowSuccess' : 
        'cursor rowIsUnavailable';
        obj['title'] += submitResultMap['message'];
      }
    }else{
      obj['className'] += 'bg-white';
    }

    return obj;
  }

  getRowTitle = (record) => {
    const {_id=''} = record;
    let rowReducerObj = this.reducerObject['rows'][_id] || {};
    if(
      rowReducerObj['selected'] && 
      (
        typeof rowReducerObj['isAvailable'] === 'boolean' && 
        !rowReducerObj['isAvailable']
      )
    ){
      return 'Unavailable for the date range';
    }else{
      return '';
    }
  }

  isCheckboxDisabled = (record) => {
    if (this.emoMode) {
      let selectedAssetID =this.addedEmo.map(val=>val.assetid);
      if (record['emoid'] || selectedAssetID.includes(record.assetid)){
        return true;
      } 
    }
    if(this.receivingMode){
      let selectedAssetID =this.addedReceivingData.map(val=>val.assetid);
      if (record['receivingid'] || selectedAssetID.includes(record.assetid)){
        return true;
      } 
    }
    if(this.componentType === 'checkout'){
      if(record['checkedout']){
        return true;
      }else{
        return false;
      }
    }else if(this.componentType === 'checkin'){
      if(record['checkedin']){
        return true;
      }else{
        return false;
      }
    }
  }

  getSectionHeight = () => {
    return `${this.height - 15}vh`;
  }

  getBodyHeight = () => {
    let tableHeight = $('#checkInOutTableWrapper').height();
    let checkInOutTableTheadHeight = $('#checkInOutTableThead').height();
    this.tableBodyHeight = `${tableHeight - checkInOutTableTheadHeight}px`
  }

  getTableWrapperHeight = () => {
    return `${0.75 * this.height}vh`;
  }

  buttonIsDisabled = (button: any = {}) => {
    let actionDisabled = this.isActionButtonDisabled(button);
    let hasPermissions = this.getButtonPermissions(button);
    if(actionDisabled || !hasPermissions || this.checkoutActionDisabled
      || this.checkinActionDisabled) {
      return true;
    }else{
      return false;
    }
  }

  projectStatusCheck = (records=[]) => {
    let pass = records.length ? true : false;
    for (let i = 0; i < records.length; i++){
      let record = records[i];
      let {
        projectstatus=''
      } = record;

      if(projectstatus !== 'A'){
        pass = false;
        break;
      }
    }

    return pass;
  }

  isActionButtonDisabled = (button: any = {}) => {
    switch(button['type']){
      case 'checkout':
        let selectedChRecords: any = this.getSelectedRecords();
        let passedProjectStatusCheck = this.projectStatusCheck(selectedChRecords)
        return passedProjectStatusCheck ? false : true;
      case 'checkin':
        let selectedChiRecords: any = this.getSelectedRecords();
        return selectedChiRecords.length > 0 ? false : true;
      case 'cancelCheckout':
        let selectedCciRecords: any = this.getSelectedRecords();
        return selectedCciRecords.length > 0 ? false : true;
      case 'reCheckout':
        let selectedRecords: any = this.getSelectedRecords();
        return selectedRecords.length > 0 ? false : true;
      case 'cancelHardReserve':
        let selectedHrRecords: any = this.getSelectedRecords();
        return selectedHrRecords.length > 0 ? false : true;
      case 'editCheckout':
        let editCheckoutRecords: any = this.getSelectedRecords();
        return editCheckoutRecords.length > 0 ? false : true;
      case 'emo':
        let emoRecords: any = this.getSelectedRecords();
        let emoidRecord = emoRecords.filter(val => val.emoid).length;
        if(emoidRecord > 0) {
          return true;
        }
        return emoRecords.length > 0 ? false : true;
      case 'receiving':
        let receivingRecords: any = this.getSelectedRecords();
        let receivingidRecord = receivingRecords.filter(val => val.receivingid).length;
        if (receivingidRecord > 0) {
          return true;
        }
        return receivingRecords.length > 0 ? false : true;
      case 'editHardReserve':
        let hardReserveRecords: any = this.getSelectedRecords();
        let projectStatusCheck = this.projectStatusCheck(hardReserveRecords)
        return projectStatusCheck ? false : true;
      case 'createServiceRequest':
        let selectedsrRecords: any = this.getSelectedRecords();
        return selectedsrRecords.length > 0 ? false : true;
      default:
        return true;
    }
  }

  readyToSubmit = () => {
    let selectedCount = 0;
    for (let k in this.reducerObject['rows']){
      let value = this.reducerObject['rows'][k];
      if(value['selected']){
        selectedCount++;
      }
    }
    if(selectedCount){
      let clientPanel = this.reducerObject['clientPanel'];
      let {
        locationcode='', locationdescription='',
        areacode='', areadescription='', custodian='', 
        custodianname=''
      } = clientPanel;
      if(['checkout', 'checkin'].includes(this.componentType)){
        if(
          locationcode && locationdescription && 
          areacode && areadescription && custodian &&
          custodianname
        ){
          return true;
        }else{
          return false;
        }
      }
    }else{
      return false;
    }
  }

  mapRecordsForCheckout = (records=[]) => {
    let clientPanel = this.reducerObject['clientPanel'];
    let mappedRecords = [];

    for (let i = 0; i < records.length; i++){
      let record = records[i];
      let newRecord = {
        ...record,
        destinationlocation : clientPanel['locationcode'],
        destinationlocationdescription : clientPanel['locationdescription'],
        destinationarea : clientPanel['areacode'],
        destinationareadescription : clientPanel['areadescription'],
        checkoutcustodianid : clientPanel['custodian'],
        checkoutcustodianname : clientPanel['custodianname'],
        customerreferencenumber : clientPanel['customerreferencenumber'],
        checkoutdate : moment(clientPanel['startdate']).isValid() ? 
        moment(clientPanel['startdate']).format('YYYY-MM-DD') 
        : 
        record['startdate'] ? 
        reformatDate(record['startdate'], 'YYYY-MM-DD')
        : 
        moment().format('YYYY-MM-DD'),
        expectedcheckindate : moment(clientPanel['enddate']).isValid() ? 
        moment(clientPanel['enddate']).format('YYYY-MM-DD') : record['enddate'] ? 
        reformatDate(record['enddate'], 'YYYY-MM-DD') : moment().format('YYYY-MM-DD'),
        checkouttime : '00:00:00',
        expectedcheckintime : '00:00:00'
      }
      mappedRecords.push(newRecord);
    }

    return mappedRecords;
  }

  mapRecordsForCheckin = (records=[]) => {
    let clientPanel = this.reducerObject['clientPanel'];
    let mappedRecords = [];

    for (let i = 0; i < records.length; i++){
      let record = records[i];
      let newRecord = {
        ...record,
        checkoutdate : record['checkoutdate'] ? 
        reformatDate(record['checkoutdate'], 'YYYY-MM-DD') : 
        record['checkoutdate'],
        checkinlocation : clientPanel['locationcode'],
        checkinlocationdescription : clientPanel['locationdescription'],
        checkinarea : clientPanel['areacode'],
        checkinareadescription : clientPanel['areadescription'],
        checkincustodianid : clientPanel['custodian'],
        checkincustodianname : clientPanel['custodianname'],
        actualcheckindate : moment(clientPanel['checkindate']).isValid() ? 
        moment(clientPanel['checkindate']).format('YYYY-MM-DD') : moment().format('YYYY-MM-DD'),
        actualcheckintime : '00:00:00',
        expectedcheckindate : record['expectedcheckindate'] ? 
        reformatDate(record['expectedcheckindate'], 'YYYY-MM-DD') : record['expectedcheckindate']
      }
      mappedRecords.push(newRecord);
    }

    return mappedRecords;
  }

  mapRecordsForHardReserve = (records=[]) => {
    let mappedRecords = [];
    for (let i = 0; i < records.length; i++){
      let record = records[i];
      let newRecord = {
        ...record,
        proposalNumber : record['proposalnumber'],
        assetId : record['assetid'],
        hrStartDate : reformatDate(record['startdate'], 'YYYY-MM-DD'),
        hrEndDate : reformatDate(record['enddate'], 'YYYY-MM-DD'),
        projectNumber : record['projectnumber'],
        pdid : record['pdid'],
        calloutid : record['calloutid'],
        businessUnit : record['businessunit']
      }
      mappedRecords.push(newRecord);
    }
    return mappedRecords;
  }

  mapRecordsForEditCheckout = (records=[], clientPanel:any = {}) => {
    let mappedRecords = [];
    for (let i = 0; i < records.length; i++){
      let record = records[i];
      let newRecord = {
        ...record,
        expectedcheckindate : record['expectedcheckindate'] ? 
        reformatDate(record['expectedcheckindate'], 'YYYY-MM-DD') : 
        record['expectedcheckindate'],
        checkoutdate : record['checkoutdate'] ? 
        reformatDate(record['checkoutdate'], 'YYYY-MM-DD') : 
        record['checkoutdate'],
        newcheckindate : moment(clientPanel['checkindate']).isValid() ? 
        moment(clientPanel['checkindate']).format('YYYY-MM-DD') : '',
        newdestinationarea : clientPanel['areacode'],
        newdestinationareadescription : clientPanel['areadescription'],
        newdestinationlocation : clientPanel['locationcode'],
        newdestinationlocationdescription : clientPanel['locationdescription'],
        newcheckoutcustodianid : clientPanel['custodian'],
        newcheckoutcustodianname : clientPanel['custodianname']
      }
      mappedRecords.push(newRecord);
    }
    return mappedRecords;
  }

  mapRecordsForEditHardReserve = (records = [], clientPanel: any = {}) => {
    let mappedRecords = [];
    for (let i = 0; i < records.length; i++) {
      let record = records[i];
      let newRecord = {
        ...record,
        startdate: moment(record.startdate).isValid() ?
          moment(record.startdate).format('YYYY-MM-DD') : '',
        enddate: moment(record.enddate).isValid() ?
          moment(record.enddate).format('YYYY-MM-DD') : '',
        newstartdate: moment(clientPanel['hardReserveStartDate']).isValid() ?
          moment(clientPanel['hardReserveStartDate']).format('YYYY-MM-DD') : '',
        newenddate: moment(clientPanel['hardReserveEndDate']).isValid() ?
          moment(clientPanel['hardReserveEndDate']).format('YYYY-MM-DD') : ''
      }
      mappedRecords.push(newRecord);
    }
    return mappedRecords;
  }

  reformatCheckoutRecords = (records) => {
    let list = [];
    for (let i = 0; i < records.length; i++){
      let record = records[i];
      let {
        checkoutdate='', expectedcheckindate=''
      } = record;
      list.push({
        ...record,
        checkoutdate : reformatDate(checkoutdate, 'YYYY-MM-DD'),
        expectedcheckindate : reformatDate(expectedcheckindate, 'YYYY-MM-DD')
      })
    }
    return list;
  }

  recheckoutFunction = () => {
    if(this.componentType === 'checkin'){
      let selectedRecords = this.getSelectedRecords();
      let recheckoutRecords = this.reformatCheckoutRecords(
        JSON.parse(JSON.stringify(selectedRecords))
      );
      this.recheckoutModalProperties = {
        ...this.recheckoutModalProperties,
        display : 'block',
        selectedAssets : JSON.parse(JSON.stringify(recheckoutRecords))
      }
    }
  }

  actionFunction = (type, mappingFunction) => {
    let selectedRecords = this.getSelectedRecords();
    let mappedRecords = mappingFunction(
      JSON.parse(JSON.stringify(selectedRecords))
    );
    if(
      type === 'checkin' && 
      this.componentType === 'checkin'
    ){
      this.actionType = type;
      this.store.dispatch(new CheckinAssets({assetList : mappedRecords}));
    }else if(
      type === 'checkout' && 
      this.componentType === 'checkout'
    ){
      this.actionType = type;
      this.store.dispatch(new CheckoutAssets({assetList : mappedRecords}));
    }else if(
      type === 'cancelCheckout' &&
      this.componentType === 'checkin'
    ){
      this.actionType = type;
      this.store.dispatch(new CancelCheckout({assetList : mappedRecords}));
    }else if(
      type === 'cancelHardReserve' &&
      this.componentType === 'checkout'
    ){
      this.actionType = type;
      this.store.dispatch(new CancelHardReservations({assetList : mappedRecords}));
    }
    this.resetAfterSubmit();
  }

  editCheckoutFunction = (data: any={}) => {
    this.actionType = 'editCheckout';
    let selectedRecords = this.getSelectedRecords();
    let mappedRecords = this.mapRecordsForEditCheckout(selectedRecords, data);
    this.store.dispatch(new EditCheckout({assetList : mappedRecords}));
    this.editTableData(data);
    this.resetAfterSubmit();
  }

  edithardReserveSubmitFunction(data: any = {}) {
    let selectedRecords = this.getSelectedRecords();
    let mappedRecords = this.mapRecordsForEditHardReserve(selectedRecords, data);
    this.store.dispatch(new GetEditHardReserve({ assetList: mappedRecords }));
    this.resetAfterSubmit();
  }

  resetAfterSubmit = () => {
    this.selectedRecordsCache = this.getSelectedRecords();
    this.resetClientPanel();
    this.reducerObject['rows'] = {};
    this.reducerObject['allRecordSelected'] = false;
    this.reducerObject['splitView'] = false;
    this.setReducerObject();
  }

  resetClientPanel = () => {
    this.reducerObject['clientPanel'] = {};
    this.setReducerObject();
  }

  triggerEditCheckout = () => {
    this.editCheckoutModalDisplay = true;
  }
  closeEditCheckoutModal = () => {
    this.editCheckoutModalDisplay = false;
  }

  openClientPanelModal = (action) => {
    this.panelStructureArrayList = [...this.panelStructureList];
  if(action === 'cancelCheckout'){
    for (let i=0; i< this.panelStructureArrayList.length; i++){
      if(
          this.panelStructureArrayList[i].label === "Check In Date" || 
          this.panelStructureArrayList[i].label === "Custodian"
        ){
        this.panelStructureArrayList.splice(i, 1)
        i--;
      }
    }
  }

    this.displayClientPanelModal = true;
  }

  closeClientPanelModal = () => {
    this.displayClientPanelModal = false;
    this.currentAction = '';
    this.resetClientPanel();
  }

  dynamicSubmitAction = () => {
    if(this.currentAction === 'checkout'){
      this.actionFunction(this.currentAction, this.mapRecordsForCheckout);
    }else if(this.currentAction === 'checkin'){
      this.actionFunction(this.currentAction, this.mapRecordsForCheckin);
    }else if(this.currentAction === 'cancelCheckout'){
      this.actionFunction('cancelCheckout', this.mapRecordsForCheckin);
    }
    this.closeClientPanelModal();
    this.selectedAssetsCount = 0;
  }

  openCancelHrModal = () => {
    this.cancelHrModalDisplay = 'block';
  }

  closeCancelHrModal = () => {
    this.cancelHrModalDisplay = 'none';
  }

  confirmCancelHardReservations = () => {
    this.actionFunction('cancelHardReserve', this.mapRecordsForHardReserve);
    this.closeCancelHrModal();
  }

  dynamicActionButton = (action) => {
    this.clickMode = false;
    this.actionMode = true;
    if(action === 'checkout'){
      this.openClientPanelModal(action);
    }else if(action === 'checkin'){
      this.openClientPanelModal(action);
    }else if(action === 'cancelCheckout'){
      this.openClientPanelModal(action);
    }else if(action === 'reCheckout'){
      this.recheckoutFunction();
    }else if(action === 'cancelHardReserve'){
      this.openCancelHrModal();
    }else if(action === 'editCheckout'){
      this.triggerEditCheckout();
    }else if(action === 'emo') {
      this.triggerEmo();
    }else if(action === 'receiving'){
      this.triggerReceiving();
    }else if(action === 'editHardReserve'){
      this.openEditHardReserveModal();
    }else if(action === 'createServiceRequest'){
      let selectedRecords = this.getSelectedRecords();
      if(this.validatedServicerequestrecords(selectedRecords)) {
        this.triggerServiceRequest(selectedRecords);
      }else{
        this.triggerErrorMessage();
      }
    }
    this.currentAction = action;
  }

  private triggerErrorMessage = () => {
    this.triggerAlertMessage.emit({message: 'Please select assets associated with single project number', state: 'error'})
  }

  openEditHardReserveModal(){
    this.editHardReserveModalDisplay = true;
  }

  closeEditHardReserveModal(){
    this.editHardReserveModalDisplay = false;
  }
  
  private triggerServiceRequest = (selectedRecords) => {
    let serviceRequestDetailsObj = this.getServiceRequestObject(selectedRecords);
    let obj = {
      selectedAssetsObject:  serviceRequestDetailsObj,
      originmodule: this.originModule[this.componentType],
      projectnumber: serviceRequestDetailsObj[0]['projectnumber'] || '',
      projectmanagername: serviceRequestDetailsObj[0]['projectmanagername'] || '',
      customername: ((this.componentType === 'checkout')? selectedRecords[0]['customername'] : selectedRecords[0]['projectcustomername']) || '',
    }
    this.store.dispatch(new SetAssetDataInServiceRequest(obj));
    this.router.navigate(['./servicerequest']);
  }

  private getServiceRequestObject(selectedRecords) {
    let serviceRequestDetailsRecord = [];
    for (let i = 0; i < selectedRecords.length; i++) {
      let record = selectedRecords[i];
      let obj: SelectedAssetsdetailsModel = new SelectedAssetsdetailsModel();
       obj = {
        ...obj,
        "assetid": record.assetid,
        "businessunit": record.businessunit,
        "enddate": (this.componentType === 'checkout')? record.enddate : record.projectenddate,
        "startdate": (this.componentType === 'checkout')? record.startdate : record.projectstartdate,
        "serialid":record.serialid,
        "tagnumber":record.tagnumber,
        "projectnumber":record.projectnumber,
        "assetdescription":record.assetdescription,
        "projectmanagername": record.projectmanagername,
      }
      serviceRequestDetailsRecord.push(obj);
    }
    return serviceRequestDetailsRecord;
  }

  private validatedServicerequestrecords = (selectedRecords) => {
    return selectedRecords.every( (element, index, array) => {
      if (index === 0) {
        return true;
      } else {
        return (element.projectnumber === array[index - 1].projectnumber);
      }
    })
  }

  triggerEmo() {
    let emoRecord = [];
    emoRecord = this.getEMoRecords();
    if(this.emoPath){
      this.router.navigate([this.emoPath]);
    } else {
      this.router.navigate(['./emodetails'])
    }
    if(!this.emoMode){
      this.store.dispatch(new resetEmoMode());
    }
    if(this.emoPath && this.emoPath !== '/emodetails'){
      emoRecord.map(emo=>{
        emo['newdetail'] = true;
        return emo;
      })
    }
    let emoObj = {
      emoRecord : emoRecord,
      isEmoDataMerged: true,
      emoMode: false,
      previousUrl:this.previousUrl,
    };
    this.store.dispatch(new setEmoMode(emoObj));
  }

  triggerReceiving() {
    let receivingRecord = [];
    receivingRecord = JSON.parse(JSON.stringify(this.getReceivingRecords()));
    if (this.receivingPath) {
      this.router.navigate([this.receivingPath]);
    }else {
      this.router.navigate(['./receiving'])
    }
    if (!this.receivingMode) {
      this.store.dispatch(new ResetReceivingMode());
    } else {
      receivingRecord = receivingRecord.map(receiving => {
        receiving['newdetail'] = true;
        return receiving;
      })
    }
    let receivingObj = {
      receivingRecord: receivingRecord,
      isReceivingDataMerged: true,
      receivingMode: false,
      previousUrl: this.previousUrl,
    };
    this.store.dispatch(new SetReceivingMode(receivingObj));
  }

  getEMoRecords() {
    let selectedRecords = this.getSelectedRecords();
    let emoRecord = [];
    for (let i = 0; i < selectedRecords.length; i++) {
      let record = selectedRecords[i];
      let obj: EmodetailsModel = new EmodetailsModel();
       obj = {
        ...obj,
        "quantity":1,
        "itemtype": "asset",
        "assetid": record.assetid,
        "businessunit": record.businessunit,
        "peoplesoftcheckoutid": record.peoplesoftcheckoutid,
        "serialid":record.serialid,
        "tagnumber":record.tagnumber,
        "projectnumber":record.projectnumber,
        "description":record.assetdescription
      }
      emoRecord.push(obj);
    }
    return emoRecord;
  }

  getReceivingRecords() {
    let selectedRecords = this.getSelectedRecords();
    let receivingRecord = [];
    for (let i = 0; i < selectedRecords.length; i++) {
      let record = selectedRecords[i];
      let obj: ReceivingDetailsModel = new ReceivingDetailsModel();
      obj = {
        ...obj,
        "quantity": 1,
        "itemtype": "asset",
        "assetid": record.assetid,
        "businessunit": record.businessunit,
        "peoplesoftcheckoutid": record.peoplesoftcheckoutid,
        "serialid": record.serialid,
        "tagnumber": record.tagnumber,
        "destinationlocation": record.destinationlocation,
        "destinationarea": record.destinationarea,
        "checkoutdate": record['checkoutdate'] ?
          reformatDate(record['checkoutdate'], 'YYYY-MM-DD') :
          record['checkoutdate'],
        "expectedcheckindate": record['expectedcheckindate'] ?
          reformatDate(record['expectedcheckindate'], 'YYYY-MM-DD') : record['expectedcheckindate'],
        "proposalnumber": record.proposalnumber,
        "projectnumber": record.projectnumber,
        "pdid": record.pdid,
        "calloutid": record.calloutid,
        "pcbusinessunit":record.pcbusinessunit,
        "customerreferencenumber": record.customerreferencenumber,
        "crmnumber": record.crmnumber,
        "subtype2": record.subtype2,
        "description":record.assetdescription
      }
      receivingRecord.push(obj);
    }
    return receivingRecord;
  }
  
  onScroll = () => {
    if(this.scrollable){
      this.scrollFunction.emit(this.filters);
    }
  }

  setSorting=(key)=>{
    this.sort = {};
    this.sort['componentType'] = this.componentType;
    this.sort['dataKey'] = key;
    this.store.dispatch(new SetSorting(this.sort))
  }
  
  sortData = (dataKey) => {
    this.setSorting(dataKey);
    this.sortingFunction.emit();
    this.visualizeSortingIcon();
  }

  visualizeSortingIcon = () => {
    let sortData = JSON.parse(JSON.stringify(this.sortObj));
    let obj={}
    for(let key in sortData){
       if(sortData[key] === 1){
        obj[key] = "fa fa-arrow-up"
       }else if(sortData[key] === -1){
        obj[key] = "fa fa-arrow-down"
       }
    }
    this.sortingIcon = obj;  
  }

  openPersonalizationModal(){
    this.tableColumnPersonalizationModalDisplay = true;
  }
 
  closePersonalisationModal() {
    this.tableColumnPersonalizationModalDisplay = false;
  }
}
