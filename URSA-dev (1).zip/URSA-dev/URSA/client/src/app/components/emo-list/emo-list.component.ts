import { Component, OnInit, HostListener, ViewChild, Input } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { GetEmoList, SetEmoList, ResetEmoDetails, ClearEmoList } from '../../actions/emo.actions';
import * as moment from 'moment';
import * as _ from 'lodash';
import localDate from '../../utils/date/localDate';
import emoFilterMap from '../../utils/emo/emoFilterMap';
import filterObjectEmoDateFormat from '../../utils/checkInOut/filterObjectDateFormat';
import { PrintReportComponent } from '../print-report/print-report.component';
import { ReSetSorting, SetSorting } from '../../actions/checkInOut.action';
import { Subscription } from 'rxjs/Subscription';
import { ClearDownloadData, GetDownloadData } from '../../actions/download.action';
import downlaodcsv from '../../utils/downloadCSV/downlaodcsv';

@Component({
  selector: 'app-emo-list',
  templateUrl: './emo-list.component.html',
  styleUrls: ['./emo-list.component.css']
})
export class EmoListComponent implements OnInit {
  @Input() assetId;
  @Input() businessunit;
  @Input() emodetailsFlag;

  emoSubscription;
  emoList=[];
  refinedEmoList=[];
  refinedEmoListCopy=[];
  emoListIsLoading=false;
  emoListError=false;
  filters: any = {
    emoid : '',
    emodate : '',
    projectsalesno : '',
    customerponumber : '',
    shipmentmustarriveby : '',
    shipdate : '',
    destinationlocation : '',
    destinationarea : '',
    shipped : '',
    createdby : '',
    createddate : '',
    modifiedby : '',
    updateddate : ''
  };
  skip:number = 0;
  limit:number = 50;
  recordCount: number = 0;
    timeout = null;
  filterObj = {
  };
  sort :any = {"createdAt" : -1, "updatedAt" : -1};
  emoCount:number = 0;
  refinedList: any[];
  onScrollLoading:boolean = false;
  selectedData = [];
  printEmoModal = 'none';
  sortingIcon :any={};
  downloadSubscription:Subscription;
  checkInOutSortingSubscription : Subscription;
  donwloadDataListIsLoading:boolean;
  selectedAssetsCount : number = 0;
  emodetailsIsLoading: boolean = false;
  headingLabel = 'EMO List';
  
  constructor(
    private store: Store<AppState>
  ) { }

  public innerHeight: any;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;
  }
  @ViewChild (PrintReportComponent) printReportComponent : PrintReportComponent;
  ngOnInit() {
    this.innerHeight = window.innerHeight;
    if(this.emodetailsFlag){
      this.filters = {
          assetid: this.assetId,
          businessunit: this.businessunit
      }
    }
    this.headingLabel =  this.emodetailsFlag? 'EMO' : 'EMO List';
    this.fetchEmoData();
    this.emoSubscription = this.store.pipe(select(state => state.Emo))
    .subscribe(emoData => {
      const {
        emoList=[], 
        emoListError=false, 
        emoListIsLoading=false,
        onScrollLoading = false,
        emoCount = 0
      } = emoData;
      
      this.emoList = emoList;
      this.recordCount = this.emoList.length
      this.emoListError = emoListError;
      this.emoListIsLoading = emoListIsLoading;
      this.onScrollLoading = onScrollLoading;
      this.emoCount = emoCount;
      
      this.refinedEmoList = this.refineEmoList(this.emoList.slice());
      this.refinedEmoList = this.refinedEmoList.map(val => {
        val.isSelected = false;
        return val; 
      });
      this.refinedEmoListCopy = this.refinedEmoList;
      })
     
      this.checkInOutSortingSubscription = this.store.pipe(select(state => state.CheckInOut))
      .subscribe(data => {
        const {sort:{emo}}=data;
          let obj={};
          for(let key in emo){
            obj[key] = emo[key];
          }
          this.sort = obj;
      });

      this.downloadSubscription = this.store.pipe(select(state => state.Download))
      .subscribe(data => {
        const { downloadData = [],isLoading} = data;
        this.donwloadDataListIsLoading = isLoading ;
        if(!isLoading && downloadData.length){
          let mappedData = this.mappDownloadData(downloadData);
          downlaodcsv('emolist', mappedData);
        }
      });
  }

  ngOnDestroy(){
    this.emoSubscription.unsubscribe();
    this.checkInOutSortingSubscription.unsubscribe();
    this.downloadSubscription.unsubscribe();
    this.store.dispatch(new ClearEmoList());
    this.store.dispatch(new ReSetSorting());
  }

  mappDownloadData = (downloadData) => {
    let _downloadData = [...downloadData];
    return _downloadData.map(record => {
      const { emoid = '', emodate = '', projectsalesno = '', customerponumber = '', shipmentmustarriveby = '',
        shipdate = '', destinationlocation = '', destinationarea = '', shipped = '', createdby = '',
        createddate = '', modifiedby = '', updateddate = '' } = record;
      let obj = {
        emoid, emodate, projectsalesno, customerponumber, shipmentmustarriveby,
        shipdate, destinationlocation, destinationarea, shipped, createdby,
        createddate, modifiedby, updateddate
      };
      return obj;
    })
  }

  refineEmoList = (emoList=[]) => {
    let newArray = [];
    for (let i = 0; i < emoList.length; i++){
      let emo = emoList[i];
      let {
        emodate='', shipmentmustarriveby='', shipdate = '', createddate='', updateddate = '', shipped
      } = emo;
      newArray.push({
        ...emo,
        emodate : emodate ? localDate(emodate, 'DD-MMM-YYYY') : '',
        shipmentmustarriveby : shipmentmustarriveby ? localDate(shipmentmustarriveby, 'DD-MMM-YYYY') : '',
        shipdate : shipdate ? localDate(shipdate, 'DD-MMM-YYYY') : '',
        shipped : shipped ? 'Yes': 'No',
        createddate : createddate ? localDate(createddate, 'DD-MMM-YYYY') : '',
        updateddate : updateddate ? localDate(updateddate, 'DD-MMM-YYYY') : ''        
      });
    }

    return newArray;
  } 

  updateFilter(map: string, text) {
    this.filters[map] = text.target.value;
    this.resetSearchMeta();
    this.fetchEmoData();
  
  }

  resetSearchMeta = () => {
    this.skip = 0;
    this.store.dispatch(new ResetEmoDetails());
    this.filterObj = {
    }
}

fetchEmoData() {
  for (let k in this.filters){
    let value = this.filters[k];
    if(value){
        this.filterObj[emoFilterMap[k]] = value
    }
  }
  this.fetchEmoDetails();
}

  fetchEmoDetails = ()=>{
    let filterObjectWithNormalizedDate = filterObjectEmoDateFormat(this.filterObj);
    let obj = {
      "skip": this.skip,
      "limit": this.limit,
      "filter":  filterObjectWithNormalizedDate,
      "sort": this.sort
    }
    this.store.dispatch(new GetEmoList(obj));
    
  }

  errorDisplayFunction = () => {  
    if (this.emoListError) {
      return 'block';
    } else {
      return 'none';
    }
  }

  modalDisplayFunction = () => {
    if (this.donwloadDataListIsLoading) {
      return 'block';
    }
    if (this.emoListIsLoading && !this.onScrollLoading) {
      return 'block';
    }
    return 'none';
  }

  onScroll(){
    if(
      this.skip <=  this.recordCount
    ){
      this.skip = this.recordCount;
      this.fetchEmoData();
  }
  }

  selectRecords(data, i) {
    if (data.isSelected) {
      this.selectedData.push(data);
    }
    else {
      this.selectedData = this.selectedData.filter(function (obj) {
        return obj._id !== data._id;
      });
    }
    this.selectedAssetsCount = this.selectedData.length;
  }

  buttonIsDisabled = () => {
    if(
      this.selectedData.length < 1
    ){
      return true;
    }else{
      return false;
    }
  }

  print(){
    this.printReportComponent.printEmoReport();
  }

  setSorting=(key)=>{
    let sort = {};
    sort['componentType'] = "emo";
    sort['dataKey'] = key;
    this.store.dispatch(new SetSorting(sort))
  }
  
  sortData = (dataKey) => {
    this.setSorting(dataKey);
    this.skip = 0;
    this.store.dispatch(new ResetEmoDetails());
    this.fetchEmoDetails();
    this.visualizeSortingIcon();
  }

  visualizeSortingIcon = () => {
    let sortData = JSON.parse(JSON.stringify(this.sort));
    let obj={}
    for(let key in sortData){
       if(sortData[key] === 1){
        obj[key] = "fa fa-arrow-up"
       }else if(sortData[key] === -1){
        obj[key] = "fa fa-arrow-down"
       }
    }
    this.sortingIcon = obj;  
  }

  downloadcsv = () => {
    let filterObjectWithNormalizedDate = filterObjectEmoDateFormat(this.filterObj);
    let obj = {
      "filter":  filterObjectWithNormalizedDate,
      "sort": this.sort
    }
    this.store.dispatch(new ClearDownloadData());
    this.store.dispatch(new GetDownloadData({ urlType: 'emolist', payload: obj }))
  }
}
