import { Component, Input, EventEmitter, Output, SimpleChange } from '@angular/core';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../models/appState';

@Component({
    selector: 'app-permissions',
    templateUrl: './permissions.component.html',
    styleUrls: ['./permissions.component.css']
})

export class PermissionsComponent {

    @Input() permissions: any[] = [];
    @Output() editRecord: EventEmitter<any> = new EventEmitter();
    @Output() deleteRecord: EventEmitter<any> = new EventEmitter();

    roleDataSubScription: Subscription;
    roles: any[] = [];
    filterPermissionData: any[] = [];
    cancelDeleteModalDisplay: string = 'none';
    deletePermissionId: string;
    confirmationMessage: string;
    isConfirmBtn: boolean = true;
    filters: any = {};

    constructor(private store: Store<AppState>) { }

    ngOnInit() {
        this.roleDataSubScription = this.store.pipe(select(state => state.RoleMatrix))
            .subscribe(data => {
                if (data) {
                    const {
                        roleData: { roleResult }
                    } = data;
                    if (roleResult && !roleResult['hasError']) {
                        this.roles = roleResult;
                    }
                }
            })
    }

    ngOnChanges(changes: SimpleChange) {
        if (changes['permissions']) {
            this.filterPermissionData = JSON.parse(JSON.stringify(this.permissions));
        }
    }

    ngOnDestroy() {
        this.roleDataSubScription.unsubscribe();
    }

    editPermission(permissionid) {
        this.editRecord.emit(permissionid);
    }

    deletePermission(permissionname, permissionid) {
        let allPermission = this.roles.map(val => val.permissionidlist);
        allPermission = Array.from(new Set(allPermission.reduce((acc, val) => acc.concat(val), [])));
        if (allPermission.includes(permissionid)) {
            this.isConfirmBtn = false;
            this.confirmationMessage = `${permissionname} Permission is already assigned for Roles,please first remove the permission from Role`;
        } else {
            this.isConfirmBtn = true;
            this.confirmationMessage = 'Are you sure you want to Delete Permission ?';
            this.deletePermissionId = permissionid;
        }
        this.cancelDeleteModalDisplay = "block";
    }

    confirmDeletePermission() {
        this.deleteRecord.emit(this.deletePermissionId);
        this.cancelDeleteModalDisplay = "none";
        this.deletePermissionId = "";
    }

    closeDeleteModal() {
        this.cancelDeleteModalDisplay = "none";
        this.deletePermissionId = "";
    }

    updateFilter(event, map: string) {
        this.filters[map] = event.target.value;
        let accumulator = this.permissions.filter(record => {
            return Object.keys(this.filters).every((mapKey) => {
                return record[mapKey].toLowerCase().includes(this.filters[mapKey].toLowerCase());
            })
        })
        this.filterPermissionData = accumulator;
    }
}