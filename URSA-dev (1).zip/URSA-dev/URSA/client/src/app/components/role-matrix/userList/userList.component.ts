import { OnInit, Component, Input, SimpleChange, Output, EventEmitter } from "@angular/core";
import { ReSetUserList } from '../../../actions/roleMatrix.action';
import { Store, select } from "@ngrx/store";
import { AppState } from "../../../models/appState";
import { Subscription } from "rxjs";
import { environment } from '../../../../environments/environment';

const applicatonObj = {
    "appid": environment.appID,
    "appname": environment.appName,
}

@Component({
    selector: 'app-user-list',
    templateUrl: './userList.component.html',
    styleUrls: ['./userList.component.css']
})
export class UserListComponent implements OnInit {

    @Input() userList: any[] = [];
    @Output() editUserRecord: EventEmitter<any> = new EventEmitter();
    @Output() deleteRoleFromUserRecord: EventEmitter<any> = new EventEmitter();
    @Output() createRestriction: EventEmitter<any> = new EventEmitter();
    @Output() editRestrictionRecord: EventEmitter<any> = new EventEmitter();
    @Output() filterUserList : EventEmitter<any> = new EventEmitter();

    filters: any = {};
    filterUserRolesData: any[] = [];
    cancelDeleteModalDisplay: string;
    deleteRoleId: string;
    role_deleteObj: any;
    filterSubscription:Subscription;
    constructor(private store: Store<AppState>) { };

    ngOnInit() { 
        this.filterSubscription = this.store.pipe(select(state => state.RoleMatrix))
        .subscribe(data => {
            if (data) {
                const {
                    userListFilter
                } = data;
                this.filters = userListFilter;
            }
        })
    }

    ngOnChanges(changes: SimpleChange) {
        if (changes['userList']) {
            this.filterUserRolesData = JSON.parse(JSON.stringify(this.userList));
        }
    }

    updateFilter(event, map: string) {
        this.filters[map] = event.target.value;
        let accumulator = this.userList.filter(record => {
            let filter = this.filters;
            return Object.keys(this.filters).every((mapKey) => {
                if (mapKey === "permissions") {
                    let permission = record[mapKey].map(permission => permission.permissionname).join(',');
                    return permission.toLowerCase().includes(filter[mapKey].toLowerCase())
                } else if (mapKey === "roles") {
                    let role = record[mapKey].map(role => role.rolename).join(',');
                    return role.toLowerCase().includes(filter[mapKey].toLowerCase())
                } else {
                    return record[mapKey].toLowerCase().includes(filter[mapKey].toLowerCase());
                }
            })
        });
        this.filterUserRolesData = accumulator;
        this.store.dispatch(new ReSetUserList())
        this.filterUserList.emit({ name: map, value: event.target.value });
    }

    editUserRole(userRole: any) {
        this.editUserRecord.emit(userRole);
    }

    mappedFilterObj() {
        let filterQuery = {};
        for (let k in this.filters) {
            let value = this.filters[k];
            if (value) {
                filterQuery[k] = {
                    $regex: `.*${value}.*`,
                    $options: 'i'
                };
            }
        }
        return filterQuery;
    }

    deleteRoleFromUser(user, role) {
        const { userid, username, email } = user;
        let roleId_list = user.roleidlist.filter(roleid => roleid !== role['_id']);
        let roleobj = {
            filter: this.mappedFilterObj(),
            userRolePayload: {
                "appid": applicatonObj.appid,
                "userid": userid,
                "username": username,
                "email": email,
                "roleidlist": roleId_list
            }
        }
        this.role_deleteObj = roleobj;
        this.cancelDeleteModalDisplay = "block";
    }

    confirmDelete() {
        this.deleteRoleFromUserRecord.emit(this.role_deleteObj);
        this.resetDeleteModalData();
    }

    closeDeleteModal() {
        this.resetDeleteModalData();
    }

    private resetDeleteModalData() {
        this.cancelDeleteModalDisplay = "none";
        this.deleteRoleId = "";
    }

    addRestriction(user, permission) {
        const { username, userid } = user;
        const { _id, permissionname } = permission;
        this.createRestriction.emit({
            username: username,
            userid: userid,
            permissionid: _id,
            permissionname: permissionname
        })
    }

    updateRestriction(user, permission) {
        const {userid, username } = user;
        const { _id, permissionname } = permission;
        this.editRestrictionRecord.emit({
            username: username,
            userid:userid,
            permissionname: permissionname,
            permissionid: _id
        });
    }
}