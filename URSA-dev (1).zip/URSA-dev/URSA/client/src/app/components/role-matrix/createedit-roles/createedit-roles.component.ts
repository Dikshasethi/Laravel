import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../models/appState';
@Component({
    selector: 'app-createedit-role',
    templateUrl: './createedit-roles.component.html',
    styleUrls: ['./createedit-roles.component.css']
})
export class CreateEditRolesComponent implements OnInit {

    roleHeader: string;
    roleData: any = {};
    roleMode: string;
    people: any;
    selectedpermission = [];
    permissions: any[] = [];
    roleDataSubScription: Subscription;
    multiSelectautoCompleteData = {
        bindLabel: "permissionname",
        bindValue: '_id',
        selectedInput: []
    };
    @Input() createeditRolesModalDisplay: any;
    @Output() closeModal: EventEmitter<any> = new EventEmitter();
    @Output() submitForm: EventEmitter<any> = new EventEmitter();

    @Input()
    set modalProperties(val) {
        if (val) {
            const { roleHeader, roleData, roleMode } = val;
            this.roleHeader = roleHeader;
            this.roleData = roleData;
            this.roleMode = roleMode;
            this.multiSelectautoCompleteData = {
                bindLabel: "permissionname",
                bindValue: '_id',
                selectedInput: []
            };
        }
    }

    constructor(private store: Store<AppState>) { }

    ngOnInit() {
        this.roleDataSubScription = this.store.pipe(select(state => state.RoleMatrix))
            .subscribe(data => {
                const {
                    permissionData: { permissionResult },
                    roleDataById: { roleByIdResult },
                } = data;
                if (permissionResult && !permissionResult['hasError'] && permissionResult.length) {
                    this.permissions = permissionResult;
                }
                if (roleByIdResult && !roleByIdResult['hasError']) {
                    this.roleData = roleByIdResult;
                    this.selectedpermission = roleByIdResult.permissionidlist;
                    this.multiSelectautoCompleteData = {
                        bindLabel: "permissionname",
                        bindValue: '_id',
                        selectedInput: this.selectedpermission || []
                    };
                }
            })
    }

    ngOnDestroy() {
        this.roleDataSubScription.unsubscribe();
    }

    closeModalFunction = () => {
        this.resetRole();
        this.closeModal.emit();
    }

    resetRole() {
        this.roleData = {
            rolename: '',
            roledescription: '',
            permissionidlist: []
        };
    }

    submitFormFunction = () => {
        const obj = {
            roleMode: this.roleMode,
            roleData: {
                ...this.roleData,
                permissionidlist: this.selectedpermission

            }
        };
        this.submitForm.emit(obj);
        this.closeModalFunction();
    }

    isSubmitButtonDisabled = () => {
        return !(this.roleData.rolename && this.roleData.roledescription);
    }

    shareCheckedList(selectedValue) {
        this.selectedpermission = selectedValue;
    }
}