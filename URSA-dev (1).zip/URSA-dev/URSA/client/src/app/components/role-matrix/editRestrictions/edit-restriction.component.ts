import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../models/appState';
@Component({
    selector: 'app-edit-restriction',
    templateUrl: './edit-restriction.component.html',
    styleUrls: ['./edit-restriction.component.css']
})
export class EditRestrictionComponent implements OnInit {

    restrictionData: any[] = [];
    mappedRestrictionData: any[] = [];
    filtersRestrictionData: any[] = [];
    restrictionHeader: string;
    userName: string;
    permissionName: string;
    permissionId: string;
    filters: any = {};
    restrictionId: string;
    restricteduserid:string;
    cancelDeleteModalDisplay: string = "none";
    rolematrixDataSubScription: Subscription;
    @Input() editRestricionModalDisplay: boolean;
    @Output() closeModal: EventEmitter<any> = new EventEmitter();
    @Output() editRestrictionRecord: EventEmitter<any> = new EventEmitter();
    @Output() deleteRestrictionRecord: EventEmitter<any> = new EventEmitter();

    @Input()
    set modalProperties(val) {
        if (val) {
            const { restrictionHeader, userName,userid, permissionid, permissionName, restrictionData } = val;
            this.restrictionHeader = restrictionHeader;
            this.userName = userName;
            this.restricteduserid = userid;
            this.restrictionData = restrictionData;
            this.permissionName = permissionName;
            this.permissionId = permissionid;
            this.mapRestrictionRecord();
        }
    }
    constructor(private store: Store<AppState>) { }

    ngOnInit() {
        this.rolematrixDataSubScription = this.store.pipe(select(state => state.RoleMatrix))
            .subscribe(data => {
                if (data) {
                    const {
                        restrictionData: { restrictionResult }
                    } = data;
                    if (restrictionResult && !restrictionResult['hasError']) {
                        this.restrictionData = restrictionResult;
                        this.mapRestrictionRecord();
                    }
                }
            });
    }

    ngOnDestroy() {
        this.rolematrixDataSubScription.unsubscribe();
    }

    mapRestrictionRecord() {
        this.mappedRestrictionData = [];
        if (this.restrictionData.length) {
            for (let i = 0; i < this.restrictionData.length; i++) {
                let record = this.restrictionData[i];
                let obj = {
                    ...record,
                    restrictiondataValue: record.restrictiondata ? record.restrictiondata.join(',') : ''
                }
                this.mappedRestrictionData.push(obj);
            }
        }
        this.filtersRestrictionData = JSON.parse(JSON.stringify(this.mappedRestrictionData));
    }

    updateFilter(event, map: string) {
        this.filters[map] = event.target.value;
        let accumulator = this.mappedRestrictionData.filter(record => {
            let filter = this.filters;
            return Object.keys(this.filters).every((mapKey) => {
                if (mapKey === "restrictiondata") {
                    let restriction = record[mapKey].join(',');
                    return restriction.toLowerCase().includes(filter[mapKey].toLowerCase())
                } else {
                    return record[mapKey].toLowerCase().includes(filter[mapKey].toLowerCase());
                }
            })
        });
        this.filtersRestrictionData = accumulator;
    }

    closeModalFunction() {
        this.closeModal.emit();
    }

    editRestriction(restrictionid: string) {
        let restrictionRecord: any = this.restrictionData.filter(restriction => restriction["_id"] === restrictionid);
        restrictionRecord = restrictionRecord[0];
        const { _id, restrictionname, restrictiontype,
            restrictiondata, permissionid, restricteduserid } = restrictionRecord
        let obj = {
            restrictionid: _id,
            restrictedusername: this.userName,
            permissionname: this.permissionName,
            permissionid: permissionid,
            restrictionname: restrictionname,
            restrictiontype: restrictiontype,
            restrictiondata: restrictiondata,
            restricteduserid: restricteduserid
        }
        this.editRestrictionRecord.emit(obj);
    }

    deleteRestriction(restrictionId) {
        this.restrictionId = restrictionId;
        this.cancelDeleteModalDisplay = "block";
    }

    closeDeleteModal() {
        this.editRestricionModalDisplay = false;
    }

    confirmDeleteRestriction() {
        this.cancelDeleteModalDisplay = "none";
        this.deleteRestrictionRecord.emit({
            restictionid: this.restrictionId,
            permissionid: this.permissionId,
            restricteduserid: this.restricteduserid,
        })
    }

    closeRestrictionDeleteModal() {
        this.cancelDeleteModalDisplay = "none";
    }
}