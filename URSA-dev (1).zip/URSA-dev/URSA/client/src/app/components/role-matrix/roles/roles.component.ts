import { Component, Input, SimpleChange, Output, EventEmitter } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../models/appState';

const applicatonObj = {
    "appid": environment.appID,
    "appname": environment.appName,
}

@Component({
    selector: 'app-roles',
    templateUrl: './roles.component.html',
    styleUrls: ['./roles.component.css']
})
export class RolesComponent {

    @Input() roles: any[] = [];
    @Output() editRecord: EventEmitter<any> = new EventEmitter();
    @Output() deleteRecord: EventEmitter<any> = new EventEmitter();
    @Output() deletepermissionFromRecord: EventEmitter<any> = new EventEmitter();

    userRoleDataSubScription: Subscription;
    filterRolesData: any[] = [];
    userRoles: any[] = [];
    filters: any = {};
    cancelDeleteModalDisplay: string = 'none';
    deleteRoleId: string;
    permission_deleteObj: any;
    deleteModalState: string = '';
    confirmationMessage: string = '';
    isConfirmBtn: boolean = true;

    constructor(private store: Store<AppState>) { }

    ngOnInit() {
        this.userRoleDataSubScription = this.store.pipe(select(state => state.RoleMatrix))
            .subscribe(data => {
                if (data) {
                    const {
                        userList: { userListResult }
                    } = data;
                    if (userListResult && !userListResult['hasError']) {
                        this.userRoles = userListResult;
                    }
                }
            })

    }

    ngOnChanges(changes: SimpleChange) {
        if (changes['roles']) {
            this.filterRolesData = JSON.parse(JSON.stringify(this.roles));
        }
    }


    ngOnDestroy() {
        this.userRoleDataSubScription.unsubscribe();
    }

    updateFilter(event, map: string) {
        this.filters[map] = event.target.value;
        let accumulator = this.roles.filter(record => {
            let filter = this.filters;
            return Object.keys(this.filters).every((mapKey) => {
                if (mapKey === "permissionlist") {
                    let permission = record[mapKey].map(permission => permission.permissionname).join(',');
                    return permission.toLowerCase().includes(filter[mapKey].toLowerCase())
                } else {
                    return record[mapKey].toLowerCase().includes(filter[mapKey].toLowerCase());
                }
            })
        });
        this.filterRolesData = accumulator;
    }

    editRole(roleId: string) {
        this.editRecord.emit(roleId);
    }

    confirmDeleteRole() {
        if (this.deleteModalState === "deleteRole") {
            this.deleteRecord.emit(this.deleteRoleId);
        }
        if (this.deleteModalState === "deletePermission") {
            this.deletepermissionFromRecord.emit(this.permission_deleteObj);
        }
        this.resetDeleteModalData();
    }

    closeDeleteModal() {
        this.resetDeleteModalData();
    }

    private resetDeleteModalData() {
        this.cancelDeleteModalDisplay = "none";
        this.deleteRoleId = "";
        this.deleteModalState = "";
        this.confirmationMessage = ""
    }

    deleteRole(rolename: string, roleId: string) {
        let allRoles = this.userRoles.map(userRole => userRole.roleidlist);
        allRoles = Array.from(new Set(allRoles.reduce((acc, val) => acc.concat(val), [])));
        if (allRoles.includes(roleId)) {
            this.isConfirmBtn = false;
            this.confirmationMessage = `${rolename} Role is already assigned for users,please first remove the role from users`;
        } else {
            this.isConfirmBtn = true;
            this.deleteModalState = "deleteRole";
            this.confirmationMessage = "Are you sure you want to Delete Role ?";
            this.deleteRoleId = roleId;
        }
        this.cancelDeleteModalDisplay = "block";
    }

    deletepermission(role: any, permission: any) {
        let permissionId_list = role.permissionidlist.filter(permissionid => permissionid !== permission.permissionId);
        let roleobj = {
            "_id": role["_id"],
            "rolename": role.rolename,
            "roledescription": role.roledescription,
            "appid": applicatonObj.appid,
            "permissionidlist": permissionId_list
        }
        this.deleteModalState = "deletePermission";
        this.confirmationMessage = "Are you sure you want to Delete Permission ?";
        this.permission_deleteObj = roleobj;
        this.cancelDeleteModalDisplay = "block";
    }

}