import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../models/appState';
import { GetUserInfo, GetUserRolesValidation } from '../../../actions/roleMatrix.action';
import { environment } from '../../../../environments/environment';

@Component({
    selector: 'app-createedit-userrole',
    templateUrl: './createedit-userrole.component.html',
    styleUrls: ['./createedit-userrole.component.css']
})
export class CreateEditUserRoleComponent implements OnInit {
    userRoleheader: string;
    userRoleData: any;
    userRoleMode: string;
    custodian: string;
    roles: any[] = [];
    isUserRoleExist: boolean = false;
    selectedRoles: string[] = [];
    suggestionList: any[] = [];
    username_clone: string;
    isShowUserByName: boolean;
    roleDataSubScription: Subscription;
    autocompleteSubscription: Subscription;
    multiSelectautoCompleteData = {
        bindLabel: "rolename",
        bindValue: '_id',
        selectedInput: []
    };
    roleOptions: string = "assignroles";
    @Input() createeditUserRoleModalDisplay: boolean;
    @Output() closeModal: EventEmitter<any> = new EventEmitter();
    @Output() submitForm: EventEmitter<any> = new EventEmitter();

    @Input()
    set modalProperties(val) {
        if (val) {
            const { userRoleHeader, userRoleMode, userRoleData } = val;
            this.userRoleheader = userRoleHeader;
            this.userRoleData = userRoleData;
            this.selectedRoles = userRoleData.roleidlist;
            this.userRoleMode = userRoleMode;
            this.isShowUserByName = userRoleMode === 'Add' ? true : false;
            this.multiSelectautoCompleteData = {
                bindLabel: "rolename",
                bindValue: '_id',
                selectedInput: this.selectedRoles || []
            };
        }
    }
    constructor(private store: Store<AppState>) { }

    ngOnInit() {
        this.roleDataSubScription = this.store.pipe(select(state => state.RoleMatrix))
            .subscribe(data => {
                const {
                    roleData: { roleResult },
                    userInfo: { userInfoList },
                    userValidation,
                } = data;
                if (roleResult && !roleResult['hasError']) {
                    this.roles = roleResult;
                }
                this.isUserRoleExist = !userValidation;
                if (userInfoList && !userInfoList['hasError']) {
                    let suggestion = [];
                    for (let i = 0; i < userInfoList.length; i++) {
                        let record = userInfoList[i];
                        suggestion.push({
                            ...record,
                            username_email: `${record.username} (${record.email})`
                        })
                    }
                    this.suggestionList = suggestion;
                }
            });
    }

    ngOnDestroy() {
        this.roleDataSubScription.unsubscribe();
    }

    handleAutocompleteInputChange(text) {
        this.suggestionList = [];
        if (text != "" && text.length >= 2) {
            let obj = {
                "index": "employeesearch",
                "search_keyword": text,
                "field": "custodian"
            }
            this.store.dispatch(new GetUserInfo(obj));
        }
    }

    suggestionSelected(suggestion) {
        this.userRoleData = {
            ...this.userRoleData,
            ...suggestion
        };
        this.store.dispatch(new GetUserRolesValidation({
            appid: environment.appID,
            filter: {
                userid: suggestion.userid,
            }
        })
        )
    }

    suggestionSelected_cloneRoles(suggestion) {
        this.username_clone = suggestion.username;
        this.userRoleData['cloneFromUserId'] = suggestion.userid;
    }

    submitFormFunction() {
        let obj = this.userRoleData;
        if (this.roleOptions === "assignroles") {
            obj = {
                ...obj,
                roleidlist: this.selectedRoles
            };
        }
        this.submitForm.emit({ option: this.roleOptions, payload: obj });
        this.closeModalFunction();
    }

    closeModalFunction = () => {
        this.resetUserRole();
        this.closeModal.emit();
    }

    resetUserRole() {
        this.roleOptions = "assignroles";
        this.username_clone = '';
        this.userRoleData = {
            userid: '',
            username: '',
            email: '',
            roleidlist: []
        };
    }

    shareCheckedList(selectedValue) {
        this.selectedRoles = selectedValue;
    }

    disableSubmitBtn() {
        const { userid, cloneFromUserId } = this.userRoleData;
        const isRoleSelected = this.selectedRoles && this.selectedRoles.length ? true : false;
        if (this.isUserRoleExist) {
            return true;
        } else {
            if (userid) {
                if (this.roleOptions === "assignroles") {
                    return !isRoleSelected;
                } else {
                    return !cloneFromUserId;
                }
            } else {
                return true;
            }
        }
    }
}