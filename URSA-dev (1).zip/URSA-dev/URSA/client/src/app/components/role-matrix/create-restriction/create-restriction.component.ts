import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../models/appState';
import restricitonType from '../../../utils/roleMatrix/restrictionType';
import { GetRestrictionData, ReSetRestrictionData } from '../../../actions/autocomplete.actions';
import { environment } from '../../../../environments/environment';

const applicatonObj = {
    "appid": environment.appID,
    "appname": environment.appName,
}

@Component({
    selector: 'app-create-restriction',
    templateUrl: './create-restriction.component.html',
    styleUrls: ['./create-restriction.component.css']
})
export class CreateRestrictionComponent implements OnInit {
    restrictionHeader: string;
    restrictionData: any;
    restrctionRecord: any;
    RoleMatrixDataSubScription: Subscription;
    restricitonDataSubscription: Subscription;
    restrictions: any[] = [];
    restrictionTypeRecord = restricitonType;
    restrictionDataList: any[] = [];
    selectedRestrictions: any[] = [];
    isRestrictionTypeSelected: boolean = false;
    restrictionMode: string;
    multiSelectautoCompleteData = {
        bindLabel: '_id',
        bindValue: '_id',
        selectedInput: []
    };

    @Input() createRestricionModalDisplay: boolean;
    @Output() closeModal: EventEmitter<any> = new EventEmitter();
    @Output() submitForm: EventEmitter<any> = new EventEmitter();
    @Output() editForm: EventEmitter<any> = new EventEmitter();

    @Input()
    set modalProperties(val) {
        if (val) {
            const { restrictionMode, restrictionHeader, restrictionData } = val;
            this.restrictionHeader = restrictionHeader;
            this.restrictionData = JSON.parse(JSON.stringify(restrictionData));
            this.restrictionMode = restrictionMode;
            const { restrictiondata } = restrictionData;
            this.multiSelectautoCompleteData = {
                bindLabel: '_id',
                bindValue: '_id',
                selectedInput: restrictiondata || []
            };
        }
    }

    constructor(private store: Store<AppState>) { }

    ngOnInit() {
        this.restricitonDataSubscription = this.store.pipe(select(state => state.Autocomplete))
            .subscribe(autocompleteObject => {
                const {
                    restrictionData: { restrictionResult, restrictionFetchisLoading }
                } = autocompleteObject;
                if (restrictionResult && !restrictionResult['hasError']) {
                    this.restrictionDataList = restrictionResult || [];
                    this.multiSelectautoCompleteData = {
                        bindLabel: '_id',
                        bindValue: '_id',
                        selectedInput: this.selectedRestrictions || []
                    };
                }
            });
    }
    ngOnDestroy() {
        this.restricitonDataSubscription.unsubscribe();
    }

    closeModalFunction() {
        this.closeModal.emit();
        this.store.dispatch(new ReSetRestrictionData());
    }

    changeRestrictionType() {
        this.isRestrictionTypeSelected = this.restrictionData.restrictiontype ? false : true;
    }

    submitFormFunction() {
        const { restrictionid, restrictionname, permissionid, restrictiontype,
            restrictedusername, restricteduserid } = this.restrictionData;
        if (this.restrictionMode === "Add") {
            const obj = {
                ...applicatonObj,
                restrictionname: restrictionname,
                permissionid: permissionid,
                restrictiontype: restrictiontype,
                restrictiondata: this.selectedRestrictions,
                restrictedusername: restrictedusername,
                restricteduserid: restricteduserid,
            };
            this.submitForm.emit(obj);
        } else {
            const obj = {
                permissionid: permissionid,
                restricteduserid:restricteduserid,
                restrictionObj: {
                    _id: restrictionid,
                    appid: applicatonObj.appid,
                    restrictiondata: this.selectedRestrictions,
                    restrictiontype: restrictiontype,
                    restrictionname: restrictionname
                }
            }
            this.editForm.emit(obj);
        }
        this.closeModalFunction();
    }

    fetchAutoCompleteApi(inputText: any) {
        this.store.dispatch(new ReSetRestrictionData());
        this.store.dispatch(new GetRestrictionData({
            restrictionType: this.restrictionData.restrictiontype,
            searchText: inputText
        }));
    }

    shareCheckedList(selectedValue) {
        this.selectedRestrictions = selectedValue;
    }
}