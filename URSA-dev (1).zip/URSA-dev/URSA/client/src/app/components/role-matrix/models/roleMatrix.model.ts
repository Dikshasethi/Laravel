interface Permission {
    _id?:string,
    permissionname: string,
    permissiondescription: string
}

export { Permission };