import { Component, OnInit, HostListener } from '@angular/core';
import {
    CreatePermission, GetPermission, GetRole, GetPermissionByID,
    EditPermission, DeletePermission, CreateRole, GetRoleByID, DeleteRole,
    EditRole, GetUserList, CreateUser, GetRestrictions, CreateRestriction,
    DeleteRestriction, EditRestriction, SetuserListFilters, ReSetUserListFilters, CloneUserRole
} from '../../actions/roleMatrix.action';
import { AppState } from '../../models/appState';
import { Store, select } from '@ngrx/store';
import { environment } from '../../../environments/environment';
import { Subscription } from 'rxjs';
import { ReSetPermissionAutoComplete } from '../../actions/autocomplete.actions';

const applicatonObj = {
    "appid": environment.appID,
    "appname": environment.appName,
}

@Component({
    selector: 'app-role-matrix',
    templateUrl: './role-matrix.component.html',
    styleUrls: ['./role-matrix.component.css']
})
export class RoleMatrixComponent implements OnInit {
    isRolesorPermission: boolean = true;
    permissionDataSubScription: Subscription;
    roleDataSubScription: Subscription;
    modalDisplay: string = 'none';
    permissions: any[] = [];
    permissionsRecord: any[] = [];
    roles: any[] = [];
    mappedRoles: any[] = [];
    userList: any[] = [];
    restrictionData: any[] = [];
    createeditPermissionModalDisplay: boolean = false;
    createeditRolesModalDisplay: boolean = false;
    createeditUserRoleModalDisplay: boolean = false;
    createRestricionModalDisplay: boolean = false;
    editRestricionModalDisplay: boolean = false;
    skip: number = 0;
    limit: number = 20;
    recordCount: number = 0;
    userListCount: number = 0;
    filters: any = {};
    filterObj: any = {};
    modalPermissionProperties: any = {
        permissionHeader: '',
        permissionMode: '',
        permissionData: {
            permissionname: '',
            permissiondescription: ''
        }
    };
    modalRoleProperties: any = {
        roleHeader: '',
        roleMode: '',
        roleData: {
            rolename: '',
            roledescription: '',
            permissionidlist: []
        }
    };
    modalUserRoleProperties: any = {
        userRoleHeader: '',
        userRoleMode: '',
        userRoleData: {
            userid: '',
            username: '',
            email: '',
            roleidlist: []
        }
    };
    modalRestrictionProperties: any = {
        restrictionHeader: '',
        restrictionMode: '',
        restrictionData: {
            restrictionname: '',
            permissionid: '',
            permissionname: '',
            restrictiontype: '',
            restrictiondata: [],
            restrictedusername: '',
            restricteduserid: '',
        }
    };
    modalEditRestrictonProperties: any = {
        restrictionHeader: 'Restrictions',
        userName: '',
        permissionid: '',
        permissionName: '',
        restrictionData: []
    };
    show_errorMessage: boolean = false;
    error_message: string;
    constructor(private store: Store<AppState>) { }
    public innerHeight: any;
    @HostListener('window:resize', ['$event'])
    onResize(event) {
        this.innerHeight = window.innerHeight;
    }
    ngOnInit() {
        this.fetchPermissions();
        this.fetchRoles();
        this.fetchUserList();
        this.permissionDataSubScription = this.store.pipe(select(state => state.RoleMatrix))
            .subscribe(data => {
                if (data) {
                    const {
                        roleData: { roleResult = [] },
                        permissionData: { permissionResult = [] },
                        userList: { userListResult, userListCount, userListFetchisLoading },
                        userListFilter,
                        loading,
                        errorState: { error = false, error_message }
                    } = data;
                    this.show_errorMessage = false;
                    this.modalDisplay = loading || userListFetchisLoading ? 'block' : 'none';
                    if (!permissionResult['hasError']) {
                        this.permissions = permissionResult;
                        this.permissionsRecord = JSON.parse(JSON.stringify(permissionResult));
                        this.getMappedRolePermissions();
                    }

                    if (!roleResult['hasError']) {
                        this.roles = roleResult;
                        this.getMappedRolePermissions();
                    }

                    if (userListResult) {
                        if (!userListResult['hasError']) {

                            this.userList = userListResult;
                            this.userListCount = userListCount;
                            this.recordCount = userListResult.length;
                        }
                    }

                    if (error) {
                        this.showErrorMessage(error_message);

                    }

                    this.filterObj = userListFilter;
                }
            })
    }

    ngOnDestroy() {
        this.permissionDataSubScription.unsubscribe();
        this.store.dispatch(new ReSetUserListFilters())
    }

    showErrorMessage(errorMsg) {
        this.error_message = errorMsg && errorMsg.error && errorMsg.error.message ? errorMsg.error.message : 'Something went wrong';
        this.show_errorMessage = true;
    }

    removeAlertIcon() {
        this.show_errorMessage = false;
    }

    mappedFilterObj() {
        let filterQuery = {};
        for (let k in this.filterObj) {
            let value = this.filterObj[k];
            if (value) {
                filterQuery[k] = {
                    $regex: `.*${value}.*`,
                    $options: 'i'
                };
            }
        }
        return filterQuery;
    }

    fetchUserList() {
        let filterQuery = this.mappedFilterObj();
        this.store.dispatch(new GetUserList({
            'appid': applicatonObj.appid,
            "limit": this.limit,
            "skip": this.skip,
            "filter": filterQuery
        }));
    }

    setFilters() {
        let filterData = {};
        for (let k in this.filters) {
            let value = this.filters[k];
            if (value) {
                filterData[k] = value;
            }
        }
        this.store.dispatch(new SetuserListFilters({ filter: filterData }))
    }

    filterUserList(event) {
        const { name, value } = event;
        this.filters[name] = value;
        this.setFilters();
        this.resetSearchMeta();
        this.fetchUserList();
    }

    resetSearchMeta = () => {
        this.skip = 0;
    }

    onScroll() {
        let difference = this.userListCount - this.recordCount;
        if (difference >= 1) {
            if (
                this.skip <= this.recordCount
            ) {
                this.skip = this.recordCount;
                this.fetchUserList();
            }
        }
    }

    fetchRoles() {
        this.store.dispatch(new GetRole({
            "filter": applicatonObj
        }));
    }

    fetchPermissions() {
        this.store.dispatch(new GetPermission({
            "filter": applicatonObj
        }));
    }

    getActiveTabClass(state) {
        if (this.isRolesorPermission) {
            return state === "roles" ? "activeTabs" : "inactiveTabs";
        } else {
            return state === "permissions" ? "activeTabs" : "inactiveTabs";
        }
    }

    openTab(state) {
        this.isRolesorPermission = state === "roles" ? true : false;
    }

    mappedPermissions(permissionidList) {
        let permissionList = [];
        for (let j = 0; j < permissionidList.length; j++) {
            for (let k = 0; k < this.permissions.length; k++) {
                let record = this.permissions[k];
                let obj: any = {};
                if (permissionidList[j] === record['_id']) {
                    obj.permissionname = record['permissionname'];
                    obj.permissionId = record['_id'];
                    permissionList.push(obj);
                    break;
                }
            }
        }
        return permissionList;
    }

    getMappedRolePermissions() {
        this.mappedRoles = [];
        if (this.roles.length && this.permissions.length) {
            for (let i = 0; i < this.roles.length; i++) {
                let record = this.roles[i];
                let permissionlist = this.mappedPermissions(record.permissionidlist);
                this.mappedRoles.push({
                    ...record,
                    permissionlist
                })
            }
        }
    }

    addNewPermission() {
        this.createeditPermissionModalDisplay = true;
        this.modalPermissionProperties = {
            permissionMode: 'Add',
            permissionHeader: 'Add New Permission',
            permissionData: {}
        }
    }

    submitPermissionForm(permission: any) {
        const { permissionMode, permissionData } = permission;
        const { _id, permissionname, permissiondescription } = permissionData;
        let permissionObj: any = {
            "permissionname": permissionname,
            "permissiondescription": permissiondescription,
            "appid": applicatonObj.appid
        }
        if (permissionMode === "Edit") {
            permissionObj['_id'] = _id;
            this.store.dispatch(new EditPermission(permissionObj));
        } else {
            permissionObj['appname'] = applicatonObj.appname;
            this.store.dispatch(new CreatePermission(permissionObj));
        }
    }

    editPermission(prmissionId) {
        this.createeditPermissionModalDisplay = true;
        this.store.dispatch(new GetPermissionByID({
            "permissionId": prmissionId
        }));
        this.modalPermissionProperties = {
            permissionMode: 'Edit',
            permissionHeader: 'Edit Permission',
            permissionData: {}
        }
    }

    deletePermission(prmissionId) {
        this.store.dispatch(new DeletePermission({
            "permissionId": prmissionId
        }));
    }

    closePermissionModal() {
        this.createeditPermissionModalDisplay = false;
        this.store.dispatch(new ReSetPermissionAutoComplete());
    }

    openRoleModal() {
        this.createeditRolesModalDisplay = true;
        this.modalRoleProperties = {
            roleMode: 'Add',
            roleHeader: 'Add New Role',
            roleData: {}
        }
    }

    editRole(roleId) {
        this.createeditRolesModalDisplay = true;
        this.store.dispatch(new GetRoleByID({
            "roleId": roleId
        }));
        this.modalRoleProperties = {
            roleMode: 'Edit',
            roleHeader: 'Edit Role',
            roleData: {},
        }
    }

    deleteRole(roleId) {
        this.store.dispatch(new DeleteRole({
            "roleId": roleId
        }));
    }

    closeRoleModal() {
        this.createeditRolesModalDisplay = false;
    }

    submitRoleForm(role: any) {
        const { roleMode, roleData } = role;
        const { _id, rolename, roledescription, permissionidlist } = roleData;
        let roleObj: any = {
            ...applicatonObj,
            "rolename": rolename,
            "roledescription": roledescription,
            "permissionidlist": permissionidlist
        }
        if (roleMode === "Edit") {
            roleObj['_id'] = _id;
            this.store.dispatch(new EditRole(roleObj));
        } else {
            this.store.dispatch(new CreateRole(roleObj));
        }
    }

    deletepermissionFromRole(roleObj: any) {
        this.store.dispatch(new EditRole(roleObj));
    }

    addNewUser() {
        this.modalUserRoleProperties = {
            userRoleHeader: 'Add new User',
            userRoleMode: 'Add',
            userRoleData: {}
        }
        this.createeditUserRoleModalDisplay = true;
    }

    submitUserRoleForm({ option, payload }) {
        const { userid, username, email, roleidlist, cloneFromUserId } = payload;
        let obj: any = {
            filter: this.mappedFilterObj(),
            userRolePayload: {
                "appid": applicatonObj.appid,
                "userid": userid,
                "username": username,
                "email": email
            }
        };

        if (option === "assignroles") {
            let userRoleobj: any = {
                ...obj,
                userRolePayload: {
                    ...obj.userRolePayload,
                    "roleidlist": roleidlist
                }
            }
            this.store.dispatch(new CreateUser(userRoleobj));
        } else {
            let cloneUserRoleObj: any = {
                ...obj,
                userRolePayload: {
                    ...obj.userRolePayload,
                    "cloneFromUserId": cloneFromUserId
                }
            }
            this.store.dispatch(new CloneUserRole(cloneUserRoleObj));
        }
        this.resetSearchMeta();
    }

    closeUserRoleModal() {
        this.createeditUserRoleModalDisplay = false;
    }

    editUserRole(userRole: any) {
        const { userid, username, email, roleidlist } = userRole;
        this.createeditUserRoleModalDisplay = true;
        this.modalUserRoleProperties = {
            userRoleHeader: 'Edit User',
            userRoleMode: 'Edit',
            userRoleData: {
                userid: userid,
                username: username,
                email: email,
                roleidlist: roleidlist || []
            }
        }
    }

    deleteRoleFromUserRole(userRole: any) {
        this.store.dispatch(new CreateUser(userRole));
    }

    closeRestrictionModal() {
        this.createRestricionModalDisplay = false;
    }

    editPermissionRestriction(permissionObj) {
        const { userid, username, permissionname, permissionid } = permissionObj
        this.editRestricionModalDisplay = true;
        this.modalEditRestrictonProperties = {
            restrictionHeader: 'Restrictions',
            userName: username,
            userid: userid,
            permissionid: permissionid,
            permissionName: permissionname,
            restrictionData: []
        }
        this.store.dispatch(new GetRestrictions({
            "filter": {
                "appid": applicatonObj.appid,
                "permissionid": permissionid,
                "restricteduserid": userid,
            }
        }));
    }

    editRestriction(restrictionObj: any) {
        this.createRestricionModalDisplay = true;
        this.modalRestrictionProperties = {
            restrictionMode: 'Edit',
            restrictionHeader: 'Edit Restriction',
            restrictionData: restrictionObj
        }
    }

    closeEditRestrictonModal() {
        this.editRestricionModalDisplay = false;
    }

    deleteRestrictions(restrictionObj) {
        this.store.dispatch(new DeleteRestriction(restrictionObj));
    }

    createRestriction(restrictionData: any) {
        this.createRestricionModalDisplay = true;
        const { userid, username, permissionid, permissionname } = restrictionData;
        this.modalRestrictionProperties = {
            restrictionMode: 'Add',
            restrictionHeader: 'Add Restriction',
            restrictionData: {
                restrictionname: '',
                permissionid: permissionid,
                permissionname: permissionname,
                restrictiontype: '',
                restrictiondata: [],
                restrictedusername: username,
                restricteduserid: userid,
            }
        }
    }

    submitFormRestriction(restrictionObj) {
        this.store.dispatch(new CreateRestriction(restrictionObj));
    }

    editRestrictionForm(restrictionRecord: any) {
        this.store.dispatch(new EditRestriction(restrictionRecord));
    }
}