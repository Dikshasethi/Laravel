import { Routes } from '@angular/router';
import { RoleMatrixComponent } from './role-matrix.component';

 export const RoleMatrixRoutes: Routes = [
   {
     path: '',
     component: RoleMatrixComponent
   }
 ];