import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Permission } from '../models/roleMatrix.model';
import { Subscription } from 'rxjs';
import { AppState } from '../../../models/appState';
import { Store, select } from '@ngrx/store';
import { environment } from '../../../../environments/environment';
import { GetPermissionAutoComplete } from '../../../actions/autocomplete.actions';

@Component({
    selector: 'app-createedit-permission',
    templateUrl: './createedit-permission.component.html',
    styleUrls: ['./createedit-permission.component.css']
})
export class CreateEditPermissionsComponent {

    permissionHeader: string;
    permissionData: Permission;
    permissionMode: string;
    roleMatrixSubScription: Subscription;
    permissionValidationSubscription: Subscription;
    permissionValidationData: any[] = [];
    permissionValidationInputClassName: string = '';
    editPermissionName: string = '';
    isLoading: boolean = false;
    @Input() createeditPermissionModalDisplay: any;
    @Output() closeModal: EventEmitter<any> = new EventEmitter();
    @Output() submitForm: EventEmitter<any> = new EventEmitter();

    @Input()
    set modalProperties(val) {
        if (val) {
            const { permissionHeader, permissionData, permissionMode } = val;
            this.permissionHeader = permissionHeader;
            this.permissionData = permissionData;
            this.permissionMode = permissionMode;
            this.permissionValidationInputClassName = '';
        }
    }

    constructor(private store: Store<AppState>) { }

    ngOnInit() {
        this.roleMatrixSubScription = this.store.pipe(select(state => state.RoleMatrix))
            .subscribe(data => {
                const {
                    permissionDataById: { permissionByIdResult },
                } = data;
                if (permissionByIdResult && !permissionByIdResult['hasError']) {
                    this.permissionData = permissionByIdResult;
                    this.editPermissionName = this.permissionData.permissionname;
                }

            });

        this.permissionValidationSubscription = this.store.pipe(select(state => state.Autocomplete))
            .subscribe(autocompleteObject => {
                const {
                    permissionValidation: { permissionValidationResult, permissionValidationFetchisLoading }
                } = autocompleteObject;
                this.isLoading = permissionValidationFetchisLoading;
                if (permissionValidationResult && !permissionValidationResult['hasError']) {
                    this.permissionValidationData = permissionValidationResult || [];
                    this.getBorderColor();
                }
            });
    }

    ngOnDestroy() {
        this.roleMatrixSubScription.unsubscribe();
        this.permissionValidationSubscription.unsubscribe();
    }

    closeModalFunction = () => {
        this.resetPermission();
        this.closeModal.emit();
    }

    resetPermission() {
        this.permissionData = {
            permissionname: '',
            permissiondescription: ''
        };
        this.permissionValidationInputClassName = '';
    }

    submitFormFunction = () => {
        let obj = {
            permissionMode: this.permissionMode,
            permissionData: this.permissionData
        }
        this.submitForm.emit(obj);
        this.closeModalFunction();
    }

    isSubmitButtonDisabled = () => {
        return !(this.permissionData.permissionname && this.permissionData.permissiondescription && !this.permissionValidationInputClassName);
    }

    inputFilter = (event: any) => {
        let inputText = event.target.value;
        let filter = { appid: environment.appID };
        filter["permissionname"] = inputText;
        let obj: any = { filter: filter };
        this.store.dispatch(new GetPermissionAutoComplete(obj));
    }

    getBorderColor() {
        if (this.permissionMode === 'Add') {
            if (this.permissionValidationData.length) {
                this.permissionValidationInputClassName = 'validation_error';
            } else {
                this.permissionValidationInputClassName = '';
            }
        } else {
            if (this.permissionValidationData.length) {
                let permision = this.permissionValidationData.filter(record => record['_id'] === this.permissionData['_id'])
                if (permision && permision.length) {
                    this.permissionValidationInputClassName = '';
                } else {
                    this.permissionValidationInputClassName = 'validation_error';
                }
            } else {
                this.permissionValidationInputClassName = '';
            }
        }
        return this.permissionValidationInputClassName;
    }
}