import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { RoleMatrixRoutes } from './roleMatrix.routes';
import { RoleMatrixComponent } from './role-matrix.component';
import { PermissionsComponent } from './permisssions/permissions.component';
import { CreateEditPermissionsComponent } from './createedit-permission/createedit-permission.component';
import { RolesComponent } from './roles/roles.component';
import { CreateEditRolesComponent } from './createedit-roles/createedit-roles.component';
import { UserListComponent } from './userList/userList.component';
import { CreateEditUserRoleComponent } from './createedit-userrole/createedit-userrole.component';
import { EditRestrictionComponent } from './editRestrictions/edit-restriction.component';
import { CreateRestrictionComponent } from './create-restriction/create-restriction.component';
import { SharedModule } from "../../shared.module";

@NgModule({
    declarations: [
        RoleMatrixComponent,
        PermissionsComponent,
        CreateEditPermissionsComponent,
        RolesComponent,
        CreateEditRolesComponent,
        UserListComponent,
        CreateEditUserRoleComponent,
        EditRestrictionComponent,
        CreateRestrictionComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(RoleMatrixRoutes)
    ],
    exports: [
        RouterModule
    ]
})
export class RoleMatrixModule { }