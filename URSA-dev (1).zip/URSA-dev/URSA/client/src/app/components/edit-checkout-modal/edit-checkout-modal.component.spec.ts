import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCheckoutModalComponent } from './edit-checkout-modal.component';

describe('EditCheckoutModalComponent', () => {
  let component: EditCheckoutModalComponent;
  let fixture: ComponentFixture<EditCheckoutModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditCheckoutModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCheckoutModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
