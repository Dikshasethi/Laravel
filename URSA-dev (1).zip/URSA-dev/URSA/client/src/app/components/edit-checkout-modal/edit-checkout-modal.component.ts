import { Component, OnInit, Input, Output, EventEmitter, SimpleChange } from '@angular/core';
import { 
  DestroyAutocompleteList, GetCustodianAutocompleteList, 
  GetCheckoutAutocomplete, GetLocationAreasCheck
} from '../../actions/autocomplete.actions';

import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import * as moment from 'moment';
import * as _ from 'lodash';
import dateValidation from '../../utils/date/dateValidator';
import defaultValues from '../../utils/autoComplete/defaultValues'

@Component({
  selector: 'app-edit-checkout-modal',
  templateUrl: './edit-checkout-modal.component.html',
  styleUrls: ['./edit-checkout-modal.component.css']
})
export class EditCheckoutModalComponent implements OnInit {

  constructor(
    private store: Store<AppState>
  ) { }
  @Input() panelStructureList: any;
  @Input() editCheckoutModalDisplay: any;
  @Output() closeModal: EventEmitter<any>  = new EventEmitter();
  @Output() submitForm: EventEmitter<any>  = new EventEmitter();

  formMap = {
    locationcode : '',
    locationdescription : '',
    areacode : '',
    areadescription : '',
    startdate : '',
    enddate : '',
    checkindate : '',
    customerreferencenumber : '',
    custodian : '',
    custodianname : '',
    minStartDate : ''
  }
  suggestionList = [];
  autoCompleteSubscription;
  userName = '';
  userId = '';
  dateValid = true;
  isGetAreaCount = false;
  isAreaSuggest = false;
  cachedAreaList = []
  areaSuggestionList=[]
  ngOnInit() {
    this.autoCompleteSubscription = this.store.pipe(select(state => state.Autocomplete))
    .subscribe(data => {
      let { areaCountForCurrentLocation, isLoading, cachedArea } = data;

      let suggestions = (data['checkoutAutocomplete'] && 
      data['checkoutAutocomplete']['suggestionList']) || [];
      this.suggestionList = [{'areaText' : 'NA', 'areaCode' : 'NA'}, ...suggestions];

      if(this.isGetAreaCount && !isLoading){
        this.isGetAreaCount = false;
        this.cachedAreaList = cachedArea;
        if(Number(areaCountForCurrentLocation) === 0){
          this.formMap.areacode = defaultValues.areaText;
          this.formMap.areadescription = defaultValues.areaText;
        }
      }

    });
  }

  ngOnChanges(changes: SimpleChange){
    if(
      changes['editCheckoutModalDisplay'] &&
      !_.isEqual(
        changes['editCheckoutModalDisplay']['currentValue'],
        changes['editCheckoutModalDisplay']['previousValue']
      )
    ){
      this.editCheckoutModalDisplay = changes['editCheckoutModalDisplay']['currentValue'];
    }
  }

  ngOnDestroy(){
    this.autoCompleteSubscription.unsubscribe();
  }

  handleAutocompleteInputChange(text, field, formMapKey){
    this.suggestionList = [];
    this.updateFormMap(formMapKey, field, text);
    if(
      field === 'custodian' && 
      text.length >= 2
    ){
      let obj={
        "index" : "employeesearch",
        "search_keyword" : text,
        "field" : "custodian"
      }
      this.store.dispatch(new DestroyAutocompleteList());
      this.store.dispatch(new GetCustodianAutocompleteList(obj));  
    }else{
      if(text.length>=2){
        let obj =  {
          "field" : field     
        }
        if(field === "location"){
          obj['locationDescription'] = text
        }
        if(field === "area"){
          this.isAreaSuggest = true;
          obj['locationCode'] = this.formMap['locationcode'];
          obj['areaDescription'] = text 
        }

        if(this.isAreaSuggest){
          this.filterAreaList(obj)
          this.isAreaSuggest = false;
        }else{
          this.store.dispatch(new DestroyAutocompleteList());
          this.store.dispatch(new GetCheckoutAutocomplete(obj));
        }
      }else{
        if(text=="" && field=="location"){
          this.formMap['locationcode'] = '';
          this.formMap['areaCode'] = '';
          this.formMap['areadescription'] = '';
        }else if(text=="" && field=="area"){
          this.formMap['areadescription'] = '';
          this.formMap['areaCode'] = '';
        }
      }
    }
  }
  filterAreaList(filterObj){
    let newSuggestionList = [];
    let subString = filterObj.areaDescription && filterObj.areaDescription || '';

    for(let areaItem of this.cachedAreaList){
      if(
        areaItem.LOCATION && 
        areaItem.SETID && 
        areaItem.DESCR && 
        areaItem.DESCR.toLowerCase().includes(subString.toLowerCase())
      ){
        let areaDescription = areaItem.DESCR
        let areaTextRef = 
          (
            subString.toLowerCase() === 'na' || 
            subString.toLowerCase() === ''
          ) ? 
          'NA' : areaDescription;

        let areaObject = {
          areaCode : areaItem.LOCATION || '',
          areaText : areaTextRef
        }
        newSuggestionList.push(areaObject)
      }
    }
    this.areaSuggestionList = newSuggestionList;
  }
  updateFormMap = (formMapKey, field, text) => {
    this.formMap[formMapKey] = text;
    if(!text){
      if(field === 'location'){
        this.formMap['locationCode'] = '';
        this.formMap['locationdescription'] ='';
      }else if(field === 'area'){
        this.formMap['areacode'] = '';
        this.formMap['areadescription'] = '';
      }else if(field === 'custodian'){
        this.formMap['custodian'] = '';
        this.formMap['custodianname'] = ''
      }
    }
  }

  isSubmitButtonDisabled = () => {
    const {
      locationcode='', locationdescription='',
      areacode='', areadescription='', 
      custodian='', custodianname='',
      checkindate=''
    } = this.formMap;
    let disabled = true;
    if(checkindate){
      disabled = false;
    }

    if(locationcode || locationdescription){
      if(locationcode && locationdescription){
        disabled = false;
      }else{
        disabled = true;
        return disabled;
      }
    }

    if(areacode || areadescription){
      if(areacode && areadescription){
        disabled = false;
      }else{
        disabled = true;
        return disabled;
      }
    }else{
      disabled = true;
      return disabled;
    }

    if(custodian || custodianname){
      if(custodian && custodianname){
        disabled = false;
      }else{
        disabled = true;
        return disabled;
      }
    }
    if (!this.dateValid) {
      disabled = true;
      return disabled;
    } else {
      disabled = false;
    }
    return disabled;
  }

  suggestionSelected = (data, dataKey) => {
    if(dataKey === 'location'){
      this.formMap['locationcode'] = data['locationCode'];
      this.formMap['locationdescription'] = data['locationText'];
      let areaCheckObj = {
        locationId : data.locationCode
      }
      this.isGetAreaCount = true;
      this.store.dispatch(new GetLocationAreasCheck(areaCheckObj));
    }else if(dataKey === 'area'){
      this.formMap['areacode'] = data['areaCode'];
      this.formMap['areadescription'] = data['areaText'];
    }else if(dataKey === 'custodian'){
      this.formMap['custodian'] = data['empId'];
      this.formMap['custodianname'] = data['empName']
    }
  }

  getDateValue = (panel, key) => {
    let mapKey = key ? key : 'dataKey';
    return moment(this.formMap[panel[mapKey]]).isValid() ? 
    moment(this.formMap[panel[mapKey]]).format('YYYY-MM-DD') : 
    '';
  }

  getInputValue = (panel) => {
    return this.formMap[panel['dataKey']];
  }

  onInputChange = (value, panel) => {
    const {dataKey='',} = panel;
    this.formMap[dataKey] = panel['type'] === 'date' ? 
    moment(value).format('YYYY-MM-DD') : value;
    if (panel['type'] === "date") {
      if(value){
        this.dateValid = dateValidation(value);
      }
      else{
        this.dateValid = true;
      }
    }
  }

  getDateError = (panel)=>{
    if(panel['type'] === "date" ){
    let windowInput = window.document.getElementById(panel['dataKey']);
      if(windowInput && windowInput['validity'].badInput){
        this.dateValid = false;
      }
    }
  }

  getClass(panel){
    if(panel['type'] === "date"){
      return !this.dateValid;
    } 
  }

  getSuggestionList = (panel) => {
    return panel['dataKey'] === 'area' ? 
    this.areaSuggestionList 
    : 
    this.suggestionList.slice(1);
  }

  getMinMaxDate = (panel, minMaxType, key) => {
    const {
      hasMax=false, hasMin=false, maxInFormMap=false,
      maxDate=0, minDate=0, minInFormMap=false
    } = panel;
    if(hasMax && minMaxType === 'max' && panel['type'] === 'date'){
      return maxInFormMap ? this.getDateValue(panel, key) : 
      moment(maxDate).format('YYYY-MM-DD');
    }else if(hasMin && minMaxType === 'min' && panel['type'] === 'date'){
      return minInFormMap ? this.getDateValue(panel, key) : 
      moment(minDate).format('YYYY-MM-DD');
    }else{
      return null;
    }
  }
  
  resetFormMap = () => {
    this.formMap = {
      locationcode : '',
      locationdescription : '',
      areacode : '',
      areadescription : '',
      startdate : '',
      enddate : '',
      checkindate : '',
      customerreferencenumber : '',
      custodian : this.userId,
      custodianname : this.userName,
      minStartDate : ''
    };
    this.dateValid = true
  }

  closeModalFunction = () => {
    this.resetFormMap();
    this.closeModal.emit()
  }

  submitFormFunction = () => {
    this.submitForm.emit(JSON.parse(JSON.stringify(this.formMap)));
    this.closeModalFunction();
  }

}
