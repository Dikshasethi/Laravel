import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetLogsComponent } from './asset-logs.component';

describe('AssetLogsComponent', () => {
  let component: AssetLogsComponent;
  let fixture: ComponentFixture<AssetLogsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetLogsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetLogsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
