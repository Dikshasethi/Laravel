import { Component, OnInit, HostListener, Input, SimpleChange } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import localDate from '../../utils/date/localDate';
import * as _ from 'lodash';
import * as moment from 'moment';
import { GetAssetLogs, ResetLogReducer } from '../../actions/assetLogs.actions';
import filterObjectDateFormat from '../../utils/checkInOut/filterObjectDateFormat';
import { ReSetSorting, SetSorting } from '../../actions/checkInOut.action';
import { Subscription } from 'rxjs/Subscription';
import { ClearDownloadData, GetDownloadData } from '../../actions/download.action';
import downlaodcsv from '../../utils/downloadCSV/downlaodcsv';

@Component({
  selector: 'app-asset-logs',
  templateUrl: './asset-logs.component.html',
  styleUrls: ['./asset-logs.component.css']
})
export class AssetLogsComponent implements OnInit {
  constructor(
    private store: Store<AppState>
  ) { }

  @Input() view: any;

  AssetLogSubscription;
  hideSpinner=false;
  modalDisplay=false;
  recordCount=0;
  totalLogCount=0;
  refinedAssetLogList=[];
  assetLogError=false;
  assetlogloading=false;
  skip:number = 0;
  limit:number = 50;
  sort :any= {"activitydate" : -1};
  localFormat = moment().localeData()['_longDateFormat']['L']
  filters: any = {
    assetid : '',
    businessunit : '',
    tagnumber : '',
    serialid : '',
    activity : '',
    activitydate : '',
    createdby : ''
  }
  checkInOutSortingSubscription : Subscription;
  sortingIcon :any={};
  downloadSubscription:Subscription;
  donwloadDataListIsLoading:boolean;
  assetLogAssetId :any;
  assetLogBusinessUnit:any;
  filterObj: any;

  public innerHeight: any;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;
  }

  ngOnInit() {
    this.innerHeight = window.innerHeight;
    this.fetchAssetLogs(this.filters, this.skip);
    this.AssetLogSubscription = this.store.pipe(select(state => state.AssetLog))
    .subscribe(logData => {
      const {
        assetLogList=[], isLoading=false,
        hasError=false, totalCount=0, filterObj
      } = logData;
      this.modalDisplay = isLoading;
      this.assetlogloading = isLoading;
      this.recordCount = assetLogList.length;
      this.totalLogCount = totalCount;
      this.refinedAssetLogList = this.refineAssetLogList(assetLogList);
      this.assetLogError = hasError;
      if(!_.isEmpty(filterObj)){
        this.filterObj = filterObj;
        this.assetlogFilterUpdate();
      }
    });

    this.checkInOutSortingSubscription = this.store.pipe(select(state => state.CheckInOut))
    .subscribe(data => {
      const {sort:{assetlogs}}=data;
        let obj={};
        for(let key in assetlogs){
          obj[key] = assetlogs[key];
        }
        this.sort = obj;
    });

     this.downloadSubscription = this.store.pipe(select(state => state.Download))
      .subscribe(data => {
        const { downloadData = [],isLoading} = data;
        this.donwloadDataListIsLoading = isLoading ;
        if(!isLoading && downloadData.length){
          let mappedData = this.mappDownloadData(downloadData);
          downlaodcsv('assetlogs', mappedData);
        }
      });
  }

  mappDownloadData = (downloadData) => {
    let _downloadData = [...downloadData];
    return _downloadData.map(record => {
      const { serialid = '', tagnumber = '', businessunit = '',
        assetid = '', activity = '', activitydate = '', createdby = '' } = record;
      let obj = {
        serialid, tagnumber, businessunit, assetid, activity,
        activitydate, createdby
      };
      return obj;
    })
  }


  ngOnDestroy(){
    this.AssetLogSubscription.unsubscribe();
    this.store.dispatch(new ResetLogReducer());
    this.store.dispatch(new ReSetSorting());
  }

  refineAssetLogList = (assetLogList=[]) => {
    let newArray = [];
    for (let i = 0; i < assetLogList.length; i++){
      let log = assetLogList[i];
      let {
        startdate='', enddate='', activitydate='',
        newcheckindate=''
      } = log;
      newArray.push({
        ...log,
        startdate : startdate ? localDate(startdate, 'DD-MMM-YYYY') : '',
        enddate : enddate ? localDate(enddate, 'DD-MMM-YYYY') : '',
        activitydate : activitydate ? localDate(activitydate, 'DD-MMM-YYYY') : '',
        newcheckindate : newcheckindate ? localDate(newcheckindate, 'DD-MMM-YYYY') : '',
        activityDateMs : new Date(activitydate).getTime()
      });
    }

    return _.orderBy(newArray, 'activityDateMs', 'desc');
  }

  assetlogFilterUpdate(){
 this.filters = {
   ...this.filters,
   ...this.filterObj
 }
    this.store.dispatch(new ResetLogReducer());
    this.executeFilter();
  }

  updateFilter(map: string, event){
    this.filters[map] = event.target.value;
    this.store.dispatch(new ResetLogReducer());
    this.executeFilter();
  }

  executeFilter(){
    this.skip = 0;
    let updatedFilter = filterObjectDateFormat(this.filters);
    this.fetchAssetLogs(updatedFilter, this.skip);
  }

  errorDisplayFunction = () => {
    if (this.assetLogError) {
      return 'block';
    } else {
      return 'none';
    }
  }

  modalDisplayFunction = () => {
    if (this.donwloadDataListIsLoading) {
      return 'block';
    }
    if (this.modalDisplay && !this.hideSpinner) {
      return 'block';
    }
    return 'none';
  }

  fetchAssetLogs = (filter, skip) => {
    if(skip){
      this.hideSpinner = true;
    }
    let obj = {
      skip,
      limit : this.limit,
      filter,
      sort : this.sort
    }
    
    if(
      !this.view ||
      (
        this.view === 'assettransaction' && 
        filter['assetid'] && filter['businessunit']
      )
    ){
      this.store.dispatch(new GetAssetLogs(obj));
    }
  }

  onScroll(){
    if(
      this.skip <=  this.recordCount
    ){
      this.skip = this.recordCount;
      this.fetchAssetLogs(this.filters, this.skip);
    }
  }

  setSorting=(key)=>{
    let sort = {};
    sort['componentType'] = "assetlogs";
    sort['dataKey'] = key;
    this.store.dispatch(new SetSorting(sort))
  }
  
  sortData = (dataKey) => {
    this.setSorting(dataKey);
    this.skip = 0;
    this.store.dispatch(new ResetLogReducer());
    this.fetchAssetLogs(this.filters, this.skip);
    this.visualizeSortingIcon();
  }

  visualizeSortingIcon = () => {
    let sortData = JSON.parse(JSON.stringify(this.sort));
    let obj={}
    for(let key in sortData){
       if(sortData[key] === 1){
        obj[key] = "fa fa-arrow-up"
       }else if(sortData[key] === -1){
        obj[key] = "fa fa-arrow-down"
       }
    }
    this.sortingIcon = obj;  
  }
  
  downloadcsv = () => {
    let obj = {
      filter:this.filters,
      sort : this.sort
    }
    this.store.dispatch(new ClearDownloadData());
    this.store.dispatch(new GetDownloadData({ urlType: 'assetlogs', payload: obj }))
  }

}
