import { Component, OnInit, Input, SimpleChange, ViewChild, Output, EventEmitter } from '@angular/core';
import * as _ from 'lodash';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { Router } from '@angular/router';
import { FullCalendarComponent } from '../full-calendar/full-calendar.component';

@Component({
    selector: 'app-product-list',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.css'],
})

export class ProductListComponent implements OnInit {
    @Input() data: any;
    @Input() totalCount: any;
    @Input() searchStartDate: any;
    @Input() searchEndDate: any;
    @Input() hardReserveMode: boolean;
    @Input() reservationCart: any;
    @Input() hrIsLoading: any;
    @Input() hrProjectNumber: any;
    @Input() maxHrCount: any;
    @Input() imageActiveList: any;
    @Input() thumbnailMap: any;
    @Input() deleteUpdateMap: any;
    @Input() fileDataObject: any;
    @Input() imageUploadErrorList: any;
    @Input() activeView: any;
    @Input() proposalCart: any;
    @Input() isProposalMode: boolean;
    @Output() scrollEvent = new EventEmitter<string>();
    @Output() productProposalEvent = new EventEmitter<any>();
    @Output() cartAction= new EventEmitter<any>();
    @Output() watchListAction= new EventEmitter<any>();
    productList = [];
    productCount = 0;
    productSubscription: any;
    displayfullcalendar = 'none';
    browserLocale;
    deletedImageProductObj: any;
    @ViewChild(FullCalendarComponent) fullCalendarComponent: FullCalendarComponent;
    constructor(
        private store: Store<AppState>,
        private router: Router,
    ) { }

    ngOnInit() {
        this.browserLocale = window.navigator.languages[0]
        this.productList = this.data || [];
        this.productCount = (this.data && this.data.length) || 0;
        this.totalCount = this.totalCount || 0;

        this.productSubscription = this.store.pipe(select(state => state.Product))
            .subscribe(productData => {
                const { productList } = productData;
                this.productList = productList;
                this.productCount = productList && productList.length || 0;
            })

    }

    ngOnChanges(changes: SimpleChange) {
        let totalCount = changes['totalCount'];
        if (totalCount) {
            if (!_.isEqual(totalCount.currentValue, totalCount.previousValue)) {
                this.totalCount = totalCount.currentValue || 0;
            }
        }

        if (this.productList && this.productList.length > 0) {
            this.syncImageDelete();
          }
    }

    ngOnDestroy() {
        this.productSubscription.unsubscribe();
    }

    ClosecalendarPopup() {
        this.displayfullcalendar = 'none';
    }


    deletedImageProduct(deletedImageProductData: any) {
        this.deletedImageProductObj = deletedImageProductData;
    }

    syncImageDelete() {
        if (this.deleteUpdateMap && Object.keys(this.deleteUpdateMap).length > 0
        && this.deletedImageProductObj 
        && Object.keys(this.deletedImageProductObj).length > 0) {
          let deletedProductIndex = this.deletedImageProductObj.index
          let deleteKey: any[] = [];
          for (let key in this.thumbnailMap) {
            deleteKey.push(key)
          }

          let delUpdateProduct = this.productList[deletedProductIndex] && this.productList[deletedProductIndex].imageList && this.productList[deletedProductIndex].imageList.filter(obj => {
            return obj.imageUrl !== this.deleteUpdateMap[deleteKey[0]]
          }) || {}

          this.productList[deletedProductIndex].imageList = delUpdateProduct;
        }
        this.deleteUpdateMap = {};
      }

    onScroll() {
        this.scrollEvent.next('componentScrolled');
    }

    hardReserveButtonText = () => {
        if (this.reservationCart.length > 0) {
            if (this.hrIsLoading) {
                return 'Reserving...'
            } else {
                return `Hard Reserve x ${this.reservationCart.length}`
            }
        } else {
            return 'Hard Reserve'
        }
    }

    productProposal(obj) {
        this.productProposalEvent.emit(obj);
    }

    toggleCart(event: any) {
        this.cartAction.emit(event)
    }

    toggleWatchList(event: any) {
        this.watchListAction.emit(event)
    }

    viewFullCalendar({ data, index }) {
        this.displayfullcalendar = 'block';
        this.fullCalendarComponent.go12(data[index].timeseries || [], 'new', data[index].stateData || [], data[index].reservationData || []);
    }

    suggestionSelected = (obj = {}) => {
        this.hrProjectNumber = obj['projectnumber'];
    }

}
