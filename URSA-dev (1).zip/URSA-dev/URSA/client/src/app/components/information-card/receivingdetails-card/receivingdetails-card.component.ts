import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { GetReceivingDetails, ReSetReceivingDetails } from '../../../actions/information-card.action';
import { AppState } from '../../../models/appState';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import localDate from '../../../utils/date/localDate';

@Component({
    selector: 'app-receivingdetails-card',
    templateUrl: './receivingdetails-card.component.html'
})
export class ReceivingDetailsCardComponent implements OnInit {

    informationCardSubScription: Subscription;
    userDetailSubscription: Subscription;
    receivingdetailsData: any[] = [];
    totalCount: number;
    receivingdetailsDataCount: number;
    emplID: string;
    skip: number = 0;
    limit: number = 20;
    sortObj: any = {
        "receiveddate": -1
    };
    empId: string = '';
    constructor(
        private store: Store<AppState>,
        private router: Router
    ) { }

    ngOnInit() {
        this.informationCardSubScription = this.store.pipe(select(state => state.InformationCard.receivingdetails))
            .subscribe(data => {
                if (data) {
                    const {
                        receivingdetailsData = [], totalCount
                    } = data;
                    if (receivingdetailsData.length) {
                        this.receivingdetailsData = receivingdetailsData;
                        this.totalCount = totalCount;
                        this.receivingdetailsDataCount = receivingdetailsData.length;
                    }
                }
            });

        this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
            .subscribe(userDetailObj => {
                const {
                    details
                } = userDetailObj;
                this.emplID = details["employee_id"];
                if (this.emplID && !this.receivingdetailsDataCount) {
                    this.fetchRecord();
                }
            })
    }

    ngOnDestroy() {
        this.store.dispatch(new ReSetReceivingDetails());
        this.informationCardSubScription.unsubscribe();
        this.userDetailSubscription.unsubscribe();
    }

    fetchRecord = () => {
        let obj = {
            filter: {
                projectmanagerid: this.emplID,
                received: false
            },
            skip: this.skip,
            limit: this.limit,
            sort: this.sortObj
        };
        this.store.dispatch(new GetReceivingDetails(obj));
    }

    onScroll = () => {
        let difference = this.totalCount - this.receivingdetailsDataCount;
        if (difference >= 1) {
            if (this.skip <= this.receivingdetailsDataCount) {
                this.skip = this.receivingdetailsDataCount;
                this.fetchRecord();
            }
        }
    }

    viewReceivingDetailsReport = (receivingid: string) => {
        this.router.navigateByUrl(`/receiving/${receivingid}`);
        return;
    }

    localDateWrapper = (date) => {
        return date ? localDate(date, 'DD-MMM-YYYY') : '';
    }
}
