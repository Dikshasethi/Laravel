import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { GetEmoDetails, ReSetEmoDetails } from '../../../actions/information-card.action';
import { AppState } from '../../../models/appState';
import localDate from '../../../utils/date/localDate';

@Component({
    selector: 'app-emodetails-card',
    templateUrl: './emodetails-card.component.html'
})
export class EmoDetailsCardComponent implements OnInit {

    shippedSubScription: Subscription;
    userDetailSubscription: Subscription;
    emodetailsData: any[] = [];
    totalCount: number;
    emodetailsDataCount: number;
    emplID: string;
    skip: number = 0;
    limit: number = 20;
    sortObj: any = {
        "emodate": -1
    };
    constructor(
        private store: Store<AppState>,
        private router: Router
    ) { }

    ngOnInit() {
        this.shippedSubScription = this.store.pipe(select(state => state.InformationCard.emodetails))
            .subscribe(data => {
                if (data) {
                    const {
                        emodetailsData = [], totalCount
                    } = data;
                    if (emodetailsData.length) {
                        this.emodetailsData = emodetailsData;
                        this.totalCount = totalCount;
                        this.emodetailsDataCount = emodetailsData.length;
                    }
                }
            });

        this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
            .subscribe(userDetailObj => {
                const {
                    details
                } = userDetailObj;
                this.emplID = details["employee_id"];
                if (this.emplID && !this.emodetailsDataCount) {
                    this.fetchRecord();
                }
            })
    }


    ngOnDestroy() {
        this.store.dispatch(new ReSetEmoDetails());
        this.shippedSubScription.unsubscribe();
        this.userDetailSubscription.unsubscribe();
    }

    fetchRecord = () => {
        let obj = {
            filter: {
                projectmanagerid: this.emplID,
                shipped : false
            },
            skip: this.skip,
            limit: this.limit,
            sort: this.sortObj
        };
        this.store.dispatch(new GetEmoDetails(obj));
    }

    onScroll = () => {
        let difference = this.totalCount - this.emodetailsDataCount;
        if (difference >= 1) {
            if (this.skip <= this.emodetailsDataCount) {
                this.skip = this.emodetailsDataCount;
                this.fetchRecord();
            }
        }
    }

    viewemodetailsReport = (emoid) =>{
        this.router.navigateByUrl(`/emodetails/${emoid}`);
        return;
    }

    localDateWrapper = (date) => {
        return date ? localDate(date, 'DD-MMM-YYYY') : '';
    }
}
