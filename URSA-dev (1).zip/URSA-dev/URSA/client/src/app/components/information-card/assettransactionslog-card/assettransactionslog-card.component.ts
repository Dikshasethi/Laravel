import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { GetAssetTransactionLogs, ReSetAssetTransactionLogs } from '../../../actions/information-card.action';
import { AppState } from '../../../models/appState';
import localDate from '../../../utils/date/localDate';

@Component({
    selector: 'app-assettransactionslog-card',
    templateUrl: './assettransactionslog-card.component.html'
})
export class AssetsTransactionsLogCardComponent implements OnInit {

    userDetailSubscription: Subscription;
    assettransactionlogsSubscription: Subscription;
    userID: string;
    assetsTransactionLogsData: any[] = [];
    totalCount: number;
    assetsTransactionLogsDataCount: number;
    skip: number = 0;
    limit: number = 20;
    sortObj: any = {
        "activitydate": -1
    };
    constructor(
        private store: Store<AppState>
    ) { }

    ngOnInit() {
        this.assettransactionlogsSubscription = this.store.pipe(select(state => state.InformationCard.assettransactionlogsdetail))
            .subscribe(data => {
                if (data) {
                    const {
                        assettransactionlogsData = [], totalCount
                    } = data;
                    if (assettransactionlogsData.length) {
                        this.assetsTransactionLogsData = assettransactionlogsData;
                        this.totalCount = totalCount;
                        this.assetsTransactionLogsDataCount = assettransactionlogsData.length;
                    }
                }
            });

        this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
            .subscribe(userDetailObj => {
                const {
                    details
                } = userDetailObj;
                this.userID = details["login"];
                if (this.userID && !this.assetsTransactionLogsDataCount) {
                    this.fetchRecord();
                }
            })
    }

    ngOnDestroy() {
        this.store.dispatch(new ReSetAssetTransactionLogs());
        this.assettransactionlogsSubscription.unsubscribe();
        this.userDetailSubscription.unsubscribe();
    }

    fetchRecord = () => {
        let obj = {
            filter: {
                createdby: this.userID
            },
            skip: this.skip,
            limit: this.limit,
            sort: this.sortObj
        };
        this.store.dispatch(new GetAssetTransactionLogs(obj));
    }

    onScroll = () => {
        let difference = this.totalCount - this.assetsTransactionLogsDataCount;
        if (difference >= 1) {
            if (this.skip <= this.assetsTransactionLogsDataCount) {
                this.skip = this.assetsTransactionLogsDataCount;
                this.fetchRecord();
            }
        }
    }

    localDateWrapper = (date) => {
        return date ? localDate(date, 'DD-MMM-YYYY') : '';
    }

}