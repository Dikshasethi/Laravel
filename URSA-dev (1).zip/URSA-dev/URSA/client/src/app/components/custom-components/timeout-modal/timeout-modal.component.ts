import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppState } from '../../../models/appState';

@Component({
  selector: 'app-timeout-modal',
  templateUrl: './timeout-modal.component.html',
  styleUrls: ['./timeout-modal.component.css']
})

export class TimeoutModalComponent implements OnInit {

  constructor(private store: Store<AppState>) { }

  authDurationReference: any = {};
  userRefrence : any = {};
  @Output() generateHash: EventEmitter<any> = new EventEmitter<any>();
  @Input() currentUser : String;
  @Input() remainingDuration : any;
  @Input() userDetailsLoading: any;
  @Input() disableRefreshButton: any;
  @Input() modalState: any;

  ngOnInit() {}


  timerRefresh = async() =>{
    //Check if auth duration is still valid
    if (this.remainingDuration > 0){
      //Duration Is still Good, Refresh User Timeout
      this.generateHash.emit();
    }
  }

}
