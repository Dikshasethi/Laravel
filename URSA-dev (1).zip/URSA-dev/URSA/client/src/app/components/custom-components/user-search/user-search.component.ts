import { Component, OnInit, Input, Output, SimpleChange, EventEmitter, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-user-search',
  templateUrl: './user-search.component.html',
  styleUrls: ['./user-search.component.css']
})
export class UserSearchComponent implements OnInit {

  @Input() inputClass : string;
  @Input() isLoadUserSearch : Boolean;
  @Input() userManagementIsLoading : Boolean;
  @Output() toggleUserSearchModal: EventEmitter<any> = new EventEmitter();
  @Output() onInput: EventEmitter<any> = new EventEmitter();
  @Output() addUser: EventEmitter<any> = new EventEmitter();
  
  @Input()
  set autoFillData( val ) {
    if( val ){  this._autoFillData = val; }    
  }

  _autoFillData : any = []

  constructor() {}
  ngOnInit() {}

  toggleModal(){
    this.toggleUserSearchModal.emit();
  }
  onKeyPress(text){
    this.onInput.emit(text);
  }

  onAddUser(userToAdd){
    this.addUser.emit(userToAdd)
  }
}
