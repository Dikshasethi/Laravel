import { AppState } from '../../../models/appState';
import { Component, Input, Output, EventEmitter, OnInit,HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription'
import { PersonalizationModel } from '../../../utils/personalization/personalizationModel';
import { GetPersonalizationTableColumnData, ResetPersonalizationTableColumnData, AddPersonalizationTableColumnData , UpdatePersonalizationTableColumnData, DeleteTableColumnPersonalizationData} from '../../../actions/tableColumnOrderPersonalization.action';
import * as _ from 'lodash';
import { DragulaService } from "ng2-dragula";
import { appId} from '../../../utils/config/config';

@Component({
  selector: 'app-tableColumnOrder-personalization-modal',
  templateUrl: './tableColumnOrder-personalization-modal.component.html',
  styleUrls: ['./tableColumnOrder-personalization-modal.component.css']
})
export class TableColumnOrderPersonalizationModalComponent implements OnInit {
  TABLE_ITEMS = 'TABLE_ITEMS';
  constructor(private store: Store<AppState>,private router: Router, private dragulaService: DragulaService) { 
    this.dragulaService
    .drop()
    .subscribe(value => {
      this.updateTableColumnOrder();
      this.currentVal=value;
    }); 
 
  }
  currentVal={};
  @Input() tableColumnPersonalizationModalDisplay:boolean;
  @Input() componentType;
  @Input() componentTypePrefix : any='';
  @Output() closeModal: EventEmitter<any> = new EventEmitter();
  @Output() setDefaultTableColumnOrder: EventEmitter<any> = new EventEmitter();
  @Input() tableBuilderList: any;
  personalizationObject: PersonalizationModel = new PersonalizationModel();
  tableColumnPersonalizationSubscription: Subscription;
  userDetailSubscription: Subscription;
  totalCount: number;
  defaultCustodian: string;
  defaultCustodianCode: any;
  permissions: any[];
  personalizationTableColumnData=[];
  addedPersonalizationTableColumnLoading: boolean = false;
  updatePersonalizationTableColumnDataLoading: boolean = false;
  personalizationTableColumnLoading: boolean = false;
  deletedPersonalizationTableColumnLoading: boolean = false;
  personalizationTableColumnError: any = {};
  empId: any;
  skip: Number = 0;
  limit: Number = 10;
  personalizationDataCount: number;
  sort :any = {};
  filters: any = {
    name: '',
  }
  alertState: string;
  alertMessage: string;
  isShowAlert: boolean = false;
  filteredTableBuilderList: any[];
  hiddenTableColumns=[];
  visibleTableColumns=[];
  tableColumnPersonalizationData={};
  personalizationData=[];

  ngOnInit() {
    this.initUiBuilder(this.tableBuilderList);
   
    this.tableColumnPersonalizationSubscription = this.store.pipe(select(state => state.TableColumnPersonalization))
    .subscribe(personalizationData => {
      const {
        personalizationTableColumnData:  {  personalizationTableColumnData, personalizationTableColumnLoading, personalizationTableColumnError, totalCount },
        addedPersonalizationTableColumnData:{  addedPersonalizationTableColumnData,  addedPersonalizationTableColumnLoading },
        updatePersonalizationTableColumnData:{updatePersonalizationTableColumnData,  updatePersonalizationTableColumnDataLoading} ,
        deletedPersonalizationTableColumnData: { deletedPersonalizationTableColumnData ,  deletedPersonalizationTableColumnLoading  },
        errorState: { error = false, error_message },
      }  = personalizationData

        this.personalizationTableColumnLoading = personalizationTableColumnLoading;
        this.addedPersonalizationTableColumnLoading = addedPersonalizationTableColumnLoading;
        this.updatePersonalizationTableColumnDataLoading=updatePersonalizationTableColumnDataLoading;
        this.personalizationTableColumnError = personalizationTableColumnError;
        this.deletedPersonalizationTableColumnLoading = deletedPersonalizationTableColumnLoading;
        
      
       if(personalizationTableColumnData && !personalizationTableColumnLoading){
          this.personalizationTableColumnData = personalizationTableColumnData;
       }
       
       if (!_.isEmpty(addedPersonalizationTableColumnData) && !addedPersonalizationTableColumnLoading && !personalizationTableColumnLoading && !addedPersonalizationTableColumnData['hasError']) {
            this.fetchPersonalizationTableColumnData();
            this.closeModalFunction();
       }

        if (!_.isEmpty(updatePersonalizationTableColumnData) && !updatePersonalizationTableColumnDataLoading && !personalizationTableColumnLoading && !updatePersonalizationTableColumnData['hasError']) {
              this.fetchPersonalizationTableColumnData();
              this.closeModalFunction();
        }
        
        if(!this.personalizationTableColumnData.length  && !deletedPersonalizationTableColumnLoading && !_.isEmpty(deletedPersonalizationTableColumnData) && !deletedPersonalizationTableColumnData['hasError']){
          this.hiddenTableColumns=[]; 
          this.tableColumnPersonalizationData={};
          this.initUiBuilder(this.tableBuilderList);
         }

        if (!_.isEmpty(deletedPersonalizationTableColumnData) && !deletedPersonalizationTableColumnLoading && !personalizationTableColumnLoading && !deletedPersonalizationTableColumnData['hasError']) {
              this.fetchPersonalizationTableColumnData();
              this.setDefaultTableColumnOrder.emit(this.filteredTableBuilderList);
              this.closeModalFunction();
        }

        if(!_.isEmpty(this.personalizationTableColumnData) && !addedPersonalizationTableColumnLoading && !personalizationTableColumnLoading && !updatePersonalizationTableColumnDataLoading){
            this.initTableColumnOrderIfExists();  
            this.updateTableColumnOrder();
        }

        

        if (error) {
          this.showErrorMessage('error',error_message);
        }
    })

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(userDetailObj => {
      const {
        details
      } = userDetailObj;
      this.defaultCustodian = details['first_name'] +' '+ details['last_name'];
      this.defaultCustodianCode = details['employee_id'] ;
      this.empId = details['employee_id'] ;
      this.permissions = details['permission'] || [];
      if(this.empId && !this.personalizationTableColumnData.length){
        this.fetchPersonalizationTableColumnData();
      }
    })
  }

  fetchPersonalizationTableColumnData = () => { 
    let updatedFilter = {
      userId:  this.empId,
      appId: appId,
      personalizationType: this.componentType+this.componentTypePrefix+'TableColumn'
    }
    let obj={
      "filter": updatedFilter,
    }
    this.store.dispatch(new GetPersonalizationTableColumnData(obj));
  }

  arraySorter(columnarray,dataArrayObjects)
  {
    const visibleArrSorter = (a, b) => {
      return columnarray.indexOf(a.dataKey) - columnarray.indexOf(b.dataKey);
     };
     return dataArrayObjects.sort(visibleArrSorter);
  }

  initTableColumnOrderIfExists() {
   this.initUiBuilder(this.tableBuilderList);
    for(let i = 0; i < this.personalizationTableColumnData.length; i++) {
      this.personalizationData=this.personalizationTableColumnData[i];
    }
    if(this.personalizationData['data'] && !_.isEmpty(this.personalizationData['data'])){
      let visibleColumnarray=this.personalizationData['data']['visibleColumn'] ? this.personalizationData['data']['visibleColumn'] : []; 
      let hiddenColumnarray=this.personalizationData['data']['hiddenColumn'] ? this.personalizationData['data']['hiddenColumn'] : [];
      let newColumntoadd=[],newvisibleDataArrayObjects=[],newhiddenDataArrayObjects=[]; 

      for(let i = 0; i < this.filteredTableBuilderList.length; i++){
        let value=this.filteredTableBuilderList[i];
        if(value['dataKey']){
            if(!visibleColumnarray.includes(value['dataKey']) && !hiddenColumnarray.includes(value['dataKey'])){
              newColumntoadd.push(value);
            }
            if(visibleColumnarray.includes(value['dataKey'])){  
              newvisibleDataArrayObjects.push(value); 
            }
            if(hiddenColumnarray.includes(value['dataKey'])){  
              newhiddenDataArrayObjects.push(value); 
            }   
        }
      }
       this.hiddenTableColumns=this.arraySorter(hiddenColumnarray,newhiddenDataArrayObjects).concat(newColumntoadd);
       this.filteredTableBuilderList=this.arraySorter(visibleColumnarray,newvisibleDataArrayObjects)

    }
  }

  isResetButtonDisabled(){
    return !(!_.isEmpty(this.personalizationTableColumnData));  
  }

  isSaveButtonDisabled(){
    return !(!_.isEmpty(this.currentVal) && !_.isEmpty(this.tableColumnPersonalizationData));  
  }

  updateTableColumnOrder= () => {
    let visibleColumns=[]; let hiddenColumns = [];
    for(let i = 0; i < this.filteredTableBuilderList.length; i++){
      let value=this.filteredTableBuilderList[i];
      if(value['dataKey']){
        visibleColumns.push(this.filteredTableBuilderList[i].dataKey);
      }
    }
    for(let i = 0; i < this.hiddenTableColumns.length; i++){
      let value=this.hiddenTableColumns[i];
      if(value['dataKey']){
        hiddenColumns.push(this.hiddenTableColumns[i].dataKey);
      }
    }
    this.tableColumnPersonalizationData['visibleColumn']=visibleColumns;
    this.tableColumnPersonalizationData['hiddenColumn']=hiddenColumns;
  }

  onSubmit() {
    let data={
      "appId": appId,
      "name": this.componentType+this.componentTypePrefix+'_'+this.empId,
      "userId": this.empId,
      "personalizationType": this.componentType+this.componentTypePrefix+'TableColumn',
      "isDefault": true,
      "data": this.tableColumnPersonalizationData
    }
    if(!_.isEmpty(this.personalizationTableColumnData)){
      this.store.dispatch(new UpdatePersonalizationTableColumnData(data));
    }
    else {
      this.store.dispatch(new AddPersonalizationTableColumnData(data));
    }
  }


  onReset() {
    for(let i = 0; i < this.personalizationTableColumnData.length; i++) {
      let obj={
        idList : [this.personalizationTableColumnData[i]._id]
      }
      this.store.dispatch(new DeleteTableColumnPersonalizationData(obj)); }
  }


  showErrorMessage(state,message) {
    if (state === "error") {
      this.alertState = "alert-danger";
    } else {
      this.alertState = "alert-success";
    }
    this.alertMessage = message.error.message
    this.isShowAlert = true;
  }
  
  removeAlertIcon() {
    this.isShowAlert = false;
  }

  ngOnDestroy(){
    this.tableColumnPersonalizationSubscription.unsubscribe();
    this.store.dispatch(new ResetPersonalizationTableColumnData());
  }
  
  closeModalFunction = () => {
    this.closeModal.emit();
  }

  initUiBuilder = (tableBuilderList) => {
    let array = [];
    for(let i = 0; i < tableBuilderList.length; i++){
      let column = tableBuilderList[i];
      let {useIn=[]} = column;
      if (useIn.includes(this.componentType)) {
        array.push(column);
      }
    }
    this.filteredTableBuilderList = array;
    this.filteredTableBuilderList = this.filteredTableBuilderList.filter(function(val) {
      return val.headerType!="action" && val.bodyType!="action";
    });
  }

}
