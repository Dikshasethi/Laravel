import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TableColumnOrderPersonalizationModalComponent } from './tableColumnOrder-personalization-modal.component';

describe('TableColumnOrderModalComponent', () => {
  let component: TableColumnOrderPersonalizationModalComponent;
  let fixture: ComponentFixture<TableColumnOrderPersonalizationModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TableColumnOrderPersonalizationModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableColumnOrderPersonalizationModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
