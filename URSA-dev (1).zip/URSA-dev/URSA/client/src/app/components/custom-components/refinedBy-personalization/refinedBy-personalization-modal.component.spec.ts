import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RefinedByPersonalizationModalComponent } from './refinedBy-personalization-modal.component';

describe('RefinedByModalComponent', () => {
  let component: RefinedByPersonalizationModalComponent;
  let fixture: ComponentFixture<RefinedByPersonalizationModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RefinedByPersonalizationModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RefinedByPersonalizationModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
