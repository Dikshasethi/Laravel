import { Component, OnInit, Input, Output, EventEmitter, SimpleChange } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Router, ActivatedRoute } from '@angular/router';
import { AppState } from '../../../models/appState';
import * as _ from 'lodash';

@Component({
  selector: 'app-confirmation-modal',
  templateUrl: './confirmation-modal.component.html',
  styleUrls: ['./confirmation-modal.component.css']
})
export class ConfirmationModalComponent implements OnInit {
  confirmationModal: string = 'none';
  @Input() showConfirmationModal: boolean = false;
  @Input() confirmationActionButtonElements: any;
  @Input() confirmationModalMessage: string = '';
  @Input() confirmModalClass: string = '';
  @Output() resetConfirmationModal = new EventEmitter<any>();
  @Output() confirmationButtonAction = new EventEmitter<any>();
  constructor(
    private store: Store<AppState>, 
    private route:ActivatedRoute, 
    private router:Router
  ) { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChange) {
    if(
      changes['showConfirmationModal'] &&
      (
        !_.isEqual(
          changes['showConfirmationModal']['currentValue'],
          changes['showConfirmationModal']['previousValue']
        ) 
      )
    ){
      this.showModal();
    }
  }

  private showModal = () => {
    if(this.showConfirmationModal) {
      this.confirmationModal = 'block';
    }
  }

  triggerSubmit = (type) => {
    this.confirmationButtonAction.emit(type)
    this.closeConfirmationModal()
  }
  
  closeConfirmationModal = () => {
    this.resetModal();
  }

  resetModal = () => {
    this.confirmationModal = 'none';
    this.resetConfirmationModal.emit();
  } 
}
