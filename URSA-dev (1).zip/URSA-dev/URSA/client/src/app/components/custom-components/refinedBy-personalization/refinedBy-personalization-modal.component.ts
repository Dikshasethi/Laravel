import { AppState } from '../../../models/appState';
import { Component, Input, Output, EventEmitter, OnInit,HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription'
import { GetPersonalizationRefinedByData, DeleteFromPersonalizationDataList, NameCheckPersonalization, AddPersonalizationRefinedByData,ResetPersonalizationData , UpdatePersonalizationRefinedByData,TriggerSearchPersonalization} from '../../../actions/refinedBy-personalization.action';
import { PersonalizationModel } from '../../../utils/personalization/personalizationModel';
import * as _ from 'lodash';
import { appId , RefineBy} from '../../../utils/config/config';

@Component({
  selector: 'app-refinedBy-personalization-modal',
  templateUrl: './refinedBy-personalization-modal.component.html',
  styleUrls: ['./refinedBy-personalization-modal.component.css']
})
export class RefinedByPersonalizationModalComponent implements OnInit {

  constructor(private store: Store<AppState>,private router: Router ) { }

  @Input() personalizationModalDisplay:boolean;
  @Input() filterobj;
  @Output() closeModal: EventEmitter<any> = new EventEmitter();
  @Output() triggerSearch = new EventEmitter<{ data: any }>();

  personalizationObject: PersonalizationModel = new PersonalizationModel();
  PersonalizationSubscription: Subscription;
  userDetailSubscription: Subscription;
  personalizationRefinedByData=[];
  deletedPersonalizationRefinedByLoading: boolean = false;
  addedPersonalizationRefinedByDataLoading: boolean = false;
  personalizationRefinedByLoading: boolean = false;
  updatePersonalizationRefinedByDataLoading: boolean = false;
  isRefreshData=false;
  totalCount: number;
  defaultCustodian: string;
  defaultCustodianCode: any;
  permissions: any[];
  empId: any;
  skip: Number = 0;
  limit: Number = 10;
  personalizationDataCount: number;
  sort :any = {};
  filters: any = {
    name: '',
  }
  cancelDeleteModalDisplay: string = 'none';
  confirmationMessage = '';
  selectedData = [];
  personalizationRefinedByError: any = {};
  nameCheckPersonalizationRefinedBy: any = {};
  nameCheckPersonalizationRefinedByLoading: boolean = false;
  nameErrorDisplay='none';
  public innerHeight: any;
  alertState: string;
  alertMessage: string;
  isShowAlert: boolean = false;

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerHeight = window.innerHeight;
  }
  ngOnInit() {
    this.innerHeight = window.innerHeight;
    this.PersonalizationSubscription = this.store.pipe(select(state => state.Personalization))
    .subscribe(personalizationData => {

        const {
          personalizationRefinedByData:  {  personalizationRefinedByData, personalizationRefinedByLoading, personalizationRefinedByError, totalCount },
          deletedPersonalizationRefinedByData: { deletedPersonalizationRefinedByData,  deletedPersonalizationRefinedByLoading },
          addedPersonalizationRefinedByData:{  addedPersonalizationRefinedByData,  addedPersonalizationRefinedByDataLoading },
          updatePersonalizationRefinedByData:{updatePersonalizationRefinedByData,  updatePersonalizationRefinedByDataLoading} ,
          errorState: { error = false, error_message },
          nameCheckPersonalizationRefinedBy,nameCheckPersonalizationRefinedByLoading
          }  = personalizationData

         this.personalizationRefinedByLoading = personalizationRefinedByLoading;
         this.deletedPersonalizationRefinedByLoading = deletedPersonalizationRefinedByLoading;
         this.addedPersonalizationRefinedByDataLoading = addedPersonalizationRefinedByDataLoading;
         this.updatePersonalizationRefinedByDataLoading=updatePersonalizationRefinedByDataLoading;
         this.personalizationRefinedByError = personalizationRefinedByError;
         

        if(personalizationRefinedByData && !personalizationRefinedByLoading){
          this.personalizationRefinedByData = personalizationRefinedByData;
          this.totalCount = totalCount;
          this.personalizationDataCount = personalizationRefinedByData.length;
        }

        if(nameCheckPersonalizationRefinedBy && !_.isEmpty(nameCheckPersonalizationRefinedBy) && !nameCheckPersonalizationRefinedByLoading) {
            this.nameCheckPersonalizationRefinedBy=nameCheckPersonalizationRefinedBy;
            if(this.nameCheckPersonalizationRefinedBy.available==true){
              this.nameErrorDisplay='none';
              this.addPersonalization();
            }
            else { this.nameErrorDisplay='block';}
        }

        if (!_.isEmpty(deletedPersonalizationRefinedByData) && !deletedPersonalizationRefinedByLoading && !personalizationRefinedByLoading && !deletedPersonalizationRefinedByData['hasError']) {
          this.skip = 0;
          this.fetchPersonalizationRefinedByData();
        }

        
        if (!_.isEmpty(addedPersonalizationRefinedByData) && !addedPersonalizationRefinedByDataLoading && !personalizationRefinedByLoading && !addedPersonalizationRefinedByData['hasError']) {
          this.skip = 0;
          this.fetchPersonalizationRefinedByData();
        }

        if (!_.isEmpty(updatePersonalizationRefinedByData) && !updatePersonalizationRefinedByDataLoading && !personalizationRefinedByLoading && !updatePersonalizationRefinedByData['hasError']) {
          this.skip = 0;
          this.fetchPersonalizationRefinedByData();
        }
  
        if (error) {
          this.showErrorMessage('error',error_message);
        }

    })

    this.userDetailSubscription = this.store.pipe(select(state => state.UserDetail))
    .subscribe(userDetailObj => {
      const {
        details
      } = userDetailObj;
      this.defaultCustodian = details['first_name'] +' '+ details['last_name'];
      this.defaultCustodianCode = details['employee_id'] ;
      this.empId = details['employee_id'] ;
      this.permissions = details['permission'] || [];
      if(this.empId && !this.personalizationRefinedByData.length){
        this.fetchPersonalizationRefinedByData();
      }
    })
  }


  closeModalFunction = () => {
    this.closeModal.emit();
  }

  removeAlertIcon() {
    this.isShowAlert = false;
  }
 
  showErrorMessage(state,message) {
    if (state === "error") {
      this.alertState = "alert-danger";
    } else {
      this.alertState = "alert-success";
    }
    this.alertMessage = message.error.message
    this.isShowAlert = true;
  }

  fetchPersonalizationRefinedByData = () => {
    let updatedFilter = {
      ...this.filters,
      userId:  this.empId,
      appId: appId,
      personalizationType: RefineBy
    }
    let obj={
      "limit" : this.limit,
      "filter": updatedFilter,
      "skip" : this.skip,
      "sort": this.sort
    }
    this.store.dispatch(new GetPersonalizationRefinedByData(obj));
  }
  

  removePersonalizationItem(items) {
    let obj={
      idList : items
    }
    this.store.dispatch(new DeleteFromPersonalizationDataList(obj));

  }

  updateFilter(map: string, event){
    this.filters[map] = event.target.value;
    this.store.dispatch(new ResetPersonalizationData());
    this.executeFilter();
  }

  
  executeFilter(){
    this.skip = 0;
    this.fetchPersonalizationRefinedByData();
  }

  checkQueryNameExist(name)
  {
    let obj = {
      userId:  this.empId,
      appId: appId,
      personalizationType: RefineBy,
      name:name
    }
    this.store.dispatch(new NameCheckPersonalization(obj));
  }

  onSubmit() {
    let payload = this.personalizationObject;
    this.checkQueryNameExist(payload.name);
  }

  addPersonalization()
  {
     let payload = this.personalizationObject;
     let data={
        "appId": appId,
        "name": payload.name,
        "userId": this.empId,
        "personalizationType": RefineBy,
        "isDefault": false,
        "data": this.filterobj
      }
      this.store.dispatch(new AddPersonalizationRefinedByData(data));
      this.personalizationObject['name']= '';
  }

  markAsDefault(refinedByData, i) {
    this.store.dispatch(new UpdatePersonalizationRefinedByData(refinedByData)); 
    if(refinedByData.isDefault==false) {
      if(sessionStorage.getItem('defaultRefiendByPersonalization')){
        sessionStorage.removeItem('defaultRefiendByPersonalization') 
      }
      sessionStorage.setItem('defaultRefiendByExists', JSON.stringify(false));
    } else{ 
      sessionStorage.setItem('defaultRefiendByPersonalization', JSON.stringify(refinedByData.data));
      sessionStorage.setItem('defaultRefiendByExists', JSON.stringify(true));
    }
  }

  onTriggerSearch(data) {
    this.triggerSearch.emit(data);   
    this.closeModal.emit();
  }

  overwriteQuery(data, i)
  {
    let dataObj={
      ...data,
      "data": this.filterobj
    }
    this.store.dispatch(new UpdatePersonalizationRefinedByData(dataObj));
  }

  isSubmitButtonDisabled(btntype) {
    if(btntype=='save'){
      return !((this.personalizationObject['name'] != '') && !_.isEmpty(this.filterobj));  }
    else
    { return !(!_.isEmpty(this.filterobj));  }
  }

  onScroll = () => {
    let difference = this.totalCount - this.personalizationDataCount;
    if (difference >= 1) {
        if (this.skip <= this.personalizationDataCount) {
            this.skip = this.personalizationDataCount;
            this.fetchPersonalizationRefinedByData();
        }
    }
  }
  
  ngOnDestroy(){
    this.PersonalizationSubscription.unsubscribe();
  }

  errorDisplayFunction = () => {  
    if (this.personalizationRefinedByError) {
      return 'block';
    } else {
      return 'none';
    }
  }

}
