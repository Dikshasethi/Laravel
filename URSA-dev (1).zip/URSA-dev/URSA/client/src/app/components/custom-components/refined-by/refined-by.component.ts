import { Component, OnInit, Input, Output, SimpleChange, EventEmitter } from '@angular/core';
import { Store, select } from '@ngrx/store';
import {AppState} from '../../../models/appState';
import * as _ from 'lodash';
import { SetFilters, SetRefinedByField } from '../../../actions/refinedBy.actions';
import { Options, LabelType } from 'ng5-slider';

@Component({
  selector: 'app-refined-by',
  templateUrl: './refined-by.component.html',
  styleUrls: ['./refined-by.component.css']
})
export class RefinedByComponent implements OnInit {
  @Input() refinedByList;
  @Input() data : {};
  @Input() searchCount : Number;
  @Input() refinedByNgrxKey;
  @Input() activeView;
  @Output() filterChangeAction: EventEmitter<any>  = new EventEmitter();
  @Output() resetListAction: EventEmitter<any>  = new EventEmitter();
  @Output() resetParentViewMetadata: EventEmitter<any>  = new EventEmitter();
  filterObject = {};
  personalizationFilterData={}; 
  masterObject = {};
  keyMapper = {};
  loopedObject = {};
  objectKeys = Object.keys;
  listStateTracker = {};
  lastFilterSectionClicked=[];
  currentDataCopy;
  refinedBySubscription;
  storeObject={};

  utilazationMinPercentage: number = 0;
  utilazationMaxPercentage: number = 100;
  daysLastCheckedinMin: number = 0;
  daysLastCheckedinMax: number = 365;

  personalizationModalDisplay: boolean = false;

  sliderOptions: Options = {
      floor: 0,
      ceil: 100,
      translate: (value: number, label: LabelType): string => {
        switch (label) {
            case LabelType.Low:
                return `${value} %`;
            case LabelType.High:
              return `${value} %`;
            default:
              return `${value}`;
        }
    }
  };

  lastCheckedinSliderOptions: Options = {
    floor: 0,
    ceil: 365,
    translate: (value: number, label: LabelType): string => {
      switch (label) {
          case LabelType.Low:
              return `${value}`;
          case LabelType.High:
            return `${value}`;
          default:
            return `${value}`;
      }
  }
  };
  constructor(
    private store: Store<AppState>
  ) {}

  ngOnInit() {
    this.setKeyMapper(this.refinedByList);
    this.refinedBySubscription = this.store.pipe(select(state => state.RefinedBy))
    .subscribe(filterObject => {
      if(filterObject){
        this.storeObject = Object.assign({}, filterObject);
        this.instantiateNgrxState(filterObject);
        this.initializeListLengthState(this.refinedByList, 'ngoninit');
        this.handleRefinedByFreeze(this.lastFilterSectionClicked, this.filterObject);
        let data = Object.assign({}, this.data); //this contains each filters objects
        this.parseData(data);
      }
    });
  }

  ngOnDestroy(){
    if(this.refinedBySubscription){  this.refinedBySubscription.unsubscribe();  }
  }

  ngOnChanges(changes: SimpleChange){
    let dataReference = changes['data'];
    let refinedByListInput = changes['refinedByList'];
    let ngrxKey = changes['refinedByNgrxKey'];
    let dataProp = Object.assign({}, dataReference);
    let count = changes['searchCount'];

    if(count){
      if(!_.isEqual(count.currentValue, count.previousValue)){
        this.initializeListLengthState(this.refinedByList, 'ngOnChanges')
      }
    }

    if(dataProp){
      let currentDataProp = dataProp.currentValue;
      let previousDataProp = dataProp.previousValue;
      if(!_.isEqual(currentDataProp, previousDataProp)){
        this.parseData(currentDataProp);
      }
    }

    if(refinedByListInput){
      if(!_.isEqual(refinedByListInput.currentValue, refinedByListInput.previousValue)){
        this.initFunction(this.data);
      }
    }

    if(ngrxKey){
      if(!_.isEqual(ngrxKey.currentValue, ngrxKey.previousValue)){
        this.initFunction(this.data);
      }
    }
  }

  initFunction = (data) => {
    this.setKeyMapper(this.refinedByList);
    this.instantiateNgrxState(this.storeObject);
    this.initializeListLengthState(this.refinedByList, 'initFunction');
    this.parseData(data);
  }

  instantiateNgrxState = (filterObject) => {
    if(this.refinedByNgrxKey && Object.keys(filterObject).length > 0){
      this.filterObject = filterObject[this.refinedByNgrxKey]['clickTracker'] || {};
      this.lastFilterSectionClicked = filterObject[this.refinedByNgrxKey]['lastFilterSectionClicked'] || [];
      this.listStateTracker = filterObject[this.refinedByNgrxKey]['listStateTracker'] || {};
      this.masterObject = filterObject[this.refinedByNgrxKey] || {};
    }
  }

  setKeyMapper = (refinedByList) => {
    let accumulator = {};
    if(refinedByList){
      for (let i = 0; i < refinedByList.length; i++){
        let refinedBy = refinedByList[i];
        const {label, value} = refinedBy;
        accumulator[label] = value
      }
    }
    this.keyMapper = accumulator;
  }

  initializeListLengthState = (refinedByList, area) => {
    let accumulator = {};
    if(refinedByList &&  !_.isEmpty(this.masterObject) && ((_.isEmpty(this.masterObject['listStateTracker']) || (Object.keys(this.masterObject['listStateTracker']).length==1 && this.masterObject['listStateTracker'].hasOwnProperty("Status")) && this.masterObject['listStateTracker']['Status']['hasSelectedFilters']==false)) 
    ) {
      for(let i = 0; i < refinedByList.length; i++){
        let refinedBy = refinedByList[i];
        const {label, value} = refinedBy;
        accumulator[label] = {
          hasSelectedFilters : false,
          fullViewLength : false
        } 
      }

      this.store.dispatch(new SetRefinedByField({
        refinedByNgrxKey : this.refinedByNgrxKey,
        field : 'listStateTracker',
        value : accumulator
      }))
    }
  }

  setFilterObject = (filterKey, filter, key) => {
    let refinedByNgrxKey = this.refinedByNgrxKey;
    let filterObject = Object.assign({}, this.filterObject || {});
    let filterKeyList = filterObject[filterKey];
    let updatedList;
    if(filterKeyList && filterKeyList.includes(filter)){
      updatedList = filterKeyList.filter(item => {
        return item !== filter;
      })
    }else {
      if(filterKeyList){
        updatedList = [...filterKeyList, filter];
      }else{
        updatedList = [filter];
      }
    }

    filterObject[filterKey] = updatedList;

    for (let k in filterObject){
      if(filterObject[k].length === 0){
        delete filterObject[k];
      }
    }
    if(!this.masterObject['lastFilterSectionClicked']){
      this.masterObject['lastFilterSectionClicked'] = [];
    }
    let newObj = {
      ...this.masterObject,
      lastFilterSectionClicked : [...this.masterObject['lastFilterSectionClicked'], filterKey],
      clickTracker : filterObject
    }
    if(
      !filterObject[filterKey] || 
      filterObject[filterKey].length === 0
    ){
      this.clearCheckedKeyItems(key);
      this.personalizationFilterData={}
    }else{
      this.handleRefinedByFreeze(
        [
          ...this.masterObject['lastFilterSectionClicked'], 
          filterObject[filterKey] && filterObject[filterKey].length > 0 ? filterKey : ''
        ], 
        filterObject
      );
      this.resetListAction.emit();
      this.resetParentViewMetadata.emit();
      this.store.dispatch(new SetFilters({key : refinedByNgrxKey, value : newObj}));
      this.personalizationFilterData=this.filterObject;
    }
  }

  parseData = (DATA) => {
    let refinedByObject = {};
    let refinedByList = this.refinedByList;
    let listStateTracker = this.listStateTracker;
    let data = this.dataPickerFunction(DATA);
    
    if(data && !_.isEmpty(data) && refinedByList && !_.isEmpty(this.listStateTracker)){
      for (let i = 0; i < refinedByList.length; i++){

        let checked = [];
        let unchecked = [];
        let consolidatedList;
        let listItem = refinedByList[i];
        const {label, value,type = ''} = listItem; 

        let subData = data[value] && data[value].map(item => item.key);
        if(['statusList'].includes(value)){
        }
        if (type === "slider") {
          refinedByObject[label] = ''
          continue;
        }
        if(subData){
          let filterObjectValue = this.filterObject[value];
          for (let k = 0; k < subData.length; k++){
            let subItem = subData[k];
            if (subItem == '-' || subItem == ''){
              continue;
            }

            if(filterObjectValue && filterObjectValue.includes(subItem)){
              checked.push(subItem);
            }else{
              unchecked.push(subItem);
            }
          }
          if(filterObjectValue){
            for (let z = 0; z < filterObjectValue.length; z++){
              let item = filterObjectValue[z];
              if(!subData.includes(item)){
                checked.push(item)
              }
            }
          }
          
        }
        checked.sort();
        unchecked.sort();
        if(listStateTracker[label] && listStateTracker[label]['fullListView']){
          consolidatedList = [...checked, ...unchecked];
        }else{
          let finalUncheckedList;
          let checkedListLength = checked.length;
          let difference = 5 - checkedListLength;
          if(difference > 0){
            finalUncheckedList = unchecked.slice(0, difference);
          }else{
            finalUncheckedList = [];
          }
          consolidatedList = [...checked, ...finalUncheckedList]
        }
        
        refinedByObject[label] = consolidatedList;
      }
      this.loopedObject = refinedByObject
    }
  }

  handleFilterSelection = (key, filter) => {
    let dataObject = Object.assign({}, this.data)
    let filterKey = this.keyMapper[key];
    this.setFilterObject(filterKey, filter, key);
    this.setListStateTrackerFilterKey(key, filterKey);
    this.parseData(dataObject);
  }

  ontriggerSearch(data)
  {
    for (let key in this.filterObject) {
      let filterKey=Object.keys(this.keyMapper).find(keys => this.keyMapper[keys] === key);
      this.masterObject['listStateTracker'][filterKey]['hasSelectedFilters'] = false;
    }
    for (let key in data) {
      let filterKey=Object.keys(this.keyMapper).find(keys => this.keyMapper[keys] === key);
      let list = data[key];
      let newObj2 = {
        ...this.masterObject,
        clickTracker : data,
        listStateTracker : {
          ...this.masterObject['listStateTracker'],
          [filterKey] : {
            ...this.masterObject['listStateTracker'][filterKey],
            hasSelectedFilters : list && list.length > 0 ? true : false
          }
        }
      }
      this.masterObject=newObj2;
    }
    this.resetListAction.emit();
    this.resetParentViewMetadata.emit();
    this.filterObject=this.masterObject['clickTracker'] ;
    this.store.dispatch(new SetFilters({key : this.refinedByNgrxKey, value :  this.masterObject})); 
  }
  handelSliderSelection = (key, filter) => {
    let filterKey = this.keyMapper[key];
    let filterKeyList = this.filterObject[filterKey];
    if (filterKeyList && filterKeyList.length > 0) this.filterObject[filterKey] = [];
    this.handleFilterSelection(key, filter);
    this.listStateTracker[key]['hasSelectedFilters'] = false;
  }

  listLengthCheckFunction = (key) => {
    if(this.listStateTracker[key]['fullListView']){
      return false;
    }
    return true;
  }

  toggleListLength = (key) => {
    let dataObject = Object.assign({}, this.data);
    let newObj = {
      ...this.masterObject,
      listStateTracker : {
        ...this.masterObject['listStateTracker'],
        [key] : {
          ...this.masterObject['listStateTracker'][key],
          fullListView : !this.masterObject['listStateTracker'][key]['fullListView']
        }
      }
    }
    this.store.dispatch(new SetFilters({key : this.refinedByNgrxKey, value : newObj}));
    this.parseData(dataObject);
  }

  setListStateTrackerFilterKey = (key, filterKey) => {
    let list = this.filterObject[filterKey];
    let newObj = {
      ...this.masterObject,
      listStateTracker : {
        ...this.masterObject['listStateTracker'],
        [key] : {
          ...this.masterObject['listStateTracker'][key],
          hasSelectedFilters : list && list.length > 0 ? true : false
        }
      }
    }
    this.store.dispatch(new SetFilters({key : this.refinedByNgrxKey, value : newObj}));
  }

  clearCheckedKeyItems = (key) => {
    this.personalizationFilterData={}
    let newLastFilterSectionClicked;
    let filterKey = this.keyMapper[key];
    let filterObject = {
      ...this.filterObject,
      [filterKey] : []
    }
    delete filterObject[filterKey];
    if(filterKey === this.lastFilterSectionClicked[this.lastFilterSectionClicked.length - 1]){
      newLastFilterSectionClicked = [...this.lastFilterSectionClicked, ''];
    }
    let sectionClickTracker = newLastFilterSectionClicked ? 
    newLastFilterSectionClicked : this.masterObject['lastFilterSectionClicked'] || [];

    let newObj = {
      ...this.masterObject,
      lastFilterSectionClicked : sectionClickTracker,
      clickTracker : filterObject,
      listStateTracker : {
        ...this.masterObject['listStateTracker'],
        [key] : {
          ...this.masterObject['listStateTracker'][key],
          hasSelectedFilters : false
        }
      }
    }

    this.handleRefinedByFreeze(sectionClickTracker, filterObject);
    this.resetListAction.emit(false);
    this.resetParentViewMetadata.emit();
    // this.filterChangeAction.emit();
    this.store.dispatch(new SetFilters({key : this.refinedByNgrxKey, value : newObj}));
  }

  checkFilterClicked = (key, filter) => {
    let filterKey = this.keyMapper[key];
    let list = this.filterObject[filterKey];
    if(
      list && list.includes(filter)
    ){
      return true;
    }else{
      return false;
    }
  }


  handleRefinedByFreeze = (filterSectionClickTracker, filterObject) => {
    let lastFilterSectionClicked = filterSectionClickTracker[filterSectionClickTracker.length - 1] || '';
    let nextToLastFilterSectionClicked = filterSectionClickTracker[filterSectionClickTracker.length - 2] || '';
    if(_.isEmpty(filterObject) || !lastFilterSectionClicked){
      this.lastFilterSectionClicked.push('');
      if(sessionStorage.getItem(`${this.refinedByNgrxKey}-frozen`)){
        sessionStorage.removeItem(`${this.refinedByNgrxKey}-frozen`);
      }
    }else{
      if(!_.isEqual(lastFilterSectionClicked, nextToLastFilterSectionClicked)){
        let cachedObj = JSON.parse(sessionStorage.getItem(`${this.refinedByNgrxKey}-frozen`)) || {};
        let newObject = {};
        if(cachedObj && cachedObj['label'] === lastFilterSectionClicked){
          newObject = cachedObj;
        }else{
          newObject = {
            label : lastFilterSectionClicked,
            value : this.data[lastFilterSectionClicked]
          }
        }
        sessionStorage.setItem(`${this.refinedByNgrxKey}-frozen`, JSON.stringify(newObject));
      }
    }
  }

  dataPickerFunction = (DATA) => {
    let lastFilterSectionClicked = this.lastFilterSectionClicked.slice(-1)[0];
    let storedData = sessionStorage.getItem(`${this.refinedByNgrxKey}-frozen`);
    if(storedData && lastFilterSectionClicked){
      let cachedObj = JSON.parse(storedData);
      let newObject = {
        ...DATA,
        [lastFilterSectionClicked] : cachedObj['value']
      }
      this.currentDataCopy = Object.assign({}, newObject);
      return newObject;
    }else{
      this.currentDataCopy = Object.assign({}, DATA);
      return DATA;
    }
  }

  filterClassFunction = (key, filter) => {
    let data = this.data[key] && this.data[key].map(item => item.key);
    if(data && !data.includes(filter)){
      return 'font-weight-light text-muted';
    }else{
      return '';
    }
  }

  openPersonalizationModal(){
    this.personalizationModalDisplay = true;
  }
 
  closePersonalisationModal() {
    this.personalizationModalDisplay = false;
  }
}