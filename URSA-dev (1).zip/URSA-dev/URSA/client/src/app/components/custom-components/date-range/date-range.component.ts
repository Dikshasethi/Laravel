import { Component, OnInit, Output, EventEmitter, ViewChild, Input,OnChanges  } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../models/appState';
import * as moment from 'moment';
import { SetDateRange } from '../../../actions/search.actions';
import { DaterangePickerComponent } from 'ng2-daterangepicker';
import localDate from '../../../utils/date/localDate';

@Component({
  selector: 'app-date-range',
  templateUrl: './date-range.component.html',
  styleUrls: ['./date-range.component.css']
})
export class DateRangeComponent implements OnInit {
  @Output() dateChangeSubmit: EventEmitter<any> = new EventEmitter();
  @Output() resetListAction: EventEmitter<any> = new EventEmitter();
  searchSubscription;

  @ViewChild(DaterangePickerComponent)
  private picker: DaterangePickerComponent;
  
  daterange: any = {
    startDate: Date.now(),
    endDate: Date.now()
  };
  options: any = {
    locale: localDate(Date.now(),{ format: 'DD-MMM-YYYY'}),
    alwaysShowCalendars: false,
    minDate: localDate(this.daterange['startDate'], {format : 'DD-MMM-YYYY'})
  }
  constructor(
    private store: Store<AppState>
  ) { }

  ngOnInit() {
    this.searchSubscription = this.store.pipe(select(state => state.Search))
      .subscribe(searchObject => {
        this.daterange = {
          startDate: searchObject.startDate,
          endDate: searchObject.endDate,
        }
      })
  }

  onDateSubmit(e: any) {
    this.store.dispatch(new SetDateRange({
      startDate: moment(e.picker.startDate).format('YYYY-MM-DD'),
      endDate: moment(e.picker.endDate).format('YYYY-MM-DD')
    }));
    this.resetListAction.emit(true);
    this.dateChangeSubmit.emit();
  }

  ngAfterViewInit() {
    this.picker.datePicker.setStartDate(localDate(this.daterange.startDate,'DD-MMM-YYYY'));
    this.picker.datePicker.setEndDate(localDate(this.daterange.endDate, 'DD-MMM-YYYY'));
  }

  ngOnDestroy() {
    if (this.searchSubscription) { this.searchSubscription.unsubscribe(); }
  }

}
