import { Component, OnInit, Input, Output, SimpleChange, EventEmitter, SimpleChanges } from '@angular/core';
import { state } from '@angular/animations';
import { IfObservable } from 'rxjs/observable/IfObservable';
import {buRefrence} from '../../../utils/config/config';
import {specialAreaRefrence} from '../../../utils/config/config';
import { async } from '@angular/core/testing';

@Component({
  selector: 'app-auto-complete',
  templateUrl: './auto-complete.component.html',
  styleUrls: ['./auto-complete.component.css']
})
export class AutoCompleteComponent implements OnInit {
  @Input() inputClass : string;
  @Input() inputStyle : string;
  @Input() displayKey : string;
  @Input() activeInputClass : string;
  @Input() inputText : any;
  @Input() placeholder : string;
  @Input() showPrependButton : boolean;
  @Input() predendButtonIcon : string;
  @Input() listWrapperStyle : {};
  @Input() listWrapperClass : string;
  @Input() prependButtonClass : string;
  @Input() suggestionClass : string;
  @Input() suggestionActiveClass : string;
  @Input() suggestionStyle : {};
  @Input() suggestionActiveStyle : {};
  @Input() prependButtonStyle : {};
  @Input() prependButtonWrapperStyle : {};
  @Input() listItemTypeField;
  @Input() listHeaderTypeText;
  @Input() isDisabled;
  @Input() hasRefrenceCode : string;
  
  @Output() inputSubmitAction: EventEmitter<any> = new EventEmitter();
  @Output() autocompleteSubmitAction: EventEmitter<any> = new EventEmitter();
  @Output() onInputChange: EventEmitter<any> = new EventEmitter();
  @Output() onFocusInput: EventEmitter<any> = new EventEmitter();
  @Output() onScrollLoad: EventEmitter<any> = new EventEmitter();

  @Input()
  set suggestionList( val ) {
    if( val ){  this._suggestionList = val; }    
  }

  _suggestionList : any = []
  currentInput : String = "";
  hasBuTag : boolean = false;
  hasSpecialArea : boolean = false;

  state = {
    activeIndex : -1,
    focus : false,
    showList : false
  };

  constructor() {}

  ngOnInit() {}

  setStateFunction = (field, value) => {
    this.state[field] = value;
  }

  dispatchInitialRequest = (text) => {
    this.onFocusInput.emit(text);
    this.setStateFunction('showList', true);
  }

  handleInputChange = (text) => {
    let buTag = '';
    let cleanText = '';
    this.hasBuTag = false;
    if(this.hasRefrenceCode){
      for(let bu of buRefrence){
        if(this.hasRefrenceCode === 'location' && text.toUpperCase().includes(bu)){
          buTag = bu;
          this.hasBuTag = true;
          break;
        }
        else if (this.hasRefrenceCode === 'area' && specialAreaRefrence.includes(text.toUpperCase())){
          this.hasSpecialArea = true;
          this.currentInput = text;

        }
      }
      if(this.hasBuTag){
        cleanText  = text.replace(` - ${buTag}`,'');
        this.currentInput = text;
        text = cleanText;
      }
    }
    this.setStateFunction('showList', true);
    this.onInputChange.emit(text);
  }

  listWrapperStyleFunction = () => {
    return {
      ...this.listWrapperStyle,
      overflow:'auto',
      position : 'absolute',
      'z-index' : 10000
    }    
  }

  getDropdownClass = (index) => {
    if(index === this.state.activeIndex){
      if(
        this.listItemTypeField && 
        this._suggestionList[index] && 
        this._suggestionList[index][this.listItemTypeField] === this.listHeaderTypeText
      ){
        return this.suggestionClass;
      }
      return this.suggestionActiveClass;
    }else{
      return this.suggestionClass;
    }
  }

  getDropdownStyle = (index) => {
    if(index === this.state.activeIndex){
      if(
        this.listItemTypeField && 
        this._suggestionList[index] && 
        this._suggestionList[index][this.listItemTypeField] === this.listHeaderTypeText
      ){
        return this.suggestionStyle;
      }
      return this.suggestionActiveStyle;
    }else{
      return this.suggestionStyle;
    }
  }

  executeSubmitAction = () => {
    this.inputSubmitAction.emit(this.inputText)
  }

  onSelection = (suggestion) => {
    this.inputText = '';
    this.autocompleteSubmitAction.emit(suggestion);
    this.setStateFunction('activeIndex', -1);
    this.setStateFunction('showList', false);
  }

  onScroll = () => {
    this.onScrollLoad.emit();
  }

  handleBlur = async() => {
    if( (this.hasBuTag || this.hasSpecialArea) && 
    this._suggestionList && 
    this._suggestionList.length > 0
    ){
      this.hasBuTag = false;
      for(let suggestion of this._suggestionList){
        if (suggestion[this.displayKey].toUpperCase() === this.currentInput.toUpperCase()){
          this.currentInput = '';
          await setTimeout(() =>{
            this.onSelection(suggestion);
          }, 200);
          break;
        }
      }    
    }
    this.setStateFunction('focus', false);
    this.setStateFunction('activeIndex', -1);
    this.setStateFunction('showList', false);
  }

  handleKeyPress = (e) => {
    const {activeIndex} = this.state;
    if(e.which === 40){
      if(activeIndex < this._suggestionList.length - 1 && this.inputText){
        this.setStateFunction('activeIndex', activeIndex + 1);
      }
    }

    if(e.which === 38){
      if(activeIndex > -1 && this.inputText){
        this.setStateFunction('activeIndex', activeIndex - 1);
      }
    }

    if(e.which === 13){
      this.setStateFunction('showList', false);
      if(activeIndex > -1){
        this.setStateFunction('activeIndex', -1);
        this.autocompleteSubmitAction.emit(this._suggestionList[activeIndex]);
      }else{
        this.inputSubmitAction.emit(this.inputText);
      }
    }
  }

}