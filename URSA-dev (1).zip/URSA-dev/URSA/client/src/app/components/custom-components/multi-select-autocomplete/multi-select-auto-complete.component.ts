import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'multi-selector-auto-complete',
    templateUrl: './multi-select-auto-complete.component.html',
    styleUrls: ['./multi-select-auto-complete.component.css']
})

export class MultiSelectAutoComplete {
    checkedList: any[] = [];
    selectedInputArray: any[] = [];
    bindLabel: string = '';
    bindValue: string = '';
    showDropDown: boolean;
    filteredData: any[] = [];
    selectedInput: any[] = [];
    inputvalue: string = '';
    @Input() list: any[] = [];
    @Input() multiSelectorType: string = '';
    @Output() shareCheckedList = new EventEmitter();
    @Output() fetchAutoCompleteApi = new EventEmitter();
    @Input()
    set multiSelectautoCompleteData(val) {
        const { bindLabel, bindValue, selectedInput } = val;
        this.bindLabel = bindLabel;
        this.bindValue = bindValue;
        this.selectedInput = selectedInput;
        if (this.multiSelectorType === 'dropdown') {
            this.checkedList = [...selectedInput];
        }
        this.mappSelectedInput();
    }

    constructor() { }

    ngOnInit() {
        this.checkedList = [...this.selectedInput];
        if (this.multiSelectorType === "autoComplete") {
            this.checkedList.forEach(val => {
                this.selectedInputArray.push({
                    Label: val,
                    Value: val
                })
            })
        }
    }

    ngOnDestroy() {
        this.checkedList = [];
        this.selectedInputArray = [];
    }

    mappSelectedInput() {
        if (this.multiSelectorType === 'dropdown') {
            this.selectedInputArray = [];
            this.list.forEach(record => {
                if (this.checkedList.indexOf(record[this.bindValue]) !== -1) {
                    record['checked'] = true;
                    this.selectedInputArray.push({
                        Label: record[this.bindLabel],
                        Value: record[this.bindValue]
                    })
                } else {
                    record['checked'] = false;
                }
            })
        } else {
            if (this.list.length) {
                let selectedInput = [];
                this.list.forEach(record => {
                    if (this.checkedList.indexOf(record[this.bindValue]) !== -1) {
                        record['checked'] = true;
                        let allSelectedValue = this.selectedInputArray.map(val => val.Value);
                        if (allSelectedValue.indexOf(record[this.bindValue]) === -1) {
                            selectedInput.push({
                                Label: record[this.bindLabel],
                                Value: record[this.bindValue]
                            })
                        }
                        this.selectedInputArray = Array.from(new Set([...this.selectedInputArray, ...selectedInput]));
                    } else {
                        this.removeRestriction(record[this.bindValue]);
                        record['checked'] = false;
                    }
                })
            }
        }
        this.filteredData = JSON.parse(JSON.stringify(this.list));
    }

    private removeRestriction(record: any) {
        let mappedSelectedInput = this.selectedInputArray.map(doc => doc.Value);
        const index = mappedSelectedInput.indexOf(record);
        if (index >= 0) {
            this.selectedInputArray.splice(index, 1);
        }
    }

    getSelectedValue(status: Boolean, value: String) {
        if (status) {
            if (this.checkedList.indexOf(value) == -1) {
                this.checkedList.push(value);
            }
        } else {
            var index = this.checkedList.indexOf(value);
            this.checkedList.splice(index, 1);
        }
        this.mappSelectedInput();
    }

    removeSelectedInput(input) {
        const index = this.checkedList.indexOf(input);
        const _index = this.list.findIndex(record => record[this.bindValue] === input);
        if (this.multiSelectorType === 'dropdown') {
            this.list[_index].checked = false;
        } else {
            this.removeRestriction(input);
        }
        this.checkedList.splice(index, 1);
        this.mappSelectedInput();
        this.inputvalue = '';
    }

    handleInputChange(event) {
        if (this.multiSelectorType === 'dropdown') {
            this.filteredData = this.list.filter(record => {
                return record[this.bindLabel].toLowerCase().includes(event.toLowerCase());
            });
        } else {
            this.fetchAutoCompleteApi.emit(event);
        }
    }

    mouseLeave() {
        this.showDropDown = false;
        this.shareCheckedList.emit(this.checkedList);
    }
}