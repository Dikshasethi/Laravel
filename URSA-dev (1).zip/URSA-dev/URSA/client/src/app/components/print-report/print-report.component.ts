import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-print-report',
  templateUrl: './print-report.component.html',
  styleUrls: ['./print-report.component.css']
})
export class PrintReportComponent implements OnInit {
  constructor() { }
  @Input() printData;
  ngOnInit() {
  }

  printEmoReport() {
    let printEmoContent = "";
    let previewWindow;
    printEmoContent = document.getElementById('emoReport').innerHTML;
    previewWindow = window.open('', '_blank', 'top=0,left=0,height=auto,width=auto');
    previewWindow.document.open();
    setTimeout(function () {
      previewWindow.document.write(`
        <html>
          <head>
            <title>EMO Print Report</title>
            <style>
            body {
              font-family: Arial, Helvetica, sans-serif;
              font-size: 12px;
              color: #000;
            }
            table tr td {
              color: #000;
              font-weight: bold;
              padding: 2px;
              border-bottom:0px;
              border-right:0px;
            }
            table tr .tdContent td{
              font-weight: normal;
            }
            #table-2 tr td {
              color: #000;
              padding: 5px;
            }
              .border-top0{border-top:0px;}
              .border-btm0{border-bottom:0px;}
            </style>
          </head>
          <body onload='window.print()'>${printEmoContent}</body>
        </html>`);
      previewWindow.document.close();
    }, 3000);

  }

}
