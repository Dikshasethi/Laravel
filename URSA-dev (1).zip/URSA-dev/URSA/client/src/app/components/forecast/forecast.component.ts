import { Component, OnInit, ViewChild, Input, SimpleChange } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../models/appState';
import { Router } from '@angular/router';
import { detailsRefinedBy } from '../../utils/refinedBy/refinedByConstants';
import * as _ from 'lodash';
import { productRefinedByList } from '../../utils/product/refinedByList';
import * as moment from 'moment';
import { Chart } from 'chart.js';
import { combineLatest } from 'rxjs/operators';
import {  Subscription } from 'rxjs';
import localDate from '../../utils/date/localDate';
import {
  GetHardReservationChart,
  Getonhiremetrics, GetSoftReservationChart, GetCheckoutmetrics, ResetChartCounts
} from '../../actions/dashbord.action';
import { DaterangepickerConfig, DaterangePickerComponent } from 'ng2-daterangepicker';
import * as Highcharts from 'highcharts';

@Component({
  selector: 'app-forecast',
  templateUrl: './forecast.component.html'
})
export class ForecastComponent implements OnInit {
  @Input() queryChangeIndicator;
  refinedByNgrxKey = detailsRefinedBy;
  refinedBySubscription: Subscription;
  dashboardSubScription: Subscription;
  checkoutSubscription: Subscription;
  onhireSubscription: Subscription;
  softReservationSubscription: Subscription;
  hardReservationSubscription: Subscription;
  refinedByList = productRefinedByList || [];
  detailsRefinedByObj = {};
  totalAssetCount: number = 0;
  checkedOutAssetsCount: number = 0;
  pastDueCount: number = 0;
  hardReservedAssetsCount: number = 0;
  SoftReservedAssetsCount: number = 0;
  @ViewChild('utilizationCanvas') utilizationCanvas;
  @ViewChild('softReservationCanvas') softReservationCanvas;
  @ViewChild('hardReservationCanvas') hardReservationCanvas;
  @ViewChild('utilization', { read: DaterangePickerComponent })
  utilizationDateRange: DaterangePickerComponent;
  @ViewChild('softReservation', { read: DaterangePickerComponent })
  softReservationDateRange: DaterangePickerComponent;
  @ViewChild('hardReservation', { read: DaterangePickerComponent })
  hardReservationDateRange: DaterangePickerComponent;
  @ViewChild('shippedReceived', { read: DaterangePickerComponent })
  shippedReceivedDateRange: DaterangePickerComponent;
  utilizationChart:Chart;
  softReservationChart: Highcharts.Chart;
  hardReservationChart: Highcharts.Chart;
  shippedReceivedChart:Chart;
  chartOptions: any = {
    responsive: true,
    elements: {
      point: {
        radius: 0,
      }
    }
  };
  displayFormat: any = {
    'week': 'DD MMM YYYY',
    'day': 'DD MMM',
    'quarter': 'MMM YYYY',
    'month': 'DD MMM YYYY',
  };
  chartProperty: any = {
    lineTension: 0.1,
    pointBorderColor: 'rgba(75,192,192,1)',
    pointBorderWidth: 1,
    pointHoverRadius: 5,
    pointHoverBackgroundColor: 'rgba(75,192,192,1)',
    pointHoverBorderColor: 'rgba(220,220,220,1)',
    pointHoverBorderWidth: 2,
    pointRadius: 5,
    pointHitRadius: 10,
    borderCapStyle: 'butt',
    borderDashOffset: 0.0,
    borderJoinStyle: 'miter',
    spanGaps: false,
  };

  daterange: any = {
    startDate: moment().format('YYYY-MM-DD'),
    endDate : moment().add(1, 'months').format('YYYY-MM-DD')
  };

  options: any = {
    locale: localDate(moment(), { format: 'YYYY-MM-DD' }),
    alwaysShowCalendars: false,
    maxDate: localDate(this.daterange['endDate'], { format: 'YYYY-MM-DD' })
  };
  mappPayload: any = {
    "buList": "businessunit",
    "subtype": "subtype2"
  }

  onhireutilizationChartData:any[];
  checkoututilizationChartData:any[];
  softReservationChartData: any[];
  hardReservationChartData: any[];
  shippedReceivedChartData: any[];
  shippedReceivedChartLoading: boolean = false;
  hardReservationChartLoading: boolean = false;
  softReservationChartLoading: boolean = false;
  onhireutilizationChartLoading: boolean = false;
  checkoututilizationChartLoading: boolean = false;
  selectedUtilizarionDateRange: string = 'month';
  selectedSoftReservationDateRange: string = 'month';
  selectedHardReservationDateRange: string = 'month';
  selectedShippedReceivedDateRange: string = 'month';
  constructor(
    private store: Store<AppState>,
    private router: Router,
    private daterangepickerOptions: DaterangepickerConfig
  ) {
    this.daterangepickerOptions.settings = {
      locale: { format: 'YYYY-MM-DD' },
      alwaysShowCalendars: false
    };
  }

  ngOnInit() {




      this.onhireSubscription = this.store.pipe(select(state => state.Dashboard.onhireutilizationChart))
      .subscribe(data => {
        if (data) {
          const { onhireutilizationChartData, onhireutilizationChartLoading } = data;
          this.onhireutilizationChartData = onhireutilizationChartData;
          this.onhireutilizationChartLoading = onhireutilizationChartLoading;
        }
      });


      this.checkoutSubscription = this.store.pipe(select(state => state.Dashboard.checkoututilizationChart))
      .subscribe(data => {
        if (data) {
          const { checkoututilizationChartData, checkoututilizationChartLoading } = data;
          this.checkoututilizationChartData = checkoututilizationChartData;
          this.checkoututilizationChartLoading = checkoututilizationChartLoading;
          if (!this.checkoututilizationChartLoading && !this.onhireutilizationChartLoading) {
            this.utilizationGraph();
          }
        }
      });

    this.softReservationSubscription = this.store.pipe(select(state => state.Dashboard.softReservationChart))
      .subscribe(data => {
        if (data) {
          const { softReservationChartData, softReservationChartLoading } = data;
          this.softReservationChartData = softReservationChartData;
          this.softReservationChartLoading = softReservationChartLoading;
          if (!softReservationChartLoading) {
            this.softReservationGraph();
          }
        }
      });

      this.hardReservationSubscription = this.store.pipe(select(state => state.Dashboard.hardReservationChart))
      .subscribe(data => {
        if (data) {
          const { hardReservationChartData, hardReservationChartLoading } = data;
          this.hardReservationChartData = hardReservationChartData;
          this.hardReservationChartLoading = hardReservationChartLoading;
          if (!hardReservationChartLoading) {
            this.hardReservationGraph();
          }
        }
      });


    this.dashboardSubScription = this.store.pipe(select(state => state.Dashboard))
      .subscribe(data => {
        if (data) {
          const {
            assetCount: { assetCountData },
            pastDueCount: { pastDueCountData },
            hardReservationCount: { hardReservationCountData },
            softReservationCount: { softReservationCountData },
            checkoutCount: { checkoutCountData }
          } = data;
          this.totalAssetCount = assetCountData;
          this.pastDueCount = pastDueCountData;
          this.checkedOutAssetsCount = checkoutCountData;
          this.hardReservedAssetsCount = hardReservationCountData;
          this.SoftReservedAssetsCount = softReservationCountData;
        }
      });

    this.refinedBySubscription = this.store.pipe(select(state => state.RefinedBy))
      .subscribe(refinedByObj => {
        const {
          detailsRefinedBy = {}
        } = refinedByObj;
        this.detailsRefinedByObj = Object.assign({}, detailsRefinedBy);
      })
  }

  ngOnDestroy() {
    this.onhireSubscription.unsubscribe();
    this.checkoutSubscription.unsubscribe();
    this.softReservationSubscription.unsubscribe();
    this.dashboardSubScription.unsubscribe();
    this.hardReservationSubscription.unsubscribe();
    this.refinedBySubscription.unsubscribe();
    this.store.dispatch(new ResetChartCounts({}));
  }

  ngOnChanges(changes: SimpleChange){
    let changeIndicator = changes['queryChangeIndicator'];
    if(changeIndicator){
      if(
        !_.isEqual(changeIndicator.currentValue, changeIndicator.previousValue)
      ){
        this.resetAllCharts();
      }
    }
  }

  ngAfterViewInit() {
    const { startDate, endDate } = this.daterange;
    this.setUtilizationDateRange(startDate, endDate);
    this.setSoftReservationDateRange(startDate, endDate);
    this.setHardReservationDateRange(startDate, endDate);
  }

  setUtilizationDateRange(startDate, endDate) {
    this.utilizationDateRange.datePicker.setStartDate(localDate(startDate, 'YYYY-MM-DD'));
    this.utilizationDateRange.datePicker.setEndDate(localDate(endDate, 'YYYY-MM-DD'));

  }

  setSoftReservationDateRange(startDate, endDate) {
    this.softReservationDateRange.datePicker.setStartDate(localDate(startDate, 'YYYY-MM-DD'));
    this.softReservationDateRange.datePicker.setEndDate(localDate(endDate, 'YYYY-MM-DD'));
  }

  setHardReservationDateRange(startDate, endDate) {
    this.hardReservationDateRange.datePicker.setStartDate(localDate(startDate, 'YYYY-MM-DD'));
    this.hardReservationDateRange.datePicker.setEndDate(localDate(endDate, 'YYYY-MM-DD'));
  }

  getActiveTabClass(chart, state) {
    if (chart === 'utilization') {
      return state === this.selectedUtilizarionDateRange ? 'chartActiveTab' : 'chartInactiveTabs'
    } else if (chart === 'softReservation') {
      return state === this.selectedSoftReservationDateRange ? 'chartActiveTab' : 'chartInactiveTabs'
    } else if (chart === 'hardReservation') {
      return state === this.selectedHardReservationDateRange ? 'chartActiveTab' : 'chartInactiveTabs'
    } else if (chart === 'shippedReceived') {
      return state === this.selectedShippedReceivedDateRange ? 'chartActiveTab' : 'chartInactiveTabs'
    } else {
      return 'chartInactiveTabs';
    }
  }

  resetAllCharts = () => {
    if(this.utilizationChart){
      this.utilizationChart.destroy();
    }
    if(this.softReservationChart){
      this.softReservationChart.destroy();
    }
  }

  utilizationGraph() {
    let checkedoutArray = [];
    let onHireArray = [];
   let tickInterval;
    for (let i = 0; i < this.checkoututilizationChartData.length; i++) {
      let { checkedout, datestamp } = this.checkoututilizationChartData[i];
      let tempcheckedarr={};
      tempcheckedarr['x']=datestamp
      tempcheckedarr['y']=checkedout;
      checkedoutArray.push(tempcheckedarr);
    }

    for (let i = 0; i < this.onhireutilizationChartData.length; i++) {
      let { onhire, datestamp } = this.onhireutilizationChartData[i];
      let temponhirearr={};
      temponhirearr['x']=datestamp;
      temponhirearr['y']=onhire;
      onHireArray.push(temponhirearr);
    }

    if(this.selectedUtilizarionDateRange === 'month') {
      tickInterval= 24 * 3600 * 1000 
    }
    else if(this.selectedUtilizarionDateRange === 'quarter'){
      tickInterval=3* 24 * 3600 * 1000;
    } 
    else if(this.selectedUtilizarionDateRange === 'halfYear'){
      tickInterval=6 * 24 * 3600 * 1000;
    }

    this.utilizationChart = Highcharts.chart('utilizationChartcontainer', {
      title: {
        text: ""
      },
      xAxis: {
        title: {
          text: 'Date'
        },
        tickInterval: parseInt(tickInterval),
        minPadding: 0,
        maxPadding: 0,
        startOnTick: true,
        endOnTick:true,
        type:'datetime',
        gridLineWidth: 0,
        dateTimeLabelFormats: {
          day: '%e %b',
          month: '%b %y'
        },
       },
       yAxis: {
        title: {
          text: "Utilization %"
        },
        max: 100,
        tickInterval:10,
        tickWidth:1,
        lineWidth:1,
        gridLineWidth: 0
      },
      tooltip: {
        formatter: function() {
          return  '<b>' + this.series.name +':</b>' + this.y + ' <br/>'+
             Highcharts.dateFormat('%e %b %Y', this.x);    
          }
      },
      credits: {
        enabled: false
      },
      plotOptions: {
        series: {
            marker: {
                enabled: true
            }
        }
     },
      series: [{
         data: checkedoutArray,
        type: 'line',
        color: 'rgb(23, 118, 182)',
        name: 'Checkout',
        lineWidth:3
      },
      {
        data: onHireArray,
        type: 'line',
        color: 'rgb(144, 237, 125)',
        name: 'OnHire',
        lineWidth:3
      }]
      }, null);
  }

  utilizationGraphChart(unit) {
    this.selectedUtilizarionDateRange = unit;
    let enddate = '';
    let forecast=true;
    let startdate = moment().format('YYYY-MM-DD');
    let filterObj = this.getFilter();
    if (unit === 'week') {
      enddate = moment().add(7, 'day').format('YYYY-MM-DD');
      this.utilizationAction({ startdate, enddate, filter: filterObj, forecast})
    } else if (unit === 'month') {
      enddate = moment().add(1, 'months').format('YYYY-MM-DD');
      this.utilizationAction({ startdate, enddate, filter: filterObj, forecast })
    } else if (unit === 'quarter') {
      enddate = moment().add(3, 'months').format('YYYY-MM-DD');
      this.utilizationAction({ startdate, enddate, filter: filterObj, forecast })
    } else if (unit === 'halfYear') {
      enddate = moment().add(6, 'months').format('YYYY-MM-DD');
      this.utilizationAction({ startdate, enddate, filter: filterObj, forecast })
    }
    this.setUtilizationDateRange(startdate, enddate);
  }

  utilizationAction(query) {
    this.utilizationChart.destroy();
    this.store.dispatch(new Getonhiremetrics(query));
    this.store.dispatch(new GetCheckoutmetrics(query));
  }

  softReservationGraph() {
    let countArray = [];
    let tickInterval
    for (let i = 0; i < this.softReservationChartData.length; i++) {
      let { quantity, datestamp } = this.softReservationChartData[i];
      let tempcountArray={};
      tempcountArray['x']=datestamp;
      tempcountArray['y']=quantity;
      countArray.push(tempcountArray);
    }

    if(this.selectedSoftReservationDateRange === 'month') {
      tickInterval= 24 * 3600 * 1000 
    }
    else if(this.selectedSoftReservationDateRange === 'quarter'){
      tickInterval=3* 24 * 3600 * 1000;
    } 
    else if(this.selectedSoftReservationDateRange === 'halfYear'){
      tickInterval=6 * 24 * 3600 * 1000;
    }
    this.softReservationChart = Highcharts.chart('softReservationcontainer', {
      chart: {
        type: 'spline',
        animation: false    
      },
      title: {
        text: ""
      },
      xAxis: {
        title: {
          text: 'Date'
        },
        tickInterval: parseInt(tickInterval),
        minPadding: 0,
        maxPadding: 0,
        startOnTick: true,
        endOnTick:true,
        type:'datetime',
        gridLineWidth: 0
      },
      yAxis: {
        title: {
          text: "Soft Reservation Count"
        },
        max: 100,
        min:0,
        tickInterval:10,
        tickWidth:1,
        lineWidth:1,
        gridLineWidth: 0
      },
      tooltip: {
        formatter: function() {
          return  '<b>' + this.series.name +':</b>' + this.y + ' <br/>'+
             Highcharts.dateFormat('%e %b %Y', this.x);
          }
      },
      credits: {
        enabled: false
      },
      series: [{
        data: countArray,
        type: 'spline',
        color: 'rgb(23, 118, 182)',
        name: 'Soft Reservation',
        lineWidth:3
      }]
      }, null);

  }

  softReservationGraphChart(unit) {
    this.selectedSoftReservationDateRange = unit;
    let enddate = '';
    let startdate = moment().format('YYYY-MM-DD');
    let filterObj = this.getFilter();
    if (unit === 'week') {
      enddate = moment().add(7, 'day').format('YYYY-MM-DD');
      this.softReservationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'month') {
      enddate = moment().add(1, 'months').format('YYYY-MM-DD');
      this.softReservationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'quarter') {
      enddate = moment().add(3, 'months').format('YYYY-MM-DD');
      this.softReservationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'halfYear') {
      enddate = moment().add(6, 'months').format('YYYY-MM-DD');
      this.softReservationAction({ startdate, enddate, filter: filterObj })
    }
    this.setSoftReservationDateRange(startdate, enddate);
  }

  softReservationAction(query) {
    this.softReservationChart.destroy();
    this.store.dispatch(new GetSoftReservationChart(query));
  }

  getFilter() {
    let filter = this.detailsRefinedByObj['clickTracker'] || {};
    let filterObj = {};
    for (let key in filter) {
      if (this.mappPayload.hasOwnProperty(key)) {
        filterObj[this.mappPayload[key]] = filter[key]
      } else {
        filterObj[key] = filter[key]
      }
    }
    return filterObj
  }

  getChartQuery(e) {
    let startdate = moment(e.picker.startDate).format('YYYY-MM-DD');
    let enddate = moment(e.picker.endDate).format('YYYY-MM-DD');
    let filterObj = this.getFilter();
    return { startdate, enddate, filter: filterObj }
  }

  onUtilizationDateChange(e: any) {
    this.selectedUtilizarionDateRange = '';
    let query = this.getChartQuery(e);
    this.utilizationAction(query);
  }

  onSoftReservationDateChange(e: any) {
    this.selectedSoftReservationDateRange = '';
    let query = this.getChartQuery(e);
    this.softReservationAction(query);
  }

  hardReservationGraph() {
    let hardReservationArray = [];
    let tickInterval;
    for (let i = 0; i < this.hardReservationChartData.length; i++) {
      let { hardreserved, datestamp } = this.hardReservationChartData[i];
      let temphardResArray={};
      temphardResArray['x']=datestamp;
      temphardResArray['y']=hardreserved;
      hardReservationArray.push(temphardResArray);
  
    }
   
    if(this.selectedSoftReservationDateRange === 'month') {
      tickInterval= 24 * 3600 * 1000 
    }
    else if(this.selectedSoftReservationDateRange === 'quarter'){
      tickInterval=3* 24 * 3600 * 1000;
    } 
    else if(this.selectedSoftReservationDateRange === 'halfYear'){
      tickInterval=6 * 24 * 3600 * 1000;
    }
    this.hardReservationChart = Highcharts.chart('hardReservationcontainer', {
      chart: {
        type: 'spline',
        animation: false    
      },
      title: {
        text: ""
      },
      xAxis: {
        title: {
          text: 'Date'
        },
        tickInterval: parseInt(tickInterval),
        minPadding: 0,
        maxPadding: 0,
        startOnTick: true,
        endOnTick:true,
        type:'datetime',
        gridLineWidth: 0
      },
      yAxis: {
        title: {
          text: "Hard Reservation %"
        },
        max: 100,
        min:0,
        tickInterval:10,
        tickWidth:1,
        lineWidth:1,
        gridLineWidth: 0
      },
      tooltip: {
        formatter: function() {
          return  '<b>' + this.series.name +':</b>' + this.y + ' <br/>'+
             Highcharts.dateFormat('%e %b %Y', this.x);
          }
      },
      credits: {
        enabled: false
      },
      series: [{
        data: hardReservationArray,
        type: 'spline',
        color: 'rgb(23, 118, 182)',
        name: 'Hard Reservation',
        lineWidth:3
      }]
      }, null);
  }

  hardReservationGraphChart(unit) {
    this.selectedHardReservationDateRange = unit;
    let enddate = '';
    let startdate = moment().format('YYYY-MM-DD');
    let filterObj = this.getFilter();
    if (unit === 'week') {
      enddate = moment().add(7, 'day').format('YYYY-MM-DD');
      this.hardReservationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'month') {
      enddate = moment().add(1, 'months').format('YYYY-MM-DD');
      this.hardReservationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'quarter') {
      enddate = moment().add(3, 'months').format('YYYY-MM-DD');
      this.hardReservationAction({ startdate, enddate, filter: filterObj })
    } else if (unit === 'halfYear') {
      enddate = moment().add(6, 'months').format('YYYY-MM-DD');
      this.hardReservationAction({ startdate, enddate, filter: filterObj })
    }
    this.setHardReservationDateRange(startdate, enddate);
  }

  hardReservationAction(query) {
    this.hardReservationChart.destroy();
    this.store.dispatch(new GetHardReservationChart(query));
  }

  onhardReservationDateChange(e: any) {
   // function was used in html but never initialised
   // causing build issue 
   // to be implemented
  }
}